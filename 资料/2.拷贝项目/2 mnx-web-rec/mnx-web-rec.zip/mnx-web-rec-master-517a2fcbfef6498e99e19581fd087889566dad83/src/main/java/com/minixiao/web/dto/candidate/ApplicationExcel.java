package com.minixiao.web.dto.candidate;

/**
 * @Author wangyj.
 * @Date 2017/3/3  10:13.
 */
public class ApplicationExcel {

    private  String id;

    private  String name;

    private String gender;

    private String jobName;

    private String department;

    private String degree;

    private String school;

    private String major;

    private String handleStaus;

    private String tags;

    public ApplicationExcel() {
    }


    public ApplicationExcel(String id, String name, String gender, String jobName, String department, String degree, String school, String major, String handleStaus, String tags) {
        this.id = id;
        this.name = name;
        this.gender = gender;
        this.jobName = jobName;
        this.department = department;
        this.degree = degree;
        this.school = school;
        this.major = major;
        this.handleStaus = handleStaus;
        this.tags = tags;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getJobName() {
        return jobName;
    }

    public void setJobName(String jobName) {
        this.jobName = jobName;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getDegree() {
        return degree;
    }

    public void setDegree(String degree) {
        this.degree = degree;
    }

    public String getSchool() {
        return school;
    }

    public void setSchool(String school) {
        this.school = school;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public String getHandleStaus() {
        return handleStaus;
    }

    public void setHandleStaus(String handleStaus) {
        this.handleStaus = handleStaus;
    }

    public String getTags() {
        return tags;
    }

    public void setTags(String tags) {
        this.tags = tags;
    }
}
