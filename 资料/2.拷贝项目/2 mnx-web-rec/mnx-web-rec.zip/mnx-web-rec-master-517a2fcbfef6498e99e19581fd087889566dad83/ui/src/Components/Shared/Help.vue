<template>
<div>
    <div class="help-head">
        <h1>帮助中心test</h1>
    </div>
    <div class="help-body">
        <!-- 标签页 -->
        <table>
            <tr>
                <td @click="seenA" :class=" {'hand-mouse':!seen}">
                    <h2 :class=" {seen:seen,line:seen}">  &nbsp;常见问题&nbsp;</h2>
                </td>
                <td @click="seenB" :class="{ 'hand-mouse':seen}">
                    <h2 :class=" {seen: !seen,line:!seen}"> &nbsp;使用手册&nbsp;</h2>
                </td>
            </tr>
        </table>

        <div class = "fengexian"></div>


        <!-- 常见问题块 -->
        <div v-if="seen" class="hand-mouse">
            <!-- 问题1 -->
            <div class="question-item" @click = "openIt('question1')">
                <!-- 问题 -->
                <div class="question">
                    <div class="questiontxt">
                        <p >【企业注册】如何注册企业账户？注册后如何发布职位？
                            <i :class="openQuestion1? 'dakai':'guanbi'"></i>
                        </p>
                    </div>
                </div>
                <!-- 答案 -->
                <div class="answer" v-if="openQuestion1">
                    <div class = "answertxt">
                        <p>1.&nbsp;进入网站，点击“企业入口”，申请开通企业账户，您的申请信息会发送到我们固定的销售邮箱中，待与您沟通后会帮助您完成账户注册。
                        </p>
                        <p>2.&nbsp;账户注册完成后，您会收到账户和密码信息的邮件，根据邮件提醒，登录后完善企业信息即可发布职位。
                        </p>
                    </div>
                </div>
            </div>
            <!-- 问题2 -->
            <div class="question-item" @click = "openIt('question2')">
                <!-- 问题 -->
                <div class="question">
                    <div class="questiontxt">
                        <p >【忘记密码】忘记了登录账户怎么办？
                            <i :class="openQuestion2? 'dakai':'guanbi'"></i>
                        </p>
                    </div>
                </div>
                <!-- 答案 -->
                <div class="answer" v-if="openQuestion2">
                    <div class = "answertxt">
                        <p>请用接收简历的企业邮箱发邮件至 advise@minixiao.com ，写明公司全称、接收简历的企业邮箱，我们会帮您查找。
                        </p>
                    </div>
                </div>
            </div>

            <!-- 问题3 -->
            <div class="question-item" @click = "openIt('question3')">
                <!-- 问题 -->
                <div class="question">
                    <div class="questiontxt">
                        <p >【公司信息】如何修改公司的信息？
                            <i :class="openQuestion3? 'dakai':'guanbi'"></i>
                        </p>
                    </div>
                </div>
                <!-- 答案 -->
                <div class="answer" v-if="openQuestion3">
                    <div class = "answertxt">
                         <p>点击 系统管理，进入 公司管理 即可完成公司信息修改。</p>
                    </div>
                </div>
            </div>

            <!-- 问题4 -->
            <div class="question-item" @click = "openIt('question4')">
                <!-- 问题 -->
                <div class="question">
                    <div class="questiontxt">
                        <p >【职位发布】我发布的职位下线了怎么办？<i :class="openQuestion4? 'dakai':'guanbi'"></i></p>
                    </div>
                </div>
                <!-- 答案 -->
                <div class="answer" v-if="openQuestion4">
                    <div class = "answertxt">
                       <p>打开对应职位，重新编辑有效期，重新发布就好了。</p>
                    </div>
                </div>
            </div>

            <!-- 问题5 -->
            <div class="question-item" @click = "openIt('question5')">
                <!-- 问题 -->
                <div class="question">
                    <div class="questiontxt">
                        <p >【职位发布】我想发布的职位，没有相应的职位类别可选，怎么办？
                            <i :class="openQuestion5? 'dakai':'guanbi'"></i>
                        </p>
                    </div>
                </div>
                <!-- 答案 -->
                <div class="answer" v-if="openQuestion5">
                    <div class = "answertxt">
                       <p>1.&nbsp;查看有无相近的职位类别可选，选择相似的类别。</p>
                        <p>2.&nbsp;或者将你要发布的职位名岗位职责以邮件的方式发送至 advise@minixiao.com，我们将进行评估，以完善我们的职位类别选项。
                        </p>
                    </div>
                </div>
            </div>
            <!-- 问题6 -->
            <div class="question-item" @click = "openIt('question6')">
                <!-- 问题 -->
                <div class="question">
                    <div class="questiontxt">
                        <p >【用户管理】添加用户有什么好处？怎么使用？
                            <i :class="openQuestion6 ? 'dakai':'guanbi'"></i>
                        </p>
                    </div>
                </div>
                <!-- 答案 -->
                <div class="answer" v-if="openQuestion6">
                    <div class = "answertxt">
                        <p>1.&nbsp;添加多用户，为用户分配角色，可以让同事帮你筛选学生的简历，提高工作效率。
                        </p>
                        <p>2.&nbsp;添加用户后，可以直接用添加的账号进行登录。</p>
                    </div>
                </div>
            </div>

            <!-- 问题7 -->
            <div class="question-item" @click = "openIt('question7')">
                <!-- 问题 -->
                <div class="question">
                    <div class="questiontxt">
                        <p >【微信推广】如何借助微信推广自己的职位与企业？
                            <i :class="openQuestion7? 'dakai':'guanbi'"></i>
                        </p>
                    </div>
                </div>
                <!-- 答案 -->
                <div class="answer" v-if="openQuestion7">
                    <div class = "answertxt">
                       <p>可以打开职位展示页面扫微信二维码，借助微信分享的功能，完成企业与职位的推广，具体详见使用手册（职位管理）
                       </p>
                    </div>
                </div>
            </div>

            <!-- 问题8 -->
            <div class="question-item" @click = "openIt('question9')">
                <!-- 问题 -->
                <div class="question">
                    <div class="questiontxt">
                        <p >【简历管理】打标签有什么好处？用途是什么？
                            <i :class="openQuestion9? 'dakai':'guanbi'"></i>
                        </p>
                    </div>
                </div>
                <!-- 答案 -->
                <div class="answer" v-if="openQuestion9">
                    <div class = "answertxt">
                        <p>打标签后可以通过筛选标签，快速查询到符合需求的学生简历</p>
                    </div>
                </div>
            </div>
        </div>

         <!-- 使用手册 -->
        <div v-if="!seen" class="hand-mouse">
            <!-- 帮助1 -->
            <div class="question-item" @click = "openIt('manual1')">
                <!-- 问题 -->
                <div class="question">
                    <div class="questiontxt">
                        <p >开通企业账户及登录
                            <i :class="openManual1? 'dakai':'guanbi'"></i>
                        </p>
                    </div>
                </div>
                <!-- 方法 -->
                <div class="answer" v-if="openManual1">
                    <div class = "answertxt">
                        <p>官网网址：
                            <a href="http://www.minixiao.com/" target="_blank">http://www.minixiao.com/</a>
                        </p>
                        <p>开通企业账户网址：
                            <a href="http://passport.minixiao.com/corp/register/" target="_blank">http://passport.minixiao.com/corp/register/</a>
                        </p>
                        <p>点击企业入口，进入企业账户申请页面</p>
                        <p><img src="../../img/img01.png"></p>
                        <p><img src="../../img/img02.png"></p>
                        <p>（申请账户后我们会有专门的销售人员与您沟通，帮您完成注册。）</p>
                        <p>登录网址：<a href="http://passport.minixiao.com/corp/login/" target="_blank">http://passport.minixiao.com/corp/ login/</a>
                         </p>
                        <p>系统支持两种方式登录。</p>
                        <p>1. 密码登录；</p>
                        <p>2. 验证码登录；</p>
                        <p><img src="../../img/img03.png"></p>
                        <p>（销售人员帮您注册后，会有邮件发送至您的常用邮箱，请注意查收，获取登录账户及登录密码）</p>
                    </div>
                </div>
            </div>

             <!-- 帮助2 -->
            <div class="question-item" @click = "openIt('manual2')">
                <!-- 问题 -->
                <div class="question">
                    <div class="questiontxt">
                        <p >简历管理 <i :class="openManual2? 'dakai':'guanbi'"></i></p>
                    </div>
                </div>
                <!-- 方法 -->
                <div class="answer" v-if="openManual2">
                    <div class = "answertxt">
                        <p>查看投递的简历信息，进入简历管理页面，对收到的简历进行维护操作。
                        </p>
                        <p>系统提供默认的简历管理是适用于一般企业的，如果默认的简历管理不符合企业需求，企业可以定制自己的页面。</p>
                        <p><h4>1)简历操作可制定项：</h4></p>
                        <p>1. 筛选流程，默认的有全部、初筛、笔试、面试、录用。如果企业认为流程不够，可以定制自己的流程。</p>
                        <p>2. 筛选条件，默认的有学生标签、学历要求、应聘职位、毕业院校、实习经历等。</p>
                        <p>3. 筛选器设置，新增筛选器后，搜索学生简历时可直接选择筛选器进行搜索。</p>
                        <p>4. 笔面试模板设置，安排学生参加笔试/面试的场地，考试时间，主考官等设置。</p>
                        <p>5. 消息模板设置，给学生发消息时可选择的模板。</p>
                        <p>（注：笔面试模板和消息模板设置一定要先设置完成，才可以对学生简历做安排笔面试和发消息操作）</p>
                        <p>筛选流程设置页面：</p>
                        <p><img src="../../img/img04.png"></p>
                        <p>筛选条件设置页面：</p>
                        <p><img src="../../img/img05.png"></p>
                        <p>筛选器设置页面：</p>
                        <p><img src="../../img/img06.png"></p>
                        <p>笔面试模板设置页面：</p>
                        <p><img src="../../img/img07.png"></p>
                        <p>消息模板设置页面：</p>
                        <p><img src="../../img/img08.png"></p>
                        <p>至此，可制定项都已完成，可以去操作学生简历了。</p>
                        <p><h4>2)学生简历处理</h4></p>
                        <p>处理学生简历，可对简历做通过/不通过、待定、打标签、安排笔/面试、阶段跳转、录用等操作。</p>
                        <p><img src="../../img/img09.png"></p>
                        <p><img src="../../img/img10.png"></p>
                        <p>安排笔试页面：</p>
                        <p><img src="../../img/img11.png"></p>
                        <p>打标签页面：</p>
                        <p><img src="../../img/img12.png"></p>
                    </div>
                </div>
            </div>
             <!-- 帮助3 -->
            <div class="question-item" @click = "openIt('manual3')">
                <!-- 问题 -->
                <div class="question">
                    <div class="questiontxt">
                        <p >职位管理 <i :class="openManual3? 'dakai':'guanbi'"></i></p>
                    </div>
                </div>
                <!-- 方法 -->
                <div class="answer" v-if="openManual3">
                    <div class = "answertxt">
                        <p>发布职位，为企业招聘人才，进入职位管理页面，对职位信息进行维护操作。</p>
                        <p>职位管理页面主要功能：新职位发布、职位编辑、职位下线、职位删除、职位刷新。（注：点击应聘简历，可以直接查看到投递该职位的学生简历。）</p>
                        <p><img src="../../img/img13.png"></p>
                        <p>以下是新职位发布页面：</p>
                        <p><img src="../../img/img14.png"></p>
                        <p>部门管理页面：</p>
                        <p><img src="../../img/img15.png"></p>
                    </div>
                </div>
            </div>

             <!-- 帮助4 -->
            <div class="question-item" @click = "openIt('manual4')">
                <!-- 问题 -->
                <div class="question">
                    <div class="questiontxt">
                        <p >用户和权限管理
                            <i :class="openManual4? 'dakai':'guanbi'"></i>
                        </p>
                    </div>
                </div>
                <!-- 方法 -->
                <div class="answer" v-if="openManual4">
                    <div class = "answertxt">
                        <p>企业可以创建多个用户，每个账号可以赋予不一样的权限，每种权限可以涉及到职位和功能相关，例如销售账户，只可操作销售的功能。可高效快速地完成校招工作。</p>
                        <p>权限管理页面，新增角色，分配权限：</p>
                        <p><img src="../../img/img16.png"></p>
                        <p>用户管理页面，新增用户，给用户分配权限：</p>
                        <p><img src="../../img/img17.png"></p>
                    </div>
                </div>
            </div>

             <!-- 帮助5 -->
            <div class="question-item" @click = "openIt('manual5')">
                <!-- 问题 -->
                <div class="question">
                    <div class="questiontxt">
                        <p >账号绑定及密码修改 <i :class="openManual5? 'dakai':'guanbi'"></i></p>
                    </div>
                </div>
                <!-- 方法 -->
                <div class="answer" v-if="openManual5">
                    <div class = "answertxt">
                        <p>进入账户管理页面，可以完成修改密码操作，也可以修改账户信息。</p>
                        <p><img src="../../img/img18.png"></p>
                    </div>
                </div>
            </div>


        </div>

    </div>

</div>
</template>

<script type="text/babel">

    export default {
        name: "help",
        data() {
            return {
              seen:true,
              lookAnswer:"",

            }
        },
        methods:{
           seenA:function() {
            this.seen=true;
           },
           seenB:function() {
            this.seen=false;
            //console.log(!this.seen);
           },
           openIt ( question ) {
            if (question === this.lookAnswer) {
                this.lookAnswer = "" ;

            }else {
                this.lookAnswer=question;

            }
           }

        },
        computed: {
            openQuestion1:function() {
                return this.lookAnswer=="question1";
            },
            openQuestion2:function() {
                return this.lookAnswer=="question2";
            },
            openQuestion3:function() {
                return this.lookAnswer=="question3";
            },
            openQuestion4:function() {
                return this.lookAnswer=="question4";
            },
            openQuestion5:function() {
                return this.lookAnswer=="question5";
            },
            openQuestion6:function() {
                return this.lookAnswer=="question6";
            },
            openQuestion7:function() {
                return this.lookAnswer=="question7";
            },
            openQuestion9:function() {
                return this.lookAnswer=="question9";
            },
            openManual1:function() {
                return this.lookAnswer=="manual1";
            },
             openManual2:function() {
                return this.lookAnswer=="manual2";
            },
             openManual3:function() {
                return this.lookAnswer=="manual3";
            },
             openManual4:function() {
                return this.lookAnswer=="manual4";
            },
             openManual5:function() {
                return this.lookAnswer=="manual5";
            },
        }
    }

</script>

<style  lang="less" scoped>
body {margin:0;}
.help-head {
    border: 1px solid transparent;
    width:100%;
    height:129px;
    margin: 0px;
    background:rgba(111, 146, 223, 1) url(../../img/help.gif) no-repeat center;
}
.help-head h1 {
    width: 900px;
    height: 129px;
    border: 1px solid transparent;
    font-weight: 700;
    /*text-align: center;*/
    /*margin: 40px 200px;*/
    line-height: 129px;
    color: #FFFFFF;
    font-size: 32px;
    margin: auto;
    // font-family: "微软雅黑"；

}
.help-body h2 {

    color: black;
    font-size: 24px;
    line-height: 80px;
    font-weight: 700;
    font-kerning: normal;
    white-space: nowrap;
    margin:0px;

}
.line {
    border-bottom: 3px solid yellow ;
}
.seen {
    color: blue;
}
.help-body {
    border: 1px solid transparent;
    width:1190px;
    margin: auto;

    color: #000099;
}
.question-item {

    border-bottom: 1px dashed #666666;
    font-size: 16px;
    padding:10px
}

.question {
     background: url(../../img/question.png) no-repeat 0px 0.75em;
     border: 1px solid transparent;
    }
.questiontxt {
      margin-left: 40px;
}
.answer {
    border: 1px solid transparent;
     background: url(../../img/answer.png) no-repeat 0px 0.75em;
    color: #666666;
    font-size: 14px;

}
.answertxt {
    margin-left: 40px;
}
.help-body img {
  width:100%;
  }
i {

    width: 16px;
    height: 16px;
    border: 1px solid transparent;

    display: inline-block;
    overflow: hidden;
}
.guanbi {
    background: url(../../img/qh-icon.png) no-repeat 0px -64px;
    width: 16px;
    height: 16px;
}
.dakai {
    background: url(../../img/qh-icon.png) no-repeat -16px -64px;
    width: 16px;
    height: 16px;
}
.fengexian {
    border: 1px solid #333333;
    margin: 0px;
    position:relative;
    top:-8px;
}
table {
    margin: 0px;
}
tr {
    margin: 0px;
    padding: 0px;
}
td {
    margin:0px;
}
.hand-mouse {
     cursor: pointer;
}
</style>


