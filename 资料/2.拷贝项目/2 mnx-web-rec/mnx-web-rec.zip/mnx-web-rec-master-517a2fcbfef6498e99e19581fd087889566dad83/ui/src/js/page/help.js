// initial file for passport
import Vue from 'vue';
import Help from '../../Components/Shared/Help.vue';
import ElementUI from 'element-ui';

// styles
import 'element-ui/lib/theme-default/index.css';

Vue.use(ElementUI);

new Vue({
    components: {
        Help
    }
}).$mount('#help');

