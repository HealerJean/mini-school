package cn.edu.dlut.career.recruiter.repository;

import cn.edu.dlut.career.recruiter.domain.ExhPlaceOrder;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 展位预约表 数据库操作
 * Created by HealerJean on 2017/3/27.
 */
@Repository
public interface ExHallOrderRepository extends CrudRepository<ExhPlaceOrder, String>{
    //查找全部信息
    List<ExhPlaceOrder> findAll();

    //根据id进行查找
    ExhPlaceOrder findById(String id);

    @Modifying
    @Query(value = "update ExhPlaceOrder set auditState = ?2 ,auditTime = ?3,auditPerson=?4 where id = ?1")
    int updateExhPlaceOrderAudit(String id, String auditState, LocalDateTime auditTime, String auditPerson);


}
