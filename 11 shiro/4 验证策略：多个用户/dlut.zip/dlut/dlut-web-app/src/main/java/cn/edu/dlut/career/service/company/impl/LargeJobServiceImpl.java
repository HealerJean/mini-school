package cn.edu.dlut.career.service.company.impl;


import cn.edu.dlut.career.domain.company.LargeJob;
import cn.edu.dlut.career.repository.company.LargeJobRepository;
import cn.edu.dlut.career.service.company.LargeJobService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * 大招预约职位 服务层
 * Created by HealerJean on 2017/3/24.
 */
@Service
@Transactional
public class LargeJobServiceImpl implements LargeJobService {

    @Autowired
    LargeJobRepository largeJobRepository;
    @Override
    public LargeJob saveLargeJob(LargeJob largeJob) {
        return largeJobRepository.save(largeJob);
    }
    @Override
    public LargeJob findById(String id) {
        return largeJobRepository.findById(id);
    }
    @Override
    public LargeJob updateLargeJob(LargeJob largeJob) {
        return largeJobRepository.save(largeJob);
    }

    @Override
    public String deleteLargeJob(String id) {
        try {
            largeJobRepository.delete(id);
            return "ok";
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    @Override
    public List<LargeJob> findAllLargeJob() {
        return largeJobRepository.findAll();
    }
}
