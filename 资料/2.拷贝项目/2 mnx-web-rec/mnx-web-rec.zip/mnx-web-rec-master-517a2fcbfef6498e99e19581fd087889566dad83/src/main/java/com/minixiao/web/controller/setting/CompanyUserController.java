package com.minixiao.web.controller.setting;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.minixiao.apiauth.client.HeaderUtil;
import com.minixiao.web.dto.recruiters.CompanyUserPwdDTO;
import com.minixiao.web.dto.recruiters.CompanyUserVO;
import com.minixiao.web.dto.recruiters.UserDTO;
import com.minixiao.web.utils.YmlConfig;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.util.UUID;

/**
 * 公司用户controller.
 * Created by xiachao on 2017/3/2.
 */
@RestController
public class CompanyUserController {
    private Logger logger = LoggerFactory.getLogger(CompanyUserController.class);

    @Autowired
    private YmlConfig ymlConfig;

    private RestTemplate restTemplate = new RestTemplate();

    private ObjectMapper objectMapper = new ObjectMapper();

    /**
     * @Description 查询该公司下的所有用户 .
     * @Author xiachao
     * @CreateTime 2017/3/3 10:32
     * @Param
     * @Return
     */
    @GetMapping("company/users")
    public String getAllUser() {
        Subject subject = SecurityUtils.getSubject();
        if (subject != null) {
            UserDTO user = (UserDTO) subject.getSession().getAttribute(
                ymlConfig.getSession_current_user());
            if (user != null) {
                UUID userId2 = user.getId();
                String userName = user.getRealName();
                UUID recId2 = user.getRecId();
                String recName = user.getRecName();
                HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                    recId2, recName);
                HttpEntity requestEntity = new HttpEntity(null, httpHeaders);
                ResponseEntity<String> responseEntity = restTemplate.exchange(
                    ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2 + "/users", HttpMethod.GET,
                    requestEntity, String.class);
                if (responseEntity.getStatusCodeValue() == 200) {
                    return responseEntity.getBody();
                }
            }
        }
        return null;
    }


    /**
     * @Description 查询某一个用户 用户管理用.
     * @Author xiachao
     * @CreateTime 2017/3/12 19:20
     * @Param
     * @Return
     */
    @GetMapping("company/users/{userId}")
    public String getUser(@PathVariable UUID userId) {
        if (userId != null) {
            Subject subject = SecurityUtils.getSubject();
            if (subject != null) {
                UserDTO user = (UserDTO) subject.getSession().getAttribute(
                    ymlConfig.getSession_current_user());
                if (user != null) {
                    UUID userId2 = user.getId();
                    String userName = user.getRealName();
                    UUID recId2 = user.getRecId();
                    String recName = user.getRecName();
                    HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                        recId2, recName);
                    HttpEntity requestEntity = new HttpEntity(null, httpHeaders);
                    ResponseEntity<String> responseEntity = restTemplate.exchange(
                        ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2 + "/users/" + userId, HttpMethod.GET,
                        requestEntity, String.class);
                    if (responseEntity.getStatusCodeValue() == 200) {
                        return responseEntity.getBody();
                    }
                }
            }
        }
        return null;
    }


    /**
     * @Description 查询某一个用户 账户管理.
     * @Author xiachao
     * @CreateTime 2017/3/12 19:20
     * @Param
     * @Return
     */
    @GetMapping("company/user")
    public String getUserInfo() {
        Subject subject = SecurityUtils.getSubject();
        if (subject != null) {
            UserDTO user = (UserDTO) subject.getSession().getAttribute(
                ymlConfig.getSession_current_user());
            if (user != null) {
                UUID userId2 = user.getId();
                String userName = user.getRealName();
                UUID recId2 = user.getRecId();
                String recName = user.getRecName();
                HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                    recId2, recName);
                HttpEntity requestEntity = new HttpEntity(null, httpHeaders);
                ResponseEntity<String> responseEntity = restTemplate.exchange(
                    ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2 + "/users/" + userId2, HttpMethod.GET,
                    requestEntity, String.class);
                if (responseEntity.getStatusCodeValue() == 200) {
                    return responseEntity.getBody();
                }
            }
        }
        return null;
    }


    /**
     * @Description 管理员创建普通用户.
     * @Author xiachao
     * @CreateTime 2017/3/2 16:48
     * @Param
     * @Return
     */
    @PostMapping("company/user")
    public String createRecruiterUser(@RequestBody CompanyUserVO companyUserVO) {
        if (companyUserVO != null) {
            Subject subject = SecurityUtils.getSubject();
            if (subject != null) {
                UserDTO user = (UserDTO) subject.getSession().getAttribute(
                    ymlConfig.getSession_current_user());
                if (user != null) {
                    UUID userId2 = user.getId();
                    String userName = user.getRealName();
                    UUID recId2 = user.getRecId();
                    String recName = user.getRecName();
                    HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                        recId2, recName);
                    httpHeaders.setContentType(MediaType.APPLICATION_JSON_UTF8);
                    HttpEntity<CompanyUserVO> requestEntity = new HttpEntity<CompanyUserVO>(companyUserVO, httpHeaders);
                    ResponseEntity<String> responseEntity = restTemplate.exchange(
                        ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2 + "/user", HttpMethod.POST,
                        requestEntity, String.class);
                    if (responseEntity.getBody() != null) {
                        return responseEntity.getBody();
                    }
                }
            }
        }
        return null;
    }

    /**
     * @Description 修改用户信息.
     * @Author xiachao
     * @CreateTime 2017/3/2 17:23
     * @Param
     * @Return
     */
    @PutMapping("company/users/{id}")
    public String updateRecruiterUser(@RequestBody CompanyUserVO companyUserVO,
                                      @PathVariable UUID id) {
        if (companyUserVO != null && id != null) {
            Subject subject = SecurityUtils.getSubject();
            if (subject != null) {
                UserDTO user = (UserDTO) subject.getSession().getAttribute(
                    ymlConfig.getSession_current_user());
                if (user != null) {
                    UUID userId2 = user.getId();
                    String userName = user.getRealName();
                    UUID recId2 = user.getRecId();
                    String recName = user.getRecName();
                    HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                        recId2, recName);
                    httpHeaders.setContentType(MediaType.APPLICATION_JSON_UTF8);
                    HttpEntity<CompanyUserVO> requestEntity = new HttpEntity<CompanyUserVO>(companyUserVO, httpHeaders);
                    ResponseEntity<String> responseEntity = restTemplate.exchange(
                        ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2 + "/users/" + id, HttpMethod.PUT,
                        requestEntity, String.class);
                    if (responseEntity.getBody() != null) {
                        return responseEntity.getBody();
                    }
                }
            }
        }
        return null;
    }

    /**
     * @Description 管理员删除用户.
     * @Author xiachao
     * @CreateTime 2017/3/2 17:29
     * @Param
     * @Return
     */
    @DeleteMapping("company/users/{id}")
    public boolean deleteRecruiterUser(@PathVariable UUID id) {
        if (id != null) {
            Subject subject = SecurityUtils.getSubject();
            if (subject != null) {
                UserDTO user = (UserDTO) subject.getSession().getAttribute(
                    ymlConfig.getSession_current_user());
                if (user != null) {
                    UUID userId2 = user.getId();
                    String userName = user.getRealName();
                    UUID recId2 = user.getRecId();
                    String recName = user.getRecName();
                    HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                        recId2, recName);
                    HttpEntity requestEntity = new HttpEntity(null, httpHeaders);
                    ResponseEntity<String> responseEntity = restTemplate.exchange(
                        ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2 + "/users/" + id, HttpMethod.DELETE,
                        requestEntity, String.class);
                    if (responseEntity.getStatusCodeValue() == 200) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * @Description 用户修改个人信息.
     * @Author xiachao
     * @CreateTime 2017/3/2 17:39
     * @Param
     * @Return
     */
    @PutMapping("company/users/self")
    public String updateSelfInfo(@RequestBody CompanyUserVO companyUserVO) {
        if (companyUserVO != null) {
            Subject subject = SecurityUtils.getSubject();
            if (subject != null) {
                UserDTO user = (UserDTO) subject.getSession().getAttribute(
                    ymlConfig.getSession_current_user());
                if (user != null) {
                    UUID userId2 = user.getId();
                    String userName = user.getRealName();
                    UUID recId2 = user.getRecId();
                    String recName = user.getRecName();
                    HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                        recId2, recName);
                    httpHeaders.setContentType(MediaType.APPLICATION_JSON_UTF8);
                    HttpEntity<CompanyUserVO> requestEntity = new HttpEntity<CompanyUserVO>(companyUserVO, httpHeaders);
                    ResponseEntity<String> responseEntity = restTemplate.exchange(
                        ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2 + "/users/self/" + userId2,
                        HttpMethod.PUT, requestEntity, String.class);
                    if (responseEntity.getStatusCodeValue() == 200) {
                        if (responseEntity.getBody() != null) {
                            return "修改成功";
                        }
                    }
                }
            }
        }
        return null;
    }

    /**
     * @Description 用户修改密码.
     * @Author xiachao
     * @CreateTime 2017/3/2 17:43
     * @Param
     * @Return
     */
    @PutMapping("company/users/pwd")
    public String updateUserPwd(@RequestBody CompanyUserPwdDTO companyUserPwdDTO) {
        if (companyUserPwdDTO != null) {
            Subject subject = SecurityUtils.getSubject();
            if (subject != null) {
                UserDTO user = (UserDTO) subject.getSession().getAttribute(
                    ymlConfig.getSession_current_user());
                if (user != null) {
                    UUID userId2 = user.getId();
                    String userName = user.getRealName();
                    UUID recId2 = user.getRecId();
                    String recName = user.getRecName();
                    HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                        recId2, recName);
                    httpHeaders.setContentType(MediaType.APPLICATION_JSON_UTF8);
                    HttpEntity requestEntity = new HttpEntity(companyUserPwdDTO, httpHeaders);
                    ResponseEntity<String> responseEntity = restTemplate.exchange(
                        ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2 + "/users/" + userId2 + "/pwd",
                        HttpMethod.PUT, requestEntity, String.class);
                    if (responseEntity.getStatusCodeValue() == 200) {
                        return "密码修改成功";
                    }
                }
            }
        }
        return null;
    }

    /**
     * @Description 公司管理员账号对普通用户进行启用 停用.
     * @Author xiachao
     * @CreateTime 2017/3/2 18:07
     * @Param
     * @Return
     */
    @PutMapping("company/users/{id}/status")
    public String updateUserStatus(@PathVariable UUID id, String status) {
        if (status != null && !("".equals(status))) {
            Subject subject = SecurityUtils.getSubject();
            if (subject != null) {
                UserDTO user = (UserDTO) subject.getSession().getAttribute(
                    ymlConfig.getSession_current_user());
                if (user != null) {
                    UUID userId2 = user.getId();
                    String userName = user.getRealName();
                    UUID recId2 = user.getRecId();
                    String recName = user.getRecName();
                    HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                        recId2, recName);
                    HttpEntity requestEntity = new HttpEntity(null, httpHeaders);
                    ResponseEntity<String> responseEntity = restTemplate.exchange(
                        ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2 + "/users/" + id +
                            "/status?status=" + status,
                        HttpMethod.PUT, requestEntity, String.class);
                    if (responseEntity.getStatusCodeValue() == 200) {
                        return "修改成功";
                    }
                }
            }
        }
        return null;
    }

}
