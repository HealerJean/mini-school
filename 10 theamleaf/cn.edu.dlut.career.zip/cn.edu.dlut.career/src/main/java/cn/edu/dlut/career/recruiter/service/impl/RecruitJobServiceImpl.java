package cn.edu.dlut.career.recruiter.service.impl;

import cn.edu.dlut.career.recruiter.domain.RecruitJob;
import cn.edu.dlut.career.recruiter.repository.RecruitJobRepository;
import cn.edu.dlut.career.recruiter.service.RecruitJobService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Created by 史念念 on 2017/3/23.
 *
 * 招聘职位  服务层实现类
 */
@Service
public class RecruitJobServiceImpl implements RecruitJobService {
  @Autowired
  private RecruitJobRepository recruitJobRepository;

  /**
   * 查询全部招聘职位信息
   * @return
   */
  @Override
  public List<RecruitJob> findAll() {
    return recruitJobRepository.findAll();
  }

  /**
   * 添加招聘职位信息
   * @param recruitJob
   * @return
   */
  @Override
  public String saveRecruitJob(RecruitJob recruitJob) {
    try {
      recruitJobRepository.save(recruitJob);
      return "ok";
    } catch (Exception e) {
      e.printStackTrace();
      return "fail";
    }
  }

  /**
   * 根据编号查找招聘职位信息
   * @param id
   * @return
   */
  @Override
  public RecruitJob findById(String id) {
    RecruitJob recruitJob = recruitJobRepository.findById(id);
    return recruitJob;
  }

  /**
   * 根据公司编号查找招聘职位信息
   * @param recId
   * @return
   */
  @Override
  public List<RecruitJob> findByRecId(String recId) {
    List<RecruitJob> ls = recruitJobRepository.findByRecId(recId);
    return ls;
  }

  /**
   * 修改审核状态,审核人,审核时间,未通过原因
   * @param id
   * @param auditStatus
   * @param auditPerson
   * @param auditTime
   * @param auditFailReason
   * @return
   */
  @Override
  public String updateAudit(String id, String auditStatus, String auditPerson, LocalDateTime auditTime, String auditFailReason) {
    int result = recruitJobRepository.updateAudit(id,auditStatus,auditPerson,auditTime,auditFailReason);

    return result>0?"ok":"fail";
  }

  /**
   * 删除招聘职位信息
   * @param id
   * @return
   */
  @Override
  public String deleteById(String id) {
    try {
        recruitJobRepository.delete(id);
        return "ok";
    }catch (Exception e){
       return "fail";
    }
  }
}
