package cn.edu.dlut.career.controller;

import cn.edu.dlut.career.shiro.UserPrincipal;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import javax.servlet.http.HttpServletRequest;

@Controller
public class HomeController {
    private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
    @Autowired
    private HttpServletRequest request;

    /**
     * 登录后展示的首页
     * @return
     */
    @GetMapping({"/", "index.html"})
    public String dashboard() {
        Subject currentUser = SecurityUtils.getSubject();
        logger.info(request.getServerName());
        //if (currentUser.isAuthenticated()) {
            logger.info("Show Index");
//            if (currentUser.hasRole("stu")) {
//                return "home-student";
//            } else if (currentUser.hasRole("rec")) {
//                return "home-rec";
//            } else if (currentUser.hasRole("teacher")) {
//                return "home-teacher";
//            }
        UserPrincipal userPrincipal = (UserPrincipal) currentUser.getPrincipal();
        logger.info(userPrincipal.getRole());
        logger.info(userPrincipal.getEmail());
            return "index";
        //} else
        //    return "redirect:login.html";
    }
    
}
