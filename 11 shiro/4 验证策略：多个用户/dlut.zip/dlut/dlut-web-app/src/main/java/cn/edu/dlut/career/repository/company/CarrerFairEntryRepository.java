package cn.edu.dlut.career.repository.company;

import cn.edu.dlut.career.domain.company.CarreFairEntry;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import javax.persistence.Entity;
import javax.persistence.Table;
import java.time.LocalDateTime;
import java.util.List;

/**
 * 双选会，招聘会预约申请 数据操作层
 * Created by HealerJean on 2017/4/6.
 */
@Repository
public interface CarrerFairEntryRepository extends CrudRepository<CarreFairEntry,String>{
    //查找全部信息
    List<CarreFairEntry> findAll();

    //根据id进行查找
    CarreFairEntry findById(String id);

    //更新审核状态 根据 id
    @Modifying
    @Query(value = "update CarreFairEntry set auditStatus = ?2 ,auditTime = ?3,auditor=?4,nopass_reason=?5 where id = ?1")
    int updateCarreFairEntryAudit(String id, String auditStatus, LocalDateTime auditTime, String auditor,String nopass_reason);


}
