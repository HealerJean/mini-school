package cn.edu.dlut.career.recruiter.controller;

import cn.edu.dlut.career.recruiter.domain.CompanyInfo;
import cn.edu.dlut.career.recruiter.service.CompanyInfoService;
import cn.edu.dlut.career.recruiter.util.MD5Util;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by wei on 2017/3/23.
 */
@RestController
public class CompanyInfoQuery {
  Logger logger = LoggerFactory.getLogger(CompanyInfo.class);
  @Autowired
  private CompanyInfoService companyInfoService;

  @GetMapping("/company/login.html")
  public String login(String email,String pwd){
    logger.debug(email);
    logger.debug(pwd);
    CompanyInfo companyInfo = companyInfoService.login(email,pwd);
    if(companyInfo != null){
      return "ok";
    }
    return "login.html";
  }

  /**
   * 查看表中是否已经存在该邮箱
   * @param email
   * @return
   */
  @GetMapping("/company/findByEmail")
  public  String findByEmail(String email){
    CompanyInfo companyInfo = companyInfoService.findByEmail(email);
    if(companyInfo != null){
      return "";
    }
    return "";
  }
}
