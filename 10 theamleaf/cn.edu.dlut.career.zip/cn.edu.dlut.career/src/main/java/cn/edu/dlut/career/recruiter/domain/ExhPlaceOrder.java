package cn.edu.dlut.career.recruiter.domain;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * 展位预约表
 * Created by HealerJean on 2017/3/27.
 */
@Entity
@Table(name="rec_exhibite_place_order")
public class ExhPlaceOrder {
    //展厅预约唯一识别Id
    @Id
    @GenericGenerator(name = "idGenerator", strategy = "uuid")
    @GeneratedValue(generator = "idGenerator")
    private String id;

    //展厅编号
    private UUID exHallId;

    //展位编号
    private UUID exPlaceId;

    //使用开始时间
    private LocalDateTime  useStartTime;

    //使用结束时间
    private LocalDateTime  useEndTime;

    //审核状态
    @Column(length = 10)
    private  String auditState;

    //审核时间
    private  LocalDateTime auditTime;

    //审核人
    @Column(length = 15)
    private String auditPerson;



    public ExhPlaceOrder() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public UUID getExHallId() {
        return exHallId;
    }

    public void setExHallId(UUID exHallId) {
        this.exHallId = exHallId;
    }

    public UUID getExPlaceId() {
        return exPlaceId;
    }

    public void setExPlaceId(UUID exPlaceId) {
        this.exPlaceId = exPlaceId;
    }

    public LocalDateTime getUseStartTime() {
        return useStartTime;
    }

    public void setUseStartTime(LocalDateTime useStartTime) {
        this.useStartTime = useStartTime;
    }

    public LocalDateTime getUseEndTime() {
        return useEndTime;
    }

    public void setUseEndTime(LocalDateTime useEndTime) {
        this.useEndTime = useEndTime;
    }

    public String getAuditState() {
        return auditState;
    }

    public void setAuditState(String auditState) {
        this.auditState = auditState;
    }

    public LocalDateTime getAuditTime() {
        return auditTime;
    }

    public void setAuditTime(LocalDateTime auditTime) {
        this.auditTime = auditTime;
    }

    public String getAuditPerson() {
        return auditPerson;
    }

    public void setAuditPerson(String auditPerson) {
        this.auditPerson = auditPerson;
    }
}
