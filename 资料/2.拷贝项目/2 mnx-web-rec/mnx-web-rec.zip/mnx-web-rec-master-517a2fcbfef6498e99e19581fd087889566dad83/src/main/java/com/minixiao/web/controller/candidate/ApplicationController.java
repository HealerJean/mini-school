package com.minixiao.web.controller.candidate;

import com.minixiao.apiauth.client.HeaderUtil;
import com.minixiao.web.dto.candidate.AppDetailDTO;
import com.minixiao.web.dto.candidate.ApplicationDTO;
import com.minixiao.web.dto.candidate.ApplicationListDTO;
import com.minixiao.web.dto.candidate.UpdateStageDTO;
import com.minixiao.web.dto.candidate.UpdateStatusDTO;
import com.minixiao.web.dto.recruiters.UserDTO;
import com.minixiao.web.email.RefusedEventEmail;
import com.minixiao.web.utils.YmlConfig;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import java.util.UUID;

/**
 * @Author 王迎接 【wangyj@minixiao.com】.
 * @Date 2017/2/28  16:39.
 */
@Controller
public class ApplicationController {

    @Autowired
    private YmlConfig ymlConfig;

    private RestTemplate restTemplate = new RestTemplate();

    /**
     * @Description 添加申请表.
     * @Author wangyj
     * @CreateDate 2017/3/15 9:31
     * @Param
     * @Return
     */
    @PostMapping("/candidate")
    private ResponseEntity<String> saveCandidate(@RequestBody AppDetailDTO appDetailDTO) {
        UUID recId = UUID.fromString("0b5c9f73-6c11-4e0a-a9d8-c1da222a74bf");
        UUID optUid = recId;
        String optName = "王迎接";
        String recName = "迷你校";
        HttpHeaders requestHeaders = HeaderUtil.getHeader(optUid, optName, "COMPANY", recId,
            recName);
        HttpEntity requestEntity = new HttpEntity(appDetailDTO, requestHeaders);
        ResponseEntity<String> responseEntity = restTemplate.exchange(
            ymlConfig.getUrl_api_recruiter() + "candidate", HttpMethod.POST, requestEntity,
            String.class);
        String result = responseEntity.getBody();
        return ResponseEntity.ok(result);
    }

    /**
     * @Description 获取申请表列表.
     * @Author 王迎接【wangyj@minixiao.com】
     * @CreateDate 2017/2/28 18:14
     * @Param
     * @Return
     */
    @GetMapping("/candidate")
    @ResponseBody
    public ResponseEntity<ApplicationListDTO> listApplications(@RequestParam String filter) {
        Subject subject = SecurityUtils.getSubject();
        if (subject != null) {
            UserDTO user = (UserDTO) subject.getSession().getAttribute(ymlConfig.getSession_current_user());
            if (user != null) {
                UUID recId = user.getRecId();
                UUID optUid = user.getId();
                String optName = user.getRealName();
                String recName = user.getRecName();
                HttpHeaders requestHeaders = HeaderUtil.getHeader(optUid, optName, "COMPANY", recId,
                    recName);
                HttpEntity requestEntity = new HttpEntity(null, requestHeaders);
                ApplicationListDTO applicationListDTO = restTemplate.exchange(
                    ymlConfig.getUrl_api_recruiter() + "candidate?filter={filter}", HttpMethod.GET, requestEntity,
                    ApplicationListDTO.class, filter).getBody();
                return ResponseEntity.ok(applicationListDTO);
            }
        }
        return null;
    }

    /**
     * @Description 获取申请表详情 .
     * @Author 王迎接【wangyj@minixiao.com】
     * @CreateDate 2017/2/28 18:15
     * @Param
     * @Return
     */
    @GetMapping("/candidate/{id}")
    @ResponseBody
    public ResponseEntity<AppDetailDTO> getApplication(@PathVariable UUID id) {
        Subject subject = SecurityUtils.getSubject();
        if (subject != null) {
            UserDTO user = (UserDTO) subject.getSession().getAttribute(ymlConfig.getSession_current_user());
            if (user != null) {
                UUID recId = user.getRecId();
                UUID optUid = user.getId();
                String optName = user.getRealName();
                String recName = user.getRecName();
                HttpHeaders requestHeaders = HeaderUtil.getHeader(optUid, optName, "COMPANY", recId,
                    recName);
                HttpEntity requestEntity = new HttpEntity(null, requestHeaders);
                AppDetailDTO appDetailDTO = restTemplate.exchange(
                    ymlConfig.getUrl_api_recruiter() + "candidate/{id}", HttpMethod.GET, requestEntity,
                    AppDetailDTO.class, id).getBody();
                return ResponseEntity.ok(appDetailDTO);
            }
        }
        return null;
    }

    /**
     * @Description 设置申请表阶段--通过.
     * @Author wangyj
     * @CreateDate 2017/3/1 14:43
     * @Param
     * @Return
     */
    @PutMapping("/candidate/stage/pass")
    public ResponseEntity<String> updateAppStagePass(@RequestBody UpdateStageDTO updateStageDTO) {
        Subject subject = SecurityUtils.getSubject();
        if (subject != null) {
            UserDTO user = (UserDTO) subject.getSession().getAttribute(ymlConfig.getSession_current_user());
            if (user != null) {
                UUID recId = user.getRecId();
                UUID optUid = user.getId();
                String optName = user.getRealName();
                String recName = user.getRecName();
                HttpHeaders requestHeaders = HeaderUtil.getHeader(optUid, optName, "COMPANY", recId,
                    recName);
                HttpEntity requestEntity = new HttpEntity(updateStageDTO, requestHeaders);
                ResponseEntity<String> responseEntity = restTemplate.exchange(
                    ymlConfig.getUrl_api_recruiter() + "candidate/stage/pass", HttpMethod.PUT, requestEntity,
                    String.class);
                String result = responseEntity.getBody();
                return ResponseEntity
                    .status(HttpStatus.OK)
                    .cacheControl(CacheControl.noCache())
                    .body(result);
            }
        }
        return ResponseEntity
            .status(HttpStatus.BAD_REQUEST)
            .cacheControl(CacheControl.noCache())
            .body("FAILED");
    }

    /**
     * @Description 设置申请表阶段--阶段跳转.
     * @Author wangyj
     * @CreateDate 2017/3/1 14:43
     * @Param
     * @Return
     */
    @PutMapping("/candidate/stage/skip")
    public ResponseEntity<String> updateAppStageSkip(@RequestBody UpdateStageDTO updateStageDTO) {
        Subject subject = SecurityUtils.getSubject();
        if (subject != null) {
            UserDTO user = (UserDTO) subject.getSession().getAttribute(ymlConfig.getSession_current_user());
            if (user != null) {
                UUID recId = user.getRecId();
                UUID optUid = user.getId();
                String optName = user.getRealName();
                String recName = user.getRecName();
                HttpHeaders requestHeaders = HeaderUtil.getHeader(optUid, optName, "COMPANY", recId,
                    recName);
                HttpEntity requestEntity = new HttpEntity(updateStageDTO, requestHeaders);
                ResponseEntity<String> responseEntity = restTemplate.exchange(
                    ymlConfig.getUrl_api_recruiter() + "candidate/stage/skip", HttpMethod.PUT, requestEntity,
                    String.class);
                String result = responseEntity.getBody();
                return ResponseEntity
                    .status(HttpStatus.OK)
                    .cacheControl(CacheControl.noCache())
                    .body(result);
            }
        }
        return ResponseEntity
            .status(HttpStatus.BAD_REQUEST)
            .cacheControl(CacheControl.noCache())
            .body("FAILED");
    }

    /**
     * @Description 设置申请表状态.
     * @Author wangyj
     * @CreateDate 2017/3/2 17:08
     * @Param
     * @Return
     */
    @PutMapping("candidate/status")
    public ResponseEntity<String> updateApplicationStatus(@RequestBody UpdateStatusDTO updateStatusDTO) {
        Subject subject = SecurityUtils.getSubject();
        if (subject != null) {
            UserDTO user = (UserDTO) subject.getSession().getAttribute(ymlConfig.getSession_current_user());
            if (user != null) {
                UUID recId = user.getRecId();
                UUID optUid = user.getId();
                String optName = user.getRealName();
                String recName = user.getRecName();
                HttpHeaders requestHeaders = HeaderUtil.getHeader(optUid, optName, "COMPANY", recId,
                    recName);
                HttpEntity requestEntity = new HttpEntity(updateStatusDTO, requestHeaders);
                ResponseEntity<String> responseEntity = restTemplate.exchange(
                    ymlConfig.getUrl_api_recruiter() + "candidate/status", HttpMethod.PUT, requestEntity,
                    String.class);
                String result = responseEntity.getBody();
                //不通过时需要出发发送事件
                if("不通过".equals(updateStatusDTO.getStatus())){
                    RefusedEventEmail.refuesdEmail(updateStatusDTO.getAppStageListDTOs(),recName);
                }
                return ResponseEntity
                    .status(HttpStatus.OK)
                    .cacheControl(CacheControl.noCache())
                    .body(result);
            }
        }
        return ResponseEntity
            .status(HttpStatus.BAD_REQUEST)
            .cacheControl(CacheControl.noCache())
            .body("FAILED");
    }
}
