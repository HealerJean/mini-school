package cn.edu.dlut.career.recruiter.service;

import cn.edu.dlut.career.recruiter.domain.RecruitmentSetUp;

import java.util.List;

/**
 * Created by wei on 2017/3/27.
 */
public interface RecruitmentSetUpService {
  void save(RecruitmentSetUp recruitmentSetUp);

  void delete(String id);

  List<RecruitmentSetUp> findAll();

  RecruitmentSetUp finOne(String id);

}
