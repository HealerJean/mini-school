package cn.edu.dlut.career.service.company.impl;

import cn.edu.dlut.career.domain.company.ExhPlaceOrder;
import cn.edu.dlut.career.repository.company.ExHallOrderRepository;
import cn.edu.dlut.career.service.company.ExhPlaceOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Created by HealerJean on 2017/3/27.
 */
@Service
@Transactional
public class ExhPlaceOrderServiceImpl implements ExhPlaceOrderService {

    @Autowired
    ExHallOrderRepository exHallOrderRepository;
    @Override
    public ExhPlaceOrder saveExHallOrder(ExhPlaceOrder exhPlaceOrder) {
        return exHallOrderRepository.save(exhPlaceOrder);
    }

    @Override
    public ExhPlaceOrder findById(String id) {
        return exHallOrderRepository.findById(id);
    }

    @Override
    public ExhPlaceOrder updateExHallOrder(ExhPlaceOrder exhPlaceOrder) {
        return exHallOrderRepository.save(exhPlaceOrder);
    }

    @Override
    public String deleteExHallOrder(String id) {
        try {
            exHallOrderRepository.delete(id);
            return  "ok";
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }
    @Override
    public List<ExhPlaceOrder> findAllExHallOrder() {
        return exHallOrderRepository.findAll();
    }

    @Override
    public int updateExhPlaceOrderAudit(String id, String auditState, LocalDateTime auditTime, String auditPerson) {

        return exHallOrderRepository.updateExhPlaceOrderAudit(id,auditState,auditTime,auditPerson);
    }
}
