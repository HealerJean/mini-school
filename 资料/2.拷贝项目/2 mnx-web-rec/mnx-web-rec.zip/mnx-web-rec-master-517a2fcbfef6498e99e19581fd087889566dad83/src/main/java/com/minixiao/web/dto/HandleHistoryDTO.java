package com.minixiao.web.dto;

import java.time.LocalDate;
import java.util.UUID;

public class HandleHistoryDTO {

  private UUID id;

  private String candidateName;

  private UUID recId;

  private String recName;

  private UUID jobId;

  private String jobName;

  private UUID optUid;

  private String optUname;

  private String optType;

  private String description;

  private String status;

  private String remark;

  public UUID getId() {
    return id;
  }

  public void setId(UUID id) {
    this.id = id;
  }

  public String getCandidateName() {
    return candidateName;
  }

  public void setCandidateName(String candidateName) {
    this.candidateName = candidateName;
  }

  public UUID getRecId() {
    return recId;
  }

  public void setRecId(UUID recId) {
    this.recId = recId;
  }

  public String getRecName() {
    return recName;
  }

  public void setRecName(String recName) {
    this.recName = recName;
  }

  public UUID getJobId() {
    return jobId;
  }

  public void setJobId(UUID jobId) {
    this.jobId = jobId;
  }

  public String getJobName() {
    return jobName;
  }

  public void setJobName(String jobName) {
    this.jobName = jobName;
  }

  public UUID getOptUid() {
    return optUid;
  }

  public void setOptUid(UUID optUid) {
    this.optUid = optUid;
  }

  public String getOptUname() {
    return optUname;
  }

  public void setOptUname(String optUname) {
    this.optUname = optUname;
  }

  public String getOptType() {
    return optType;
  }

  public void setOptType(String optType) {
    this.optType = optType;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public String getRemark() {
    return remark;
  }

  public void setRemark(String remark) {
    this.remark = remark;
  }

  /**
   * 构造函数.
   */
  public HandleHistoryDTO() {
  }
}
