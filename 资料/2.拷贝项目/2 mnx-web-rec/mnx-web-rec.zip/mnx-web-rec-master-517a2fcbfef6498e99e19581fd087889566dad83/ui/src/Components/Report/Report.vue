<template>
    <h1>This is Report.</h1>
</template>

<script type="text/babel">

    export default {
        name: 'report',
        data() {
            return {};
        }
    }

</script>

<style>

</style>