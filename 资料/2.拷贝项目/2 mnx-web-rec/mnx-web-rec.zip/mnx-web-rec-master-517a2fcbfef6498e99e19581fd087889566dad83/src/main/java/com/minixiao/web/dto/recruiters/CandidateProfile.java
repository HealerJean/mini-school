package com.minixiao.web.dto.recruiters;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * @Description 筛选器中的嵌入类 .
 * @Author xiachao
 * @CreateTime 2017/2/13 15:20
 * @Param
 * @Return
 */
public class CandidateProfile {
    //职位名称
    private String position;

    //最高学历
    //筛选建议用最低学历做筛选
    private String degree;

    //毕业学校（可多选）
    private String school;

    //专业名称
    private String major;

    //处理状态
    private String status;

    //简历标签(英文状态逗号切分)
    private String label;

    //性别
    private String gender;

    //聘用部门
    private String department;

    //专业排名
    private String rank;

    //英语等级
    private String englishLevel;

    //奖学金
    private String reward;

    //附件简历
    private String attachment;

    //手机号码
    private String mobile;

    //城市，英文状态逗号切分
    private String city;

    //出生年份大于
    private String birthFrom;

    //出生年份小于
    private String birthTo;

    //毕业年份大于
    private String graduateFrom;

    //毕业年份小于
    private String graduateTo;

    //投递时间大于
    private String deliveryFrom;

    //投递时间小于
    private String deliveryTo;


    /**
     * .
     */
    public CandidateProfile() {
    }

    /**
     * .
     */


    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public String getAttachment() {
        return attachment;
    }

    public void setAttachment(String attachment) {
        this.attachment = attachment;
    }

    public String getReward() {
        return reward;
    }

    public void setReward(String reward) {
        this.reward = reward;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSchool() {
        return school;
    }

    public void setSchool(String school) {
        this.school = school;
    }

    public String getEnglishLevel() {
        return englishLevel;
    }

    public void setEnglishLevel(String englishLevel) {
        this.englishLevel = englishLevel;
    }

    public String getBirthFrom() {
        return birthFrom;
    }

    public void setBirthFrom(String birthFrom) {
        this.birthFrom = birthFrom;
    }

    public String getBirthTo() {
        return birthTo;
    }

    public void setBirthTo(String birthTo) {
        this.birthTo = birthTo;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getGraduateTo() {
        return graduateTo;
    }

    public void setGraduateTo(String graduateTo) {
        this.graduateTo = graduateTo;
    }

    public String getGraduateFrom() {
        return graduateFrom;
    }

    public void setGraduateFrom(String graduateFrom) {
        this.graduateFrom = graduateFrom;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getDeliveryTo() {
        return deliveryTo;
    }

    public void setDeliveryTo(String deliveryTo) {
        this.deliveryTo = deliveryTo;
    }

    public String getDeliveryFrom() {
        return deliveryFrom;
    }

    public void setDeliveryFrom(String deliveryFrom) {
        this.deliveryFrom = deliveryFrom;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getDegree() {
        return degree;
    }

    public void setDegree(String degree) {
        this.degree = degree;
    }

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }
}
