package com.minixiao.web.controller.setting;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.minixiao.apiauth.client.HeaderUtil;
import com.minixiao.web.dto.recruiters.CandidateFilterVO;
import com.minixiao.web.dto.recruiters.UserDTO;
import com.minixiao.web.utils.YmlConfig;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.util.UUID;

/**
 * 候选人筛选器controller.
 * Created by xiachao on 2017/3/3.
 */
@RestController
public class CandidateFilterController {
    private Logger logger = LoggerFactory.getLogger(CandidateLabelController.class);

    @Autowired
    private YmlConfig ymlConfig;

    private RestTemplate restTemplate = new RestTemplate();

    /**
     * @Description 查询该用户下的所有筛选器.
     * @Author xiachao
     * @CreateTime 2017/3/3 11:03
     * @Param
     * @Return
     */
    @GetMapping("company/users/filter/candidate")
    public String getAllFilters() {
        Subject subject = SecurityUtils.getSubject();
        if (subject != null) {
            UserDTO user = (UserDTO) subject.getSession().getAttribute(
                ymlConfig.getSession_current_user());
            if (user != null) {
                UUID userId = user.getId();
                String userName = user.getRealName();
                UUID recId = user.getRecId();
                String recName = user.getRecName();
                HttpHeaders httpHeaders = HeaderUtil.getHeader(userId, userName, "COMPANY",
                    recId, recName);
                HttpEntity requestEntity = new HttpEntity(null, httpHeaders);
                ResponseEntity<String> responseEntity = restTemplate.exchange(
                    ymlConfig.getUrl_api_recruiter() + "recruiters/account/" + userId + "/filter/candidates",
                    HttpMethod.GET, requestEntity, String.class);
                if (responseEntity.getStatusCodeValue() == 200) {
                    return responseEntity.getBody();
                }
            }
        }
        return null;
    }

    /**
     * @Description 添加筛选器.
     * @Author xiachao
     * @CreateTime 2017/3/3 11:08
     * @Param
     * @Return
     */
    @PostMapping("company/users/filter/candidate")
    public String addCandidateFilter(@RequestBody CandidateFilterVO candidateFilterVO) {
        if (candidateFilterVO != null) {
            Subject subject = SecurityUtils.getSubject();
            if (subject != null) {
                UserDTO user = (UserDTO) subject.getSession().getAttribute(
                    ymlConfig.getSession_current_user());
                if (user != null) {
                    UUID userId = user.getId();
                    String userName = user.getRealName();
                    UUID recId = user.getRecId();
                    String recName = user.getRecName();
                    HttpHeaders httpHeaders = HeaderUtil.getHeader(userId, userName, "COMPANY",
                        recId, recName);
                    httpHeaders.setContentType(MediaType.APPLICATION_JSON_UTF8);
                    HttpEntity<CandidateFilterVO> requestEntity = new HttpEntity<CandidateFilterVO>(candidateFilterVO, httpHeaders);
                    ResponseEntity<String> responseEntity = restTemplate.exchange(
                        ymlConfig.getUrl_api_recruiter() + "recruiters/account/" + userId + "/filter/candidate",
                        HttpMethod.POST, requestEntity, String.class);
                    if (responseEntity.getStatusCodeValue() == 200) {
                        return "添加成功";
                    }
                }
            }
        }
        return "添加失败";
    }

    /**
     * @Description 修改筛选器.
     * @Author xiachao
     * @CreateTime 2017/3/3 15:03
     * @Param
     * @Return
     */
    @RequestMapping("company/users/filter/candidate/{id}")
    public String updateCandidateFilter(@PathVariable UUID id, @RequestBody CandidateFilterVO candidateFilterVO) {
        if (candidateFilterVO != null && id != null) {
            Subject subject = SecurityUtils.getSubject();
            if (subject != null) {
                UserDTO user = (UserDTO) subject.getSession().getAttribute(
                    ymlConfig.getSession_current_user());
                if (user != null) {
                    UUID userId2 = user.getId();
                    String userName = user.getRealName();
                    UUID recId = user.getRecId();
                    String recName = user.getRecName();
                    HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                        recId, recName);
                    httpHeaders.setContentType(MediaType.APPLICATION_JSON_UTF8);
                    HttpEntity<CandidateFilterVO> requestEntity = new HttpEntity<CandidateFilterVO>(candidateFilterVO, httpHeaders);
                    ResponseEntity<String> responseEntity = restTemplate.exchange(
                        ymlConfig.getUrl_api_recruiter() + "recruiters/account/" + userId2 + "/filter/candidates/" + id,
                        HttpMethod.PUT, requestEntity, String.class);
                    if (responseEntity.getStatusCodeValue() == 200) {
                        return "保存成功";
                    }
                }
            }
        }
        return "保存失败";
    }

    /**
     * @Description 删除筛选器.
     * @Author xiachao
     * @CreateTime 2017/3/3 15:10
     * @Param
     * @Return
     */
    @DeleteMapping("company/users/filter/candidate/{id}")
    public String deleteCandidateFilter(@PathVariable UUID id) {
        if (id != null) {
            Subject subject = SecurityUtils.getSubject();
            if (subject != null) {
                UserDTO user = (UserDTO) subject.getSession().getAttribute(
                    ymlConfig.getSession_current_user());
                if (user != null) {
                    UUID userId2 = user.getId();
                    String userName = user.getRealName();
                    UUID recId = user.getRecId();
                    String recName = user.getRecName();
                    HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                        recId, recName);
                    HttpEntity requestEntity = new HttpEntity(null, httpHeaders);
                    ResponseEntity<String> responseEntity = restTemplate.exchange(
                        ymlConfig.getUrl_api_recruiter() + "recruiters/account/" + userId2 + "/filter/candidates/" + id,
                        HttpMethod.DELETE, requestEntity, String.class);
                    if (responseEntity.getStatusCodeValue() == 200) {
                        return "删除成功";
                    }
                }
            }
        }
        return "删除失败";
    }


}
