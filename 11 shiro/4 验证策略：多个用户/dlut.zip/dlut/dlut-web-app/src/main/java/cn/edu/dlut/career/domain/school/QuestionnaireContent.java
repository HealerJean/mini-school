package cn.edu.dlut.career.domain.school;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

/**
 * 实体类 问卷问题内容
 * Created by HealerJean on 2017/4/6.
 */
@Entity
@Table(name="questionnaire_content")
public class QuestionnaireContent {
    //编号，主键UUID
    @Id
    @GenericGenerator(name = "idGenerator", strategy = "uuid")
    @GeneratedValue(generator = "idGenerator")
    private String id;

    //问卷信息id(外键)
    @Column(length = 30,nullable = false)
    private String quesInfoId;

    //题干(问题内容)
    @Column(length = 50,nullable = false)
    private String title;

    //类型：1 选择题，2 问答题，3 判断题
    @Column(length = 1,nullable = true)
    private char type;


    //是否必填:（1必填，2不必填）
    @Column(length = 1,nullable = true)
    private char isRequired;

    //是选项A
    @Column(length = 50 ,nullable = true)
    private char optionA;

    //选项B
    @Column(length = 50 ,nullable = true)
    private char optionB;

    //选项C
    @Column(length = 50 ,nullable = true)
    private char optionC;

    //选项D
    @Column(length = 50 ,nullable = true)
    private char optionD;

    //选项E
    @Column(length = 50 ,nullable = true)
    private char optionE;

    //选项F
    @Column(length = 50 ,nullable = true)
    private char optionF;




    public QuestionnaireContent() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getQuesInfoId() {
        return quesInfoId;
    }

    public void setQuesInfoId(String quesInfoId) {
        this.quesInfoId = quesInfoId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public char getType() {
        return type;
    }

    public void setType(char type) {
        this.type = type;
    }

    public char getIsRequired() {
        return isRequired;
    }

    public void setIsRequired(char isRequired) {
        this.isRequired = isRequired;
    }

    public char getOptionA() {
        return optionA;
    }

    public void setOptionA(char optionA) {
        this.optionA = optionA;
    }

    public char getOptionB() {
        return optionB;
    }

    public void setOptionB(char optionB) {
        this.optionB = optionB;
    }

    public char getOptionC() {
        return optionC;
    }

    public void setOptionC(char optionC) {
        this.optionC = optionC;
    }

    public char getOptionD() {
        return optionD;
    }

    public void setOptionD(char optionD) {
        this.optionD = optionD;
    }

    public char getOptionE() {
        return optionE;
    }

    public void setOptionE(char optionE) {
        this.optionE = optionE;
    }

    public char getOptionF() {
        return optionF;
    }

    public void setOptionF(char optionF) {
        this.optionF = optionF;
    }
}


