package cn.edu.dlut.career.domain.student;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * Created by wei on 2017/4/5.
 * 违约申请表信息
 */
@Entity
@Table(name = "default_application")
public class DefaultApplication {
    //编号，主键UUID
    @Id
    @GenericGenerator(name = "idGenerator",strategy = "uuid")
    @GeneratedValue(generator = "idGenerator")
    private String id;
    //生成协议书编号
    @Column(length = 40,nullable = false)
    private String agreementId;
    //违约原因
    @Column(length = 20,nullable = false)
    private String defaultReason;
    //申请原因
    @Column(length = 10,nullable = false)
    private String applicationReason;
    //违约金金额
    @Column(nullable = true)
    private double penaltyNum;
    //申请状态
    @Column(length =20,nullable = true)
    private String applicationStatus;
    //院系审批人
    @Column(length = 30,nullable = true)
    private String deptApprover;
    //院系审批时间
    @Column(nullable = true)
    private LocalDateTime deptApprovalTime;
    //院系审核是否同意
    @Column(length = 1,nullable = true)
    private String deptOpinion;
    //院系审核不同意原因
    @Column(length = 100,nullable = true)
    private String deptRejectionReason;
    //学校审批人
    @Column(length = 30,nullable = true)
    private String schoolApprover;
    //学校审批时间
    @Column(nullable = true)
    private LocalDateTime schoolApprovalTime;
    //学校审核是否同意
    @Column(length = 1,nullable = true)
    private String schoolOpinion;
    //学校审核不同意原因
    @Column(length = 100,nullable = true)
    private String schoolRejectionReason;
    //申请时间
    @Column(nullable = false)
    private LocalDateTime applicationTime;

    public DefaultApplication() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAgreementId() {
        return agreementId;
    }

    public void setAgreementId(String agreementId) {
        this.agreementId = agreementId;
    }

    public String getDefaultReason() {
        return defaultReason;
    }

    public void setDefaultReason(String defaultReason) {
        this.defaultReason = defaultReason;
    }

    public String getApplicationReason() {
        return applicationReason;
    }

    public void setApplicationReason(String applicationReason) {
        this.applicationReason = applicationReason;
    }

    public double getPenaltyNum() {
        return penaltyNum;
    }

    public void setPenaltyNum(double penaltyNum) {
        this.penaltyNum = penaltyNum;
    }

    public String getApplicationStatus() {
        return applicationStatus;
    }

    public void setApplicationStatus(String applicationStatus) {
        this.applicationStatus = applicationStatus;
    }

    public String getDeptApprover() {
        return deptApprover;
    }

    public void setDeptApprover(String deptApprover) {
        this.deptApprover = deptApprover;
    }

    public LocalDateTime getDeptApprovalTime() {
        return deptApprovalTime;
    }

    public void setDeptApprovalTime(LocalDateTime deptApprovalTime) {
        this.deptApprovalTime = deptApprovalTime;
    }

    public String getDeptOpinion() {
        return deptOpinion;
    }

    public void setDeptOpinion(String deptOpinion) {
        this.deptOpinion = deptOpinion;
    }

    public String getDeptRejectionReason() {
        return deptRejectionReason;
    }

    public void setDeptRejectionReason(String deptRejectionReason) {
        this.deptRejectionReason = deptRejectionReason;
    }

    public String getSchoolApprover() {
        return schoolApprover;
    }

    public void setSchoolApprover(String schoolApprover) {
        this.schoolApprover = schoolApprover;
    }

    public LocalDateTime getSchoolApprovalTime() {
        return schoolApprovalTime;
    }

    public void setSchoolApprovalTime(LocalDateTime schoolApprovalTime) {
        this.schoolApprovalTime = schoolApprovalTime;
    }

    public String getSchoolOpinion() {
        return schoolOpinion;
    }

    public void setSchoolOpinion(String schoolOpinion) {
        this.schoolOpinion = schoolOpinion;
    }

    public String getSchoolRejectionReason() {
        return schoolRejectionReason;
    }

    public void setSchoolRejectionReason(String schoolRejectionReason) {
        this.schoolRejectionReason = schoolRejectionReason;
    }

    public LocalDateTime getApplicationTime() {
        return applicationTime;
    }

    public void setApplicationTime(LocalDateTime applicationTime) {
        this.applicationTime = applicationTime;
    }
}
