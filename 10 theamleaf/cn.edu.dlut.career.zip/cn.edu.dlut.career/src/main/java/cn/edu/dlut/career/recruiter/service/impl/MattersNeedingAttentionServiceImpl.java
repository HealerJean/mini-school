package cn.edu.dlut.career.recruiter.service.impl;

import cn.edu.dlut.career.recruiter.domain.MattersNeedingAttention;
import cn.edu.dlut.career.recruiter.repository.MattersNeedingAttentionRepository;
import cn.edu.dlut.career.recruiter.service.MattersNeedingAttentionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by wei on 2017/3/27.
 */
@Service
@Transactional
public class MattersNeedingAttentionServiceImpl implements MattersNeedingAttentionService {
  @Autowired
  private MattersNeedingAttentionRepository mattersNeedingAttentionRepository;

  @Override
  public void save(MattersNeedingAttention mattersNeedingAttention) {
    mattersNeedingAttentionRepository.save(mattersNeedingAttention);
  }

  @Override
  public void delete(String id) {
    mattersNeedingAttentionRepository.delete(id);
  }

  @Override
  public List<MattersNeedingAttention> findAll() {
    return mattersNeedingAttentionRepository.findAll();
  }

  @Override
  public MattersNeedingAttention finOne(String id) {
    return mattersNeedingAttentionRepository.findOne(id);
  }


}
