package com.minixiao.infra.subdomain.repository;

import com.minixiao.infra.subdomain.domain.Subdomain;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;


/**
 * Created by 史念念 on 2017/3/21.
 */
public interface SubdomainRepository extends CrudRepository<Subdomain,Integer> {

  //根据子域名查找跳转链接
  @Query("select href from Subdomain where sub=?1")
  String findBySub(String sub);

  //根据关键字查找链接信息
  @Query("select s from Subdomain s where s.name like %?1%")
  List<Subdomain> findByKeywords(String keyword);

  //查找全部信息
  List<Subdomain> findAll();

  //根据id查找
  Subdomain findById(int id);

}
