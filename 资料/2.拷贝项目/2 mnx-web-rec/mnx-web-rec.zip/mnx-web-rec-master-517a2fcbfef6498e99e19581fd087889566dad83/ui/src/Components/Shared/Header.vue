<template>
    <div v-if="headerLogin">
        <header-login></header-login>
    </div>
    <div v-else>
        <header-nologin></header-nologin>
    </div>
</template>

<script>
  import HeaderNologin from './HeaderNoLogin'
  import HeaderLogin from './HeaderLogin'


    export default {
      name: 'app',
      data:function(){
        return {
          headerLogin:true
        }
      },
      components: {
        HeaderNologin,
        HeaderLogin
      }
    }
</script>

<style lang="less">

</style>
