# WEB 视觉规范

待完善

## 前言

* 本设计规范基于SaaS端，自发布之日起开始执行
* 本规范中所有元素版权归迷你校所有
* 本规范仅限内部使用，不得外传；否则涉及后果自负

## 1 页面尺寸 Page Size
根据主流浏览器的宽度以及用户习惯进行栅格规范，以整体宽度1200pt、24栅格分栏、20pt栅格间隔、有效内容宽度1180pt基础上设计，使网站页面更加美观。

<table bgcolor="#F3F3F3" cellpadding="20" cellspacing="20" style="text-align:center;border:2pt solid #F4F4F4; color:#FEFEFE;">
  <thead>
  <tr style="background-color:rgba(0, 160, 233, 0.7)">
    <td width="8.33333333%"></td>
    <td width="8.33333333%"></td>
    <td width="8.33333333%"></td>
    <td width="8.33333333%"></td>
    <td width="8.33333333%"></td>
    <td width="8.33333333%"></td>
    <td width="8.33333333%"></td>
    <td width="8.33333333%"></td>
    <td width="8.33333333%"></td>
    <td width="8.33333333%"></td>
    <td width="8.33333333%"></td>
    <td width="8.33333333%"></td>
    <td width="8.33333333%"></td>
    <td width="8.33333333%"></td>
    <td width="8.33333333%"></td>
    <td width="8.33333333%"></td>
    <td width="8.33333333%"></td>
    <td width="8.33333333%"></td>
    <td width="8.33333333%"></td>
    <td width="8.33333333%"></td>
    <td width="8.33333333%"></td>
    <td width="8.33333333%"></td>
    <td width="8.33333333%"></td>
    <td width="8.33333333%"></td>
  </tr>
  </thead>
  <tbody>
  <tr style="background-color:rgba(0, 160, 233, 0.7)">
    <td colspan="24">.col-24 width:1180pt</td>
  </tr>
  <tr style="background-color:rgba(0, 160, 233, 0.7)">
    <td colspan="18">.col-18 width:880pt</td>
    <td colspan="6">.col-6 width:280pt</td>
  </tr>
  <tr style="background-color:rgba(0, 160, 233, 0.7)">
    <td colspan="8">.col-8 width:380pt</td>
    <td colspan="8">.col-8 width:380pt</td>
    <td colspan="8">.col-8 width:380pt</td>
  </tr>
  <tr style="background-color:rgba(0, 160, 233, 0.7)">
    <td colspan="6">.col-6 width:280pt</td>
    <td colspan="18">.col-18 width:880pt</td>
  </tr>
  </tbody>
</table>

## 2 图片尺寸 Image Size

## 3 页面颜色 Page Color

<div style="background-color:049cff;padding:10pt 20pt; width:25%; height:6em; float:left;">标准色<br>当前态<br>一般高亮显示</div>
<div style="background-color:333333;padding:10pt 20pt; width:25%; height:6em; float:left;">详情页标题文字</div>
<div style="background-color:464646;padding:10pt 20pt; width:25%; height:6em; float:left;">重要问题标题</div>
<div style="background-color:555555;padding:10pt 20pt; width:25%; height:6em; float:left;">正文</div>
<div style="background-color:707070;padding:10pt 20pt; width:25%; height:6em; float:left;">详情页二级文字</div>
<div style="background-color:909090;padding:10pt 20pt; width:25%; height:6em; float:left;">说明文字</div>
<div style="background-color:049cff;padding:10pt 20pt; width:25%; height:6em; float:left;">标准色<br>当前态<br>一般高亮显示</div>
<div style="background-color:049cff;padding:10pt 20pt; width:25%; height:6em; float:left;">标准色<br>当前态<br>一般高亮显示</div>
<div style="background-color:049cff;padding:10pt 20pt; width:25%; height:6em; float:left;">标准色<br>当前态<br>一般高亮显示</div>
<div style="clear:both;"></div>

## 4 文字样式 Text Style
网站主要字体使用无衬线字体。

英文字体首选 Helvetica Neue/Helvetica 字体；中文字体首选 PingFang SC（Mac 系统）／Hiragino Sans GB（Mac 系统）／Microsoft YaHei（Windows 系统） 字体。

字体家族CSS代码如下：

```
font-family: "Helvetica Neue",Helvetica,"PingFang SC","Hiragino Sans GB","Microsoft YaHei","微软雅黑",Arial,sans-serif;
```
字体使用规范

## 5 图标规范 Icon

## 按键规范 Button