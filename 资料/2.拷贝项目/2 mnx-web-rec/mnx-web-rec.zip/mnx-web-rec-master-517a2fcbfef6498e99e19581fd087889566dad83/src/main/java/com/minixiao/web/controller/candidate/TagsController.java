package com.minixiao.web.controller.candidate;

import com.minixiao.apiauth.client.HeaderUtil;
import com.minixiao.web.dto.candidate.TagsDTO;
import com.minixiao.web.dto.recruiters.UserDTO;
import com.minixiao.web.utils.YmlConfig;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.client.RestTemplate;

import java.util.UUID;

/**
 * @Author wangyj.
 * @Date 2017/2/28  15:14.
 */
@Controller
public class TagsController {
    @Autowired
    private YmlConfig ymlConfig;

    private RestTemplate restTemplate = new RestTemplate();


    /**
     * @Description 添加标签.
     * @Author wangyj
     * @CreateDate 2017/3/1 9:30
     * @Param
     * @Return
     */
    @PostMapping("/candidate/tags")
    public ResponseEntity<String> saveTags(@RequestBody TagsDTO tagsDTO) {
        Subject subject = SecurityUtils.getSubject();
        String result ="";
        if (subject != null) {
            UserDTO user = (UserDTO) subject.getSession().getAttribute(ymlConfig.getSession_current_user());
            if (user != null) {
                UUID recId = user.getRecId();
                UUID optUid = user.getId();
                String optName = user.getRealName();
                String recName = user.getRecName();
                HttpHeaders requestHeaders = HeaderUtil.getHeader(optUid, optName, "COMPANY", recId,
                    recName);
                HttpEntity requestEntity = new HttpEntity(tagsDTO, requestHeaders);
                ResponseEntity<String> responseEntity = restTemplate.exchange(
                    ymlConfig.getUrl_api_recruiter() + "candidate/tags", HttpMethod.POST, requestEntity,
                    String.class);
                result = responseEntity.getBody();
                if("ok".equals(result)) {
                    return ResponseEntity
                        .status(HttpStatus.OK)
                        .cacheControl(CacheControl.noCache())
                        .body(result);
                }
            }
        }
        return ResponseEntity
            .status(HttpStatus.BAD_REQUEST)
            .cacheControl(CacheControl.noCache())
            .body(result);
    }

    @DeleteMapping("/candidate/tags/{id}")
    public ResponseEntity<String> delete(@PathVariable UUID id) {
        Subject subject = SecurityUtils.getSubject();
        String result ="";
        if (subject != null) {
            UserDTO user = (UserDTO) subject.getSession().getAttribute(ymlConfig.getSession_current_user());
            if (user != null) {
                UUID recId = user.getRecId();
                UUID optUid = user.getId();
                String optName = user.getRealName();
                String recName = user.getRecName();
                HttpHeaders requestHeaders = HeaderUtil.getHeader(optUid, optName, "COMPANY", recId,
                    recName);
                HttpEntity requestEntity = new HttpEntity(null, requestHeaders);
                ResponseEntity<String> responseEntity = restTemplate.exchange(
                    ymlConfig.getUrl_api_recruiter() + "candidate/tags/{id}", HttpMethod.DELETE, requestEntity, String.class, id);
                result = responseEntity.getBody();
                return ResponseEntity
                    .status(HttpStatus.OK)
                    .cacheControl(CacheControl.noCache())
                    .body(result);
            }
        }
        return ResponseEntity
            .status(HttpStatus.BAD_REQUEST)
            .cacheControl(CacheControl.noCache())
            .body("failed");
    }
}
