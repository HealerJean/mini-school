<template>


    <div class="detail-and-history" >

        <el-tabs v-model="activeName" >
            <el-tab-pane label="简历详情" name="first">
                <div class="candidate-detail">
                    <div class="float-right">
                        <div class="candidate-status">
                            <h3>简历状态</h3>
                            <p><span>投递职位</span>&nbsp;&nbsp;&nbsp;&nbsp;<span>{{candidateDetail.jobTarget[0].job_name}}</span></p>
                            <p><span>阶段</span>&nbsp;&nbsp;&nbsp;&nbsp;<span>{{candidateDetail.stage}}</span></p>
                            <p><span>状态</span>&nbsp;&nbsp;&nbsp;&nbsp;<span>{{candidateDetail.status}}</span></p>

                        </div>

                        <div class="candidate-tags">
                            <h3>简历标签</h3>
                            <el-row  v-for="item in optNameList">
                              <el-col :span="6">{{item}}</el-col>
                              <el-col :span="12">
                                  <el-tag v-for="tag in candidateDetail.tags" v-if="item===tag.optName" :closable="tag.optName===userName" @close="removeTag(tag)">
                                    <!-- <el-tag v-for="tag in candidateDetail.tags" v-if="item===tag.optName" :closable="tag.optName==='王迎接'"@close="removeTag(tag)"> -->
                                  {{tag.tag}}
                                  </el-tag>
                              </el-col>
                            </el-row>
                        </div>
                    </div>

                    <div class="candidate-detail-body">
                        <ul>
                            <li class="basic-information-item">
                                <p>基本信息</p>
                                <el-row>
                                    <el-col :span="8">
                                        <span>姓名</span>&nbsp;&nbsp;&nbsp;&nbsp;<span>{{candidateDetail.basic.name}}</span>
                                    </el-col>
                                </el-row>
                                <el-row>
                                    <el-col :span="8">
                                        <span>性别</span>&nbsp;&nbsp;&nbsp;&nbsp;<span>{{candidateDetail.basic.gender}}</span>
                                    </el-col>
                                    <el-col :span="8">
                                        <span>出生日期</span>&nbsp;&nbsp;&nbsp;&nbsp;<span>{{candidateDetail.basic.birthday}}</span>
                                    </el-col>
                                    <el-col :span="8">
                                        <span>政治面貌</span>&nbsp;&nbsp;&nbsp;&nbsp;<span>{{candidateDetail.basic.political}}</span>
                                    </el-col>
                                </el-row>
                                <el-row>
                                    <el-col :span="8">
                                        <span>现居住地</span>&nbsp;&nbsp;&nbsp;&nbsp;<span>{{candidateDetail.basic.city}}</span>
                                    </el-col>
                                    <el-col :span="8">
                                        <span>生源地</span>&nbsp;&nbsp;&nbsp;&nbsp;<span>{{candidateDetail.basic.city}}</span>
                                    </el-col>
                                </el-row>
                                <el-row>
                                    <el-col :span="8">
                                        <span>手机号码</span>&nbsp;&nbsp;&nbsp;&nbsp;<span>{{candidateDetail.basic.mobile}}</span>
                                    </el-col>
                                    <el-col :span="8">
                                        <span>接收邮箱</span>&nbsp;&nbsp;&nbsp;&nbsp;<span>demo@minixiao.com</span>
                                    </el-col>
                                </el-row>
                            </li>
                            <li class="basic-information-item" >
                                <p class="">教育经历</p>
                                <el-row v-for="item in candidateDetail.education">
                                    <el-col :span="6">
                                        <span>{{item.start_date}}-{{item.end_date}}</span>
                                    </el-col>
                                    <el-col :span="6">
                                        <span>{{item.school}}</span>
                                    </el-col>
                                    <el-col :span="5">
                                        <span>{{item.major}}</span>
                                    </el-col>
                                    <el-col :span="7">
                                        <span>{{item.degree}}</span><span>（{{item.rank}}）</span>
                                    </el-col>
                                </el-row>
                            </li>
                            <li class="basic-information-item" v-if="candidateDetail.work">
                                <p>实习经历</p>
                                <el-row >
                                    <el-col :span="24">
                                        <p>{{candidateDetail.work}}</p>
                                    </el-col>
                                    <!-- <el-col :span="5">
                                        <span>2014.09-2015-07</span>
                                    </el-col>
                                    <el-col :span="6">
                                        <span>北京互联网科学技术有限公司</span>
                                    </el-col>
                                    <el-col :span="5">
                                        <span>销售经理</span>
                                    </el-col> -->
                                </el-row>
                            </li>
                            <li class="basic-information-item" v-if="candidateDetail.club">
                                <p>社团经历</p>
                                    <el-row >
                                        <el-col :span="24">
                                            <span>{{candidateDetail.club}}</span>
                                        </el-col>
                                    </el-row>
                            </li>
                            <li class="basic-information-item" v-if="candidateDetail.practices">
                                <p>项目经验</p>
                                <el-row >
                                    <el-col :span="24">
                                        <span>{{candidateDetail.practices}}</span>
                                    </el-col>
                                </el-row>
                            </li>
                            <li class="basic-information-item" v-if="candidateDetail.resume">
                                <p>附件简历</p>
                                <span>{{candidateDetail.resume.fileName}}</span><a href="">下载附件</a>
                            </li>
                            <li class="basic-information-item">
                                <p>其他信息</p>
                            </li>
                        </ul>
                    </div>
                    <div class="candidate-detail-footer">
                        <div class="footer-text">请对{{candidateDetail.basic.name}}的简历进行如下操作：</div>
                        <div class="controller-body">
                            <ul class="con-ul">
                                <li v-if="isShowWrittenBtn">
                                    <el-dropdown trigger="click">
                                        <el-button >安排笔试</el-button>
                                        <el-dropdown-menu slot="dropdown">
                                            <el-dropdown-item>修改笔试安排</el-dropdown-item>
                                            <el-dropdown-item>取消笔试</el-dropdown-item>
                                        </el-dropdown-menu>
                                    </el-dropdown>
                                </li>
                                <li v-if="isShowInterviewBtn">
                                    <el-dropdown trigger="click">
                                        <el-button >安排面试</el-button>
                                        <el-dropdown-menu slot="dropdown">
                                            <el-dropdown-item>修改面试安排</el-dropdown-item>
                                            <el-dropdown-item>取消面试</el-dropdown-item>
                                        </el-dropdown-menu>
                                    </el-dropdown>
                                </li>
                                <li v-if="isShowOfferBtn">
                                    <el-button @click="confirmOffer">确认offer</el-button>
                                </li>
                                <li v-if="isShowPassBtn">
                                    <el-button  @click="pass" style="background-color:#ff9900">通过</el-button>
                                </li>
                                <li v-if="isShowNotPassBtn">
                                    <el-button type="primary" @click="noPass">不通过</el-button>
                                </li>
                                <li v-if="isShowUndeterminedBtn">
                                    <el-button @click="undetermined">待定</el-button>
                                </li>
                                <li v-if="isShowWeedOutBtn">
                                    <el-button @click="weedOut">淘汰</el-button>
                                </li>
                                <li>
                                    <el-dropdown trigger="click" @command="stageJump">
                                        <el-button >阶段跳转</el-button>
                                        <el-dropdown-menu slot="dropdown">
                                            <el-dropdown-item v-for="item in recruiterFlows" :command="item.name">{{item.name}}</el-dropdown-item>

                                        </el-dropdown-menu>
                                    </el-dropdown>
                                </li>
                                <li>
                                    <el-dropdown trigger="click" @command="batchAddTag">
                                        <el-button >打标签</el-button>
                                        <el-dropdown-menu slot="dropdown" >
                                            <el-dropdown-item v-for="item in tagsList" :command="item.name" v-if="item.status">{{item.name}}</el-dropdown-item>
                                        </el-dropdown-menu>
                                    </el-dropdown>
                                </li>
                                <li>
                                    <el-button v-if="isShowEmailBtn" @click="email">发邮件</el-button>
                                </li>

                                <li>
                                    <!-- <el-popover ref="popoverExportPage" placement="right" width="400" trigger="click">
                                        <div>请输入导出指定导出页</div>
                                        <div>
                                            <el-row>
                                                <el-col :span="2">导出第</el-col>
                                                <el-col :span="8"><el-input></el-input></el-col>
                                                <el-col :span="8"><el-input></el-input></el-col>
                                                <el-col :span="6">页<el-button type="primary">导出</el-button></el-col>
                                            </el-row>
                                        </div>
                                    </el-popover> -->
                                    <el-dropdown trigger="click">
                                        <el-button >导出</el-button>
                                        <el-dropdown-menu slot="dropdown">
                                            <el-dropdown-item>导出Word</el-dropdown-item>
                                            <!-- <el-dropdown-item ><el-button type="text" v-popover:popoverExportPage>导出指定页</el-button></el-dropdown-item> -->
                                            <el-dropdown-item>导出Excel</el-dropdown-item>
                                        </el-dropdown-menu>
                                    </el-dropdown>
                                </li>
                            </ul>
                            <sent-email-message-modal :isSentEmail="showEmailModal" :candidates="candidates" @closeSentEmail="closeSentEmail" @sentEmail="sentEmail"></sent-email-message-modal>

                        </div>
                    </div>

                </div>
            </el-tab-pane>
            <el-tab-pane label="操作历史" name="second">
                <div class="candidate-history">
                    <div class="float-right">
                        <div class="candidate-status">
                            <p><span>投递职位</span>&nbsp;&nbsp;&nbsp;&nbsp;<span>{{candidateDetail.jobTarget[0].job_name}}</span></p>
                            <p><span>阶段</span>&nbsp;&nbsp;&nbsp;&nbsp;<span>{{candidateDetail.stage}}</span></p>
                            <p><span>状态</span>&nbsp;&nbsp;&nbsp;&nbsp;<span>{{candidateDetail.status}}</span></p>

                        </div>

                        <!-- <div class="candidate-detail-navigation">

                        </div> -->
                    </div>
                    <div class="candidate-history-body">
                        <el-table :data="candidateHistory.content" style="width:100%">
                            <el-table-column prop="optDate" label="日期" width="180" header-align="center" align="center" :formatter="formatDate">
                            </el-table-column>
                            <el-table-column prop="optUname" label="操作人" width="150" header-align="center"  align="center">
                            </el-table-column>
                            <el-table-column prop="status" label="操作阶段" width="150" header-align="center" align="center">
                            </el-table-column>
                            <el-table-column prop="optType" label="操作类型"  header-align="center" align="center">
                            </el-table-column>
                        </el-table>

                    </div>
                </div>
            </el-tab-pane>
        </el-tabs>
    </div>
</template>

<script type="text/babel">
import SentEmailMessageModal from '../Modal/SentEmailMessageModal.vue';

    export default {
        name: 'candidate-detail',
        data() {
            return {
                //已选候选人名单
               // multipleSelection: [],
                isShowOfferBtn:false,
                isShowWrittenBtn:false,
                isShowInterviewBtn:false,
                isShowNotPassBtn:false,
                isShowPassBtn:false,
                isShowUndeterminedBtn:false,
                isShowWeedOutBtn:false,
                isShowEmailBtn:false,

                showEmailModal:false,

                activeName: 'first',
                candidateHistory:{},

                 candidateDetail:{
                  "id": "",
                  "stuId": "",
                  "recId": "",
                  "recName": "",
                  "jobTarget": [
                    {
                      "id": "",
                      "stuId": null,
                      "area": "上海",
                      "department": "",
                      "score": 0,
                      "job_name": "",
                      "job_category": "",
                      "is_current": true,
                      "current_status": ""
                    }
                  ],
                  "basic": {
                    "name": "",
                    "gender": "",
                    "email": "",
                    "mobile": "",
                    "birthday": "",
                    "province": "",
                    "city": "",
                    "political": ""
                  },
                  "education": [
                    {
                      "rank": "1",
                      "major": "",
                      "degree": "2",
                      "school": "",
                      "end_date": "",
                      "is_highest": true,
                      "start_date": ""
                    }
                  ],
                  "stageId": null,
                  "status": "3313",
                  "tags": [
                    {
                      "id": "efdbec2a-289c-4442-b8e9-d80e172046e4",
                      "applicationId": "b9aa0c97-bac7-40ad-9eaf-3ddf0ce62857",
                      "tag": "待定",
                      "optId": "693f8256-082b-46c9-b9e4-f24aad84b911",
                      "optName": "图图",
                      "creatDate": "20170304062614"
                    }
                  ],
                  "applyDate": "20170301054309"
                 }
            }
        },
        computed:{
            candidates(){
                let candidates = new Array()
                candidates.push(this.candidateDetail);
                return candidates;
            },
            recruiterFlows(){
                return this.$store.state.candidate.recruiterFlows
            },
            tagsList(){
                return this.$store.state.candidate.tagsList
            },
            userId(){
                return this.$store.getters.userId
            },
            userName(){
                return this.$store.getters.userName
            },
            recId(){
                return this.$store.getters.recId
            },
            optNameList(){
                let set = new Set();
                for(let i=0;i<this.candidateDetail.tags.length;i++){
                    console.log(this.candidateDetail.tags[i].optName)
                    set.add(this.candidateDetail.tags[i].optName);
                }
                console.log(set);
                return [...set];
            }
        },
        methods:{
            //根据流程名字查类型
            findFlowTypeByName(){
                for(let i=0;i<this.recruiterFlows.length;i++){

                    if(this.recruiterFlows[i].name===this.candidateDetail.stage){

                        return this.recruiterFlows[i].type;
                    }
                }
            },
            getTagsList(){
                console.log('获取候选人标签列表')
                this.$http.get('company/labels').then(response =>{
                    let a = response.body;
                    console.log(a);
                    //存到状态库中

                    this.$store.commit('updateTagsList' , a);
                })
            },
            getCacdidateDetail(){
                this.$http.get('/candidate/'+this.$route.params.id).then(response =>{
                    console.log(response.body);
                    this.candidateDetail = response.body;
                    this.activeControllerButton();

                },response =>{
                    console.log(response);
                })
            },
            getCandidateHistory(){
                console.log('获取候选人历史')
                this.$http.get('/candidate/'+this.$route.params.id+'/history').then(response =>{
                    console.log(response.body);
                    this.candidateHistory = response.body;
                },response =>{
                    console.log(response);
                })
            },
            //删除标签
            removeTag(tag){
                console.log('删除标签');
                this.$http.delete('/candidate/tags/'+tag.id).then(response =>{
                    if(response.status==200){
                        this.$message({
                            message: '删除成功',
                            duration:2000
                        });
                    }else{
                        this.$message({
                            message: '操作失败',
                            duration:2000
                        });
                    }
                    console.log(response);
                    this.getCacdidateDetail();
                })
            },
            formatDate(val) {
                if(val){
                    return val.optDate.substring(0,4)+'-'+val.optDate.substring(4,6)+'-'+val.optDate.substring(6,8);
                }
            },
            getRecruiterFlows(){
                //刷新流程
                console.log('刷新流程');
                this.$http.get('/company/flows').then(
                    response => {
                       let flows = response.body;
                       console.log(flows);
                        this.$store.commit('updateRecruiterFlows' , flows)

                    });
            },

            //取消发邮件
            closeSentEmail(){
                this.showEmailModal = false;
            },
            //发邮件
            email(){
                console.log('发邮件')
                let candidates = new Array();
                candidates.push(this.candidateDetail);
                if(candidates.length===0){
                    this.$message({
                        message: '请选择操作的候选人',
                        type: 'warning',
                        duration:2000
                    });
                    return;
                };
                if(candidates.length>100){
                    this.$message({
                        message: '每次最多发送100份',
                        type: 'warning',
                        duration:2000
                    });
                };
                let noEmail = new Array();
                for(let i=0;i<candidates.length;i++ ){
                    if(!candidates[i].basic.email){
                        noEmail.push(candidates[i]);
                    }
                }
                if(noEmail.length>0){
                    this.$message({
                        message: '列表中'+noEmail[0].basic.name+'等'+noEmail.length+'人没有邮箱',
                        type: 'warning',
                        duration:2000
                    });
                    return;
                }
                this.showEmailModal = true;
            },
            //发送邮件
            sentEmail(val){
                let candidates = new Array();
                candidates.push(this.candidateDetail);
                console.log(val);
                let checkedCandidateList = new Array();
                for(let i=0;i<candidates.length;i++){
                    let a = {
                        "candidateId": candidates[i].id,
                        "candidateName" : candidates[i].basic.name,
                        "jobId": candidates[i].jobTarget[0].id,
                        "jobName": candidates[i].jobTarget[0].job_name,
                        "email":candidates[i].basic.email

                    }
                    checkedCandidateList.push(a);
                }
                let checkedCandidateLData = {
                    "emailSendDTOs":checkedCandidateList,
                    "stage":this.activeRecruiterFlowName,
                    "status":"已通知",
                    "localInfo":"",
                    "content": val.content,
                    "title": val.title
                };

                this.$http.post('/candidate/email',checkedCandidateLData,{headers: {'Content-Type':'application/json'}}).then(response =>{
                    if(response.status==200){
                        this.$message({
                            message: '操作成功',
                            duration:2000
                        });
                    }else{
                        this.$message({
                            message: '操作失败',
                            duration:2000
                        });
                    }

                this.getCacdidateDetail();
                },response =>{

                });
            },
            nextStage(){
                for(let i=0;i<this.recruiterFlows.length;i++){
                    if(this.candidateDetail.stage===this.recruiterFlows[i].name){
                        return this.recruiterFlows[i+1].name;
                    }
                }
            },
            //通过操作
            pass(){
                console.log('通过')

                let candidates = new Array();
                candidates.push(this.candidateDetail);
                if(candidates.length===0){
                    this.$message({
                        message: '请选择操作的候选人',
                        type: 'warning',
                        duration:2000
                    });
                    return;
                }

                let toStage =this.nextStage();
                let jumpStageList = new Array();
                for(let i=0;i<candidates.length;i++){
                    let a = {
                        "id": candidates[i].id,
                        "stuId":candidates[i].stuId,
                        "jobId": candidates[i].jobTarget[0].id,
                        "jobName": candidates[i].jobTarget[0].job_name,
                        "candidateName" : candidates[i].basic.name
                    }
                    jumpStageList.push(a);
                }
                let jumpStageData = {
                    "appStageListDTOs":jumpStageList,
                    "fromStage":this.candidateDetail.stage,
                    "toStage":toStage
                };

                this.$http.put('/candidate/stage/pass',jumpStageData,{headers: {'Content-Type':'application/json'}}).then(response =>{
                    if(response.status==200){
                        this.$message({
                            message: '操作成功',
                            duration:2000
                        });
                    }else{
                        this.$message({
                            message: '操作失败',
                            duration:2000
                        });
                    }
                    console.log(response.body);
                this.getCacdidateDetail();

                },response =>{

                });


            },
            //不通过
            noPass(){
                console.log('不通过')
                let candidates = new Array();
                candidates.push(this.candidateDetail);
                if(candidates.length===0){
                    this.$message({
                        message: '请选择操作的候选人',
                        type: 'warning',
                        duration:2000
                    });
                    return;
                }
                let checkedCandidateList = new Array();
                for(let i=0;i<candidates.length;i++){
                    let a = {
                        "id": candidates[i].id,
                        "stuId":candidates[i].stuId,
                        "jobId": candidates[i].jobTarget[0].id,
                        "jobName": candidates[i].jobTarget[0].job_name,
                        "candidateName" : candidates[i].basic.name
                    }
                    checkedCandidateList.push(a);
                }
                let checkedCandidateLData = {
                    "appStageListDTOs":checkedCandidateList,
                    "stage":this.activeRecruiterFlowName,
                    "status":"不通过"
                };

                this.$http.put('/candidate/status',checkedCandidateLData,{headers: {'Content-Type':'application/json'}}).then(response =>{
                    if(response.status==200){
                        this.$message({
                            message: '操作成功',
                            duration:2000
                        });
                    }else{
                        this.$message({
                            message: '操作失败',
                            duration:2000
                        });
                    }
                this.getCacdidateDetail();
                },response =>{

                    console.log(response.body);
                });
            },
            //确认offer
            confirmOffer(){
                console.log('确认offer')
                let candidates = new Array();
                candidates.push(this.candidateDetail);
                if(candidates.length===0){
                    this.$message({
                        message: '请选择操作的候选人',
                        type: 'warning',
                        duration:2000
                    });
                    return;
                }
                let checkedCandidateList = new Array();
                for(let i=0;i<candidates.length;i++){
                    let a = {
                        "id": candidates[i].id,
                        "stuId":candidates[i].stuId,
                        "jobId": candidates[i].jobTarget[0].id,
                        "jobName": candidates[i].jobTarget[0].job_name,
                        "candidateName" : candidates[i].basic.name
                    }
                    checkedCandidateList.push(a);
                }
                let checkedCandidateLData = {
                    "appStageListDTOs":checkedCandidateList,
                    "stage":this.activeRecruiterFlowName,
                    "status":"确定OFFER"
                };

                this.$http.put('/candidate/status',checkedCandidateLData,{headers: {'Content-Type':'application/json'}}).then(response =>{
                    if(response.status==200){
                        this.$message({
                            message: '操作成功',
                            duration:2000
                        });
                    }else{
                        this.$message({
                            message: '操作失败',
                            duration:2000
                        });
                    }

                this.getCacdidateDetail();
                },response =>{

                });
            },
            //淘汰
            weedOut(){
                console.log('淘汰')
                let candidates = new Array();
                candidates.push(this.candidateDetail);
                if(candidates.length===0){
                    this.$message({
                        message: '请选择操作的候选人',
                        type: 'warning',
                        duration:2000
                    });
                    return;
                }
                let checkedCandidateList = new Array();
                for(let i=0;i<candidates.length;i++){
                    let a = {
                        "id": candidates[i].id,
                        "stuId":candidates[i].stuId,
                        "jobId": candidates[i].jobTarget[0].id,
                        "jobName": candidates[i].jobTarget[0].job_name,
                        "candidateName" : candidates[i].basic.name
                    }
                    checkedCandidateList.push(a);
                }
                let checkedCandidateLData = {
                    "appStageListDTOs":checkedCandidateList,
                    "stage":this.activeRecruiterFlowName,
                    "status":"淘汰"
                };

                this.$http.put('/candidate/status',checkedCandidateLData,{headers: {'Content-Type':'application/json'}}).then(response =>{
                    if(response.status==200){
                        this.$message({
                            message: '操作成功',
                            duration:2000
                        });
                    }else{
                        this.$message({
                            message: '操作失败',
                            duration:2000
                        });
                    }

                this.getCacdidateDetail();
                },response =>{

                });
            },
            //待定
            undetermined(){
                console.log('待定')
                let candidates = new Array();
                candidates.push(this.candidateDetail);
                if(candidates.length===0){
                    this.$message({
                        message: '请选择操作的候选人',
                        type: 'warning',
                        duration:2000
                    });
                    return;
                }
                let checkedCandidateList = new Array();
                for(let i=0;i<candidates.length;i++){
                    let a = {
                        "id": candidates[i].id,
                        "stuId":candidates[i].stuId,
                        "jobId": candidates[i].jobTarget[0].id,
                        "jobName": candidates[i].jobTarget[0].job_name,
                        "candidateName" : candidates[i].basic.name
                    }
                    checkedCandidateList.push(a);
                }
                let checkedCandidateLData = {
                    "appStageListDTOs":checkedCandidateList,
                    "stage":this.activeRecruiterFlowName,
                    "status":"待定"
                };

                this.$http.put('/candidate/status',checkedCandidateLData,{headers: {'Content-Type':'application/json'}}).then(response =>{
                    if(response.status==200){
                        this.$message({
                            message: '操作成功',
                            duration:2000
                        });
                    }else{
                        this.$message({
                            message: '操作失败',
                            duration:2000
                        });
                    }
                this.getCacdidateDetail();
                },response =>{

                });
            },
            //阶段跳转
            stageJump(toStage){
                //console.log('跳转到'+toStage);
                let candidates = new Array();
                candidates.push(this.candidateDetail);
                if(candidates.length===0){
                    this.$message({
                        message: '请选择操作的候选人',
                        type: 'warning',
                        duration:3000
                    });
                    return;
                }
                let jumpStageList = new Array();
                for(let i=0;i<candidates.length;i++){
                    let a = {
                        "id": candidates[i].id,
                        "stuId":candidates[i].stuId,
                        "jobId": candidates[i].jobTarget[0].id,
                        "jobName": candidates[i].jobTarget[0].job_name,
                        "candidateName" : candidates[i].basic.name
                    }
                    jumpStageList.push(a);
                }
                let jumpStageData = {
                    "appStageListDTOs":jumpStageList,
                    "fromStage":this.candidateDetail.stage,
                    "toStage":toStage
                };
                console.log(jumpStageData);

                this.$http.put('/candidate/stage/skip',jumpStageData,{headers: {'Content-Type':'application/json'}}).then(response =>{
                    if(response.status==200){
                        this.$message({
                            message: '操作成功',
                            duration:2000
                        });
                    }else{
                        this.$message({
                            message: '操作失败',
                            duration:2000
                        });
                    }
                this.getCacdidateDetail();
                },response =>{
                    console.log(response.body);

                });
            },
            batchAddTag(tag){
                console.log('打标签'+tag);
                let candidates = new Array();
                candidates.push(this.candidateDetail);
                if(candidates.length===0){
                    this.$message({
                        message: '请选择操作的候选人',
                        type: 'warning',
                        duration:2000
                    });
                    return;
                }
                // for(let i=0;i<candidates.length;i++){
                //     let ownTags = new Array();
                //     let cts = candidates[i].tags
                //     for(let j=0;j<cts.length;i++){
                //         if(cts[j].optId === this.userId){
                //             ownTags.push(cts[j]);
                //         }
                //     }
                //     if(ownTags.length>=3){
                //         this.$message({
                //             message: '您已经对'+candidates[i].basic.name+'打过3个标签',
                //             type: 'warning',
                //             duration:2000
                //         });
                //         return;
                //     }
                //     if(ownTags.find(tag)){
                //         this.$message({
                //             message: '您已经对'+candidates[i].basic.name+'打过此标签',
                //             type: 'warning',
                //             duration:2000
                //         });
                //         return;
                //     }
                // }

                let addTagList = new Array();
                for(let i=0;i<candidates.length;i++){
                    let a = {
                        "id": candidates[i].id,
                        "jobId": candidates[i].jobTarget[0].id,
                        "jobName": candidates[i].jobTarget[0].job_name,
                        "candidateName" : candidates[i].basic.name
                    }
                    addTagList.push(a);

                }

                let addTagData = {
                    "tags":tag,
                    "appTagList":addTagList,
                    "optId":this.userId,
                    "optName":this.userName,
                    "stage":this.activeRecruiterFlowName
                }




                this.$http.post('/candidate/tags',addTagData,{headers: {'Content-Type':'application/json'}}).then(response =>{
                    if(response.status==200){
                        this.$message({
                            message: '操作成功',
                            duration:2000
                        });
                    }else{
                        this.$message({
                            message: '操作失败',
                            duration:2000
                        });
                    }
                   this.getCacdidateDetail();
                })
            },







            //控制按钮按流程显示
            activeControllerButton(){
                if(this.findFlowTypeByName()==='筛选类型'){
                    this.isShowWrittenBtn =false;
                    this.isShowInterviewBtn =false;
                    this.isShowNotPassBtn =true;
                    this.isShowPassBtn =true;
                    this.isShowUndeterminedBtn = true;
                    this.isShowEmailBtn = false;
                    this.isShowWeedOutBtn = false;
                    this.isShowOfferBtn = false;
                }
                if(this.findFlowTypeByName()==='笔试类型'){
                    this.isShowWrittenBtn =true;
                    this.isShowInterviewBtn =false;
                    this.isShowNotPassBtn =true;
                    this.isShowPassBtn =true;
                    this.isShowUndeterminedBtn = false;
                    this.isShowEmailBtn = true;
                    this.isShowWeedOutBtn = false;
                    this.isShowOfferBtn = false;
                }
                if(this.findFlowTypeByName()==='面试类型'){
                    this.isShowWrittenBtn =false;
                    this.isShowInterviewBtn =true;
                    this.isShowNotPassBtn =true;
                    this.isShowPassBtn =true;
                    this.isShowUndeterminedBtn = false;
                    this.isShowEmailBtn = true;
                    this.isShowWeedOutBtn = false;
                    this.isShowOfferBtn = false;
                }
                if(this.findFlowTypeByName()==='录用类型'){
                    this.isShowWrittenBtn =false;
                    this.isShowInterviewBtn =false;
                    this.isShowNotPassBtn =false;
                    this.isShowPassBtn =false;
                    this.isShowUndeterminedBtn = false;
                    this.isShowEmailBtn = true;
                    this.isShowWeedOutBtn = true;
                    this.isShowOfferBtn = true;
                }
            },
        },
        created(){
            console.log('加载成功');
            console.log(this.$route.params);
            this.getCacdidateDetail();
            this.getCandidateHistory();
            this.getTagsList();
            this.getRecruiterFlows();

        },
        mounted(){
           // this.multipleSelection.push(this.candidateDetail);

            console.log(this.findFlowTypeByName()+'流程类型');
        },
        components:{
            SentEmailMessageModal
        }
    }

</script>

<style lang="less" >
    .detail-and-history {
        width:1180px;
        margin-top:20px;
        // position: relative;
        overflow: hidden;
        ul {
            padding:0;
            margin:0;
            li {
                list-style-type:none;
            }
        }
        .float-right {

             float:right;
            .candidate-status {
                width:220px;
                height:156px;
                padding:20px;
                background-color: #fff;

            }
            .candidate-tags {
                margin-top: 20px;
                width:220px;
                padding:20px;
                background-color: #fff;
                .el-tag {
                    margin:2px;
                    border-radius: 10px;
                    height: 20px;
                    line-height: 18px;
                    background-color: #ffd86f;
                    color: #464646;
                    border-color: #ffbc05;
                }
            }
        }
        .el-tabs__header {
            background-color: #fff;
        }
        .candidate-history {
            .candidate-history-body {
                width:900px;
                background-color: #fff;
            }
        }

        .candidate-detail {
            .candidate-detail-footer {
                width:100%;
                height:120px;
                background-color: #313131;
                position: fixed;
                bottom:0;
                left: 0;
                text-align: center;
                .footer-text {
                    color:#ffffff;
                    font-size: 20px;
                }
                .controller-body {
                    height:50px;

                    text-align: center;

                    .con-ul {
                        padding:0;
                        margin:0;
                        li{
                            list-style-type:none;
                            display: inline-block;
                           // float: left;
                            height:30px;
                            margin:10px 0px;
                            text-align:center;
                            line-height: 30px;

                        }
                    }

                }

            }

            .el-row {
                margin:0;
            }
            width:1180px;
            background-color: #f6f6f6;
            .padding_left_4 {
                padding-left: 4px;
            }
            .candidate-simple {
                border-bottom: 1px solid #ddd;
                width: 860px;
                padding: 30px 20px;
                background-color: #fff;
                overflow: auto;


               .candidate-header {

                    width: 90px;
                    height:90px;
                    display: inline-block;
                    float:left;
                    margin-right: 20px;
                    .candidate-headerImg {
                        border-radius:50%;
                        width: 90px;
                        height:90px;
                    }
                }
                .candidate-basic {
                    // border: 1px solid transparent;
                    width: 600px;
                    display: inline-block;
                    float:left;
                    overflow: auto;
                    .candidate-name {
                        font-size: 20px;
                    }
                    ul {

                        li {

                            list-style-type:none;
                            display: inline-block;
                            float: left;
                            text-align:center;
                            span {
                                border-right: 1px solid #000000;
                                padding: 0 4px;
                                font-size: 15px;
                                line-height: 24px;
                            }
                        }
                        :last-child span{
                            border-right:1px solid transparent;
                        }
                    }
                }
            }
            .candidate-detail-body {
                width: 860px;
                padding: 20px;
                background-color: #fff;
                overflow: hidden;
                ul {

                    padding:0;
                    margin:0;

                    li {
                        list-style-type: none;
                        p {
                            margin:0;
                            border-bottom: 1px dashed #e2e2e2;
                            font-size: 16px;
                            line-height: 36px;
                            margin-bottom: 20px;
                            margin-top: 6px;
                        }
                        .el-row {
                            margin-bottom: 14px;
                        }
                    }
                }
            }
        }
    }





</style>
