<template>
    <div class="resume">
       <!--  <el-input placeholder="搜索" icon="search" v-model="searchContent" :on-icon-click="handleIconClick" v-on:keyup.enter="search" class="candidate-search" >
    </el-input> -->
        <!-- <div>{{activeRecruiterFlowType}}-{{activeRecruiterFlowTab}}</div> -->
        <el-tabs v-model="activeRecruiterFlowTab">
        <!-- <el-tab-pane name="初筛">
            <span slot="label">初筛（57）</span>
            <candidate-manage-model :workflow="chushai"></candidate-manage-model>
        </el-tab-pane> -->

        <el-tab-pane  v-for="(item,index) in recruiterFlows" :name="'recruiterFlow'+index">
            <span slot="label">{{item.name}}（{{item.candidateCount}}）</span>
            <candidate-manage-model :modalName="item.name" :currentRecruiterFlowIndex="index" @refresh-workflow="getRecruiterFlows"></candidate-manage-model>
        </el-tab-pane>

        <!-- <el-tab-pane name="录用">
            <span slot="label">录用（89）</span>
            <candidate-manage-model :workflow="luyong"></candidate-manage-model>
        </el-tab-pane> -->
  </el-tabs>
    </div>
</template>

<script type="text/babel">

import CandidateManageModel from './CandidateManageModel.vue'

    export default {
        name: 'candidate-manage',

        data:function(){
            return{
            }
        },
        components: {
            CandidateManageModel
        },

        computed: {
            userId(){
                return this.$store.getters.userId
            },
            userName(){
                return this.$store.getters.userName
            },
            recId(){
                return this.$store.getters.recId
            },
            recruiterFlows(){
                return this.$store.state.candidate.recruiterFlows
            },
            activeRecruiterFlowTab: {
                get () {
                    return this.$store.state.candidate.activeRecruiterFlowTab
                },
                set (value) {
                    this.$store.commit('updateActiveRecruiterFlowTab' , value)
                }
            },
            // searchContent: {
            //     get () {
            //         return this.$store.state.candidate.searchContent
            //     },
            //     set (value) {
            //         this.$store.commit('updateSearchContent' , value)
            //     }
            // },
            activeRecruiterFlowType () {
                return this.$store.getters.activeRecruiterFlow.type
            }
        },
        methods:{
            getRecruiterFlows(){
                //刷新流程
                console.log('刷新流程');
                this.$http.get('/company/flows').then(
                    response => {
                       let flows = response.body;
                       console.log(flows);
                        this.$store.commit('updateRecruiterFlows' , flows)

                    });
            }
        },
        mounted(){

        },
        created(){
            this.getRecruiterFlows();
        }

    }

</script>

<style lang="less" >
    .resume {
        width: 1180px;
        margin: auto;
        // .candidate-search {
        //     float: right;
        //     width:286px;
        //     height:34px;
        //     z-index:2;
        //     .el-input__inner {
        //         height:34px;
        //         padding-left: 30px;
        //     }
        //     .el-input__icon {
        //         cursor: pointer;
        //         left:0;
        //     }
        // }


    }
</style>
