<template>
    <div class="account">
        <div>我的位置：
            <el-breadcrumb separator=">">
                <el-breadcrumb-item>个人中心</el-breadcrumb-item>
                <el-breadcrumb-item>账号管理</el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        <div class="account-body">
            <el-tabs v-model="activeName">
                <el-tab-pane label="基本资料" name="first">
                    <el-form   label-width="150px" :rules="ruleBasic" ref="modifyBasic" :model="modifyBasic">
                        <el-form-item label="账号：" >
                            <span>{{account}}</span>
                        </el-form-item>
                        <el-form-item label="姓名：" :required="true" prop="name">
                            <el-input :autofocus="true" v-model="modifyBasic.name"></el-input>
                        </el-form-item>
                        <el-form-item label="固话：" prop="tel">
                            <el-input v-model="modifyBasic.teleplone"></el-input>
                        </el-form-item>
                        <el-form-item label="手机：">
                            <el-input v-model="modifyBasic.mobile" prop="mobile"></el-input>
                        </el-form-item>
                        <el-form-item>
                            <el-button type="primary" @click="submitBasicForm('modifyBasic')">提交</el-button>
                        </el-form-item>
                    </el-form>

                </el-tab-pane>
                <el-tab-pane label="修改密码" name="second">
                    <el-form :model="modifyPwd" label-width="150px" :rules="rulePwd" ref="modifyPwd">
                        <el-form-item label="旧密码：" :required="true" prop="oldPwd">
                            <el-input type="password" :autofocus="true" v-model="modifyPwd.oldPwd"></el-input>
                        </el-form-item>
                        <el-form-item label="新密码：" :required="true" prop="newPwd">
                            <el-input type="password" v-model="modifyPwd.newPwd"></el-input>
                        </el-form-item>
                        <el-form-item  label="重新输入密码：" :required="true" prop="newPwd2">
                            <el-input type="password" v-model="modifyPwd.newPwd2"></el-input>
                        </el-form-item>
                        <el-form-item>
                            <el-button type="primary" @click="submitForm('modifyPwd')">提交</el-button>
                            <el-button @click="resetForm('modifyPwd')">清空</el-button>
                        </el-form-item>
                    </el-form>

                </el-tab-pane>

            </el-tabs>
        </div>
    </div>
</template>

<script type="text/babel">

    export default {
        name: 'account',
        data:function(){
            let validateName = (rule,value,callback) => {
                if (value === ''){
                    callback(new Error('请输入名字'));
                }else {
                    callback();
                }
            };
            let validateOldpwd = (rule,value,callback) => {
                if (value === ''){
                    callback(new Error('请输入原密码'));
                }else {
                    callback();
                }
            };
            let validatePwd = (rule,value,callback) => {
                if (value === ''){
                    callback(new Error('请输入密码'));
                }else {
                    if(this.modifyPwd.newPwd2 !== ''){
                        this.$refs.modifyPwd.validateField('newPwd2');
                    }
                    callback();
                }
            };
            let validatePwd2 = (rule,value,callback) => {
                if (value === ''){
                    callback(new Error('请再次输入密码'));
                } else if (value!== this.modifyPwd.newPwd){
                    callback(new Error('两次密码不一致'));
                }else{
                    callback();
                }

            };

            return{
                account:'',
                modifyBasic:{
                    name:'',
                    teleplone:'',
                    mobile:''
                },
                modifyPwd: {
                    oldPwd:'',
                    newPwd:'',
                    newPwd2:''
                },
                rulePwd: {
                    oldPwd: [
                        {validator: validateOldpwd, trigger:'blur'}
                    ],
                    newPwd: [
                        {validator: validatePwd, trigger:'blur'}
                    ],
                    newPwd2: [
                        {validator: validatePwd2, trigger:'blur'}
                    ],

                },
                ruleBasic:{
                     name: [
                        {validator: validateName, trigger:'blur'}
                      ]
                },
                activeName: 'first',
            }
        },
        methods:{
            submitBasicForm(formName) {
                console.log("修改资料")
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        let a = {
                            email:this.account,
                            realName:this.modifyBasic.name,
                            tel:this.modifyBasic.teleplone,
                            mobile:this.modifyBasic.mobile
                        }
                        this.$http.put('/company/users/self',a,{headers: {'Content-Type':'application/json'}}).then(response =>{
                            if(response.status==200){
                                this.$message({
                                    message: '操作成功',
                                    duration:2000
                                });
                            }else{
                                this.$message({
                                    message: '操作失败',
                                    duration:2000
                                });
                            }
                        })
                    } else {
                        this.$message({
                                message: '请按要求填写',
                                duration:2000
                            });
                        return false;
                    }
                });
            },
            submitForm(formName) {
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        let a = {
                            oldPwd:this.modifyPwd.oldPwd,
                            newPwd:this.modifyPwd.newPwd,
                            newPwdConfirm:this.modifyPwd.newPwd2

                        }
                        this.$http.put('/company/users/pwd',a,{headers: {'Content-Type':'application/json'}}).then(response =>{
                            if(response.status==200){
                                this.$message({
                                    message: '操作成功',
                                    duration:2000
                                });
                            }else{
                                this.$message({
                                    message: '操作失败',
                                    duration:2000
                                });
                            }
                        })
                    } else {
                        this.$message({
                                message: '请按要求填写',
                                duration:2000
                            });
                        return false;
                    }
                });
            },
            resetForm(formName) {
                this.$refs[formName].resetFields();
            },
            getBasic(){
                this.$http.get('/company/user').then(response =>{
                    this.account = response.body.email;
                    this.modifyBasic.name=response.body.realName;
                    this.modifyBasic.teleplone = response.body.tel;
                    this.modifyBasic.mobile = response.body.mobile;
                })
            }

        },
        created(){
            this.getBasic();
        }
    }

</script>

<style lang="less">
    .account {
        .el-breadcrumb {
            display: inline-block;
        }
        .account-body {
            background-color: #ffffff;
            margin-top: 20px;
            .el-input {
                width:450px;
            }
            .el-form-item {
                margin-bottom: 22px;
            }
        }
    }
</style>
