package cn.edu.dlut.career.service.company;



import cn.edu.dlut.career.domain.company.LargeJob;

import java.util.List;

/**
 * 大招预约职位 服务层 接口
 * Created by HealerJean on 2017/3/24.
 */
public interface LargeJobService {
    //保存，添加
    LargeJob saveLargeJob(LargeJob largeJob) ;

    //根据id查询
    LargeJob findById(String id);

    // 更新
    LargeJob updateLargeJob(LargeJob largeJob);

    //根据id删除 删除成功返回 ok ，否则 null
    String deleteLargeJob(String id);

    //查询所有的数据
    List<LargeJob> findAllLargeJob();

}
