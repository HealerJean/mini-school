package com.minixiao.web.email;

/**
 * @Author wangyj.
 * @Date 2017/3/13  18:01.
 */
public class HtmlUtils {

    public static String getHtml(String content){
        String head = "<!DOCTYPE html>\n" +
            "<html lang=\"en\">\n" +
            "<head>\n" +
            "    <meta charset=\"UTF-8\">\n" +
            "    <title>邮件提醒</title>\n" +
            "</head>\n" +
            "<body style=\"background:#000;\">\n" +
            "<div style=\"width:700px; background:#fff;\">\n" +
            "    <div style=\"border-bottom:1px solid #00a0e9; padding:16px 25px; margin:0 10px; text-align: left;\"><img src=\"http://www.minixiao.com/st/edm/logo.png\" alt=\"迷你校LOGO\"></div>\n" +
            "    \n" +
            "    <div style=\"padding:0 25px;\">\n" +
            "        <div style=\"border:1px solid #00a0e9; padding:8px 14px; margin-bottom:10px\">";

        String tail ="  </div>\n" +
            "    </div>\n" +
            "\n" +
            "    <div><img src=\"http://www.minixiao.com/st/edm/QRbg.png\" alt=\"\"></div>\n" +
            "    <div style=\"margin:20px 10px 0; border-top:1px solid #bfbfbf;border-bottom:1px solid #bfbfbf; text-align: center; color:#999; font-size:12px; line-height: 18px; padding:5px 0;\">\n" +
            "        如在使用过程中有任何疑问和建议，欢迎联系我们！<br>\n" +
            "        Email：advise@minixiao.com\n" +
            "    </div>\n" +
            "    <div style=\"color:#4e4e4e; font-size:12px; line-height: 34px; text-align: center\">如果您不想收到此类邮件，请<a style=\"color:#049cff; text-decoration:none; cursor:pointer\" href=\"http://www.minixiao.com\" target=\"_blank\">点击退订</a></div>\n" +
            "</div>\n" +
            "</body>\n" +
            "</html>";
        StringBuffer html =new StringBuffer();
        html.append(head).append(content).append(tail);
         return html.toString();
    }

    public static String  getRefuesdEmail(String candidateName ,String recName){
    String html = "<!DOCTYPE html>\n" +
        "<html lang=\"en\">\n" +
        "<head>\n" +
        "    <meta charset=\"UTF-8\">\n" +
        "    <title>邮件提醒</title>\n" +
        "</head>\n" +
        "<body style=\"background:#000;\">\n" +
        "<div style=\"width:700px; background:#fff;\">\n" +
        "    <div style=\"border-bottom:1px solid #00a0e9; padding:16px 25px; margin:0 10px; text-align: left;\"><img src=\"http://www.minixiao.com/st/edm/logo.png\" alt=\"迷你校LOGO\"></div>\n" +
        "    \n" +
        "<div style=\"margin: 20px 0;\">\n" +
        candidateName+"同学您好！ <br />\n" +
        "迷你校抱歉的通知您：经过"+recName+"企业综合考量，您针对于该企业的内推流程已经终止，不过迷你校会帮您继续关注其他企业的校招，同时也请您继续通过迷你校平台关注其他企业的校园招聘。\n" +
        "同时您也可以登录迷你校后台，查看自己的内推流程。\n" +
        "</div>\n" +
        "\n" +
        "    <div><img src=\"http://www.minixiao.com/st/edm/QRbg.png\" alt=\"\"></div>\n" +
        "    <div style=\"margin:20px 10px 0; border-top:1px solid #bfbfbf;border-bottom:1px solid #bfbfbf; text-align: center; color:#999; font-size:12px; line-height: 18px; padding:5px 0;\">\n" +
        "        如在使用过程中有任何疑问和建议，欢迎联系我们！<br>\n" +
        "        Email：advise@minixiao.com\n" +
        "    </div>\n" +
        "    <div style=\"color:#4e4e4e; font-size:12px; line-height: 34px; text-align: center\">如果您不想收到此类邮件，请<a style=\"color:#049cff; text-decoration:none; cursor:pointer\" href=\"http://www.minixiao.com\" target=\"_blank\">点击退订</a></div>\n" +
        "</div>\n" +
        "</body>\n" +
        "</html>";

    return html;
    }
}
