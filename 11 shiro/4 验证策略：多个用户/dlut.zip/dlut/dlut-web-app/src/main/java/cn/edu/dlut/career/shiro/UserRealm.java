package cn.edu.dlut.career.shiro;

import cn.edu.dlut.career.dto.company.RecLoginDTO;
import cn.edu.dlut.career.service.company.CompanyInfoService;
import org.apache.shiro.authc.AccountException;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authz.AuthorizationException;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.cache.Cache;
import org.apache.shiro.crypto.hash.Md5Hash;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.subject.SimplePrincipalCollection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * 用户登录认证处理
 */
public class UserRealm extends AuthorizingRealm {
    private static final Logger logger = LoggerFactory.getLogger(UserRealm.class);

    @Autowired
    private CompanyInfoService companyInfoService;
    /**
     * 用户认证处理
     */
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken authcToken)
        throws AuthenticationException {
        SimpleAuthenticationInfo info = null;
        UserLoginToken token = (UserLoginToken) authcToken;
        String username = token.getUsername();
        //通过type判断登录的类型，决定调用哪一个认证方法
        String type = token.getType();
        if (username == null) {
            throw new AccountException("Null usernames are not allowed by this realm.");
        }
        if (token.getPassword().length < 1) {
            throw new UnknownAccountException("Null password are not allowed by this realm.");
        }

        //调用企业认证
        if ("COMPANY".equals(type)) {
            try {
                RecLoginDTO recLoginDTO  = companyInfoService.findLoginInfo(username);
                if(recLoginDTO!=null){
                    //对原密码用盐加密处理后认证
                    String salt = recLoginDTO.getSalt();
                    char[] pwd = new Md5Hash(token.getPassword(), salt).toString().toCharArray();
                    token.setPassword(pwd);
                     info= new SimpleAuthenticationInfo(new UserPrincipal(recLoginDTO.getId(),recLoginDTO.getName(),recLoginDTO.getEmail(),"COMPANY"),
                        recLoginDTO.getPwd(),getName());
                    logger.info("用户:" + username + "登陆");
                    return info;
                } else{
                    throw  new AuthenticationException("No this user.");
                }
            } catch (Exception e) {
                throw new AuthenticationException(e.getMessage());
            }
        }else if("STUDENT".equals(type)){
            // TODO: 2017/4/6 学生认证实现
            return null;
        }else if("TEACHER".equals(type)){
            // TODO: 2017/4/6 教师认证实现
            return null;
        }else{
            return null;
        }
    }

    /**
     * 获取用户授权信息
     */
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principals) {
        if (principals == null) {
            throw new AuthorizationException("PrincipalCollection method argument cannot be null.");
        }
        Object obj = getAvailablePrincipal(principals);
        UserPrincipal principal = (UserPrincipal) obj;
        String userRole = "";
        if (principal.getRole()!=null) {
            principal.getRole();
        }
        SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();
        info.addRole(userRole);

        return info;
    }

    /**
     * 清空用户关联权限认证，待下次使用时重新加载。
     *
     * @param principal
     */
    public void clearCachedAuthorizationInfo(String principal) {
        SimplePrincipalCollection principals = new SimplePrincipalCollection(principal, getName());
        clearCachedAuthorizationInfo(principals);
    }

    /**
     * 清空所有关联认证
     */
    public void clearAllCachedAuthorizationInfo() {
        Cache<Object, AuthorizationInfo> cache = getAuthorizationCache();
        if (cache != null) {
            for (Object key : cache.keys()) {
                cache.remove(key);
            }
        }
    }
}
