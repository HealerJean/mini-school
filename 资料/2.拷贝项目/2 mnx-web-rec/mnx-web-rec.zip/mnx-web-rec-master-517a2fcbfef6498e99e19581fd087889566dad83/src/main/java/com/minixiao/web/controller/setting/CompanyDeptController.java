package com.minixiao.web.controller.setting;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.minixiao.apiauth.client.HeaderUtil;
import com.minixiao.web.dto.recruiters.CompanyDeptDTO;
import com.minixiao.web.dto.recruiters.UserDTO;
import com.minixiao.web.utils.YmlConfig;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Created by xiachao on 2017/3/2.
 */
@RestController
public class CompanyDeptController {

    private Logger logger = LoggerFactory.getLogger(CompanyDeptController.class);

    @Autowired
    private YmlConfig ymlConfig;

    private RestTemplate restTemplate = new RestTemplate();

    private ObjectMapper objectMapper = new ObjectMapper();

    /**
     * @Description 根据公司Id查询该公司下的所有部门.
     * @Author xiachao
     * @CreateTime 2017/3/2 13:59
     * @Param
     * @Return
     */
    @GetMapping("company/departments")
    public String findAllRecruiterDept() {
            Subject subject = SecurityUtils.getSubject();
            if (subject != null) {
                UserDTO user = (UserDTO) subject.getSession().getAttribute(
                    ymlConfig.getSession_current_user());
                if (user != null) {
                    UUID userId2 = user.getId();
                    String userName = user.getRealName();
                    UUID recId2 = user.getRecId();
                    String recName = user.getRecName();
                    HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                        recId2, recName);
                    HttpEntity requestEntity = new HttpEntity(null, httpHeaders);
                    ResponseEntity<String> responseEntity = restTemplate.exchange(
                        ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2 + "/departments", HttpMethod.GET,
                        requestEntity, String.class);
                    if (responseEntity.getStatusCodeValue() == 200) {
                        return responseEntity.getBody();
                    }
                }
            }
        return null;
    }


    /**
     * @Description 默认为公司创建一个一级部门 即公司全称作为公司的一级部门.
     * @Author xiachao
     * @CreateTime 2017/3/2 13:36
     * @Param
     * @Return
     */
    @PostMapping("company/department/init")
    public String initRecruiterDept() {
            Subject subject = SecurityUtils.getSubject();
            if (subject != null) {
                UserDTO user = (UserDTO) subject.getSession().getAttribute(
                    ymlConfig.getSession_current_user());
                if (user != null) {
                    UUID userId2 = user.getId();
                    String userName = user.getRealName();
                    UUID recId2 = user.getRecId();
                    String recName = user.getRecName();
                    HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                        recId2, recName);
                    httpHeaders.setContentType(MediaType.APPLICATION_JSON_UTF8);
                    Map<String, String> map = new HashMap<String, String>();
                    map.put("name", recName);
                    String requestBody = "";
                    try {
                        requestBody = objectMapper.writeValueAsString(map);
                    } catch (JsonProcessingException ex) {
                        ex.printStackTrace();
                    }
                    HttpEntity requestEntity = new HttpEntity(requestBody, httpHeaders);
                    ResponseEntity<String> responseEntity = restTemplate.exchange(
                        ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2 + "/department/init", HttpMethod.POST,
                        requestEntity, String.class);
                    if (responseEntity.getStatusCodeValue() == 200) {
                        return "初始化一级部门成功";
                    }
                }
        }
        return null;
    }

    /**
     * @Description 公司创建部门.
     * @Author xiachao
     * @CreateTime 2017/3/2 12:01
     * @Param
     * @Return
     */
    @PostMapping("company/department")
    public String createRecruiterDept(@RequestBody CompanyDeptDTO companyDeptDTO) {
        if (companyDeptDTO != null) {
            Subject subject = SecurityUtils.getSubject();
            if (subject != null) {
                UserDTO user = (UserDTO) subject.getSession().getAttribute(
                    ymlConfig.getSession_current_user());
                if (user != null) {
                    UUID userId2 = user.getId();
                    String userName = user.getRealName();
                    UUID recId2 = user.getRecId();
                    String recName = user.getRecName();
                    HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                        recId2, recName);
                    httpHeaders.setContentType(MediaType.APPLICATION_JSON_UTF8);
                    HttpEntity<CompanyDeptDTO> requestEntity = new HttpEntity<CompanyDeptDTO>(companyDeptDTO, httpHeaders);
                    ResponseEntity<String> responseEntity = restTemplate.exchange(
                        ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2 + "/department", HttpMethod.POST,
                        requestEntity, String.class);
                    if (responseEntity.getStatusCodeValue() == 200) {
                        return responseEntity.getBody();
                    }
                }
            }
        }
        return null;
    }

    /**
     * @Description 修改部门名称.
     * @Author xiachao
     * @CreateTime 2017/3/2 14:52
     * @Param
     * @Return
     */
    @PutMapping("company/departments/{id}")
    public String updateRecruiterName(@PathVariable UUID id, String name) {
        if ( id != null && name != null && name != "") {
            Subject subject = SecurityUtils.getSubject();
            if (subject != null) {
                UserDTO user = (UserDTO) subject.getSession().getAttribute(
                    ymlConfig.getSession_current_user());
                if (user != null) {
                    UUID userId2 = user.getId();
                    String userName = user.getRealName();
                    UUID recId2 = user.getRecId();
                    String recName = user.getRecName();
                    HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                        recId2, recName);
                    Map<String, String> map = new HashMap<String, String>();
                    map.put("name", name);
                    String requestBody = "";
                    try {
                        requestBody = objectMapper.writeValueAsString(map);
                    } catch (JsonProcessingException e) {
                        e.printStackTrace();
                    }
                    httpHeaders.setContentType(MediaType.APPLICATION_JSON_UTF8);
                    HttpEntity requestEntity = new HttpEntity(requestBody, httpHeaders);
                    ResponseEntity<String> responseEntity = restTemplate.exchange(
                        ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2 + "/departments/" + id,
                        HttpMethod.PUT, requestEntity, String.class);
                    if (responseEntity.getStatusCodeValue() == 200) {
                        return "修改成功";
                    }
                }
            }
        }
        return "修改失败";
    }

    /**
     * @Description 删除部门.
     * @Author xiachao
     * @CreateTime 2017/3/2 14:57
     * @Param
     * @Return
     */
    @DeleteMapping("company/departments/{id}")
    public String deleteRecruiterDept( @PathVariable UUID id) {
        if ( id != null) {
            Subject subject = SecurityUtils.getSubject();
            if (subject != null) {
                UserDTO user = (UserDTO) subject.getSession().getAttribute(
                    ymlConfig.getSession_current_user());
                if (user != null) {
                    UUID userId2 = user.getId();
                    String userName = user.getRealName();
                    UUID recId2 = user.getRecId();
                    String recName = user.getRecName();
                    HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                        recId2, recName);
                    HttpEntity requestEntity = new HttpEntity(null, httpHeaders);
                    ResponseEntity<String> responseEntity = restTemplate.exchange(
                        ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2 + "/departments/" + id,
                        HttpMethod.DELETE, requestEntity, String.class);
                    if (responseEntity.getStatusCodeValue() == 200) {
                        return responseEntity.getBody();
                    }
                }
            }
        }
        return null;
    }
}
