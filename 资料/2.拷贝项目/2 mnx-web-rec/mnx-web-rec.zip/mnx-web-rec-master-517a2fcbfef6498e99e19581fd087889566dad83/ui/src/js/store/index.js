import Vue from 'vue'
import Vuex from 'vuex'
import * as actions from './actions'
import * as getters from './getters'
import candidate from './modules/candidate'
import shared from './modules/shared'
import job from './modules/job'
import company from './modules/company'

Vue.use(Vuex)


export default new Vuex.Store({
  actions,
  getters,
  modules: {
    candidate,
    shared,
    job,
    company
  }
})
