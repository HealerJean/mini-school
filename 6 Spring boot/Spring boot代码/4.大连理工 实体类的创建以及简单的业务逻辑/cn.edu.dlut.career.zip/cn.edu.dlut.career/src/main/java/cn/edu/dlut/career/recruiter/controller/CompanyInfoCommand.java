package cn.edu.dlut.career.recruiter.controller;

import cn.edu.dlut.career.recruiter.domain.CompanyInfo;
import cn.edu.dlut.career.recruiter.service.CompanyInfoService;
import cn.edu.dlut.career.recruiter.util.MD5Util;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PostMapping;

/**
 * Created by wei on 2017/3/23.
 */
@Transactional
@Controller
public class CompanyInfoCommand {
  @Autowired
  private CompanyInfoService companyInfoService;

  /**
   * 公司注册信息
   * @param companyInfo
   * @return
   */
  @PostMapping("/admin/saveCompany")
  public String saveCompany(CompanyInfo companyInfo){
    if(companyInfo != null){
      String pwd = companyInfo.getPwd();
      if(!"".equals(pwd)){
          companyInfoService.saveCompany(companyInfo);
          return "ok";
        }
    }
    return "regist";
  }


}
