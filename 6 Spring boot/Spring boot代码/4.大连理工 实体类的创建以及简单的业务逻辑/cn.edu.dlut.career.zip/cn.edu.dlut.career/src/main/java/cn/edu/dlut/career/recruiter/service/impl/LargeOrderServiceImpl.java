package cn.edu.dlut.career.recruiter.service.impl;

import cn.edu.dlut.career.recruiter.domain.LargeOrder;
import cn.edu.dlut.career.recruiter.repository.LargeOrderRepository;
import cn.edu.dlut.career.recruiter.service.LargeOrderService;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 专场预约 服务层
 * Created by HealerJean on 2017/3/23.
 */
@Service
@Transactional
public class LargeOrderServiceImpl implements LargeOrderService {

    private Logger logger = LoggerFactory.getLogger(LargeOrderServiceImpl.class);

    @Autowired
    LargeOrderRepository largeOorderRepository;

    /**
     * 添加，保存LargeOrder
     * @param largeOrder
     * @return
     * @throws JsonProcessingException
     */
    @Override
    public LargeOrder saveLargeOrder(LargeOrder largeOrder) {

        return largeOorderRepository.save(largeOrder);
    }



    @Override
    public LargeOrder findById(String id) {
        return largeOorderRepository.findById(id);
    }

    @Override
    public LargeOrder updateLargeOrder(LargeOrder largeOrder) {

        return largeOorderRepository.save(largeOrder);
    }


    @Override
    public String  deleteLargeOrder(String id) {
        try {
            largeOorderRepository.delete(id);
            return  "ok";
        }catch (Exception e){
            e.printStackTrace();
        }
            return null;

    }
    @Override
    public List<LargeOrder> findAllLargeOrder() {

        return largeOorderRepository.findAll();
    }

    @Override
    public int updateLargeOrderAudit(String id, String auditState, LocalDateTime auditTime, String auditPerson) {

        return  largeOorderRepository.updateLargeOrderAudit(id,auditPerson,auditTime,auditState);

    }
}
