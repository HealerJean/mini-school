<template>
    <h1>This is Task.</h1>
</template>

<script type="text/babel">

    export default {
        name: 'task',
        data() {
            return {};
        }
    }

</script>

<style>

</style>