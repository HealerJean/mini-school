package com.minixiao.web.dto.recruiters;


import java.io.Serializable;

/**
 * 公司用户VO.
 * Created by xiachao on 2017/3/2.
 */
public class CompanyUserVO implements Serializable {

    //邮箱地址作为用户的登录账号
    private String email;

    //用户的真实姓名
    private String realName;

    //登录密码
    private String pwd;

    //固定电话
    private String tel;

    //手机号
    private String mobile;

    //所属部门唯一Id
    private String deptId;

    //所属部门名称
    private String deptName;

    public CompanyUserVO() {
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getDeptId() {
        return deptId;
    }

    public void setDeptId(String deptId) {
        this.deptId = deptId;
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }
}
