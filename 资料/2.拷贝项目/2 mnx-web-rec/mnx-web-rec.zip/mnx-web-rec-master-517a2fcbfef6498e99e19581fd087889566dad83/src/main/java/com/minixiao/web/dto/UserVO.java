package com.minixiao.web.dto;

import java.io.Serializable;
import java.util.UUID;

/**
 * 公司用户VO.
 * Created by JiangYh on 2017/3/2.
 */
public class UserVO implements Serializable {

    //标识
    private UUID id;

    //公司Id
    private UUID recId;

    //公司名称
    private String recName;

    //邮箱地址作为用户的登录账号
    private String email;

    //用户的真实姓名
    private String realName;

    //所属部门唯一Id
    private String deptId;

    //所属部门名称
    private String deptName;

    //是否管理员账号
    private boolean isAdmin;



    public UserVO() {
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public String getDeptId() {
        return deptId;
    }

    public void setDeptId(String deptId) {
        this.deptId = deptId;
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public boolean isAdmin() {
        return isAdmin;
    }

    public void setAdmin(boolean admin) {
        isAdmin = admin;
    }

    public UUID getRecId() {
        return recId;
    }

    public void setRecId(UUID recId) {
        this.recId = recId;
    }

    public String getRecName() {
        return recName;
    }

    public void setRecName(String recName) {
        this.recName = recName;
    }


}
