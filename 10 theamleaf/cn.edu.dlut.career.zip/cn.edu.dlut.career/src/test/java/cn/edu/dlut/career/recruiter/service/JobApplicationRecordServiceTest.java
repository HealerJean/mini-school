package cn.edu.dlut.career.recruiter.service;

import cn.edu.dlut.career.recruiter.domain.JobApplicationRecord;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

import static org.junit.Assert.*;

/**
 * Created by wei on 2017/3/24.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class JobApplicationRecordServiceTest {
  @Resource JobApplicationRecordService jobApplicationRecordService;
  @Test
  public void save() throws Exception {
    DateTimeFormatter ymd = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    LocalDateTime localDate =LocalDateTime.parse("2015-11-23 11:00:00", ymd);
    JobApplicationRecord jobApplicationRecord = new JobApplicationRecord();
    jobApplicationRecord.setId(UUID.randomUUID().toString());
    jobApplicationRecord.setApplicationTime(localDate);
    jobApplicationRecord.setJob("Java开发");
    jobApplicationRecord.setRecId(UUID.randomUUID().toString());
    jobApplicationRecord.setStuId(UUID.randomUUID().toString());
    jobApplicationRecordService.save(jobApplicationRecord);
  }

  @Test
  public void delete() throws Exception {
    jobApplicationRecordService.delete("402881b55afe4668015afe467a730000");
  }

  @Test
  public void update() throws Exception {
    JobApplicationRecord jobApplicationRecord = jobApplicationRecordService.finOne("402881b55afe4668015afe467a730000");
    jobApplicationRecord.setJob("PHP");
    jobApplicationRecordService.update(jobApplicationRecord);
  }

  @Test
  public void findAll() throws Exception {
  jobApplicationRecordService.findAll();
  }

}