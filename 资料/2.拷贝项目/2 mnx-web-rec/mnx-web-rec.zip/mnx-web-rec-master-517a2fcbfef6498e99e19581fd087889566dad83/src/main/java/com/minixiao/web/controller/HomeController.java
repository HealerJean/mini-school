package com.minixiao.web.controller;

import com.minixiao.web.dto.CurrentUserVO;
import com.minixiao.web.dto.UserVO;
import com.minixiao.web.dto.recruiters.UserDTO;
import com.minixiao.web.utils.YmlConfig;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class HomeController {
    private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
    @Autowired
    private YmlConfig ymlConfig;

    @GetMapping({"/","/index.html"})
    @ConfigurationProperties(prefix="mnxProps")
    public String Home() {
        Subject subject = SecurityUtils.getSubject();
        //查看是否有权限（公司信息是否填写完整）进入首页
        if (subject.isPermitted("corpInfoComplete")) {
            return "index";
        } else {
            return "redirect:/guide.html";
        }
    }

    /**
     * 引导页
     * @return
     */
    @GetMapping("/guide.html")
    public String guide() {
        Subject subject = SecurityUtils.getSubject();
        //查看是否有权限（公司信息是否填写完整）进入首页
        if (subject.isPermitted("corpInfoComplete")) {
            return "redirect:/index.html";
        } else {
            return "guide";
        }
    }

    /**
     * 显示用户登录页面
     * @return
     */
    @GetMapping("/payload")
    public ResponseEntity<UserVO> userPayLoad() {
        Subject subject = SecurityUtils.getSubject();
        if (subject != null) {
            UserDTO user = (UserDTO)subject.getSession().getAttribute(ymlConfig.getSession_current_user());
            if (user != null) {
                UserVO userVO = new UserVO();
                userVO.setId(user.getId());
                userVO.setRecId(user.getRecId());
                userVO.setRecName(user.getRecName());
                userVO.setEmail(user.getEmail());
                userVO.setRealName(user.getRealName());
                userVO.setDeptName(user.getDeptName());
                userVO.setDeptId(user.getDeptId());
                userVO.setAdmin(user.isAdmin());
                return ResponseEntity.ok(userVO);
            }
        }
        return ResponseEntity.ok(null);
    }



}
