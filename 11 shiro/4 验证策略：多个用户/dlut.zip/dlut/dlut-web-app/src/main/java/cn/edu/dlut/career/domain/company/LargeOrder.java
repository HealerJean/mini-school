package cn.edu.dlut.career.domain.company;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 大型招聘会预约
 * Created by HealerJean on 2017/3/23.
 */

@Entity
@Table(name = "rec_large_order")
public class LargeOrder implements Serializable {

    //编号id
    @Id
    @GenericGenerator(name = "idGenerator", strategy = "uuid")
    @GeneratedValue(generator = "idGenerator")
    private String id;

    //企业编号 recId
    private String recId;

    // 招聘会编号recruitId
    private String recruitId;

    // 报名方式orderMethod
    @Column(length = 30)
    private String orderMethod;

    // 报名时间orderTime
    @CreationTimestamp
    private LocalDateTime orderTime;

    // 预约展位orderPosition
    @Column(length = 50)
    private String orderPosition;

    // 费用cost
    private Double cost;

    // 支付状态payState
    @Column(length = 10)
    private String payState;

    //支付时间payTime
    private LocalDateTime payTime;

    // 备注remarks
    @Column(length = 200)
    private String remarks;

    // 审核状态auditState
    @Column(length = 10)
    private String auditState;

    // 审核时间auditTime
    private LocalDateTime auditTime   ;

    // 审核人auditPerson
    @Column(length = 32)
    private String auditPerson;

  /*@OneToMany(cascade= CascadeType.ALL)
    @JoinColumn(name = "order_id")
    private List<LargePerson> largePersons;

    @OneToMany(cascade= CascadeType.ALL)
    @JoinColumn(name = "order_id")
    private List<LargeSign> largeSigns;

    @OneToMany(cascade= CascadeType.ALL)
    @JoinColumn(name = "order_id")
    private List<LargeJob> largeJobs;
*/

    public String getRecId() {
        return recId;
    }

    public void setRecId(String recId) {
        this.recId = recId;
    }

   /* public List<LargePerson> getLargePersons() {
        return largePersons;
    }

    public void setLargePersons(List<LargePerson> largePersons) {
        this.largePersons = largePersons;
    }

    public List<LargeSign> getLargeSigns() {
        return largeSigns;
    }

    public void setLargeSigns(List<LargeSign> largeSigns) {
        this.largeSigns = largeSigns;
    }

    public List<LargeJob> getLargeJobs() {
        return largeJobs;
    }

    public void setLargeJobs(List<LargeJob> largeJobs) {
        this.largeJobs = largeJobs;
    }*/

    public LargeOrder(String orderMethod, String orderPosition, Double cost, String payState, String remarks, String auditState, LocalDateTime auditTime, String auditPerson) {
        this.orderMethod = orderMethod;
        this.orderPosition = orderPosition;
        this.cost = cost;
        this.payState = payState;
        this.remarks = remarks;
        this.auditState = auditState;
        this.auditTime = auditTime;
        this.auditPerson = auditPerson;
    }

    public String getRecruitId() {
        return recruitId;
    }

    public void setRecruitId(String recruitId) {
        this.recruitId = recruitId;
    }

    public Double getCost() {
        return cost;
    }

    public void setCost(Double cost) {
        this.cost = cost;
    }



    public LargeOrder() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }



    public String getOrderMethod() {
        return orderMethod;
    }

    public void setOrderMethod(String orderMethod) {
        this.orderMethod = orderMethod;
    }

    public LocalDateTime getOrderTime() {
        return orderTime;
    }

    public void setOrderTime(LocalDateTime orderTime) {
        this.orderTime = orderTime;
    }

    public String getOrderPosition() {
        return orderPosition;
    }

    public void setOrderPosition(String orderPosition) {
        this.orderPosition = orderPosition;
    }




    public String getPayState() {
        return payState;
    }

    public void setPayState(String payState) {
        this.payState = payState;
    }

    public LocalDateTime getPayTime() {
        return payTime;
    }

    public void setPayTime(LocalDateTime payTime) {
        this.payTime = payTime;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getAuditState() {
        return auditState;
    }

    public void setAuditState(String auditState) {
        this.auditState = auditState;
    }

    public LocalDateTime getAuditTime() {
        return auditTime;
    }

    public void setAuditTime(LocalDateTime auditTime) {
        this.auditTime = auditTime;
    }

    public String getAuditPerson() {
        return auditPerson;
    }

    public void setAuditPerson(String auditPerson) {
        this.auditPerson = auditPerson;
    }
}
