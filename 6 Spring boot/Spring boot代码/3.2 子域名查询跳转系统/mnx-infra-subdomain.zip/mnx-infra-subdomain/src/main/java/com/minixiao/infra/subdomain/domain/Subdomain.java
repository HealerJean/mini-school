package com.minixiao.infra.subdomain.domain;

import javax.persistence.*;
import java.util.Date;

/**
 * Created by 史念念 on 2017/3/21.
 */
@Entity
@Table(name="subdomains") //没有默认就是这个实体类的名字
public class Subdomain {


  @Id
  @GeneratedValue(strategy= GenerationType.IDENTITY)
  private Integer id;  //id

  @Column(length = 50,nullable = true)
  private String name;

  @Column(length = 50,nullable = true)
  private String sub;

  @Column(length = 255,nullable = true)
  private String href;

  @Column(nullable = true)
  private Date createOn;//创建时间

  public Subdomain(){}



  @Override
  public String toString() {
    return "Subdomain{" +
        "id=" + id +
        ", name='" + name + '\'' +
        ", subdomain='" + sub + '\'' +
        ", href='" + href + '\'' +
        ", create_on=" + createOn +
        '}';
  }

  public Integer getId() {
    return id;
  }

  public String getName() {
    return name;
  }

  public String getSub() {
    return sub;
  }

  public void setSub(String sub) {
    this.sub = sub;
  }

  public String getHref() {
    return href;
  }

  public Date getCreateOn() {
    return createOn;
  }

  public void setCreateOn(Date createOn) {
    this.createOn = createOn;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public void setName(String name) {
    this.name = name;
  }


  public void setHref(String href) {
    this.href = href;
  }

}
