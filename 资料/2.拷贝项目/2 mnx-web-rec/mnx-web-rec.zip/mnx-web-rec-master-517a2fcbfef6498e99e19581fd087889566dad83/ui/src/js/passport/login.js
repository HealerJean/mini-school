// initial file for passport
import Vue from 'vue';
import ElementUI from 'element-ui';
import VueResource from 'vue-resource';

import AppHeader from '../../Components/Shared/HeaderNoLogin.vue';
import AppFooter from '../../Components/Shared/FooterNoLogin.vue';
import Login from '../../Components/Passport/Login.vue';
// styles
import 'element-ui/lib/theme-default/index.css';
import 'less/shared/common.less';

Vue.use(ElementUI);
Vue.use(VueResource);

Vue.http.options.emulateJSON = false;

new Vue({
    components: {
        Login,
        AppHeader,
        AppFooter
    }
}).$mount('#app');
