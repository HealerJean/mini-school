package cn.edu.dlut.career.recruiter.domain;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Created by wei on 2017/3/23.
 * 公司信息表
 */
@Entity
@Table(name = "rec_info")
public class CompanyInfo {
  //编号，主键UUID
  @Id
  @GenericGenerator(name = "idGenerator",strategy = "uuid")
  @GeneratedValue(generator = "idGenerator")
  private String id;

  //登录密码
  @Column(length = 100)
  private String pwd;

  //公司名称
  @Column(length = 100)
  private String name;

  //组织机构代码
  @Column(length = 100)
  private String organizationCode;

  //公司性质
  @Column(length = 100)
  private String nature;

  //公司行业
  @Column(length = 100)
  private String industry;

  //公司地址
  @Column(length = 100)
  private String address;

  //联系人
  @Column(length = 100)
  private String contacts;

  //联系电话
  @Column(length = 100)
  private String contactNumber;

  //联系邮箱 用于登录
  @Column(length = 100)
  private String email;

  //营业执照/代码证图片
  @Column(length = 100)
  private String businessLicense;

  //公司邮编
  @Column(length = 100)
  private String zipCode;

  //企业网址
  @Column(length = 100)
  private String website;

  //企业简介
  @Column(length = 1000)
  private String synopsis;

  //备注
  @Column(length = 1000)
  private String remarks;

  //公司规模
  @Column(length = 100)
  private String size;

  //公司注册时间
  @Column(nullable = true)
  private LocalDateTime registrationTime;

  //审核状态
  /**
   * 0待审核
   * 1审核通过
   * 2审核未通过
   */
  @Column(length = 2)
  private String auditStatus;

  //审核时间
  @Column()
  private LocalDateTime auditTime;

  //审核人
  @Column(length = 100)
  private String reviewer;

  //标签
  @Column(length = 100)
  private String label;

  //注册资本
  @Column(length = 50)
  private String capital;

  //过期时间
  @Column
  private LocalDateTime expirationTime;

  public String getCapital() {
    return capital;
  }

  public void setCapital(String capital) {
    this.capital = capital;
  }

  public LocalDateTime getExpirationTime() {
    return expirationTime;
  }

  public void setExpirationTime(LocalDateTime expirationTime) {
    this.expirationTime = expirationTime;
  }

  public String getId() {
    return id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getPwd() {
    return pwd;
  }

  public void setPwd(String pwd) {
    this.pwd = pwd;
  }

  public String getOrganizationCode() {
    return organizationCode;
  }

  public void setOrganizationCode(String organizationCode) {
    this.organizationCode = organizationCode;
  }

  public CompanyInfo() {
  }


  public String getNature() {
    return nature;
  }

  public void setNature(String nature) {
    this.nature = nature;
  }

  public String getIndustry() {
    return industry;
  }

  public void setIndustry(String industry) {
    this.industry = industry;
  }

  public String getAddress() {
    return address;
  }

  public void setAddress(String address) {
    this.address = address;
  }

  public String getContacts() {
    return contacts;
  }

  public void setContacts(String contacts) {
    this.contacts = contacts;
  }

  public String getContactNumber() {
    return contactNumber;
  }

  public void setContactNumber(String contactNumber) {
    this.contactNumber = contactNumber;
  }

  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public String getBusinessLicense() {
    return businessLicense;
  }

  public void setBusinessLicense(String businessLicense) {
    this.businessLicense = businessLicense;
  }

  public String getZipCode() {
    return zipCode;
  }

  public void setZipCode(String zipCode) {
    this.zipCode = zipCode;
  }

  public String getWebsite() {
    return website;
  }

  public void setWebsite(String website) {
    this.website = website;
  }

  public String getSynopsis() {
    return synopsis;
  }

  public void setSynopsis(String synopsis) {
    this.synopsis = synopsis;
  }

  public String getRemarks() {
    return remarks;
  }

  public void setRemarks(String remarks) {
    this.remarks = remarks;
  }

  public String getSize() {
    return size;
  }

  public void setSize(String size) {
    this.size = size;
  }

  public LocalDateTime getRegistrationTime() {
    return registrationTime;
  }

  public void setRegistrationTime(LocalDateTime registrationTime) {
    this.registrationTime = registrationTime;
  }

  public String getAuditStatus() {
    return auditStatus;
  }

  public void setAuditStatus(String auditStatus) {
    this.auditStatus = auditStatus;
  }

  public LocalDateTime getAuditTime() {
    return auditTime;
  }

  public void setAuditTime(LocalDateTime auditTime) {
    this.auditTime = auditTime;
  }

  public String getReviewer() {
    return reviewer;
  }

  public void setReviewer(String reviewer) {
    this.reviewer = reviewer;
  }

  public String getLabel() {
    return label;
  }

  public void setLabel(String label) {
    this.label = label;
  }
}
