package cn.edu.dlut.career.recruiter.controller;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by wei on 2017/3/23.
 */
public class CompanyInfoCommandTest {

}