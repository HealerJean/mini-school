package com.minixiao.web.controller.candidate;

import com.minixiao.apiauth.client.HeaderUtil;
import com.minixiao.web.dto.candidate.ApplicationDTO;
import com.minixiao.web.dto.candidate.ApplicationListDTO;
import com.minixiao.web.dto.candidate.Education;
import com.minixiao.web.dto.candidate.JobTarget;
import com.minixiao.web.dto.candidate.Tags;
import com.minixiao.web.utils.YmlConfig;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;


import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.Date;
import java.util.UUID;

/**
 * @Author wangyj.
 * @Date 2017/3/3  10:11.
 */

@RestController
public class AppListExportExcelController {

    @Autowired
    private YmlConfig ymlConfig;

    private RestTemplate restTemplate = new RestTemplate();


    /**
     * @Description 设置excel相关.
     * @Author wangyj
     * @CreateDate 2017/3/3 10:44
     * @Param
     * @Return
     */
    private void createTitle(HSSFWorkbook workbook, HSSFSheet sheet) {
        /***
         * 创建表头
         * @param workbook
         * @param sheet
         */
        HSSFRow row = sheet.createRow(0);
        //设置列宽，setColumnWidth的第二个参数要乘以256，这个参数的单位是1/256个字符宽度
        sheet.setColumnWidth(0, 5 * 256);
        sheet.setColumnWidth(1, 10 * 256);
        sheet.setColumnWidth(2, 5 * 256);
        sheet.setColumnWidth(3, 18 * 256);
        sheet.setColumnWidth(4, 15 * 256);
        sheet.setColumnWidth(5, 10 * 256);
        sheet.setColumnWidth(6, 15 * 256);
        sheet.setColumnWidth(7, 15 * 256);
        sheet.setColumnWidth(8, 12 * 256);
        sheet.setColumnWidth(9, 27 * 256);

        //设置为居中加粗
        HSSFCellStyle style = workbook.createCellStyle();
        HSSFFont font = workbook.createFont();
        font.setBold(true);
        style.setAlignment(HorizontalAlignment.CENTER);
        style.setFont(font);

        HSSFCell cell;
        cell = row.createCell(0);
        cell.setCellValue("序号");
        cell.setCellStyle(style);

        cell = row.createCell(1);
        cell.setCellValue("姓名");
        cell.setCellStyle(style);

        cell = row.createCell(2);
        cell.setCellValue("性别");
        cell.setCellStyle(style);

        cell = row.createCell(3);
        cell.setCellValue("投递职位");
        cell.setCellStyle(style);

        cell = row.createCell(4);
        cell.setCellValue("招聘部门");
        cell.setCellStyle(style);

        cell = row.createCell(5);
        cell.setCellValue("最高学历");
        cell.setCellStyle(style);

        cell = row.createCell(6);
        cell.setCellValue("毕业学校");
        cell.setCellStyle(style);

        cell = row.createCell(7);
        cell.setCellValue("专业");
        cell.setCellStyle(style);

        cell = row.createCell(8);
        cell.setCellValue("处理状态");
        cell.setCellStyle(style);

        cell = row.createCell(9);
        cell.setCellValue("标签");
        cell.setCellStyle(style);
    }

    /**
     * @Description 将申请表列表导出为excel.
     * @Author wangyj
     * @CreateDate 2017/3/3 10:38
     * @Param
     * @Return
     */
    @GetMapping("/candidate/excel")
    public void getExcel(@RequestParam String filter, HttpServletResponse response) throws IOException {
        HSSFWorkbook workbook = new HSSFWorkbook();
        HSSFSheet sheet = workbook.createSheet("候选人列表");
        createTitle(workbook, sheet);

        //获取申请人列表
        ApplicationListDTO responseEntity = null;
//        Subject subject = SecurityUtils.getSubject();
//        if (subject != null) {
//            UserDTO user = (UserDTO) subject.getSession().getAttribute(ymlConfig.getSession_current_user());
//            if (user != null) {
//                UUID recId = user.getRecId();
//                UUID optUid = user.getId();
//                String optName = user.getRealName();
//                String recName = user.getRecName();
//                HttpHeaders requestHeaders = HeaderUtil.getHeader(optUid, optName, "COMPANY", recId,
//                    recName);
//                HttpEntity requestEntity = new HttpEntity(null, requestHeaders);
//                responseEntity = restTemplate.exchange(
//                    ymlConfig.getUrl_api_recruiter() + "candidate?filter={filter}", HttpMethod.GET, requestEntity,
//                    ApplicationListDTO.class, filter).getBody();
//            }
//        }

        UUID optUid = UUID.fromString("354bdb8f-ecd6-4c82-80fe-5f42db62d0a1");
        String optName = "小米";
        UUID recId = UUID.fromString("dcb765d9-b394-4258-9d5b-371bf88483e2");
        String recName = "迷你校";
        HttpHeaders requestHeaders = HeaderUtil.getHeader(optUid, optName, "COMPANY", recId,
            recName);

        HttpEntity requestEntity = new HttpEntity(null, requestHeaders);
                responseEntity = restTemplate.exchange(
                   ymlConfig.getUrl_api_recruiter() + "candidate?filter={filter}", HttpMethod.GET, requestEntity,
                    ApplicationListDTO.class, filter).getBody();
        if (responseEntity != null) {
            //新增数据行，并且设置单元格数据
            int rowNum = 1;
            for (ApplicationDTO applicationDTO : responseEntity.getApplicationDTOList()) {

                HSSFRow row = sheet.createRow(rowNum);

                //姓名
                row.createCell(0).setCellValue(rowNum);
                //姓名
                row.createCell(1).setCellValue(applicationDTO.getBasic().getName());
                //性别
                row.createCell(2).setCellValue(applicationDTO.getBasic().getGender());

                //求职目标
                String currJobName = "";
                String currDepartment = "";
                for (JobTarget taget : applicationDTO.getJobTarget()) {
                    if (taget.getIsCurrent() && (taget.getJobName() != null) && (taget.getDepartment() != null)) {
                        currJobName = taget.getJobName();
                        currDepartment = taget.getDepartment();
                        break;
                    }
                }
                //投递职位
                row.createCell(3).setCellValue(currJobName);
                //招聘部门
                row.createCell(4).setCellValue(currDepartment);

                //教育
                String highestDegree = "";
                String school = "";
                String major = "";
                for (Education edu : applicationDTO.getEducation()) {
                    if (edu.getIsHighest() && (edu.getDegree() != null) && (edu.getSchool() != null)
                        && (edu.getMajor() != null)) {
                        highestDegree = edu.getDegree();
                        school = edu.getSchool();
                        major = edu.getMajor();
                        break;
                    }
                }
                //最高学历

                row.createCell(5).setCellValue(highestDegree);
                //毕业学校
                row.createCell(6).setCellValue(school);
                //专业
                row.createCell(7).setCellValue(major);
                //处理状态
                row.createCell(8).setCellValue(applicationDTO.getStatus());
                //标签
                StringBuilder tag = new StringBuilder("");
                for (Tags tags : applicationDTO.getTags()) {
                    tag.append(tags.getTag() + "  ");
                }
                row.createCell(9).setCellValue(tag.toString());

                rowNum++;
            }


//        response.setCharacterEncoding("UTF-8");
//        response.setHeader("Content-disposition",
//            "attachment;filename=" + URLEncoder.encode(String.valueOf(new Date().getTime()), "UTF-8") + ".xls");
//        response.setContentType("application/octet-stream");
            response.setContentType("application/vnd.ms-excel");
            String excelName ="简历列表" + new Date().getTime() + ".xls";
            response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(excelName, "UTF-8"));
            OutputStream out = response.getOutputStream();
            workbook.write(out);
            out.flush();
            out.close();

        }
    }
}
