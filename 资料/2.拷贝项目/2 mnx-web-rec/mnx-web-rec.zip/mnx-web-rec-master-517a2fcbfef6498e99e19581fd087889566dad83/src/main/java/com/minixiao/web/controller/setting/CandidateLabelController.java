package com.minixiao.web.controller.setting;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.minixiao.apiauth.client.HeaderUtil;
import com.minixiao.web.dto.recruiters.UserDTO;
import com.minixiao.web.utils.YmlConfig;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * 候选人标签conroller.
 * Created by xiachao on 2017/3/3.
 */
@RestController
public class CandidateLabelController {
    private Logger logger = LoggerFactory.getLogger(CandidateLabelController.class);

    @Autowired
    private YmlConfig ymlConfig;

    private RestTemplate restTemplate = new RestTemplate();

    private ObjectMapper objectMapper = new ObjectMapper();


    /**
     * @Description 查看所有标签.
     * @Author xiachao
     * @CreateTime 2017/3/3 10:15
     * @Param
     * @Return
     */
    @GetMapping("company/labels")
    public String getAllLabels() {
        Subject subject = SecurityUtils.getSubject();
        if (subject != null) {
            UserDTO user = (UserDTO) subject.getSession().getAttribute(
                ymlConfig.getSession_current_user());
            if (user != null) {
                UUID userId2 = user.getId();
                String userName = user.getRealName();
                UUID recId2 = user.getRecId();
                String recName = user.getRecName();
                HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                    recId2, recName);
                HttpEntity requestEntity = new HttpEntity(null, httpHeaders);
                ResponseEntity<String> responseEntity = restTemplate.exchange(
                    ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2 + "/candidateLabels",
                    HttpMethod.GET, requestEntity, String.class);
                if (responseEntity.getStatusCodeValue() == 200) {
                    return responseEntity.getBody();
                }
            }
        }
        return null;
    }

    /**
     * @Description 添加标签.
     * @Author xiachao
     * @CreateTime 2017/3/3 10:18
     * @Param
     * @Return
     */
    @PostMapping("company/label")
    public String addLabels(String name) {
        if (name != null && !("".equals(name))) {
            Subject subject = SecurityUtils.getSubject();
            if (subject != null) {
                UserDTO user = (UserDTO) subject.getSession().getAttribute(
                    ymlConfig.getSession_current_user());
                if (user != null) {
                    UUID userId2 = user.getId();
                    String userName = user.getRealName();
                    UUID recId2 = user.getRecId();
                    String recName = user.getRecName();
                    HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                        recId2, recName);
                    Map<String, String> map = new HashMap<String, String>();
                    map.put("name", name);
                    String requestBody = "";
                    try {
                        requestBody = objectMapper.writeValueAsString(map);
                    } catch (JsonProcessingException e) {
                        e.printStackTrace();
                    }
                    httpHeaders.setContentType(MediaType.APPLICATION_JSON_UTF8);
                    HttpEntity requestEntity = new HttpEntity(requestBody, httpHeaders);
                    ResponseEntity<String> responseEntity = restTemplate.exchange(
                        ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2 + "/candidatelabel",
                        HttpMethod.POST, requestEntity, String.class);
                    if (responseEntity.getStatusCodeValue() == 200) {
                        return responseEntity.getBody();
                    }
                }
            }
        }
        return null;
    }

    /**
     * @Description 删除标签.
     * @Author xiachao
     * @CreateTime 2017/3/3 10:23
     * @Param
     * @Return
     */
    @RequestMapping("company/labels/{id}")
    public String deleteLabels(@PathVariable UUID id) {
        if ( id != null) {
            Subject subject = SecurityUtils.getSubject();
            if (subject != null) {
                UserDTO user = (UserDTO) subject.getSession().getAttribute(
                    ymlConfig.getSession_current_user());
                if (user != null) {
                    UUID userId2 = user.getId();
                    String userName = user.getRealName();
                    UUID recId2 = user.getRecId();
                    String recName = user.getRecName();
                    HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                        recId2, recName);
                    HttpEntity requestEntity = new HttpEntity(null, httpHeaders);
                    ResponseEntity<String> responseEntity = restTemplate.exchange(
                        ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2 + "/candidatelabels/" + id,
                        HttpMethod.DELETE, requestEntity, String.class);
                    if (responseEntity.getStatusCodeValue() == 200) {
                        return responseEntity.getBody();
                    }
                }
            }
        }
        return null;
    }

    /**
     * @Description 修改标签状态.
     * @Author xiachao
     * @CreateTime 2017/3/3 10:25
     * @Param
     * @Return
     */
    @PutMapping("company/labels/{id}/status")
    public String updateLabelStatus( @PathVariable UUID id,
                                    boolean status) {
        if (id != null) {
            Subject subject = SecurityUtils.getSubject();
            if (subject != null) {
                UserDTO user = (UserDTO) subject.getSession().getAttribute(
                    ymlConfig.getSession_current_user());
                if (user != null) {
                    UUID userId2 = user.getId();
                    String userName = user.getRealName();
                    UUID recId2 = user.getRecId();
                    String recName = user.getRecName();
                    HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                        recId2, recName);
                    Map map = new HashMap<>();
                    map.put("status", status);
                    String requestBody = "";
                    try {
                        requestBody = objectMapper.writeValueAsString(map);
                    } catch (JsonProcessingException e) {
                        e.printStackTrace();
                    }
                    httpHeaders.setContentType(MediaType.APPLICATION_JSON_UTF8);
                    HttpEntity requestEntity = new HttpEntity(requestBody, httpHeaders);
                    ResponseEntity<String> responseEntity = restTemplate.exchange(
                        ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2 + "/candidatelabels/" + id +
                            "/status?status=" + status, HttpMethod.PUT, requestEntity, String.class);
                    if (responseEntity.getStatusCodeValue() == 200) {
                        return responseEntity.getBody();
                    }
                }
            }
        }
        return null;
    }
}
