package cn.edu.dlut.career.recruiter.service.impl;

import cn.edu.dlut.career.recruiter.domain.RecSpecialOrder;
import cn.edu.dlut.career.recruiter.domain.recruitjob.embedment.Audit;
import cn.edu.dlut.career.recruiter.service.RecSpecialOrderService;
import cn.edu.dlut.career.recruiter.service.recruitjob.impl.RecruitJobServiceImplTest;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.LocalDateTime;
import java.util.List;


/**
 * Created by 史念念 on 2017/3/24.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class RecSpecialOrderServiceImplTest {
  @Autowired
  private RecSpecialOrderService recSpecialOrderService;

  private Logger logger = LoggerFactory.getLogger(RecruitJobServiceImplTest.class);

  RecSpecialOrder recSpecialOrder = null;

  /**
   * 测试修改接待人，接待人联系方式
   */
  @Test
  public void updateReceptionistAndRecepTel(){
    String result = recSpecialOrderService.updateReceptionistAndRecepTel("402881fc5b0daefc015b0daf08a30000","李四四","12345567");

    logger.info("得到的结果是"+result);
  }

  /**
   * 测试删除功能
   */
  @Test
  public void deleteById(){
    String result = recSpecialOrderService.deleteById("402881fc5aff19e5015aff19f27b0000");

    logger.info(result);
  }

  /**
   * 测试修改审核状态,审核人,审核时间,未通过原因
   */
  @Test
  public void updateAuditStatus(){
    String result = recSpecialOrderService.updateAudit("402881fc5aff13d2015aff13deec0000","1","史念念", LocalDateTime.now(),"");

    logger.info(result);
  }

  /**
   * 测试通过企业id查找
   */
  @Test
  public void findByRecId(){
    List<RecSpecialOrder> ls = recSpecialOrderService.findByRecId("1");
    logger.info("查询到了"+ls.size()+"条信息");

  }

  /**
   * 测试根据ID查找
   */
  @Test
  public void findById(){
    RecSpecialOrder recSpecialOrder= recSpecialOrderService.findById("402881fc5aff13d2015aff13deec0000");

    logger.info(recSpecialOrder.getJobFairName());
  }

  /**
   * 测试全部查找功能
   */
  @Test
  public void findAll(){
    List<RecSpecialOrder> recSpecialOrders = recSpecialOrderService.findAll();

    logger.info("查询到了"+recSpecialOrders.size()+"条信息");
  }

  /**
   * 测试添加功能
   */
  @Test
  public void save(){
    recSpecialOrder = new RecSpecialOrder();
    Audit audit = new Audit();
    audit.setAuditStatus("1");
    recSpecialOrder.setRecId("1");
    recSpecialOrder.setJobFairName("abababa");
    recSpecialOrder.setFairCatalog("招聘");
    recSpecialOrder.setHoldTime(LocalDateTime.now());
    recSpecialOrder.setStartTime(LocalDateTime.now());
    recSpecialOrder.setEndTime(LocalDateTime.now());
    recSpecialOrder.setContacts1("张三");
    recSpecialOrder.setConTel1("123445565");
    recSpecialOrder.setAudit(audit);

    String result  = recSpecialOrderService.saveRecSpecialOrder(recSpecialOrder);
  }

}