<template>
    <footer class="footer">
        <div class="inner">
            <el-row>
                <el-col :span="10" class="footer-address">
                    ©2016 Minixiao 京ICP备14031516-1
                </el-col>
                <el-col :span="14">
                    <ul class="footer-l-nav">
                        <li v-for="item in footNavs">
                            <router-link v-if="item.isLink === 'toRouter'" :to="item.navUrl">{{item.navName}}
                            </router-link>
                            <template v-else-if="item.isLink === 'toUrl'">
                                <a :href="item.navUrl" target="_blank">{{item.navName}}</a>
                            </template>
                            <template v-else>
                                {{item.navName}}
                            </template>
                            <div v-if="item.isLink === 'toQR'" class="qr-img">
                                <img src='../../img/common/QR_com_b.png'>
                            </div>
                        </li>
                    </ul>
                </el-col>
            </el-row>
        </div>
    </footer>
</template>

<script>
export default {
    data:function(){
        return {
            footNavs:[
                {navName:'联系我们：bd@minixiao.com'},
                {isLink:'toQR',navName:'迷你校微信'},
                {isLink:'toUrl',navUrl:'https://www.weibo.com',navName:'迷你校微博'},
                {isLink:'toRouter',navUrl:'/help',navName:'帮助中心'},
                {isLink:'toRouter',navUrl:'/about',navName:'关于我们'}
            ]
        }
    }
};
</script>

