package cn.edu.dlut.career.recruiter.repository;

import cn.edu.dlut.career.recruiter.domain.RecSpecialOrder;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Created by 史念念 on 2017/3/24.
 *
 * 专场招聘会预约 持久层
 */
@Transactional
public interface RecSpecialOrderRepository extends CrudRepository<RecSpecialOrder,String>{

  /**
   * 查询所有专场招聘会预约信息
   * @return
   */
 List<RecSpecialOrder> findAll();

  /**
   * 根据id查找专场招聘会信息
   * @param id
   * @return
   */
 RecSpecialOrder findById(String id);

  /**
   * 根据公司Id查找专场招聘会预约信息
   * @param recId
   * @return
   */
 List<RecSpecialOrder> findByRecId(String recId);

 /**
  * 修改接待人，接待人联系方式
  * @param receptionist 接待人
  * @param recepTel 接待人联系方式
  * @return
  */
 @Modifying
 @Query("update RecSpecialOrder set receptionist=?2,recepTel=?3 where id=?1")
 int updateReceptionistAndRecepTel(String id,String receptionist,String recepTel);

  /**
   * 修改审核状态,审核人,审核时间,未通过原因
   * @param auditStatus
   * @return
   */
  @Modifying
  @Query("update RecSpecialOrder  set audit.auditStatus=?2 ,audit.auditPerson=?3 ," +
      "audit.auditTime=?4,audit.auditFailReason=?5 where id = ?1")
  int updateAudit(String id , String auditStatus,
                  String auditPerson, LocalDateTime auditTime,
                  String auditFailReason);

}
