package cn.edu.dlut.career.service.company.impl;


import cn.edu.dlut.career.domain.company.YardOrder;
import cn.edu.dlut.career.repository.company.YardOrderRepository;
import cn.edu.dlut.career.service.company.YardOrderService;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 场地预约 服务层
 * Created by HealerJean on 2017/3/23.
 */
@Service
@Transactional
public class YardOrderServiceImlp implements YardOrderService {

    private Logger logger = LoggerFactory.getLogger(LargeOrderServiceImpl.class);
    @Autowired
    YardOrderRepository yardOrderRepository;

    @Override
    public List<YardOrder> findAll() {
        return yardOrderRepository.findAll();
    }

    /**
     * 保存，添加 YardOrder
     * @param yardOrder
     * @return
     * @throws JsonProcessingException
     */
    @Override
    public String saveYardOrder(YardOrder yardOrder) throws JsonProcessingException {
        yardOrderRepository.save(yardOrder);
        logger.info("insert into yardOrder");
        return "ok";
    }

    /**
     *  根据id查询YardOrder
     * @param id
     * @return
     */
    @Override
    public YardOrder findById(String id) {
        logger.info("select *  yardOrder byid");
        return yardOrderRepository.findById(id);
    }

    /**
     * 更新YardOrder
     * @param yardOrder
     * @return
     * @throws JsonProcessingException
     */
    @Override
    public String updateYardOrder(YardOrder yardOrder) throws JsonProcessingException {
        yardOrderRepository.save(yardOrder);
        return "ok";
    }

    /**
     * 根据id删除YardOrder
     * @param id
     */
    @Override
    public String deleteYardOrder(String id) {
        try {
            yardOrderRepository.delete(id);
            return "ok";
        }catch (Exception e){
            e.printStackTrace();
        }
      return null;
    }


    /**
     * 查询YardOrder 所有的数据
     * @return
     */
    @Override
    public List<YardOrder> findAllYardOrder() {

        return yardOrderRepository.findAll();
    }

    @Override
    public int updateYardOrderAudit(String id, String auditState, LocalDateTime auditTime, String auditPerson) {

        return  yardOrderRepository.updateYardOrderAudit(id,auditPerson,auditTime,auditState);

    }
}
