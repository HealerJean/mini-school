/**
 * @module ajax request
 * used to send Ajax request
 */
import Vue from 'vue';
import VueResource from 'vue-resource';

Vue.use(VueResource);

// configurations
Vue.http.options.root = '';
Vue.http.headers = {};

const defaultOptions = {
    timeout: 10000,
    credentials: true
};

// method get
// get('someurl', { foo: bar }, [options])
const get = (url, params, options = {}) => {
    let serializedParams = [];
    // serializing params
    for (let key in params) {
        serializedParams.push(`${key}=${params[key]}`);
    }
    url = `${url}${serializedParams.join('&')}`;
    options = Object.assign({}, defaultOptions, options);
    return Vue.$http.get(url, options);
};

// method post
// post('someurl', { foo: bar }, [options])
const post = (url, params, options = {}) => {
    options = Object.assign({}, defaultOptions, options);
    return Vue.$http.post(url, params, options);
};

export default {
    get,
    post
};
