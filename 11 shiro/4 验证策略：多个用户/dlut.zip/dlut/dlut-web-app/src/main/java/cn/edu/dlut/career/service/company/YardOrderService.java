package cn.edu.dlut.career.service.company;

import cn.edu.dlut.career.domain.company.YardOrder;
import com.fasterxml.jackson.core.JsonProcessingException;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 场地预约 服务层 接口
 * Created by HealerJean on 2017/3/23.
 */
public interface YardOrderService {
    //查询所有的
    List<YardOrder> findAll();

    //保存，添加
    String saveYardOrder(YardOrder yardOrder) throws JsonProcessingException;

    //根据id查询
    YardOrder findById(String id);

   // 更新
    String updateYardOrder(YardOrder yardOrder) throws JsonProcessingException;

    //根据id删除 删除成功返回 ok ，否则 null
    String deleteYardOrder(String id);

    //查询所有的数据
    List<YardOrder> findAllYardOrder();

    //根据Id进行更新审核状态，审核时间，审核人
    int updateYardOrderAudit(String id, String auditState, LocalDateTime auditTime, String auditPerson);


}
