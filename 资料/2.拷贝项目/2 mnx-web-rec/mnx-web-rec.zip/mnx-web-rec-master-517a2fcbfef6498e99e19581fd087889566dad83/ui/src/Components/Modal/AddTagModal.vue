<template>
    <el-dialog title="公司标签"
               v-model="tagAddingModalVisible"
               size="large"
               :close-on-click-modal="false"
               :close-on-press-escape="false"
               @close="closeModal">
        <div class="container-tags-added">
            <h4 class="tags-added-title">已添加标签<span>（最多可选择9个标签）</span></h4>
            <div class="tags-added-body">
                <el-tag v-if="modifideTags.length === 0"
                        :closable="false"
                        :close-transition="true"
                        type="gray">
                    暂无任何标签</el-tag>
                <el-tag v-else v-for="tag in modifideTags"
                        :closable="true"
                        :close-transition="true"
                        type="warning"
                        @close="removeTag(tag)">
                    {{ tag }}
                </el-tag>

            </div>
        </div>
        <el-form :inline="true" class="tags-added-form">
            <el-form-item>
                <el-input
                    placeholder="输入自定义标签 最多6个字"
                    v-model="customTag"
                    :disabled="modifideTags.length >= 9 && !modifideTags.includes(tag)"
                ></el-input>
            </el-form-item>
            <el-form-item>
                <el-button type="primary"
                           @click="addCustomTag(customTag)"
                           :disabled="modifideTags.length >= 9 && !modifideTags.includes(tag)"
                           :plain="true"
                >添加</el-button>
            </el-form-item>
        </el-form>
        <div class="container-tags-selection">
            <h4 class="tags-selection-title">选择常用标签</h4>
            <div class="tags-selection-body">
                <el-checkbox-group v-model="modifideTags">
                    <el-checkbox
                        v-for="tag in recommendTags"
                        :label="tag"
                        :disabled="modifideTags.length >= 9 && !modifideTags.includes(tag)">
                        {{ tag }}
                    </el-checkbox>
                </el-checkbox-group>
                <!--<el-tag v-if="recommendTags.length === 0"-->
                        <!--:closable="false"-->
                        <!--:close-transition="true"-->
                        <!--type="gray"-->
                <!--&gt;暂无任何可选标签</el-tag>-->
            </div>
        </div>
        <div slot="footer" class="dialog-footer">
            <el-button type="primary" @click="modalConfirm">确定</el-button>
            <el-button @click="closeModal">取消</el-button>
        </div>
    </el-dialog>
</template>

<script type="text/babel">

    import eventBus from '../../js/shared/eventBus';

    export default {
        name: 'add-tag-modal',

        data() {
            return {
                modifideTags: [],
                customTag: ''
            };
        },

        computed: {
            tagAddingModalVisible() {
                this.modifideTags = this.addedTags;
                return this.isAddingTags;
            },
            recommendTags() {
                return this.$store.state.company.recommendTags;
            },
            addedTags() {
                return this.$store.state.company.companyInformation.tags.replace(/，/g,',').split(',');
            }
        },

        props: {
            isAddingTags: {
                type: Boolean,
                default: false
            }
        },

        methods: {
            closeModal() {
                eventBus.$emit('modal:add-tags-closing');
            },

            addCustomTag(tag) {
                if(tag===''){
                    this.$message({
                        message: '标签不能为空',
                        type: 'warning',
                        duration:2000
                    });
                    return;
                }
                if(tag.length>6){
                    this.$message({
                        message: '标签不能为超过6个字',
                        type: 'warning',
                        duration:2000
                    });
                    return;
                }
                this.modifideTags.push(tag);
                this.customTag = '';
            },

            modalConfirm() {
                eventBus.$emit('modal:emit-added-tags', this.modifideTags);
                eventBus.$emit('modal:add-tags-closing');
            },

            removeTag(tag) {
                this.modifideTags.splice(this.modifideTags.indexOf(tag), 1);
            }
        }
    }

</script>

<style lang="less" scoped>

    @import "../../less/shared/variables";

    .tags-added-title,
    .tags-selection-title {
        margin-top: 0;
        margin-bottom: 14px;
        color:extract(@gray-group,3);
        font-weight:600;
        &>span{
            color:extract(@gray-group,5);
            font-size:@size-sm;
            font-weight:400;
        }
    }

    .tags-added-body{
        padding: 10px 5px 0;
        box-sizing: border-box;
    }

    .container-tags-added {
        margin-bottom: 20px;
    }

</style>

<style lang="less">

    @import "../../less/shared/variables";

    .container-tags-selection {
        .tags-selection-body {
            .el-checkbox {
                margin: 0;

                .el-checkbox__input {
                    display: none;
                }

                .el-checkbox__label {
                    display: inline-block;
                    margin: 0 10px 10px 0;
                    padding: 0 8px;
                    line-height: 20px;
                    height: 22px;
                    font-size: 12px;
                    color: @warning-color;
                    box-sizing: border-box;
                    border: 1px solid @warning-color;
                    border-radius: 2px;
                    white-space: nowrap;
                }

                .is-checked + .el-checkbox__label {
                    border:@border-gray;
                    background-color:extract(@gray-group,11);
                    border-color:extract(@gray-group,9);
                    color:extract(@gray-group,6);
                }
            }
        }
    }
    .tags-added-body{
        background-color:extract(@gray-group,12);
        .el-tag .el-icon-close{
            position: absolute;
            -ms-transform: scale(.5);
            transform: scale(.5);
            top: -3px;
            right: -3px;
            &:hover{
                background-color:inherit;
                color:inherit;
            }
        }
    }

    .tags-added-form{
        margin-bottom:20px;
        .el-form-item__content {
            line-height: 32px;
            position: relative;
            font-size: 14px;
        }
        .el-input__inner{
            border-radius: 2px;
            border: 1px solid #ddd;
            color: #555;
            height: 32px;
            width: 200px;
        }
        .el-button{
            font-size:@size-md;
        }
    }

</style>
