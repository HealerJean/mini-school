<template>
    <div class="department">
        <div>我的位置：
            <el-breadcrumb separator=">">
                <el-breadcrumb-item>系统设置</el-breadcrumb-item>
                <el-breadcrumb-item>部门管理</el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        <div class="department-title">
            部门信息
        </div>
        <div class="department-body">
            <div class="department-button">
                <el-button type="primary" @click="newDepartment">新建</el-button>
                <el-button type="primary" @click="modifyDepartment">编辑</el-button>
                <el-button type="primary" @click="deleteDepartment">删除</el-button>
            </div>
            <create-department-modal :isCreateDepartment="isCreateDepartment" @closeCreateDepartment="claseEditor" @createDepartment="createDepartment"></create-department-modal>
            <modify-department-modal :departmentName="checkedDepartmentName":isModifyDepartment="isModifyDepartment" @closeModifyDepartment="claseModify" @modifyDepartment="updatedDepartment"></modify-department-modal>
            <div class="department-tree">
                <el-tree :data="departmentTree" :props="defaultProps" :highlight-current="true" node-key="deptId" ref="tree" :default-expand-all="true" @node-click="selectDepartment"></el-tree>
            </div>
        </div>
    </div>
</template>

<script type="text/babel">

import CreateDepartmentModal from '../Modal/CreateDepartModal.vue';
import ModifyDepartmentModal from '../Modal/ModifyDepartmentModal.vue';

    export default {
        name: 'department',
        data:function(){
            return{
                checkedDepartmentName:'',
                checkedDepartmentDeptId:'',
                checkedDepartment:{},
                isCreateDepartment:false,
                isModifyDepartment:false,
                departmentTree: [{
                    "id": "1ab28b34-4c36-4e5d-8092-1f1189d2f4e1",
                    "deptId": 10,
                    "name": "迷你校测试公司",
                    "createdOn": "20170304185637",
                    "updatedOn": "20170304185637",
                    "children": [{
                        "id": "58ebf871-d914-4e24-8f1d-c0c57176dfca",
                        "deptId": "1000",
                        "name": "迷你校上海分公司",
                        "createdOn": "20170304190041",
                        "updatedOn": "20170304190213",
                    }]
                }],
                departmentArray:[
                  // {
                  //   "id": "1ab28b34-4c36-4e5d-8092-1f1189d2f4e1",
                  //   "deptId": 10,
                  //   "name": "迷你校测试公司",
                  //   "createdOn": "20170304185637",
                  //   "updatedOn": "20170304185637"
                  // },
                  // {
                  //   "id": "58ebf871-d914-4e24-8f1d-c0c57176dfca",
                  //   "deptId": 1000,
                  //   "name": "迷你校上海分公司",
                  //   "createdOn": "20170304190041",
                  //   "updatedOn": "20170304190213"
                  // },
                  // {
                  //   "id": "1bcb8354-fbb2-4f81-9aaa-d0fdeafb4e9f",
                  //   "deptId": 1001,
                  //   "name": "迷你校北京分公司",
                  //   "createdOn": "20170306131700",
                  //   "updatedOn": "20170306131708"
                  // },
                  // {
                  //   "id": "abcb8354-f7b2-4f81-93aa-d0f3eafb4e9f",
                  //   "deptId": 100000,
                  //   "name": "销售部",
                  //   "createdOn": "20170306131733",
                  //   "updatedOn": "20170306131744"
                  // },
                  // {
                  //   "id": "92cb5354-f4b2-4f81-93aa-d04de6fb4e9f",
                  //   "deptId": 100001,
                  //   "name": "开发部",
                  //   "createdOn": "20170306131809",
                  //   "updatedOn": "20170306131827"
                  // },
                  // {
                  //   "id": "7b0b8954-fbb2-4f81-93aa-d0f3eafb4e9f",
                  //   "deptId": 100100,
                  //   "name": "运营组",
                  //   "createdOn": "20170306131848",
                  //   "updatedOn": "20170306131906"
                  // }
                ],
                defaultProps:{
                    children: 'children',
                    label: 'name'
                }
            }
        },
        computed:{
            userId(){
                return this.$store.getters.userId
            },
            userName(){
                return this.$store.getters.userName
            },
            recId(){
                return this.$store.getters.recId
            }
        },
        methods:{
            selectDepartment(value) {
                this.checkedDepartmentName = value.name;
                this.checkedDepartmentDeptId = value.deptId;
                this.checkedDepartment = value;
                console.log(this.checkedDepartmentName+this.checkedDepartmentDeptId);
            },
            createDepartment(value){
                console.log('创建'+value);
                let department = {
                    parentId:this.checkedDepartmentDeptId,
                    name:value
                }
                this.$http.post('/company/department',department,{headers: {'Content-Type':'application/json'}}).then(response =>{
                    console.log(response);
                    this.$message({
                        message: '创建成功',
                        type: 'warning',
                        duration:2000
                    });
                    this.getDepartmentList();
                },response =>{
                    console.log('cuo le ')
                })

            },
            newDepartment(){
                if(this.checkedDepartmentDeptId===''){
                    this.$message({
                        message: '请选择上级部门',
                        type: 'warning',
                        duration:2000
                    });
                    return;
                }
                this.isCreateDepartment = true;
            },
            modifyDepartment(){
                if(this.checkedDepartmentDeptId===''){
                    this.$message({
                        message: '请选择需要修改的部门',
                        type: 'warning',
                        duration:2000
                    });
                    return;
                }
                this.isModifyDepartment = true;
            },
            deleteDepartment(){
                if(this.checkedDepartmentDeptId===''){
                    this.$message({
                        message: '请选择需要删除的部门',
                        type: 'warning',
                        duration:2000
                    });
                    return;
                }
                this.$http.delete('/company/departments/'+this.checkedDepartment.id).then(response =>{
                    console.log(response);
                    this.$message({
                        message: response.body,
                        duration:2000
                    });
                    this.checkedDepartmentDeptId='';
                    this.checkedDepartmentName='';
                    this.checkedDepartment={};
                    this.getDepartmentList();
                })
            },
            updatedDepartment(value){
                console.log(value);
                this.$http.put('/company/departments/'+this.checkedDepartment.id+'?name='+value).then(response =>{
                    this.$message({
                        message: response.body,
                        duration:2000
                    });
                    this.getDepartmentList();
                })
            },
            getDepartmentList(){
                this.$http.get('/company/departments').then(response =>{
                    let a = response.body;
                    this.departmentArray = a;
                    this.departmentTree = arrayToTree(this.departmentArray,"");
                })
            },
            claseEditor(){
                this.isCreateDepartment = false;
            },
            claseModify(){
                this.isModifyDepartment = false;
            }
        },
        mounted(){
            this.getDepartmentList();
        },
        components:{
            CreateDepartmentModal,
            ModifyDepartmentModal
        }
    }
    function arrayToTree(data,pid){
        let result = [];
        let temp;
        for(let i=0;i<data.length;i++){
            if(data[i].deptId.slice(0,-2) === pid){
                let obj = {"id":data[i].id,"deptId":data[i].deptId,"name":data[i].name,"createdOn":data[i].createdOn,"updatedOn":data[i].updatedOn};
                temp = arrayToTree(data,data[i].deptId);
                if(temp.length>0){
                    obj.children = temp;
                }
                result.push(obj);
            }
        }
        return result;
    }

</script>

<style lang="less">
    .department {
        .el-breadcrumb {
            display: inline-block;
        }
        .department-title {
            margin-top: 20px;
            background-color: #ffffff;
        }
        .department-button {
            margin:20px 0;
        }
    }
</style>
