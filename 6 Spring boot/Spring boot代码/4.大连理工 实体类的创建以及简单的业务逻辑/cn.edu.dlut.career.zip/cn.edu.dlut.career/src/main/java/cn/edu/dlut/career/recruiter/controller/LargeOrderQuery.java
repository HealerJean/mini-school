package cn.edu.dlut.career.recruiter.controller;

import cn.edu.dlut.career.recruiter.domain.LargeOrder;
import cn.edu.dlut.career.recruiter.service.LargeOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

/**
 * Created by HealerJean on 2017/3/27.
 */
@RestController
public class LargeOrderQuery {
    @Autowired
    LargeOrderService largeOrderService;

    /**
     * 更新 大型招聘会的审核状态
     *
     *  需要参数  以下四个
     *  说明：经过测试，表示成功
     * @param id
     * @param auditState
     * @param auditTime
     * @param auditPerson
     * @return
     */
    @PutMapping("/largeOrder/updateAudit")
    public String  updateAudit(String id, String auditState, Date auditTime, String auditPerson ) {

       int  updateStatus = largeOrderService.updateLargeOrderAudit(id,auditState,this.DateToLocalDateTime(auditTime), auditPerson);
            if(updateStatus!=0){
                return "ok";
            }
        return  null;
    }
    //将url字符串日期转化为Date 类型
    @InitBinder
    public void initBinder(ServletRequestDataBinder binder){
        binder.registerCustomEditor(Date.class, new CustomDateEditor(new SimpleDateFormat("yyyy-MM-dd"), true));
    }
    //将Date转化为LocalDateTime
    public LocalDateTime DateToLocalDateTime(Date auditTime){
        Instant instant = Instant.ofEpochMilli(auditTime.getTime());
        LocalDateTime res = LocalDateTime.ofInstant(instant, ZoneId.systemDefault());
        return  res;
    }

    //添加大型招聘预约表 信息
    @PostMapping("/largeOrder/saveLargeOrder")
    public String  saveLargeOrder(@RequestBody LargeOrder largeOrder) {
         LargeOrder saveState = largeOrderService.saveLargeOrder(largeOrder);
         if(saveState!=null){
             return "ok";
         }
            return  null;
      }



}
