package cn.edu.dlut.career.repository.company;

import cn.edu.dlut.career.domain.company.YardOrder;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

/** 场地预约 数据库操作
 * Created by HealerJean on 2017/3/23.
 */
@Repository
public interface YardOrderRepository extends CrudRepository<YardOrder, String> {

    //根据id进行查找
    YardOrder findById(String id);

    //查找全部信息
    List<YardOrder> findAll();

    //更新审核状态 根据 id
    @Modifying
    @Query(value = "update YardOrder set auditState = ?2 ,auditTime = ?3,auditPerson=?4 where id = ?1")
    int updateYardOrderAudit(String id, String auditState, LocalDateTime auditTime, String auditPerson);


}
