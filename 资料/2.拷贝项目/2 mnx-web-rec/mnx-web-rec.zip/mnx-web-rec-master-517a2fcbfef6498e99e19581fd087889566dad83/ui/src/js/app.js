// dependencies
import Vue from 'vue';
import ElementUI from 'element-ui';
import VueRouter from 'vue-router';
import VueResource from 'vue-resource';

// styles
import 'element-ui/lib/theme-default/index.css';
import 'less/shared/shared.less';
import 'less/reset/reset.less';
import 'less/mixins/mixins.less';
import 'less/pages/pages.less';
import 'less/shared/common.less';

// routers
import routes from './routers';

// components
import AppHeader from '../Components/Shared/Header.vue';
import AppFooter from '../Components/Shared/Footer.vue';

//store
import store from './store';


Vue.use(ElementUI);
Vue.use(VueRouter);
Vue.use(VueResource);

const router = new VueRouter({
    routes
});

new Vue({
    router,
    components: {
        AppHeader,
        AppFooter
    },
    store,
    created(){
        if(window.localStorage){
            console.log('支持')
        }else{
            console.log('不支持')
        };
        this.$http.get('/payload').then(response =>{
            console.log(response.body);
             this.$store.commit('updateUserInfor' , response.body );
            window.localStorage.setItem("updateUserInfor", response.body);
            console.log(window.localStorage.getItem('updateUserInfor'))
        })
    }

}).$mount('#app');
