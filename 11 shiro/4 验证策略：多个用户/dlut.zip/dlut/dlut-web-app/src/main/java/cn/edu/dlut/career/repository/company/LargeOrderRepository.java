package cn.edu.dlut.career.repository.company;

import cn.edu.dlut.career.domain.company.LargeOrder;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 大型招聘会预约 数据库操作
 * Created by HealerJean on 2017/3/23.
 */
@Repository
public interface LargeOrderRepository extends CrudRepository<LargeOrder, String> {
    //根据id进行查找
    LargeOrder findById(String id);

    //查找全部信息
    List<LargeOrder> findAll();

    //更新审核状态 根据 id
    @Modifying
    @Query(value = "update LargeOrder set auditState = ?2 ,auditTime = ?3,auditPerson=?4 where id = ?1")
    int updateLargeOrderAudit(String id, String auditState, LocalDateTime auditTime, String auditPerson);

}
