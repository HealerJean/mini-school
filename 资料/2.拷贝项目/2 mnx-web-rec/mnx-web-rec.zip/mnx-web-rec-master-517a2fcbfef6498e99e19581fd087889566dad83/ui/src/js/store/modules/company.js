
// initial state
const state = {
    recommendTags:[
        "五险一金","年终奖","餐补","班车","旅游"
    ],
    companyInformation:{
        "id" : "0e62a6e3-d3b1-4aa1-8e31-10d434af1916",
        "fullName" : "精准头网络科技（北京）有限公司",
        "shortName" : "迷你校",
        "slogan" : "迷你校垂直于校园领域，致力于帮助企业快速、高效、低成本获取高校良才的平台。",
        "description" : "迷你校垂直于校园领域，致力于帮助企业快速、高效、低成本获取高校良才的平台。迷你校利用大数据及人工智能技术，打造行业颠覆式、独有的创新校招系统——“校招云SaaS系统”，将企业需求与学生能力精准匹配，帮助企业在万千简历中锁定所需人才。经过一年快速发展，迷你校已跻身校园人才领域第一阵营，现平台已拥有10万份名校毕业生数据，涵盖北京大学、清华大学、复旦大学、武汉大学等国内重点高校。通过迷你校连接企业与学生，让企业没有难招的学生，让学生没有难找的工作。",
        "subdomain": "liukuai.minixiao.com",
        "recHref" : "www.minixiao.com/liukuai",
        "nature" : "上市公司",
        "size" : "2000-5000人",

        "primaryIndustry" : "互联网·游戏·软件",
        "slaveIndustry" : "计算机软件",
        "city" : "北京",
        "detailAddress" : "北京-朝阳",
        "website" : "http://www.minixiao.com/",
        "tags" : "股票期权,五险一金,年终奖",
        "postcode" : 100509,
        "logo" : "http://www.minixiao.com/st/images/corpLogo/201612/23270190d9e17648648cc197fd31542.png",
        "validityStart" : "20170223",
        "validityEnd" : "20190223",
        "salesInfo" : "销售员张三",
        "scale" : "SSS",
        "createdOn" : "20170223020830",
        "updatedOn" : "20170223020833"
    }


    // {
    //     "id":"4bcb8354-fbb2-4f81-93aa-d0fdeafb4e9f",
    //     "fullName":"上海六块科技有限公司",
    //     "shortName":"上块",
    //     "slogan":"最资深的外卖公司(不是骗人的)",
    //     "description":"不是是是是骗人的公司",
    //     "subdomain":"liukuai.minixiao.com",
    //     "recHref":"www.minixiao.com/liukuai",
    //     "nature":"国有企业","size":"50-99人",
    //     "primaryIndustry":"互联网·游戏·软件dd",
    //     "slaveIndustry":"计算机软件dd",
    //     "city":"北京000","detailAddress":
    //     "北京市朝阳区甜水园商务中心a-207",
    //     "website":"www.minixiao.cn",
    //     "tags":"股票期权,五险一金,年终奖,餐补,班车",
    //     "logo":"http://www.minixiao.com/st/images/corpLogo/201612/23270190d9e17648648cc197fd31542.png",
    //     "pictures":[],
    //     "salesInfo":"销售员张三","scale":"SSS","validityStart":null,
    //     "validityEnd":[2017,3,1],
    //     "createdOn":"20170302114917",
    //     "updatedOn":"20170306113537"
    // }

}

//getters
const getters = {

}

//actions
const actions = {

}

//mutations
const mutations = {
    updateCompanyInformation (state,value) {
            state.companyInformation = value;
            // console.log(typeof(value));
            // console.log(state.companyInformation)
        },
}


export default {
  state,
  getters,
  actions,
  mutations
}
