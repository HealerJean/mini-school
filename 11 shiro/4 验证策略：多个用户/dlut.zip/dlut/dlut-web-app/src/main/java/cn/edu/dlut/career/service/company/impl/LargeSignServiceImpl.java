package cn.edu.dlut.career.service.company.impl;


import cn.edu.dlut.career.domain.company.LargeSign;
import cn.edu.dlut.career.repository.company.LargeSignRepository;
import cn.edu.dlut.career.service.company.LargeSignService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * 大招签到 服务层
 * Created by HealerJean on 2017/3/24.
 */
@Service
@Transactional
public class LargeSignServiceImpl implements LargeSignService {
    @Autowired
    LargeSignRepository largeSignRepository;


    @Override
    public LargeSign saveLargeSign(LargeSign largeSign) {
        return largeSignRepository.save(largeSign);
    }

    @Override
    public LargeSign findById(String id) {
        return largeSignRepository.findById(id);
    }

    @Override
    public LargeSign updateLargeSign(LargeSign largeSign) {
        return largeSignRepository.save(largeSign);
    }

    @Override
    public String deleteLargeSign(String id) {
        try {
            largeSignRepository.delete(id);
            return "ok";
        }catch (Exception e){
            e.printStackTrace();
        }
        return  null;
    }

    @Override
    public List<LargeSign> findAllLargeSign() {
        return largeSignRepository.findAll();
    }
}
