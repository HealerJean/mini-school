package cn.edu.dlut.career.recruiter.ThymeLeaf;

import cn.edu.dlut.career.recruiter.domain.LargeOrder;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Created by HealerJean on 2017/3/28.
 */
public interface TestPageableRepository extends JpaRepository<LargeOrder ,String>{

    LargeOrder findById(String id);
}
