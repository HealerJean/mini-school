<template>
    <div class="set-filter">
        <div>我的位置：
            <el-breadcrumb separator=">">
                <el-breadcrumb-item>系统设置</el-breadcrumb-item>
                <el-breadcrumb-item>筛选器管理</el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        <div v-if="!isOpened" >
            <div class="filter-add">
                <el-button type="primary" @click="addfilter">+添加筛选器</el-button>
                    <div v-on:keyup.enter="search" class="filter-search">
                        <el-input placeholder="请输入筛选器名称" icon="search" v-model="filterName" :on-icon-click="search" >
                    </el-input>
                </div>
            </div>
            <el-table :data="filterList" style="width:100%" :row-style="rowStyle">
                <el-table-column  label="序号" type="index" width="100" header-align="center" align="center">
                </el-table-column>
                <el-table-column prop="name" label="筛选器名称" header-align="center" align="center">
                </el-table-column>
                <el-table-column prop="updatedOn" label="创建/修改时间" header-align="center"  align="center" :formatter="formatDate">
                </el-table-column>
                <el-table-column label="操作" header-align="center" align="center">
                    <template scope="scope">
                        <span style="line-height: 58px;">
                            <el-button type="text" @click="modify(scope.row)">修改</el-button>
                            <el-button type="text" @click="remove(scope.row)">删除</el-button>
                        </span>
                    </template>
                </el-table-column>
            </el-table>
        </div>
        <div v-if="isOpened" class="add-editor-filter">
            <div class="add-filter-title">
                <h2>
                    添加/编辑筛选器
                </h2>
            </div>
            <div class="title-text">
                查询条件
            </div>
            <el-form ref=""label-width="100px">
                        <!-- 弹出窗 -->
                <!-- 存为筛选器 -->
                <save-sizer :isSaveSizer="isSaveSizer" @saveSizer="makeSureSaveSizer" @closeSizer="closeSizer"></save-sizer>
                <!-- 选择部门 -->
                <select-department-modal :isSelectDepartment="isSelectDepartment"></select-department-modal>
                <!-- 选择大学 -->
                <select-university-modal :isSelectUniversity="isSelectUniversity" @modal:select-university-closing="closeSelectUniversity" @modal:emit-selected-universities="selectedUniversity" :max="maxUniversity"></select-university-modal>
                <!-- 选择家庭所在地 -->
                <select-city-modal :isSelectingCity="isSelectCity" @modal:select-city-closing="closeSelectCity" @modal:emit-selected-cities="selectedCity" :max="maxCity"></select-city-modal>
                <!-- 展开查询条件 -->
                <div class="options-all input-size-md">

                    <el-row :gutter="70">
                        <el-col :span="8">
                            <el-form-item label="投递职位">
                                <el-select v-model="position" placeholder="不限" >
                                    <el-option v-for="item in positionItems" :label="item.label" :value="item.value">
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="最高学历">
                                <el-select v-model="degree" placeholder="不限" >
                                    <el-option v-for="item in degreeItems" :label="item.label" :value="item.value">
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="毕业院校">
                                <el-input v-model="school" @focus="isSelectUniversity=true" readonly placeholder="请选择"></el-input>
                            </el-form-item>
                        </el-col>
                    </el-row>

                    <el-row :gutter="70">
                        <el-col :span="8">
                            <el-form-item label="专业">
                                <el-input v-model="major"></el-input>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="处理状态">
                                <el-select v-model="status" placeholder="不限" >
                                    <el-option v-for="item in statusItems" :label="item.label" :value="item.value">
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="简历标签">
                                <el-select v-model="label" placeholder="不限" multiple>
                                    <el-option v-for="item in tags" :label="item.label" :value="item.value">
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                    </el-row>

                    <el-row :gutter="70">
                        <el-col :span="8">
                            <el-form-item label="性别">
                                <el-select v-model="gender" placeholder="不限" >
                                    <el-option v-for="item in genderItems" :label="item.label" :value="item.value">
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="聘用部门">
                                <el-input v-model="department" @focus="selectDepartment" readonly placeholder="请选择"></el-input>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="专业排名">
                                <el-select v-model="rank" placeholder="不限" >
                                    <el-option v-for="item in rankItems" :label="item.label" :value="item.value">
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                    </el-row>

                    <el-row :gutter="70">
                        <el-col :span="8">
                            <el-form-item label="英语等级">
                                <el-select v-model="englishLevel" placeholder="不限" multiple>
                                        <el-option v-for="item in englishLevelItems" :label="item.label" :value="item.value">
                                        </el-option>
                                    </el-select>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="获奖荣誉">
                                <el-select v-model="reward" placeholder="不限" >
                                    <el-option v-for="item in rewardItems" :label="item.label" :value="item.value">
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="附件简历">
                                <el-select v-model="attachment" placeholder="不限" >
                                    <el-option v-for="item in attachmentItems" :label="item.label" :value="item.value">
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                    </el-row>

                    <el-row :gutter="70">
                        <el-col :span="8">
                            <el-form-item label="手机号码">
                                <el-input v-model="mobile"></el-input>
                            </el-form-item>
                        </el-col>
                       <el-col :span="8">
                            <el-form-item label="家庭所在地">
                                <el-input v-model="city" @focus="isSelectCity=true" readonly placeholder="请选择家庭所在地"></el-input>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="出生年份" class="jq-date-group">
                                <el-col :span="11">
                                    <el-date-picker v-model="birthFrom" align="right" type="year" placeholder="不限" :picker-options="pickerOptionsStartBirth" :editable="false" :clearable="false">
                                    </el-date-picker>
                                </el-col>
                                <el-col class="line" :span="2" style="padding:1px 0 0 2px;">~</el-col>
                                <el-col :span="11">
                                    <el-date-picker v-model="birthTo" align="right" type="year" placeholder="不限" style="float:right;" :picker-options="pickerOptionsEndBirth" :editable="false" :clearable="false">
                                    </el-date-picker>
                                </el-col>
                            </el-form-item>
                        </el-col>
                    </el-row>

                    <el-row :gutter="70">
                        <el-col :span="8">
                            <el-form-item label="毕业时间" class="jq-date-group">
                                <el-col :span="11">
                                    <el-date-picker v-model="graduateFrom" align="right" type="year" placeholder="不限" :picker-options="pickerOptionsgraduateFrom" :editable="false" :clearable="false">
                                    </el-date-picker>
                                </el-col>
                                <el-col class="line" :span="2" style="padding:1px 0 0 2px;">~</el-col>
                                <el-col :span="11">
                                    <el-date-picker v-model="graduateTo" align="right" type="year" placeholder="不限" :picker-options="pickerOptionsgraduateTo"  style="float:right;" :editable="false" :clearable="false">
                                    </el-date-picker>
                                </el-col>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="投递日期" class="jq-date-group">
                                <el-col :span="11">
                                    <el-date-picker v-model="deliveryFrom" type="date" placeholder="不限" :picker-options="pickerOptionsSendStart" format="MM-dd" :editable="false" :clearable="false">
                                    </el-date-picker>
                                </el-col>
                               <el-col class="line" :span="2" style="padding:1px 0 0 2px;">~</el-col>
                               <el-col :span="11">
                                    <el-date-picker v-model="deliveryTo" type="date" placeholder="不限" :picker-options="pickerOptionsSendEnd"  format="MM-dd" style="float:right;" :editable="false" :clearable="false">
                                    </el-date-picker>
                                </el-col>
                            </el-form-item>
                        </el-col>
                    </el-row>



                    <div class="button-list">
                        <el-button type="primary" class="my-button" @click="saveSizer">保存</el-button>
                        <el-button class="my-button gray-button" @click="resetFilter">重置</el-button>
                        <el-button class="my-button" @click="closeMore">取消</el-button>
                    </div>
                </div>
            </el-form>
        </div>
    </div>
</template>

<script type="text/babel">
import SelectDepartmentModal from '../Modal/SelectDepartmentModal.vue';
import SelectCityModal from '../Modal/SelectCityModal.vue';
import SelectUniversityModal from '../Modal/SelectUniversityModal';
import SaveSizer from '../Candidate/SaveSizerModel.vue';

    export default {
        name: 'filter',
        data() {
            return {
                filterName:'',
                modifyingId:'',
                searchContent:'',

                // 投递职位
                position:'',
                // 最高学历
                degree:'',
                // 毕业院校
                school:'',
                // 专业
                major:'',
                // 处理状态
                status:'',
                // 简历标签
                label:[],
                // 性别
                gender:'',
                // 聘用部门
                department:'',
                // 实习经历
                practices:'',
                // 项目经验
                work:'',
                // 专业排名
                rank:'',
                // 英语等级
                englishLevel:[],
                // 奖学金
                reward:'',
                // 参赛经历
                competition:'',
                // 附件简历
                attachment:'',
                // 手机号码
                mobile:'',
                // 家庭所在地
                city:'',
                // 出生年份开始时间
                birthFrom:'',
                // 出生年份截止时间
                birthTo:'',
                // 毕业时间开始
                graduateFrom:'',
                // 毕业时间截止
                graduateTo:'',
                // 投递日期开始
                deliveryFrom:'',
                // 投递日期截止
                deliveryTo:'',
                //名字
                name:'',

                maxCity:5,
                maxUniversity:6,
                isSelectCity:false,
                isSelectUniversity:false,
                custom:'custom',
                tags:[
                    {label:'一般',value:'一般'},
                    {label:'还可以',value:'还可以'},
                    {label:'优秀',value:'优秀'},
                    {label:'待定',value:'待定'}
                ],
                optionsData: [],
                isOpened: false,
                isSaveSizer: false,
                isAddTag: false,
                isSelectDepartment: false,

                positions: [],

                statusItemss:{
                '筛选类型': [
                    {label:'不限' ,value:''},
                    {label:'未处理',value:'1___'},
                    {label:'待定',value:'2___'},
                    {label:'未通过',value:'3___'}],
                '笔试类型': [
                    {label:'不限' ,value:''},
                    {label:'未处理',value:'11__'},
                    {label:'已安排笔试（未通知）',value:'121_'},
                    {label:'已安排笔试（已通知）',value:'122_'},
                    {label:'未通过',value:'3___'}
                    ],
                '面试类型': [
                    {label:'不限' ,value:''},
                    {label:'未处理',value:'11__'},
                    {label:'已安排面试（未通知）',value:'121_'},
                    {label:'已安排面试（已通知）',value:'122_'},
                    {label:'未通过',value:'3___'}
                    ],
                '录用类型': [
                    {label:'不限' ,value:''},
                    {label:'未处理',value:'1_1_'},
                    {label:'已发offer',value:'5_2_'},
                    {label:'已淘汰（未通知）',value:'4_1_'},
                    {label:'已淘汰（已通知）',value:'4_2_'}]
                },

                degreeItems:[
                    {label:'不限' ,value:''},
                    {label:'大专' ,value:'1'},
                    {label:'本科' ,value:'2'},
                    {label:'研究生' ,value:'3'},
                    {label:'博士' ,value:'4'},
                    ],
                englishLevelItems: [
                    {label:'四级',value:'四级'},
                    {label:'六级',value:'六级'},
                    {label:'专业四级',value:'专业四级'},
                    {label:'专业八级',value:'专业八级'},
                    {label:'其他',value:'其他'},
                ],
                genderItems:[
                    {label:'不限',value:''},
                    {label:'男',value:'男'},
                    {label:'女',value:'女'}
                ],
                rankItems:[
                    {label:'不限',value:''},
                    {label:'前5%',value:'1'},
                    {label:'前10%',value:'2'},
                    {label:'前20%',value:'3'},
                    {label:'前50%',value:'4'},
                ],

                // workItems: [
                //     {label:'不限',value:''},
                //     {label:'有',value:'有'},
                //     {label:'无',value:'无'}
                // ],

                practicesItems: [
                    {label:'不限',value:''},
                    {label:'有',value:'Y'},
                    {label:'无',value:'N'}
                ],

                rewardItems: [
                    {label:'不限',value:''},
                    {label:'有',value:'Y'},
                    {label:'无',value:'N'}
                ],

                competitionItems: [
                    {label:'不限',value:''},
                    {label:'有',value:'Y'},
                    {label:'无',value:'N'}
                ],

                attachmentItems: [
                    {label:'不限',value:''},
                    {label:'有',value:'Y'},
                    {label:'无',value:'N'}
                ],

                pickerOptionsSendEnd:{
                    disabledDate:(time)=> {
                        return time.getTime() <= new Date(this.deliveryFrom).getTime() - 8.64e7;
                    }
                },
                pickerOptionsSendStart:{
                    disabledDate:(time)=> {
                        let disTime = Date.now() - 8.64e7 + 24*60*60*1000;
                        if(!(this.deliveryTo==='') && this.deliveryTo<disTime){
                            disTime = new Date(this.deliveryTo).getTime() - 8.64e7;
                        }
                        return time.getTime() >  disTime;
                    }
                },

                pickerOptionsStartBirth: {
                    disabledDate: (time) => {
                        let disTime = Date.now() - 8.64e7 + 24*60*60*1000;
                        if(!(this.birthTo === '') && this.birthTo < disTime){
                            disTime = new Date(this.birthTo).getTime() - 8.64e7;
                        }
                        return time.getTime() >  disTime;
                    }
                },
                pickerOptionsEndBirth: {
                    disabledDate: (time) => {
                        return time.getTime() <= new Date(this.birthFrom).getTime() - 8.64e7;
                    }
                },

                pickerOptionsgraduateFrom: {
                    disabledDate: (time) => {
                        let disTime = Date.now() - 8.64e7 + 24*60*60*1000;
                        if(!(this.graduateTo === '') && this.graduateTo < disTime){
                            disTime = new Date(this.graduateTo).getTime() - 8.64e7;
                        }
                        return time.getTime() >  disTime;
                    }
                },
                pickerOptionsgraduateTo: {
                    disabledDate:(time)=> {
                        return time.getTime() <= new Date(this.graduateFrom).getTime() - 8.64e7;
                    }
                },
            };
        },
        methods: {
            rowStyle(row){
                if(!row.name.includes(this.filterName)){
                    return "display:none;";
                }
            },
            getTagsList(){
                console.log('获取候选人标签列表')
                this.$http.get('company/labels').then(response =>{
                    let a = response.body;
                    console.log(a);
                    //存到状态库中

                    this.$store.commit('updateTagsList' , a);
                })
            },
            modify(value){
                this.modifyingId = value.id;
                // 投递职位
                this.position=value.candidateProfile.position;
                // 最高学历
                this.degree=value.candidateProfile.degree;
                // 毕业院校
                this.school=value.candidateProfile.school;
                // 专业
                this.major=value.candidateProfile.major;
                // 处理状态
                this.status=value.candidateProfile.status;
                // 简历标签
                if(value.candidateProfile.label.split(",")){
                    this.label = [];
                }else{
                    this.label=value.candidateProfile.label.split(",");
                }
                // 性别
                this.gender=value.candidateProfile.gender;
                // 聘用部门
                this.department=value.candidateProfile.department;


                // 专业排名
                this.rank=value.candidateProfile.rank;
                // 英语等级
                if(value.candidateProfile.englishLevel.split(",")){
                    this.englishLevel = [];
                }else{
                    this.englishLevel=value.candidateProfile.englishLevel.split(",");
                }
                // 奖学金
                this.reward=value.candidateProfile.reward;

                // 附件简历
                this.attachment=value.candidateProfile.attachment;
                // 手机号码
                this.mobile=value.candidateProfile.mobile;
                // 家庭所在地
                this.city=value.candidateProfile.city;
                // 出生年份开始时间
                this.birthFrom=value.candidateProfile.birthFrom;
                // 出生年份截止时间
                this.birthTo=value.candidateProfile.birthTo;
                // 毕业时间开始
                this.graduateFrom=value.candidateProfile.graduateFrom;
                // 毕业时间截止
                this.graduateTo=value.candidateProfile.graduateTo;
                // 投递日期开始
                this.deliveryFrom=value.candidateProfile.deliveryFrom;
                // 投递日期截止
                this.deliveryTo=value.candidateProfile;
                this.isOpened = true;
            },
            remove(value){
                console.log('删除筛选器')
                this.$http.delete('company/users/filter/candidate/'+value.id).then(response =>{
                    this.$message({
                            message: response.body,
                            duration:2000
                        });
                    this.getFilterList();
                })
            },

            search(){
                console.log(this.searchContent);
            },
            //选择部门
            selectDepartment(){
                this.isSelectDepartment = true;
            },
            closeSelectDepartmentModal(){
                this.isSelectDepartment = false;
            },
            makeSureSelectDepartment(value){
                this.department = value;
            },
            selectedCity: function(value){
                this.city = value.join(',');
            },
            closeSelectCity: function(){
                this.isSelectCity = false;
            },
            selectedUniversity: function(value){
                this.school = value.join(',');
            },
            //关闭大学选择框
            closeSelectUniversity: function(){
                this.isSelectUniversity = false;
            },
            //保存筛选器按钮方法
            saveSizer: function(){
                this.isSaveSizer=true;
            },
            //关闭编辑筛选器名字
            closeSizer: function(){
                this.isSaveSizer = false;

            },
            //关闭按钮方法
            closeMore: function(){
                this.isOpened=false;
                this.modifyingId = "";
            },
            //添加筛选器按钮方法
            addfilter(){
                this.modifyingId = '';
                this.isOpened = true;
            },
            //存为筛选器
            makeSureSaveSizer: function(value){
                let saveingSizer ={
                    "position": this.position,
                    "degree": this.degree,
                    "school": this.school,
                    "major": this.major,
                    "status": this.status,
                    "label": this.label.join(','),
                    "gender": this.gender,
                    "department": this.department,
                    "rank": this.rank,
                    "englishLevel": this.englishLevel.join(','),
                    "reward": this.reward,
                    "attachment": this.attachment,
                    "mobile": this.mobile,
                    "city": this.city,
                    "birthFrom": this.birthFrom,
                    "birthTo": this.birthTo,
                    "graduateFrom": this.graduateFrom,
                    "graduateTo": this.graduateTo,
                    "deliveryFrom": this.deliveryFrom,
                    "deliveryTo": this.deliveryTo
                }
                let filterData = {
                    name: value,
                    candidateProfile: saveingSizer,
                }

                if(this.modifyingId){
                    console.log('修改筛选器')
                    this.$http.put('company/users/filter/candidate/' + this.modifyingId,filterData,{headers: {'Content-Type':'application/json'}}).then(response =>{
                            this.$message({
                                    message: response.body,
                                    duration:2000
                                });
                            this.getFilterList();
                        },response =>{

                    });

                }else {
                    console.log('创建筛选器')
                    this.$http.post('company/users/filter/candidate',filterData,{headers: {'Content-Type':'application/json'}}).then(response =>{
                            this.$message({
                                    message: response.body,
                                    duration:2000
                                });

                            this.getFilterList();

                        },response =>{

                    });
                }

                this.isOpened=false;
                this.modifyingId="";
            },
            resetFilter(){
                // 投递职位
                this.position='';
                // 最高学历
                this.degree='';
                // 毕业院校
                this.school='';
                // 专业
                this.major='';
                // 处理状态
                this.status='';
                // 简历标签
                this.label=[];
                // 性别
                this.gender='';
                // 聘用部门
                this.work='';
                // 专业排名
                this.rank='';
                // 英语等级
                this.englishLevel=[];
                // 奖学金
                this.reward='';
                // 参赛经历
                this.competition='';
                // 附件简历
                this.attachment='';
                // 手机号码
                this.mobile='';
                // 家庭所在地
                this.city='';
                // 出生年份开始时间
                this.birthFrom='';
                // 出生年份截止时间
                this.birthTo='';
                // 毕业时间开始
                this.graduateFrom='';
                // 毕业时间截止
                this.graduateTo='';
                // 投递日期开始
                this.deliveryFrom='';
                // 投递日期截止
                this.deliveryTo='';

            },
            //获取筛选器列表
            getFilterList(){
                console.log('获取筛选器列表')
                this.$http.get('company/users/filter/candidate').then(response =>{
                    let a = response.body;
                    console.log(a);
                    //存到状态库中

                    this.$store.commit('updateFilterList' , a);
                })
            },
            formatDate(val) {
                if(val){
                    return val.updatedOn.substring(0,4)+'-'+val.updatedOn.substring(4,6)+'-'+val.updatedOn.substring(6,8);
                }
            },
        },
        mounted(){
            this.getFilterList();
            this.getTagsList()
        },
        computed:{
            tagsList(){
                return this.$store.state.candidate.tagsList
            },
            filterList(){
                return this.$store.state.candidate.filterList
            },
            userId(){
                return this.$store.getters.userId
            },
            userName(){
                return this.$store.getters.userName
            },
            recId(){
                return this.$store.getters.recId
            }
        },

        components: {
            SaveSizer,
            SelectDepartmentModal,
            SelectCityModal,
            SelectUniversityModal

        }
    }

</script>

<style lang="less">
@import "../../less/shared/variables.less";
    .set-filter {
        .el-table {
            .el-button {
                padding:0;
            }
        }
        .el-breadcrumb {
            display: inline-block;
        }
        .filter-add {
            margin-top: 20px;
            margin-bottom: 20px;
            .filter-search {
                float: right;
                width:286px;
                height:34px;
                .el-input__inner {
                    height:34px;
                    padding-left: 30px;
                }
                .el-input__icon {
                    cursor: pointer;
                    left:0;
                }
            }
        }
        .add-editor-filter {
            background-color: #ffffff;
            .title-text {
                padding-left: 40px;
                line-height: 50px;
                background-color: #f6f8fc;
            }
         }
            .add-filter-title {
                line-height: 60px;
                h2 {
                    margin:0;
                }
            }
            .options-all {
                width: 100%;
                border: @border-gray;
                background: @white;
                padding: 20px 20px;
                margin-bottom: 15px;
                box-sizing: border-box;


                .button-list {
                    text-align: center;
                    width: 1140px;
                    margin-top:30px;
                    margin-bottom: 10px;
                    .close-more {
                        position: absolute;
                        right: 0px;
                        }
                    .my-button {
                            width:90px;
                            height:34px;
                        }
                    .gray-button {
                        background-color: #eeeeee;
                    }

                }

            .options-all {
                .el-input__inner {
                    height: 34px;
                }

            }
        }
    }
</style>
