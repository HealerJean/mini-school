package cn.edu.dlut.career.domain.company;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;

/**
 * Created by 史念念 on 2017/3/24.
 *
 * 专场招聘会预约 实体类
 */
@Entity
@Table(name = "rec_career_event")
public class RecCareerEvent {

    //主键
    @Id
    @GenericGenerator(name = "idGenerator", strategy = "uuid")
    @GeneratedValue(generator = "idGenerator")
    private String id;

    //招聘简章id
    @Column(name = "bulletin_id", nullable = false)
    private String bulletinId;

    //招聘会名称
    @Column(name = "fair_name", length = 100, nullable = false)
    private String fairName;

    //计划召开日期
    @Column(name = "hold_time", nullable = false)
    private LocalDateTime holdTime;

    //开始时间
    @Column(name = "start_time", nullable = false)
    private LocalDateTime startTime;

    //结束时间
    @Column(name = "end_time", nullable = false)
    private LocalDateTime endTime;

    //企业id
    @Column(name = "rec_id", nullable = false)
    private String recId;

    //企业名称
    @Column(name = "rec_name", length = 100, nullable = false)
    private String recName;

    //企业所在地
    @Column(name = "rec_address", length = 100, nullable = false)
    private String recAddress;

    //联系人
    @Column(name = "contacts", length = 50, nullable = false)
    private String contacts;

    //联系人联系电话
    @Column(name = "con_tel", length = 20, nullable = false)
    private String conTel;

    //联系人邮箱
    @Column(name = "con_email", length = 100, nullable = false)
    private String conEmail;

    //场地要求/类型(多媒体教室、机房...)
    @Column(name = "area_require", length = 3, nullable = false)
    private char areaRequire;

    //场地规模(0-50人，50-100人，....)
    @Column(name = "area_size", length = 3, nullable = false)
    private char areaSize;

    //场地数量
    @Column(name = "area_num", nullable = false)
    private int areaNum;

    //场地用途
    @Column(name = "area_using", length = 100, nullable = false)
    private String areaUsing;

    //审核状态（待处理，借用中，已落实，已回复，未落实）
    @Column(name = "audit_status", length = 3, nullable = false)
    private char auditStatus;

    //审批意见
    @Column(name = "audit_suggest", length = 1000, nullable = true)
    private String auditSuggest;

    //场地地址
    @Column(name = "area_address", length = 100, nullable = true)
    private String areaAddress;

    //场地费用
    @Column(name = "area_cost", nullable = true)
    private float areaCost;

    //接待人
    @Column(name = "receiver", length = 50, nullable = true)
    private String receiver;

    //接待人联系方式
    @Column(name = "receiver_tel", length = 20, nullable = true)
    private String receiverTel;

    //审核时间
    @Column(name = "audit_time", nullable = true)
    private LocalDateTime auditTime;

    //审核人
    @Column(length = 50, nullable = true)
    private String auditor;

    //缴费方式(线上，线下)
    @Column(name = "pay_type", length = 3, nullable = true)
    private char payType;

    //缴费时间
    @Column(name = "pay_time", nullable = true)
    private LocalDateTime payTime;

    //申请日期
    @Column(name = "application_time", nullable = false)
    @CreationTimestamp
    private LocalDateTime applicationTime;

    //备注
    @Column(name = "remarks", length = 1000, nullable = true)
    private String remarks;

    public RecCareerEvent() {
    }

    public RecCareerEvent(String id, String bulletinId, String fairName, LocalDateTime holdTime, LocalDateTime startTime, LocalDateTime endTime, String recId, String recName, String recAddress, String contacts, String conTel, String conEmail, char areaRequire, char areaSize, int areaNum, String areaUsing, char auditStatus, String auditSuggest, String areaAddress, float areaCost, String receiver, String receiverTel, LocalDateTime auditTime, String auditor, char payType, LocalDateTime payTime, LocalDateTime applicationTime, String remarks) {
        this.id = id;
        this.bulletinId = bulletinId;
        this.fairName = fairName;
        this.holdTime = holdTime;
        this.startTime = startTime;
        this.endTime = endTime;
        this.recId = recId;
        this.recName = recName;
        this.recAddress = recAddress;
        this.contacts = contacts;
        this.conTel = conTel;
        this.conEmail = conEmail;
        this.areaRequire = areaRequire;
        this.areaSize = areaSize;
        this.areaNum = areaNum;
        this.areaUsing = areaUsing;
        this.auditStatus = auditStatus;
        this.auditSuggest = auditSuggest;
        this.areaAddress = areaAddress;
        this.areaCost = areaCost;
        this.receiver = receiver;
        this.receiverTel = receiverTel;
        this.auditTime = auditTime;
        this.auditor = auditor;
        this.payType = payType;
        this.payTime = payTime;
        this.applicationTime = applicationTime;
        this.remarks = remarks;
    }

    public String getId() {
        return id;
    }

    public String getBulletinId() {
        return bulletinId;
    }

    public String getFairName() {
        return fairName;
    }

    public LocalDateTime getHoldTime() {
        return holdTime;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public String getRecId() {
        return recId;
    }

    public String getRecName() {
        return recName;
    }

    public String getRecAddress() {
        return recAddress;
    }

    public String getContacts() {
        return contacts;
    }

    public String getConTel() {
        return conTel;
    }

    public String getConEmail() {
        return conEmail;
    }

    public char getAreaRequire() {
        return areaRequire;
    }

    public char getAreaSize() {
        return areaSize;
    }

    public int getAreaNum() {
        return areaNum;
    }

    public String getAreaUsing() {
        return areaUsing;
    }

    public char getAuditStatus() {
        return auditStatus;
    }

    public String getAuditSuggest() {
        return auditSuggest;
    }

    public String getAreaAddress() {
        return areaAddress;
    }

    public float getAreaCost() {
        return areaCost;
    }

    public String getReceiver() {
        return receiver;
    }

    public String getReceiverTel() {
        return receiverTel;
    }

    public LocalDateTime getAuditTime() {
        return auditTime;
    }

    public String getAuditor() {
        return auditor;
    }

    public char getPayType() {
        return payType;
    }

    public LocalDateTime getPayTime() {
        return payTime;
    }

    public LocalDateTime getApplicationTime() {
        return applicationTime;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setBulletinId(String bulletinId) {
        this.bulletinId = bulletinId;
    }

    public void setFairName(String fairName) {
        this.fairName = fairName;
    }

    public void setHoldTime(LocalDateTime holdTime) {
        this.holdTime = holdTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    public void setRecId(String recId) {
        this.recId = recId;
    }

    public void setRecName(String recName) {
        this.recName = recName;
    }

    public void setRecAddress(String recAddress) {
        this.recAddress = recAddress;
    }

    public void setContacts(String contacts) {
        this.contacts = contacts;
    }

    public void setConTel(String conTel) {
        this.conTel = conTel;
    }

    public void setConEmail(String conEmail) {
        this.conEmail = conEmail;
    }

    public void setAreaRequire(char areaRequire) {
        this.areaRequire = areaRequire;
    }

    public void setAreaSize(char areaSize) {
        this.areaSize = areaSize;
    }

    public void setAreaNum(int areaNum) {
        this.areaNum = areaNum;
    }

    public void setAreaUsing(String areaUsing) {
        this.areaUsing = areaUsing;
    }

    public void setAuditStatus(char auditStatus) {
        this.auditStatus = auditStatus;
    }

    public void setAuditSuggest(String auditSuggest) {
        this.auditSuggest = auditSuggest;
    }

    public void setAreaAddress(String areaAddress) {
        this.areaAddress = areaAddress;
    }

    public void setAreaCost(float areaCost) {
        this.areaCost = areaCost;
    }

    public void setReceiver(String receiver) {
        this.receiver = receiver;
    }

    public void setReceiverTel(String receiverTel) {
        this.receiverTel = receiverTel;
    }

    public void setAuditTime(LocalDateTime auditTime) {
        this.auditTime = auditTime;
    }

    public void setAuditor(String auditor) {
        this.auditor = auditor;
    }

    public void setPayType(char payType) {
        this.payType = payType;
    }

    public void setPayTime(LocalDateTime payTime) {
        this.payTime = payTime;
    }

    public void setApplicationTime(LocalDateTime applicationTime) {
        this.applicationTime = applicationTime;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
}
