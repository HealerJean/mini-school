package com.minixiao.web.controller.setting;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.minixiao.apiauth.client.HeaderUtil;
import com.minixiao.web.dto.recruiters.CandidateFilterVO;
import com.minixiao.web.dto.recruiters.EmailTemplateVO;
import com.minixiao.web.dto.recruiters.UserDTO;
import com.minixiao.web.utils.YmlConfig;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.util.UUID;

/**
 * 邮件通知模板 .
 * Created by xiachao on 2017/3/3.
 */
@RestController
public class NotificationTemplateController {
    private Logger logger = LoggerFactory.getLogger(NotificationTemplateController.class);

    private RestTemplate restTemplate = new RestTemplate();

    @Autowired
    private YmlConfig ymlConfig;

    private ObjectMapper objectMapper = new ObjectMapper();

    /**
     * @Description 根据公司id查询该公司下所有的邮件模板.
     * @Author xiachao
     * @CreateTime 2017/3/3 14:14
     * @Param
     * @Return
     */
    @GetMapping(value = "company/template/emails")
    public String getAllEmailTemplates() {
        Subject subject = SecurityUtils.getSubject();
        if (subject != null) {
            UserDTO user = (UserDTO) subject.getSession().getAttribute(
                ymlConfig.getSession_current_user());
            if (user != null) {
                UUID userId2 = user.getId();
                String userName = user.getRealName();
                UUID recId2 = user.getRecId();
                String recName = user.getRecName();
                HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                    recId2, recName);
                HttpEntity requestEntity = new HttpEntity(null, httpHeaders);
                ResponseEntity<String> responseEntity = restTemplate.exchange(
                    ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2 + "/templates/email",
                    HttpMethod.GET, requestEntity, String.class);
                if (responseEntity.getStatusCodeValue() == 200) {
                    return responseEntity.getBody();
                }
            }
        }
        return null;
    }

    /**
     * @Description 根据模板id查询该模板的详细信息.
     * @Author xiachao
     * @CreateTime 2017/3/3 17:17
     * @Param
     * @Return
     */
    @GetMapping("company/template/email/{id}")
    public String getEmailTemplate(@PathVariable UUID id) {
        Subject subject = SecurityUtils.getSubject();
        if (subject != null) {
            UserDTO user = (UserDTO) subject.getSession().getAttribute(
                ymlConfig.getSession_current_user());
            if (user != null) {
                UUID userId2 = user.getId();
                String userName = user.getRealName();
                UUID recId2 = user.getRecId();
                String recName = user.getRecName();
                HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                    recId2, recName);
                HttpEntity requestEntity = new HttpEntity(null, httpHeaders);
                ResponseEntity<String> responseEntity = restTemplate.exchange(
                    ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2 + "/templates/email/" + id,
                    HttpMethod.GET, requestEntity, String.class);
                if (responseEntity.getStatusCodeValue() == 200) {
                    return responseEntity.getBody();
                }
            }
        }
        return null;
    }


    /**
     * @Description 新建邮件模板.
     * @Author xiachao
     * @CreateTime 2017/3/3 17:06
     * @Param
     * @Return
     */
    @RequestMapping(value = "company/template/email")
    public String addEmailTemplate(@RequestBody EmailTemplateVO templateVO) {
        if (templateVO != null) {
            Subject subject = SecurityUtils.getSubject();
            if (subject != null) {
                UserDTO user = (UserDTO) subject.getSession().getAttribute(
                    ymlConfig.getSession_current_user());
                if (user != null) {
                    UUID userId2 = user.getId();
                    String userName = user.getRealName();
                    UUID recId2 = user.getRecId();
                    String recName = user.getRecName();
                    HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                        recId2, recName);
                    httpHeaders.setContentType(MediaType.APPLICATION_JSON_UTF8);
                    HttpEntity<EmailTemplateVO> requestEntity = new HttpEntity<EmailTemplateVO>(templateVO, httpHeaders);
                    ResponseEntity<String> responseEntity = restTemplate.exchange(
                        ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2 + "/templates/email",
                        HttpMethod.POST, requestEntity, String.class);
                    if (responseEntity.getStatusCodeValue() == 200) {
                        return responseEntity.getBody();
                    }
                }
            }
        }
        return null;
    }

    /**
     * @Description 修改邮件模板.
     * @Author xiachao
     * @CreateTime 2017/3/3 17:26
     * @Param
     * @Return
     */
    @PutMapping("company/template/email/{id}")
    public String updateEmailTemplate(@PathVariable UUID id,
                                      @RequestBody EmailTemplateVO emailTemplateVO) {
        if (emailTemplateVO != null) {
            Subject subject = SecurityUtils.getSubject();
            if (subject != null) {
                UserDTO user = (UserDTO) subject.getSession().getAttribute(
                    ymlConfig.getSession_current_user());
                if (user != null) {
                    UUID userId2 = user.getId();
                    String userName = user.getRealName();
                    UUID recId2 = user.getRecId();
                    String recName = user.getRecName();
                    HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                        recId2, recName);
                    HttpEntity<EmailTemplateVO> requestEntity = new HttpEntity<EmailTemplateVO>(emailTemplateVO, httpHeaders);
                    ResponseEntity<String> responseEntity = restTemplate.exchange(
                        ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2 + "/templates/email/" + id,
                        HttpMethod.PUT, requestEntity, String.class);
                    if (responseEntity.getStatusCodeValue() == 200) {
                        return responseEntity.getBody();
                    }
                }
            }
        }
        return null;
    }

    /**
     * @Description 删除邮件模板.
     * @Author xiachao
     * @CreateTime 2017/3/3 17:22
     * @Param
     * @Return
     */
    @DeleteMapping("company/template/email/{id}")
    public String deleteEmailTemplate( @PathVariable UUID id) {
        if (id != null) {
            Subject subject = SecurityUtils.getSubject();
            if (subject != null) {
                UserDTO user = (UserDTO) subject.getSession().getAttribute(
                    ymlConfig.getSession_current_user());
                if (user != null) {
                    UUID userId2 = user.getId();
                    String userName = user.getRealName();
                    UUID recId2 = user.getRecId();
                    String recName = user.getRecName();
                    HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                        recId2, recName);
                    HttpEntity requestEntity = new HttpEntity(null, httpHeaders);
                    ResponseEntity<String> responseEntity = restTemplate.exchange(
                        ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2 + "/templates/email/" + id,
                        HttpMethod.DELETE, requestEntity, String.class);
                    if (responseEntity.getStatusCodeValue() == 200) {
                        return "删除成功";
                    }
                }
            }
        }
        return "删除失败";
    }
}
