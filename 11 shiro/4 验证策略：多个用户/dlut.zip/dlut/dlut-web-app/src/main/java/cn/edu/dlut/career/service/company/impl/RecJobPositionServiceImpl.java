package cn.edu.dlut.career.service.company.impl;


import cn.edu.dlut.career.domain.company.RecJobPosition;
import cn.edu.dlut.career.dto.company.RecJobPositionDTO;
import cn.edu.dlut.career.repository.company.RecJobPositionRepository;
import cn.edu.dlut.career.service.company.RecJobPositionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Created by 史念念 on 2017/3/23.
 * <p>
 * 招聘职位  服务层实现类
 */
@Service
public class RecJobPositionServiceImpl implements RecJobPositionService {
    @Autowired
    private RecJobPositionRepository recJobPositionRepository;

    /**
     * 查询全部招聘职位信息
     *
     * @return
     */
    @Override
    public List<RecJobPosition> findAll() {
        return recJobPositionRepository.findAll();
    }

    /**
     * 添加招聘职位信息
     *
     * @param recJobPosition
     * @return
     */
    @Override
    public String saveRecJobPosition(RecJobPosition recJobPosition, RecJobPositionDTO recJobPositionDTO) {
        try {
            LocalDate startTime = LocalDate.parse(recJobPositionDTO.getStartTime());
            LocalDate endTime = LocalDate.parse(recJobPositionDTO.getEndTime());

            recJobPosition.setRecId(recJobPositionDTO.getRecId());
            recJobPosition.setName(recJobPositionDTO.getName());
            recJobPosition.setDescription(recJobPositionDTO.getDescription());
            recJobPosition.setType(recJobPositionDTO.getType());
            recJobPosition.setCategory(recJobPositionDTO.getCategory());
            recJobPosition.setDegree(recJobPositionDTO.getDegree());
            recJobPosition.setMajor(recJobPositionDTO.getMajor());
            recJobPosition.setReceiveMode(recJobPositionDTO.getReceiveMode());
            recJobPosition.setRecEmail(recJobPositionDTO.getRecEmail());
            recJobPosition.setCity(recJobPositionDTO.getCity());
            recJobPosition.setAddress(recJobPositionDTO.getAddress());
            recJobPosition.setRecruitmentNum(recJobPositionDTO.getRecruitmentNum());
            recJobPosition.setSalary(recJobPositionDTO.getSalary());
            recJobPosition.setStartTime(startTime);
            recJobPosition.setEndTime(endTime);
            recJobPosition.setAuditStatus(recJobPositionDTO.getAuditStatus());
            recJobPosition.setAuditTime(recJobPositionDTO.getAuditTime());
            recJobPosition.setAuditor(recJobPositionDTO.getAuditor());
            recJobPosition.setNopassReason(recJobPositionDTO.getNopassReason());
            recJobPosition.setOnlineStatus(recJobPositionDTO.getOnlineStatus());
            recJobPosition.setTags(recJobPositionDTO.getTags());

            recJobPositionRepository.save(recJobPosition);
            return "ok";
        } catch (Exception e) {
            e.printStackTrace();
            return "fail";
        }
    }

    /**
     * 根据编号查找招聘职位信息
     *
     * @param id
     * @return
     */
    @Override
    public RecJobPosition findById(String id) {
        RecJobPosition recJobPosition = recJobPositionRepository.findById(id);
        return recJobPosition;
    }

    /**
     * 根据公司编号查找招聘职位信息
     *
     * @param recId
     * @return
     */
    @Override
    public List<RecJobPosition> findByRecId(String recId) {
        List<RecJobPosition> ls = recJobPositionRepository.findByRecId(recId);
        return ls;
    }

    /**
     * 修改审核状态,审核人,审核时间,未通过原因
     *
     * @param id
     * @param auditStatus
     * @param auditor
     * @param auditTime
     * @param nopassReason
     * @return
     */
    @Override
    public String updateAudit(String id, char auditStatus, String auditor, LocalDateTime auditTime, String nopassReason) {
        int result = recJobPositionRepository.updateAudit(id, auditStatus, auditor, auditTime, nopassReason);

        return result > 0 ? "ok" : "fail";
    }

    /**
     * 删除招聘职位信息
     *
     * @param id
     * @return
     */
    @Override
    public String deleteById(String id) {
        try {
            recJobPositionRepository.delete(id);
            return "ok";
        } catch (Exception e) {
            return "fail";
        }
    }
}
