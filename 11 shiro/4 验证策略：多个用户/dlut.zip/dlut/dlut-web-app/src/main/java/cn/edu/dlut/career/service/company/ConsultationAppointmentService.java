package cn.edu.dlut.career.service.company;


import cn.edu.dlut.career.domain.school.ConsultationAppointment;

import java.util.List;

/**
 * Created by liang on 2017/3/30.
 */
public interface ConsultationAppointmentService {
    List<ConsultationAppointment> findAll();

    ConsultationAppointment finOne(String id);

    void delete(String id);

    void save(ConsultationAppointment consultationAppointment);



}
