<template>

</template>

<script type="text/babel">

    export default {
        data() {

        }
    }

</script>

<style lang="less">

</style>
