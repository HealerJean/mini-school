package cn.edu.dlut.career.service.company.impl;


import cn.edu.dlut.career.domain.company.LargePerson;
import cn.edu.dlut.career.repository.company.LargePersonRepository;
import cn.edu.dlut.career.service.company.LargePersonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * 大招代表人 服务层
 * Created by HealerJean on 2017/3/24.
 */
@Service
@Transactional
public class LargePersonServiceImpl implements LargePersonService {

    @Autowired
    LargePersonRepository largePersonRepository;
    @Override
    public LargePerson saveLargePerson(LargePerson largePerson) {
        return largePersonRepository.save(largePerson);
    }

    @Override
    public LargePerson findById(String id) {
        return largePersonRepository.findById(id);
    }

    @Override
    public LargePerson updateLargePerson(LargePerson largePerson) {
        return largePersonRepository.save(largePerson);
    }

    @Override
    public String deleteLargePerson(String id) {
        try {
            largePersonRepository.delete(id);
            return "ok";
        }catch (Exception e){
            e.printStackTrace();
        }
        return  null;
    }

    @Override
    public List<LargePerson> findAllLargePerson() {
        return largePersonRepository.findAll();
    }
}
