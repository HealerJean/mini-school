package cn.edu.dlut.career.repository;

import cn.edu.dlut.career.domain.student.BaseInfo;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

/**
 * 学生信息的数据库操作
 */
public interface StudentRepository extends JpaRepository<BaseInfo, String> {
    BaseInfo findOne(String id);
}
