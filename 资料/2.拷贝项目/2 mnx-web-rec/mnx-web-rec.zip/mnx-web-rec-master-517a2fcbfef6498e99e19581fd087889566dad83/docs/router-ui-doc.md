# 前端路由整理（待完善）

## 登录前路由

| 路由 | 说明|
| --- | --- |
| '/about.html' | 关于我们 |
| '/help.html' | 帮助中心 |
| '/login.html' | 登录 |
| '/register.html' | 注册 |
| '/logout.html' | 退出登录 |
| '/{pageView}.html' | “pageView”页面 |

## 登录后路由

| 路由 | 说明|
| --- | --- |
| '/#/' | 首页 |
| '/#/setting/account' | 公司信息 |
| '/#/setting/department' | 部门管理 |
| '/#/setting/workflow' | 流程设置 |
| '/#/setting/users' | 用户管理 |
| '/#/setting/?' | 笔面管理 |
| '/#/template/email' | 通知模板 |
| '/#/job' | 职位管理首页 |
| '/#/job/add' | 添加职位 |
| '/#/candidate' | 简历管理 |
| '/#/talent' | 人才邀约 |
