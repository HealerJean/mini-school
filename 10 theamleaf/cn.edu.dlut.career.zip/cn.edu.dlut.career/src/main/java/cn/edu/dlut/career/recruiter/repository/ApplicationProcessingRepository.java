package cn.edu.dlut.career.recruiter.repository;

import cn.edu.dlut.career.recruiter.domain.ApplicationProcessing;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

/**
 * Created by wei on 2017/3/24.
 */
public interface ApplicationProcessingRepository extends CrudRepository<ApplicationProcessing,String> {
  List<ApplicationProcessing> findAll();
}
