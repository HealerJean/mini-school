package cn.edu.dlut.career.recruiter.repository.recruitjob;

import cn.edu.dlut.career.recruiter.domain.recruitjob.RecruitJob;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Created by 史念念 on 2017/3/23.
 *
 * 招聘职位持久层
 */
@Transactional
public interface RecruitJobRepository extends CrudRepository<RecruitJob,String> {

  /**
   * 查询全部招聘职位信息
   * @return
   */
  List<RecruitJob> findAll();

  /**
   * 根据编号查找公司招聘信息
   * @param id
   * @return
   */
  RecruitJob findById(String id);

  /**
   * 根据公司编号查找招聘信息
   * @param recId
   * @return
   */
  List<RecruitJob> findByRecId(String recId);

  /**
   * 修改审核状态,审核人,审核时间,未通过原因
   * @param auditStatus
   * @return
   */
  @Modifying
  @Query("update RecruitJob  set audit.auditStatus=?2 ,audit.auditPerson=?3 ," +
      "audit.auditTime=?4,audit.auditFailReason=?5 where id = ?1")
  int updateAudit(String id , String auditStatus,
                         String auditPerson, LocalDateTime auditTime,
                         String auditFailReason);


}
