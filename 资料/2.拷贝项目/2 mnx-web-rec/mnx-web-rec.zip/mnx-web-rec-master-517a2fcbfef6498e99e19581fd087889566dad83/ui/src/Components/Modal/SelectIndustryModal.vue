<template>
    <el-dialog title="选择行业分类"
               v-model="dialogVisible"
               class="industr-modal"
               :close-on-click-modal="false"
               :close-on-press-escape="false"
               size="large"
               :resizable="false">
        <div class="container-industry-selection">
            <div class="industry-selection-header">
                <h4 class="industry-selection-title">最多选择{{max}}项</h4>
                <div class="industry-selected-body">
                    <template v-for="(item,index) in selectedIndustries">
                        <span class="selected-industry" @click="delIndustry(index)">{{ item }}</span>
                    </template>
                </div>
            </div>
            <el-table :data="industryData" border
                      :show-header=false
                      :highlight-current-row=false
                      max-height="400">
                <el-table-column prop="name" label="" width="150"></el-table-column>
                <el-table-column prop="option" label="" >
                    <template scope="scope">
                        <el-checkbox-group v-model="selectedIndustries">
                            <el-checkbox class="industry-checkbox"
                                         v-for="item in scope.row.option"
                                         :label="item"
                                         :disabled="selectedIndustries.length >= max && !selectedIndustries.includes(item)">
                                {{ item }}
                            </el-checkbox>
                        </el-checkbox-group>
                    </template>
                </el-table-column>
            </el-table>
        </div>
        <div slot="footer" class="dialog-footer btn-size-md">
            <el-button type="primary" @click="modalConfirm">确定</el-button>
            <el-button @click="closeModal" :plain="true">取消</el-button>
        </div>
    </el-dialog>
</template>

<script type="text/babel">

    export default {
        name: "select-industry",
        data() {
            return {
                selectedIndustries: []
            }

        },
        computed: {
            dialogVisible() {
                return this.isSelectingIndustry;
            }
        },
        props: {
            isSelectingIndustry: {
                type: Boolean,
                default: false
            },
            max: {
                type:Number,
                default:1
            },
            industryData: {
                type: Array,
                default() {
                    return [
                        {
                            name: "互联网-游戏-软件",
                            option: ["奢侈品/收藏品/工艺品/珠宝", "O2O","数据服务", "计算机软件", "分类信息","电子商务", "游戏", "社交网络","门户/搜索", "IT服务"]
                        },
                        {
                            name: "电子-通信-硬件",
                            option: ["计算机硬件", "运营商/增值服务","通信设备", "电子/半导体"]
                        },
                        {
                            name: "金融",
                            option: ["互联网金融", "保险", "基金", "会计/审计","银行", "证券", "投资","担保/典当/拍卖"]
                        },
                        {
                            name: "生产-机械-制造",
                            option: ["汽车/摩托车", "印刷/包装/造纸","加工/模具", "服装/纺织/皮革","机械/设备/重工", "办公用品","家具/家电/玩具/礼品"]
                        },
                        {
                            name: "房地产-建筑-物业",
                            option: ["房产经济/中介", "规划设计","物业管理/商业中心", "建筑工程"]
                        }
                    ];
                }
            }
        },
        methods: {
            closeModal() {
                this.$emit('modal:select-industry-closing');
            },

            modalConfirm() {
                this.$emit(
                    'modal:emit-selected-industries',
                    this.selectedIndustries
                );
                this.$emit('modal:select-industry-closing');
            },
            delIndustry: function (index) {
                this.selectedIndustries.splice(index, 1);
            }
        }
    }

</script>

<style lang="less">
    @import "../../less/shared/variables";
    .container-industry-selection{
        line-height: 24px;
        .industry-selection-header {
            min-height: 32px;
            margin-bottom: 2px;
        }
        .industry-selection-title {
            margin: 0;
            font-weight: 400;
            float: left;
        }
        .industry-selected-body {
            margin-left: 90px;
            .selected-industry {
                display: inline-block;
                margin-right: 6px;
                margin-bottom: 8px;
                padding: 0 10px;
                color: @white;
                background: @primary-color;
                border-radius: 24px;
                height: 24px;
                cursor: pointer;
            }
        }
    }

    .container-industry-selection{
        .el-table__body{
            width:100%;
            overflow-x:hidden;
        }
        .el-table_1_column_1{
            font-weight:600;
            text-align: center;
        }
        .el-checkbox-group{
            margin-left:-15px;
            padding: 5px 0;
        }
        .el-checkbox{
            margin-left: 15px;
        }
    }

    .industry-checkbox {
        display:inline-block;
        width:189px;
        .el-checkbox__inner {
            width: 14px;
            height: 14px;
            border: 1px solid #b5b5b5;
            border-radius: 1px;
            margin-bottom: 1px;
        }
        .el-checkbox__label {
            color: extract(@gray-group, 2);
            padding-left: 3px;
        }
        .el-checkbox__inner:after {
            height: 6px;
            left: 3px;
            top: 1px;
        }
        .el-checkbox__input.is-checked .el-checkbox__inner {
            background-color: @primary-color;
            border-color: @primary-color;
        }
    }

</style>
