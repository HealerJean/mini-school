<template>
    <div class="add-job">
        <breadcrumb :breadcrumbs="breadcrumbs"></breadcrumb>
        <h1 class="title">编辑用户</h1>
        <div class="add-job-con input-size-lg">
            <el-form :model="addUserForm" ref="addUserForm" :rules="rules" label-width="100px">
                <el-row :gutter="20">
                    <el-col :span="10">
                        <el-form-item label="邮箱：" prop="email" class="required-two">
                            <el-input v-model="addUserForm.email" placeholder="请输入邮箱地址"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="14">
                        <div class="form-add-tip">（邮箱地址作为新建用户的登陆账号）</div>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="10">
                        <el-form-item label="姓名：" prop="realName" class="required-two">
                            <el-input v-model="addUserForm.realName" placeholder="请输入真实姓名"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="14">
                        <div class="form-add-tip">（请填写新建用户的真实姓名）</div>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="10">
                        <el-form-item label="固话：" prop="tel" class="required-two">
                            <el-input v-model="addUserForm.tel" placeholder="请输入固定电话"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="14">
                        <div class="form-add-tip">（请填写新建用户的固定电话）</div>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="10">
                        <el-form-item label="手机：" prop="mobile" class="required-two">
                            <el-input v-model="addUserForm.mobile" placeholder="请输入手机号码"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="14">
                        <div class="form-add-tip">（请填写新建用户的手机号码）</div>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="10">
                        <el-form-item label="所属部门：" prop="deptName">
                            <el-input
                                readonly
                                v-model="addUserForm.deptName"
                                placeholder="请选择所属部门"
                                icon="caret-bottom"
                                @focus="isSelectDepartment = true"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="14">
                        <div class="form-add-tip">（请填写新建用户的所属部门）</div>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="10">
                        <el-form-item label="密码：" prop="pwd" class="required-two" required>
                            <el-input type="password" placeholder="请输入密码" v-model="addUserForm.pwd" auto-complete="off"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="14">
                        <div class="form-add-tip">（包含数字和字母，6-40个字符，建议不要用公司电话）</div>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="24" class="btn-group-left-lg btn-size-lg">
                        <el-button type="primary" @click="onSubmit('addUserForm')">保存</el-button>
                        <el-button @click="cancleUserFrom">取消</el-button>
                    </el-col>
                </el-row>
            </el-form>
        </div>

        <select-one-department
            :isSelectDepartment="isSelectDepartment"
            @modal:select-department-closing="closeSelectDepartmentModal"
            @modal:select-department="makeSureSelectDepartment"></select-one-department>
    </div>
</template>

<script type="text/babel">
    import Breadcrumb from "../Shared/Breadcrumb.vue"
    import SelectOneDepartment from '../Modal/SelectOneDepartmentModal.vue';

    export default {
        name: 'add-user',
        components: {
            SelectOneDepartment,
            Breadcrumb
        },
        data () {
            let telRule = (rule, value, callback) => {
                let reg=/^([0-9]|[-])+$/;
                if (value === '') {
                    callback();
                }else if(value.indexOf('-') == -1 && value.length>8){
                    callback(new Error('固话个数超过8个'));
                } else {
                    if(!reg.test(value)){
                        callback(new Error('请输入正确固话格式'));
                    }else{
                        callback();
                    }
                }
            };
            let mobileRule = (rule, value, callback) => {
                let reg=/^((\+?86)|(\(\+86\)))?(13[012356789][0-9]{8}|15[012356789][0-9]{8}|18[02356789][0-9]{8}|147[0-9]{8}|1349[0-9]{7})$/;
                if (value === '') {
                    callback();
                } else {
                    if(!reg.test(value)){
                        callback(new Error('请输入正确手机格式'));
                    }else{
                        callback();
                    }
                }
            };
            let pwdRule = (rule, value, callback) => {
                let reg=/^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,40}$/;
                console.log(value);
                if (value === '') {
                    callback(new Error('密码不能为空'));
                }else if(value.length > 40){
                    callback(new Error('密码不能超过40个字符'));
                }else if(value.length < 6){
                    callback(new Error('密码不能少于6个字符'));
                }else{
                    if(!reg.test(value)){
                        callback(new Error('密码不能是纯数字或纯字母'));
                    }else{
                        callback();
                    }
                }
            };
            return {
                isSelectDepartment: false,
                //面包屑
                breadcrumbs: [
                    {'router': '', 'text': '系统设置'},
                    {'router': '/setting/users', 'text': '用户管理'},
                    {'router': '', 'text': '编辑用户'}
                ],

                addUserForm: {
                    email: '',
                    realName: '',
                    tel: '',
                    mobile: '',
                    deptName: '',
                    deptId: '',
                    pwd: ''
                },
                rules: {
                    email: [
                        {required: true, message: '邮箱不能为空', trigger: 'change'},
                        {type:'email', message: '请输入正确邮箱地址', trigger: 'blur'}
                    ],
                    realName: [
                        {required: true, message: '姓名不能为空', trigger: 'change'}
                    ],
                    tel:[
                        { validator: telRule, trigger: 'blur' }
                    ],
                    mobile:[
                        { validator: mobileRule, trigger: 'blur' }
                    ],
                    deptName: [
                        {required: true, message: '所属部门不能为空', trigger: 'change'}
                    ],
                    pwd: [
                        { validator: pwdRule, trigger: 'change' }
                    ]
                }
            }
        },
        watch: {},
        methods: {
            closeSelectDepartmentModal(){
                this.isSelectDepartment = false;
            },
            makeSureSelectDepartment(val1,val2){
                this.addUserForm.deptName = val1;
                this.addUserForm.deptId = val2;
            },
            cancleUserFrom:function(){
                this.addUserForm={
                    email: '',
                    realName: '',
                    tel: '',
                    mobile: '',
                    deptName: '',
                    deptId: '',
                    pwd: ''
                };
                this.$router.push({ path: '/setting/users'})
            },

            onSubmit(formName) {
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        let formData = {
                            email: this.addUserForm.email,
                            realName: this.addUserForm.realName,
                            tel: this.addUserForm.tel,
                            mobile: this.addUserForm.mobile,
                            deptName: this.addUserForm.deptName,
                            deptId: this.addUserForm.deptId,
                            pwd: this.addUserForm.pwd
                        };
                        /* eslint-disable */
                        console.log(formData);
                        /* eslint-disable */
                        let self=this;
                        this.$http.put('/company/users/'+this.$route.params.id, formData).then(response => {
                            console.log('success');
                            this.$router.push({ path: '/setting/users'})
                        }, response => {
                            /* eslint-disable */
                            console.log('error');
                            /* eslint-disable */
                        });
                    } else {
                        return false;
                    }
                });
            },

            editGetUserData(){
                this.$http.get('/company/users/'+this.$route.params.id).then(response => {
                    let newData=response.body;
                    this.addUserForm={
                        email: newData.email,
                        realName: newData.realName,
                        tel: newData.tel,
                        mobile: newData.mobile,
                        deptName: newData.deptName,
                        deptId: newData.deptId,
                        pwd:''
                    }
                }, response => {
                    /* eslint-disable */
                    console.log('error');
                    /* eslint-disable */
                });
            }
        },
        mounted() {
            this.editGetUserData();
        }
    }
</script>

<style lang="less">
    @import "../../less/shared/variables.less";

    .add-job {
        .title {
            margin: 0;
            padding: 0 20px;
            font-size: @size-xxlg;
            line-height: 50px;
            font-weight: 400;
            color: extract(@gray-group, 1);
            border-bottom: @border-gray;
            background-color: @white;
        }
    }

    .add-job-con {
        margin: 0 0 40px;
        padding: 20px 20px 50px;
        background-color: @white;
        .el-form-item {
            margin-bottom: 10px;
        }
        .el-form-item.is-required .el-form-item__label:before {
            color: @error-color;
            position: absolute;
            left: 0;
            top: 13px;
        }
        .required-two.el-form-item.is-required .el-form-item__label:before {
            left: 32px;
        }
        .el-input-number {
            width: 100%;
            overflow: initial;
        }
        .el-input-number__decrease, .el-input-number__increase {
            line-height: 32px;
        }
        .el-form-item.is-error + .description-tip {
            margin: 12px 0 0;
        }
    }

    .form-add-tip {
        line-height: 34px;
        color: extract(@gray-group, 7);
        & > i {
            margin-right: 5px;
        }
        &.description-tip {
            padding-left: 100px;
            margin: -10px 0 0;
        }
    }


    .btn-group-left-lg {
        padding-top: 18px;
        padding-left: 100px;
    }
</style>

