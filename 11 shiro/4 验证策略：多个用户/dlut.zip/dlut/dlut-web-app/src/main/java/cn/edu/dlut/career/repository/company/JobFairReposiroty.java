package cn.edu.dlut.career.repository.company;

import cn.edu.dlut.career.domain.company.JobFair;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 双选会，招聘会信息表 数据操作层
 * Created by HealerJean on 2017/4/6.
 */
@Repository
public interface JobFairReposiroty extends CrudRepository<JobFair ,String>{
    //查找全部信息
    List<JobFair> findAll();

    //根据id进行查找
    JobFair findById(String id);
}
