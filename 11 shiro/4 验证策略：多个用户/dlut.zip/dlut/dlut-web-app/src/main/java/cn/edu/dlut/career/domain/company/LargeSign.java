package cn.edu.dlut.career.domain.company;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * 大型招聘会签到 表
 * Created by HealerJean on 2017/3/23.
 */
@Entity
@Table(name="rec_large_sign")
public class LargeSign {

    //编号id
    @Id
    @GenericGenerator(name = "idGenerator", strategy = "uuid")
    @GeneratedValue(generator = "idGenerator")
    private String id;

     //预约编号orderId
     private String orderId;

    //签到类型signType
    @Column(length = 20)
    private  String signType;

     //签到编号signId
     private  UUID signId;

     //签到姓名signName
     @Column(length = 20)
     private  String signName;

    //签到时间signTime
     private LocalDateTime signTime;

    public LargeSign() {
    }


    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }


    public String getSignType() {
        return signType;
    }

    public void setSignType(String signType) {
        this.signType = signType;
    }

    public UUID getSignId() {
        return signId;
    }

    public void setSignId(UUID signId) {
        this.signId = signId;
    }

    public String getSignName() {
        return signName;
    }

    public void setSignName(String signName) {
        this.signName = signName;
    }

    public LocalDateTime getSignTime() {
        return signTime;
    }

    public void setSignTime(LocalDateTime signTime) {
        this.signTime = signTime;
    }
}
