package com.minixiao.web.dto.jobrequistion;

import com.minixiao.web.dto.jobrequistion.embedment.ApplyPeriod;
import com.minixiao.web.dto.jobrequistion.embedment.Audit;
import com.minixiao.web.dto.jobrequistion.embedment.Department;
import com.minixiao.web.dto.jobrequistion.embedment.Sarlary;
import java.time.LocalDateTime;
import java.util.UUID;


/**
 * @Description 职位需求实体类.
 * @Author JiangYh
 * @CreateTime 2017/2/10 18:04
 * @Param
 * @Return
 */
public class JobRequistion {
    //主键
    private UUID id;

    //职位名称
    private String title;

    //职位描述
    private String description;

    //职位状态
    private String status;

    //职位类型
    private String jobType;

    //招聘人数
    private Integer headcount;

    //职位类别
    private String jobCategory;

    //职位级别
    private String careerLevel;

    //工作地区
    private String jobArea;

    private Department department;

    //薪资
    private Sarlary sarlary;

    private ApplyPeriod applyPeriod;

    //审核相关
    private Audit audit;

    //投递链接
    private String applyUrl;

    //内部编号
    private String innerNo;

    //创建时间
    private LocalDateTime createdOn;

    //更新时间
    private LocalDateTime updatedOn;

    public JobRequistion(UUID id,  String title, String description, String status, String jobType, Integer headcount, String jobCategory, String careerLevel, String jobArea, Department department, Sarlary sarlary, ApplyPeriod applyPeriod, Audit audit, String applyUrl, String innerNo, LocalDateTime createdOn, LocalDateTime updatedOn) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.status = status;
        this.jobType = jobType;
        this.headcount = headcount;
        this.jobCategory = jobCategory;
        this.careerLevel = careerLevel;
        this.jobArea = jobArea;
        this.department = department;
        this.sarlary = sarlary;
        this.applyPeriod = applyPeriod;
        this.audit = audit;
        this.applyUrl = applyUrl;
        this.innerNo = innerNo;
        this.createdOn = createdOn;
        this.updatedOn = updatedOn;
    }



    public JobRequistion() {

    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getJobType() {
        return jobType;
    }

    public void setJobType(String jobType) {
        this.jobType = jobType;
    }

    public Integer getHeadcount() {
        return headcount;
    }

    public void setHeadcount(Integer headcount) {
        this.headcount = headcount;
    }

    public String getJobCategory() {
        return jobCategory;
    }

    public void setJobCategory(String jobCategory) {
        this.jobCategory = jobCategory;
    }

    public String getCareerLevel() {
        return careerLevel;
    }

    public void setCareerLevel(String careerLevel) {
        this.careerLevel = careerLevel;
    }

    public String getJobArea() {
        return jobArea;
    }

    public void setJobArea(String jobArea) {
        this.jobArea = jobArea;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public Sarlary getSarlary() {
        return sarlary;
    }

    public void setSarlary(Sarlary sarlary) {
        this.sarlary = sarlary;
    }

    public ApplyPeriod getApplyPeriod() {
        return applyPeriod;
    }

    public void setApplyPeriod(ApplyPeriod applyPeriod) {
        this.applyPeriod = applyPeriod;
    }

    public Audit getAudit() {
        return audit;
    }

    public void setAudit(Audit audit) {
        this.audit = audit;
    }

    public String getApplyUrl() {
        return applyUrl;
    }

    public void setApplyUrl(String applyUrl) {
        this.applyUrl = applyUrl;
    }

    public String getInnerNo() {
        return innerNo;
    }

    public void setInnerNo(String innerNo) {
        this.innerNo = innerNo;
    }

    public LocalDateTime getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(LocalDateTime createdOn) {
        this.createdOn = createdOn;
    }

    public LocalDateTime getUpdatedOn() {
        return updatedOn;
    }

    public void setUpdatedOn(LocalDateTime updatedOn) {
        this.updatedOn = updatedOn;
    }
}
