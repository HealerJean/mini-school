// initial file for passport
import Vue from 'vue';
import ElementUI from 'element-ui';

// styles
import 'less/shared/common.less';
import 'element-ui/lib/theme-default/index.css';

import Register from '../../Components/Passport/Register.vue';
import AppHeader from '../../Components/Shared/HeaderNoLogin.vue';
import AppFooter from '../../Components/Shared/FooterNoLogin.vue';

Vue.use(ElementUI);

new Vue({
    components: {
        Register,
        AppHeader,
        AppFooter
    }
}).$mount('#app');