<template>
    <div>
        <div class='job-query-box'>
            <el-form :model="jobQueryForm" label-width="100px" class="input-size-md">
                <el-row :gutter="70">
                    <el-col :span="8">
                        <el-form-item label="职位名称">
                            <el-input v-model="name" placeholder="请输入职位名称"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="职位类别">
                            <el-input
                                readonly
                                v-model="jobType"
                                placeholder="请输入职位类别"
                                icon="caret-bottom"
                                @focus="isChoosingJobType = true"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="工作地区" class="checked-regions">
                            <el-select v-model="region" multiple placeholder="不限"
                                       popper-class="regions-select">
                                <el-option
                                    v-for="item in jobQueryRegion"
                                    :label="item"
                                    :value="item">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row :gutter="70">
                    <el-col :span="8">
                        <el-form-item label="所属部门">
                            <el-input
                                readonly
                                v-model="department"
                                placeholder="请选择所属部门"
                                icon="caret-bottom"
                                @focus="isSelectDepartment = true"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="网申开始时间">
                            <el-date-picker
                                id="beginDate"
                                range-separator="至"
                                v-model="beginDate"
                                type="daterange"
                                placeholder="选择开始时间范围"
                                :editable="false"
                                :picker-options="pickerBeginDate">
                            </el-date-picker>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="网申结束时间">
                            <el-date-picker
                                id="overDate"
                                range-separator="至"
                                v-model="overDate"
                                type="daterange"
                                placeholder="选择结束时间范围"
                                :editable="false"
                                :picker-options="pickerOverDate">
                            </el-date-picker>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row class="job-query-foot">
                    <el-col :span="24" class="btn-group-center btn-size-lg">
                        <el-button type="primary" @click="findJobList">查询</el-button>
                        <el-button @click="resetFilter">重置</el-button>
                    </el-col>
                </el-row>
            </el-form>
        </div>
        <div class="job-tab">
            <el-tabs v-model="activeJobTabName" @tab-click="tabClick">
                <el-tab-pane :label="openCount" name="open">
                    <job-list-main :jobLists="open" :tabActive="tabOnline"></job-list-main>
                </el-tab-pane>
                <el-tab-pane :label="waitingCount" name="waiting">
                    <job-list-main :jobLists="waiting" :tabActive="tabCheckPending"></job-list-main>
                </el-tab-pane>
                <el-tab-pane :label="notThroughCount" name="notThrough">
                    <job-list-main :jobLists="notThrough" :tabActive="tabFailed"></job-list-main>
                </el-tab-pane>
                <el-tab-pane :label="onHoldCount" name="onHold">
                    <job-list-main :jobLists="onHold" :tabActive="tabOffline"></job-list-main>
                </el-tab-pane>
            </el-tabs>
            <router-link to="add" class="job-creat-btn">
                <i class="joblist-icon"></i>
                <span>创建新职位</span>
            </router-link>
        </div>

        <choose-job-type
            :isChoosingJobType="isChoosingJobType"
            @modal:choose-job-type-closing="closeJobType"
            @modal:emit-chosen-type="selectedJobType"></choose-job-type>
        <select-department
            :isSelectDepartment="isSelectDepartment"
            @modal:select-department-closing="closeSelectDepartmentModal"
            @modal:select-department="makeSureSelectDepartment"></select-department>
    </div>
</template>

<script type="text/babel">
    import ChooseJobType from '../Modal/ChooseJobTypeModal.vue';
    import SelectDepartment from '../Modal/SelectDepartmentModal.vue';
    import JobListMain from './JobListMain.vue'
    import eventBus from '../../js/shared/eventBus';

    export default {
        components: {
            ChooseJobType,
            SelectDepartment,
            JobListMain
        },
        data() {
            return {
                isChoosingJobType: false,
                isSelectDepartment: false,

                name: '',
                jobType: '',
                region: [],
                department: '',
                beginDate: '',
                overDate: '',

                jobQueryRegion: [],
                pickerBeginDate: {
                    disabledDate: (time) => {
                        let overDateVal = this.overDate;
                        if (overDateVal) {
                            let overDateFrom = new Date(overDateVal[0]).getTime();
                            return time.getTime() > overDateFrom;
                        }
                    }
                },
                pickerOverDate: {
                    disabledDate: (time) => {
                        let beginDateVal = this.beginDate;
                        if (beginDateVal) {
                            let beginDateTo = new Date(beginDateVal[1]).getTime();
                            return time.getTime() < beginDateTo;
                        }
                    }
                },

                isChangeTime: false,
                //tab列表的过滤器显示隐藏
                tabOnline: {
                    isOnline: false,
                    isOffline: true
                },
                tabCheckPending: {
                    isOnline: false,
                    isOffline: false
                },
                tabFailed: {
                    isOnline: false,
                    isOffline: false
                },
                tabOffline: {
                    isOnline: true,
                    isOffline: false
                },

                //tab列表数据
                open: [],
                waiting: [],
                notThrough: [],
                onHold: []
            }
        },
        computed: {
            jobListsStatus:function(){
                return this.$store.state.job.jobListsStatus;
            },
            openCount: function () {
                return "已上线（" + this.tabNameCount.open + "）";
            },
            waitingCount: function () {
                return "待审核（" + this.tabNameCount.waiting + "）";
            },
            notThroughCount: function () {
                return "审核未通过（" + this.tabNameCount.notThrough + "）";
            },
            onHoldCount: function () {
                return "已下线（" + this.tabNameCount.onHold + "）";
            },

            //当选tabName
            activeJobTabName(){
                return this.$store.state.job.activeJobTabName;
            },
            tabNameCount:function(){
                return this.$store.state.job.tabNameCount;
            },
            //筛选容器
            jobQueryFormStatus() {
                return this.$store.state.job.jobQueryFormStatus;
            },
            //初始过滤值
            initFilter() {
                if (this.jobQueryFormStatus[this.activeJobTabName] === undefined) {
                    return {
                        name: '',
                        jobType: '',
                        region: [],
                        department: '',
                        beginDate: '',
                        overDate: ''
                    }
                } else {
                    return this.jobQueryFormStatus[this.activeJobTabName]
                }
            },
            activeFilter(){
                return {
                    name: this.name,
                    type: this.jobType,
                    region: this.region,
                    department: this.department,
                    beginDate: this.beginDate,
                    overDate: this.overDate
                }
            }
        },
        watch: {
            name: function () {
                this.$store.commit('changeJobQueryVal', this.activeFilter);
            },
            jobType: function () {
                this.$store.commit('changeJobQueryVal', this.activeFilter);
            },
            region: function () {
                this.$store.commit('changeJobQueryVal', this.activeFilter);
            },
            department: function () {
                this.$store.commit('changeJobQueryVal', this.activeFilter);
            },
            beginDate: function () {
                this.$store.commit('changeJobQueryVal', this.activeFilter);
            },
            overDate: function () {
                this.$store.commit('changeJobQueryVal', this.activeFilter);
            }
        },
        methods: {
            closeJobType: function(){
                this.isChoosingJobType = false;
            },
            selectedJobType: function(val){
                this.jobType = val.primaryType + '-' + val.secondaryType + '-' + val.chosenType;
            },
            closeSelectDepartmentModal(){
                this.isSelectDepartment = false;
            },
            makeSureSelectDepartment(val1,val2){
                this.department = val1;
            },
            //重置过滤器
            resetFilter(){
                this.name = '';
                this.jobType = '';
                this.region = [];
                this.department = '';
                this.beginDate = '';
                this.overDate = '';
                if (this.activeJobTabName == 'open' || this.activeJobTabName == 'onHold') {
                    this.$http.get('/requisitions?status=' + this.activeJobTabName +'&page=0&size=10').then(response => {
                        let newData = response.body.content;
                        this[this.activeJobTabName]= newData;
                        this.tabNameCount[this.activeJobTabName]=response.body.totalElements;
                    }, response => {
                        /* eslint-disable */
                        console.log(response);
                        /* eslint-disable */
                    });
                } else if (this.activeJobTabName == 'waiting' || this.activeJobTabName == 'notThrough') {
                    this.$http.get('/requisitions/listForAudit?auditStatus=' + this.activeJobTabName +'&page=0&size=10').then(response => {
                        let newData = response.body.content;
                        this[this.activeJobTabName]= newData;
                        this.tabNameCount[this.activeJobTabName]=response.body.totalElements;
                    }, response => {
                        /* eslint-disable */
                        console.log(response);
                        /* eslint-disable */
                    });
                } else {
                    console.log('resetFilter-error')
                }
            },
            //查询职位列表
            findJobList() {
                let temp = this.jobQueryFormStatus,
                    tempTab = this.activeJobTabName;
                let params = {
                    jobTitle: temp[tempTab].name,
                    jobCategory: temp[tempTab].type,
                    jobArea: temp[tempTab].region,
                    departmentName: temp[tempTab].department,
                    beginDateFrom: this.jobListFormatDate(temp[tempTab].beginDate[0]),
                    beginDateTo: this.jobListFormatDate(temp[tempTab].beginDate[1]),
                    endDateFrom: this.jobListFormatDate(temp[tempTab].overDate[0]),
                    endDateTo: this.jobListFormatDate(temp[tempTab].overDate[1])
                };
                var urlParams = this.urlencode(params);
                console.log(urlParams);

                if (tempTab == 'open' || tempTab == 'onHold') {
                    this.$http.get('/requisitions?status=' + tempTab + '&' + urlParams+'&page=0&size=10').then(response => {
                        let newData = response.body.content;
                        console.log(response.body);
                        this.tabNameCount[tempTab]=response.body.totalElements;
                        this[tempTab]=newData;

                    }, response => {
                        /* eslint-disable */
                        console.log(response);
                        /* eslint-disable */
                    });
                } else if (tempTab == 'waiting' || tempTab == 'notThrough') {
                    this.$http.get('/requisitions/listForAudit?auditStatus=' + tempTab + '&' + urlParams+'&page=0&size=10').then(response => {
                        let newData = response.body.content;
                        console.log(response.body);
                        this.tabNameCount[tempTab]=response.body.totalElements;
                        this[tempTab]=newData;
                    }, response => {
                        /* eslint-disable */
                        console.log(response);
                        /* eslint-disable */
                    });
                } else {
                    console.log('faidJobList-error')
                }

            },
            //查询路径
            urlencode(data){
                var _result = [];
                for (var key in data) {
                    var value = data[key];
                    if (typeof value == 'undefined' || value == '') {
                        console.log('undefined');
                    } else {
                        if (value instanceof Array) {
                            let strArr = '';
                            value.forEach(function (_value) {
                                strArr += _value + ','
                            });
                            strArr = strArr.substring(0, strArr.length - 1);
                            _result.push(key + "=" + strArr);
                        } else {
                            _result.push(key + '=' + value);
                        }
                    }
                }
                return _result.join('&');
            },
            //切换tab的筛选器当前值
            activeJobQueryStatus(){
                this.name = this.initFilter.name;
                this.jobType = this.initFilter.jobType;
                this.region = this.initFilter.region;
                this.department = this.initFilter.department;
                this.beginDate = this.initFilter.beginDate;
                this.overDate = this.initFilter.overDate
            },
            //添加已发布过的职位地址
            getJobQueryRegion(){
                this.$http.get('/requisitions/jobArea').then(response => {
                    this.jobQueryRegion = response.body;
                }, response => {
                    /* eslint-disable */
                    console.log(response);
                    /* eslint-disable */
                });
            },

            //渲染列表
            getJobList: function () {
                this.$http.get('/requisitions?status=open'+'&page=0&size=10').then(response => {
                    let newData = response.body.content;
                    console.log(response.body);
                    this.tabNameCount.open = response.body.totalElements;
                    this.open=newData

                }, response => {
                    /* eslint-disable */
                    console.log(response);
                    /* eslint-disable */
                });
                this.$http.get('/requisitions?status=onHold'+'&page=0&size=10').then(response => {
                    let newData = response.body.content;
                    this.tabNameCount.onHold = response.body.totalElements;
                    this.onHold=newData

                }, response => {
                    /* eslint-disable */
                    console.log(response);
                    /* eslint-disable */
                });
                this.$http.get('/requisitions/listForAudit?auditStatus=waiting'+'&page=0&size=10').then(response => {
                    let newData = response.body.content;
                    this.tabNameCount.waiting = response.body.totalElements;
                    this.waiting=newData

                }, response => {
                    /* eslint-disable */
                    console.log(response);
                    /* eslint-disable */
                });
                this.$http.get('/requisitions/listForAudit?auditStatus=notThrough'+'&page=0&size=10').then(response => {
                    let newData = response.body.content;
                    this.tabNameCount.notThrough = response.body.totalElements;
                    this.notThrough=newData

                }, response => {
                    /* eslint-disable */
                    console.log(response);
                    /* eslint-disable */
                });
            },
            //查询渲染列表
            searchJobList: function () {
                console.log(this.activeJobTabName);
                if(this.activeJobTabName == 'open' ||this.activeJobTabName == 'onHold'){
                    this.$http.get('/requisitions?status='+this.activeJobTabName+'&page=0&size=10').then(response => {
                        let statusData = response.body.content;
                        this.tabNameCount.open = response.body.totalElements;
                        this[this.activeJobTabName]=statusData;

                    }, response => {
                        /* eslint-disable */
                        console.log(response);
                        /* eslint-disable */
                    });
                }else if(this.activeJobTabName == 'waiting' ||this.activeJobTabName == 'notThrough'){
                    this.$http.get('/requisitions/listForAudit?auditStatus='+this.activeJobTabName+'&page=1&size=10').then(response => {
                        let auditStatusData = response.body.content;
                        this.tabNameCount.notThrough = response.body.totalElements;
                        this[this.activeJobTabName]=auditStatusData;

                    }, response => {
                        /* eslint-disable */
                        console.log(response);
                        /* eslint-disable */
                    });
                }
            },
            tabClick(tab) {
                this.$store.commit('changeActiveJobTabName', tab.name);
                this.activeJobQueryStatus();
            },
            jobListFormatDate(date) {
                if (date) {
                    let newDate = new Date(date);
                    let year = newDate.getFullYear(),
                        month = newDate.getMonth() >= 9 ? newDate.getMonth() + 1 : '0' + (newDate.getMonth() + 1),
                        day = newDate.getDate() >= 10 ? newDate.getDate() : '0' + newDate.getDate();
                    return year + '-' + month + '-' + day
                } else {
                    return '';
                }
            },

        },
        mounted() {
            let instance = this;

            //单选上线
            eventBus.$on('job-onlineing', function (val) {
                instance.tabNameCount.open += 1;
                instance.tabNameCount.onHold -= 1;
                instance.onHold.splice(val, 1);
                instance.open.unshift(val);
            });
            //单选下线
            eventBus.$on('job-offlineing', function (val) {
                instance.tabNameCount.onHold += 1;
                instance.tabNameCount.open -= 1;
                instance.open.splice(val, 1);
                instance.onHold.unshift(val);
            });

            //多选上线
            eventBus.$on('job-check-onlineing', function (val) {
                val.forEach(function (item) {
                    instance.onHold.splice(item, 1);
                    instance.open.unshift(item);
                })
                instance.tabNameCount.open += val.length;
            });

            //多选下线
            eventBus.$on('job-check-offlineing', function (val) {
                val.forEach(function (item) {
                    instance.open.splice(item, 1);
                    instance.onHold.unshift(item);
                })
                instance.tabNameCount.onHold += val.length;
            });

            //修改时间弹出窗
            eventBus.$on('modal:change-time-closing', ()=> {
                instance.isChangeTime = false;
            });

            this.getJobQueryRegion();
            this.activeJobQueryStatus();
            console.log('setTimeoutBegin');
            setTimeout(function(){
                console.log('setTimeout');
                instance.getJobList();
            },1000)
        }
    }

</script>

<style lang="less">
    .joblist-icon {
        display: inline-block;
        background: url("../../img/job/joblist-icon.png") 0 0 no-repeat;
    }
</style>
<style lang="less">
    @import "../../less/shared/variables.less";

    .job-tab {
        position: relative;
        margin-bottom: 40px;
        .el-tabs__content {
            width: 100%;
            overflow: visible;
        }
    }

    .job-creat-btn {
        position: absolute;
        right: 12px;
        top: 0;
        height: 46px;
        line-height: 46px;
        font-size: @size-lg;
        color: extract(@gray-group, 3);
        text-decoration: none;
        cursor: pointer;
        .joblist-icon {
            width: 14px;
            height: 14px;
            background-position: -20px -40px;
            margin-bottom: -1px;
        }
    }

    .el-tabs__header {
        border-bottom: 2px solid #ddd;
    }

    .el-tabs__active-bar {
        bottom: -2px;
        background-color: @primary-color;
        height: 4px;
    }

    .el-tabs__item {
        height: 46px;
        line-height: 46px;
        font-size: @size-lg;
        color: extract(@gray-group, 3);
        padding: 0 35px;
        .is-active {
            color: @primary-color;
        }
    }


</style>
<style lang="less">
    @import "../../less/shared/variables.less";

    .checked-regions {
        .el-tag {
            display: inline;
            margin: 0;
            background-color: @white;
            border: none;
            color: #555;
            padding: 0;
            border-radius: 0;
            font-size: @size-md;
        }
        .el-select {
            height: 34px;
        }
        .el-select__tags {
            text-overflow: ellipsis;
            overflow: hidden;
            padding: 0 15px 0 10px;
            z-index: 1;
        }
        .el-tag--primary {
            color: extract(@gray-group, 3);
            &:after {
                content: ',';
            }
            &:last-child:after {
                content: '';
            }
        }
        .el-tag__close {
            display: none;
        }
        .el-input__inner {
            height: 34px !important;
        }
        .el-input__icon {
            z-index: 10;
        }
        .el-select-dropdown.is-multiple .el-select-dropdown__item.selected {
            color: @primary-color;
        }
    }

    .regions-select {
        .el-select-dropdown__wrap {
            max-height: 340px;
        }
        .el-select-dropdown__item {
            height: 34px;
        }
    }

    .job-query-box {
        width: 100%;
        border: @border-gray;
        background: @white;
        padding: 30px 20px;
        margin-bottom: 15px;
        box-sizing: border-box;
    }

    .el-row {
        margin-bottom: 12px;
        &:last-child {
            margin-bottom: 0;
        }
    }

    .el-form-item {
        margin-bottom: 0;
    }

    .jq-date-group {
        & > .el-form-item__content {
            width: 234px;
        }
        .el-date-editor--date {
            width: 95%;
            float: left;
            cursor: pointer;
            .el-input__inner {
                cursor: pointer;
            }
        }
    }

    .job-query-foot {
        padding-top: 18px;
    }
</style>

