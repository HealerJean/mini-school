package cn.edu.dlut.career.domain.company;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 *
 * 实体类  双选会，招聘会信息表
 * Created by HealerJean on 2017/4/6.
 */
@Entity
@Table(name="rec_job_fair")
public class JobFair {
    //编号，主键UUID
    @Id
    @GenericGenerator(name = "idGenerator", strategy = "uuid")
    @GeneratedValue(generator = "idGenerator")
    private String id;



    //招聘会名称
    @Column(length = 50,nullable = true)
    private String name;

    //招聘会简介
    @Column(length = 1000,nullable = true)
    private String description;

    //类型：1 大型招聘,2 组团招聘
    @Column(length = 1,nullable = true)
    private char type;

    //召开时间
    @Column(nullable = false)
    private LocalDateTime holdTime;

    //报名开始时间
    @Column(nullable = false)
    private LocalDateTime startTime;

    //报名结束时间
    @Column(nullable = false)
    private LocalDateTime endTime;

    //召开地点
    @Column(length = 50,nullable = false)
    private String location;

    //是否收取服务费：1收取，2，不收取
    @Column(length = 1,nullable = false)
    private char needCost;

    //	邀请函
    @Column(length = 1000,nullable = true)
    private String invitation;

    //	校验码
    @Column(length = 16,nullable = true)
    private String checkCode;

    //	创建人
    @Column(length = 10,nullable = false)
    private String creator;

    //创建时间
    @CreationTimestamp
    @Column(nullable = false)
    private LocalDateTime createTime;

    //最后修改时间
    @Column(nullable = false)
    private LocalDateTime updateTime;

    //	最后修改人
    @Column(length = 10,nullable = false)
    private String updatePerson;

    public JobFair() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public char getType() {
        return type;
    }

    public void setType(char type) {
        this.type = type;
    }

    public LocalDateTime getHoldTime() {
        return holdTime;
    }

    public void setHoldTime(LocalDateTime holdTime) {
        this.holdTime = holdTime;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public char getNeedCost() {
        return needCost;
    }

    public void setNeedCost(char needCost) {
        this.needCost = needCost;
    }

    public String getInvitation() {
        return invitation;
    }

    public void setInvitation(String invitation) {
        this.invitation = invitation;
    }

    public String getCheckCode() {
        return checkCode;
    }

    public void setCheckCode(String checkCode) {
        this.checkCode = checkCode;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    public LocalDateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }

    public String getUpdatePerson() {
        return updatePerson;
    }

    public void setUpdatePerson(String updatePerson) {
        this.updatePerson = updatePerson;
    }
}

