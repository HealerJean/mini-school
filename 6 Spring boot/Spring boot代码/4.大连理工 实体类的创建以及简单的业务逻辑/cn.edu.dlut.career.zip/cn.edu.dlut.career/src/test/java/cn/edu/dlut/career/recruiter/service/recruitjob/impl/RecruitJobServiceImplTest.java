package cn.edu.dlut.career.recruiter.service.recruitjob.impl;

import cn.edu.dlut.career.recruiter.domain.recruitjob.RecruitJob;
import cn.edu.dlut.career.recruiter.service.recruitjob.RecruitJobService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;


/**
 * Created by 史念念 on 2017/3/23.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class RecruitJobServiceImplTest {
  @Autowired
  private RecruitJobService recruitJobService;

  private Logger logger = LoggerFactory.getLogger(RecruitJobServiceImplTest.class);
  RecruitJob recruitJob = null;

  /**
   * 测试招聘职位添加功能
   */
  @Test
  public void save(){
    recruitJob = new RecruitJob();
    recruitJob.setRecId("1");
    recruitJob.setJobTarget("Java工程师");
    recruitJob.setJobType("1");
    recruitJob.setSalary("1");
    recruitJob.setLocation("北京");
    recruitJob.setDetailedAddress("甜水园 迷你校");
    recruitJob.setQualification("1");
    recruitJob.setRecruitmentNum(12);
    recruitJob.setJobDescription("java高级工程师，包吃住，包解决北京户口");
    recruitJob.setMajor("1");
    recruitJob.setTags("java，工程师，程序猿");


    String result = recruitJobService.saveRecruitJob(recruitJob);

    logger.info(result);
  }

  /**
   * 测试查询所有
   */
  @Test
  public void findAll(){
    List<RecruitJob> ls = recruitJobService.findAll();
    logger.info("一共有"+ls.size()+"条数据");
  }

  /**
   * 测试通过id查找
   */
  @Test
  public void findById(){
    recruitJob = recruitJobService.findById("402881fc5afa2da0015afa2dab370000");

    logger.info(recruitJob.toString());
  }

  /**
   * 测试通过公司编号查找招聘信息
   */
  @Test
  public void findByRecId(){
    List<RecruitJob> ls = recruitJobService.findByRecId("1");
    logger.info("一共有"+ls.size()+"条数据");
  }

  /**
   * 测试修改审核状态,审核人,审核时间,未通过原因
   */
  @Test
  public void updateAuditStatus(){
    String result = recruitJobService.updateAudit("402881fc5afa2da0015afa2dab370000","1","史念念", LocalDateTime.now(),"");

    logger.info(result);
  }

  /**
   * 测试删除职位信息
   */
  @Test
  public void deleteById(){
    String result = recruitJobService.deleteById("402881fc5afa21cb015afa21d6510000");

    logger.info("输出的信息是"+result);
  }

}