package com.minixiao.web.dto;

/**
 * @Description .
 * @Author xiachao
 * @CreateTime 2017/2/27 16:05
 */

public class RecruiterInfo {
}
