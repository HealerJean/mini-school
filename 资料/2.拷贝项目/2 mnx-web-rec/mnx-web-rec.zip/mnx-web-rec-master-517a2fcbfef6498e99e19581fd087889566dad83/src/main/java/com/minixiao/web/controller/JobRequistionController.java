package com.minixiao.web.controller;

import com.minixiao.apiauth.client.HeaderUtil;
import com.minixiao.web.dto.jobrequistion.JobRequistion;
import com.minixiao.web.dto.recruiters.UserDTO;
import com.minixiao.web.utils.YmlConfig;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * @Description .
 * @Author JiangYh
 * @CreateTime 2017/2/13 11:09
 */
@Controller
@RequestMapping(value = "/requisitions")
public class JobRequistionController {

    @Autowired
    private YmlConfig ymlConfig;

    RestTemplate restTemplate = new RestTemplate();

    /**
     * @return
     */
    @PostMapping
    @ResponseBody
    public UUID requisitions(@RequestBody JobRequistion jobRequistion) {
        Subject subject = SecurityUtils.getSubject();
        if (subject != null) {
            UserDTO user = (UserDTO)subject.getSession().getAttribute(ymlConfig.getSession_current_user());
            if (user != null) {
                UUID recId = user.getRecId();
                String url = ymlConfig.getUrl_api_recruiter() + "requisitions";
                UUID optUid = user.getId();
                String optName = user.getRealName();
                String recName = user.getRecName();
                HttpHeaders requestHeaders = HeaderUtil.getHeader(optUid, optName, "COMPANY", recId,
                    recName);
                requestHeaders.setContentType(MediaType.APPLICATION_JSON);
                HttpEntity<JobRequistion> request = new HttpEntity<JobRequistion>(jobRequistion, requestHeaders);
                ResponseEntity<UUID> rEntity = restTemplate.exchange(url, HttpMethod.POST,
                    request, UUID.class);
                return rEntity.getBody();
            }

        }
        return null;

    }

    /**
     * @return
     */
    @PutMapping("/{id}")
    @ResponseBody
    public UUID updates(@RequestBody JobRequistion jobRequistion, @PathVariable UUID id) {
        Subject subject = SecurityUtils.getSubject();
        if (subject != null) {
            UserDTO user = (UserDTO) subject.getSession().getAttribute(ymlConfig.getSession_current_user());
            if (user != null) {
                UUID recId = user.getRecId();
                UUID optUid = user.getId();
                String optName = user.getRealName();
                String recName = user.getRecName();
                String url = ymlConfig.getUrl_api_recruiter() + "requisitions/" + id;
                HttpHeaders requestHeaders = HeaderUtil.getHeader(optUid, optName, "COMPANY", recId,
                    recName);
                requestHeaders.setContentType(MediaType.APPLICATION_JSON);
                HttpEntity<JobRequistion> request = new HttpEntity<JobRequistion>(jobRequistion, requestHeaders);
                ResponseEntity<UUID> rEntity = restTemplate.exchange(url, HttpMethod.PUT,
                    request, UUID.class);
                return rEntity.getBody();
            }
        }
        return null;
    }

    /**
     * @return
     */
    @PutMapping("/{id}/online")
    @ResponseBody
    public UUID online(@PathVariable UUID id) {
        Subject subject = SecurityUtils.getSubject();
        if (subject != null) {
            UserDTO user = (UserDTO) subject.getSession().getAttribute(ymlConfig.getSession_current_user());
            if (user != null) {
                String url = ymlConfig.getUrl_api_recruiter() + "requisitions/" + id + "/online";
                UUID recId = user.getRecId();
                UUID optUid = user.getId();
                String optName = user.getRealName();
                String recName = user.getRecName();
                HttpHeaders requestHeaders = HeaderUtil.getHeader(optUid, optName, "COMPANY", recId,
                    recName);
                requestHeaders.setContentType(MediaType.APPLICATION_JSON);
                HttpEntity<String> request = new HttpEntity<String>(null, requestHeaders);
                ResponseEntity<UUID> rEntity = restTemplate.exchange(url, HttpMethod.PUT,
                    request, UUID.class);
                return rEntity.getBody();
            }
        }
        return null;

    }

    /**
     * @return
     */
    @PutMapping("/{id}/offline")
    @ResponseBody
    public UUID offline(@PathVariable UUID id) {
        Subject subject = SecurityUtils.getSubject();
        if (subject != null) {
            UserDTO user = (UserDTO) subject.getSession().getAttribute(ymlConfig.getSession_current_user());
            if (user != null) {
                String url = ymlConfig.getUrl_api_recruiter() + "requisitions/" + id + "/offline";
                UUID recId = user.getRecId();
                UUID optUid = user.getId();
                String optName = user.getRealName();
                String recName = user.getRecName();
                HttpHeaders requestHeaders = HeaderUtil.getHeader(optUid, optName, "COMPANY", recId,
                    recName);
                requestHeaders.setContentType(MediaType.APPLICATION_JSON);
                HttpEntity<String> request = new HttpEntity<String>(null, requestHeaders);
                ResponseEntity<UUID> rEntity = restTemplate.exchange(url, HttpMethod.PUT,
                    request, UUID.class);
                return rEntity.getBody();
            }
        }
        return null;
    }

    /**
     * @return
     */
    @GetMapping("/{id}")
    @ResponseBody
    public String detail(@PathVariable UUID id) {
        Subject subject = SecurityUtils.getSubject();
        if (subject != null) {
            UserDTO user = (UserDTO) subject.getSession().getAttribute(ymlConfig.getSession_current_user());
            if (user != null) {
                String url = ymlConfig.getUrl_api_recruiter() + "requisitions/" + id;
                UUID recId = user.getRecId();
                UUID optUid = user.getId();
                String optName = user.getRealName();
                String recName = user.getRecName();
                HttpHeaders requestHeaders = HeaderUtil.getHeader(optUid, optName, "COMPANY", recId,
                    recName);
                HttpEntity<String> request = new HttpEntity<String>(null, requestHeaders);
                ResponseEntity<String> rEntity = restTemplate.exchange(url, HttpMethod.GET,
                    request, String.class);
                return rEntity.getBody();
            }
        }
        return null;
    }

    /**
     * @return
     */
    @GetMapping
    @ResponseBody
    public Page<JobRequistion> findList(String status, String jobTitle, String departmentName,
                                        String jobCategory, String jobArea, String beginDateFrom,
                                        String beginDateTo, String endDateFrom,
                                        String endDateTo, Pageable pageable) {
        Subject subject = SecurityUtils.getSubject();
        if (subject != null) {
            UserDTO user = (UserDTO) subject.getSession().getAttribute(ymlConfig.getSession_current_user());
            if (user != null) {
                String url = ymlConfig.getUrl_api_recruiter() + "requisitions?sort=updatedOn,desc";
                int page = pageable.getPageNumber();
                url += "&page=" + page;
                int size = pageable.getPageSize();
                url += "&size=" + size;
                if (status != null && !"".equals(status)) {
                    url += "&status=" + status;
                }
                if (jobTitle != null && !"".equals(jobTitle)) {
                    url += "&jobTitle=" + jobTitle;
                }
                if (jobCategory != null && !"".equals(jobCategory)) {
                    url += "&jobCategory=" + jobCategory;
                }
                if (jobArea != null && !"".equals(jobArea)) {
                    url += "&jobArea=" + jobArea;
                }
                if (beginDateFrom != null && !"".equals(beginDateFrom)) {
                    url += "&beginDateFrom=" + beginDateFrom;
                }
                if (beginDateTo != null && !"".equals(beginDateTo)) {
                    url += "&beginDateTo=" + beginDateTo;
                }
                if (endDateFrom != null && !"".equals(endDateFrom)) {
                    url += "&endDateFrom=" + endDateFrom;
                }
                if (endDateTo != null && !"".equals(endDateTo)) {
                    url += "&endDateTo=" + endDateTo;
                }
                if (departmentName != null && !"".equals(departmentName)) {
                    url += "&departmentName=" + departmentName;
                }
                UUID recId = user.getRecId();
                UUID optUid = user.getId();
                String optName = user.getRealName();
                String recName = user.getRecName();
                HttpHeaders requestHeaders = HeaderUtil.getHeader(optUid, optName, "COMPANY", recId,
                    recName);
                HttpEntity<String> request = new HttpEntity<String>(null, requestHeaders);
                ResponseEntity<Map> rEntity = restTemplate.exchange(url, HttpMethod.GET,
                    request, Map.class);
                Object obj = rEntity.getBody().get("content");
                Object total = rEntity.getBody().get("totalElements");
                if (obj instanceof ArrayList<?>) {
                    List list = (ArrayList) obj;
                    return new PageImpl(list, pageable, Long.valueOf(total.toString()));
                }
                return null;
            }
        }
        return null;
    }


    /**
     * @return
     */
    @GetMapping("/count")
    @ResponseBody
    public Integer count() {
        Subject subject = SecurityUtils.getSubject();
        if (subject != null) {
            UserDTO user = (UserDTO) subject.getSession().getAttribute(ymlConfig.getSession_current_user());
            if (user != null) {
                String url = ymlConfig.getUrl_api_recruiter() + "requisitions/count";
                UUID recId = user.getRecId();
                UUID optUid = user.getId();
                String optName = user.getRealName();
                String recName = user.getRecName();
                HttpHeaders requestHeaders = HeaderUtil.getHeader(optUid, optName, "COMPANY", recId,
                    recName);
                HttpEntity<String> request = new HttpEntity<String>(null, requestHeaders);
                ResponseEntity<Integer> rEntity = restTemplate.exchange(url, HttpMethod.GET,
                    request, Integer.class);
                return rEntity.getBody();
            }
        }
        return null;
    }

   /* *//**
     * @return
     *//*
    @PutMapping("/onlineForBatch")
    @ResponseBody
    public String onlineForBatch(String uuIds) {
        String url = "http://192.168.1.156:9112/requisitions/onlineForBatch?"+uuIds;
        UUID optUid = UUID.fromString("354bdb8f-ecd6-4c82-80fe-5f42db62d0a1");
        String optName = "小米";
        UUID recId = UUID.fromString("354bdb8f-ecd6-4c82-80fe-5f42db62d0a1");
        String recName = "迷你校";
        HttpHeaders requestHeaders = HeaderUtil.getHeader(optUid, optName, "COMPANY", recId,
            recName);
        requestHeaders.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> request = new HttpEntity<String>(null, requestHeaders);
        ResponseEntity<String> rEntity = restTemplate.exchange(url, HttpMethod.PUT,
            request, String.class);
        return rEntity.getBody();
    }

    *//**
     * @return
     *//*
    @PutMapping("/offlineForBatch")
    @ResponseBody
    public String offlineForBatch(String uuIds) {
        String url = "http://192.168.1.156:9112/requisitions/offlineForBatch?"+uuIds;
        UUID optUid = UUID.fromString("354bdb8f-ecd6-4c82-80fe-5f42db62d0a1");
        String optName = "小米";
        UUID recId = UUID.fromString("354bdb8f-ecd6-4c82-80fe-5f42db62d0a1");
        String recName = "迷你校";
        HttpHeaders requestHeaders = HeaderUtil.getHeader(optUid, optName, "COMPANY", recId,
            recName);
        requestHeaders.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> request = new HttpEntity<String>(null, requestHeaders);
        ResponseEntity<String> rEntity = restTemplate.exchange(url, HttpMethod.PUT,
            request, String.class);
        return rEntity.getBody();
    }*/

    /**
     * @return
     */
    @GetMapping("/listForAudit")
    @ResponseBody
    public Page<JobRequistion> listForAudit(String auditStatus, String jobTitle,String departmentName,
                                        String jobCategory, String jobArea, String beginDateFrom,
                                        String beginDateTo, String endDateFrom,
                                        String endDateTo, Pageable pageable) {

        Subject subject = SecurityUtils.getSubject();
        if (subject != null) {
            UserDTO user = (UserDTO) subject.getSession().getAttribute(ymlConfig.getSession_current_user());
            if (user != null) {
                String url = ymlConfig.getUrl_api_recruiter() + "requisitions/listForAudit?sort=updatedOn,desc";
                int page = pageable.getPageNumber();
                url += "&page=" + page;
                int size = pageable.getPageSize();
                url += "&size=" + size;
                if (auditStatus != null && !"".equals(auditStatus)) {
                    url += "&auditStatus=" + auditStatus;
                }
                if (jobTitle != null && !"".equals(jobTitle)) {
                    url += "&jobTitle=" + jobTitle;
                }
                if (jobCategory != null && !"".equals(jobCategory)) {
                    url += "&jobCategory=" + jobCategory;
                }
                if (jobArea != null && !"".equals(jobArea)) {
                    url += "&jobArea=" + jobArea;
                }
                if (beginDateFrom != null && !"".equals(beginDateFrom)) {
                    url += "&beginDateFrom=" + beginDateFrom;
                }
                if (beginDateTo != null && !"".equals(beginDateTo)) {
                    url += "&beginDateTo=" + beginDateTo;
                }
                if (endDateFrom != null && !"".equals(endDateFrom)) {
                    url += "&endDateFrom=" + endDateFrom;
                }
                if (endDateTo != null && !"".equals(endDateTo)) {
                    url += "&endDateTo=" + endDateTo;
                }
                if (departmentName != null && !"".equals(departmentName)) {
                    url += "&departmentName=" + departmentName;
                }
                UUID recId = user.getRecId();
                UUID optUid = user.getId();
                String optName = user.getRealName();
                String recName = user.getRecName();
                HttpHeaders requestHeaders = HeaderUtil.getHeader(optUid, optName, "COMPANY", recId,
                    recName);
                HttpEntity<String> request = new HttpEntity<String>(null, requestHeaders);
                ResponseEntity<Map> rEntity = restTemplate.exchange(url, HttpMethod.GET,
                    request, Map.class);
                Object obj = rEntity.getBody().get("content");
                Object total = rEntity.getBody().get("totalElements");
                if (obj instanceof ArrayList<?>) {
                    List list = (ArrayList) obj;
                    return new PageImpl(list, pageable, Long.valueOf(total.toString()));
                }
                return null;
            }
        }
        return null;
    }

    /**
     * @return
     */
    @GetMapping ("/jobArea")
    @ResponseBody
    public String jobArea() {
        Subject subject = SecurityUtils.getSubject();
        if (subject != null) {
            UserDTO user = (UserDTO) subject.getSession().getAttribute(ymlConfig.getSession_current_user());
            if (user != null) {
                String url = ymlConfig.getUrl_api_recruiter() + "requisitions/jobArea";
                UUID recId = user.getRecId();
                UUID optUid = user.getId();
                String optName = user.getRealName();
                String recName = user.getRecName();
                HttpHeaders requestHeaders = HeaderUtil.getHeader(optUid, optName, "COMPANY", recId,
                    recName);
                requestHeaders.setContentType(MediaType.APPLICATION_JSON);
                HttpEntity<String> request = new HttpEntity<String>(null, requestHeaders);
                ResponseEntity<String> rEntity = restTemplate.exchange(url, HttpMethod.GET,
                    request, String.class);
                return rEntity.getBody();
            }
        }
        return null;

    }

    /**
     * @return
     */
    @GetMapping ("/jobTitle")
    @ResponseBody
    public List<String> jobTitle() {
        Subject subject = SecurityUtils.getSubject();
        if (subject != null) {
            UserDTO user = (UserDTO) subject.getSession().getAttribute(ymlConfig.getSession_current_user());
            if (user != null) {
                String url = ymlConfig.getUrl_api_recruiter() + "requisitions/jobTitle";
                UUID recId = user.getRecId();
                UUID optUid = user.getId();
                String optName = user.getRealName();
                String recName = user.getRecName();
                HttpHeaders requestHeaders = HeaderUtil.getHeader(optUid, optName, "COMPANY", recId,
                    recName);
                requestHeaders.setContentType(MediaType.APPLICATION_JSON);
                HttpEntity<String> request = new HttpEntity<String>(null, requestHeaders);
                ResponseEntity<List> rEntity = restTemplate.exchange(url, HttpMethod.GET,
                    request, List.class);
                return rEntity.getBody();
            }
        }
        return null;

    }

}
