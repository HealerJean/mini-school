package cn.edu.dlut.career.service.company;


import cn.edu.dlut.career.domain.company.LargeOrder;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 专场预约 服务层 接口
 * Created by HealerJean on 2017/3/23.
 */
public interface LargeOrderService {
            //保存，添加
            LargeOrder saveLargeOrder(LargeOrder largeOrder) ;

             //根据id查询
            LargeOrder findById(String id);

             // 更新
             LargeOrder updateLargeOrder(LargeOrder largeOrder);

            //根据id删除 删除成功返回 ok ，否则 null
            String deleteLargeOrder(String id);

          //查询所有的数据
            List<LargeOrder> findAllLargeOrder();

            //根据Id进行更新审核状态，审核时间，审核人
            int updateLargeOrderAudit(String id, String auditState, LocalDateTime auditTime, String auditPerson);
        }
