package cn.edu.dlut.career.recruiter.service.recruitjob;

import cn.edu.dlut.career.recruiter.domain.recruitjob.RecruitJob;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Created by 史念念 on 2017/3/23.
 *
 * 招聘职位 服务层接口
 */
public interface RecruitJobService {

  /**
   * 查询全部招聘职位信息
   * @return
   */
  List<RecruitJob> findAll();

  /**
   * 添加招聘职位信息
   * @param recruitJob
   * @return
   */
  String saveRecruitJob(RecruitJob recruitJob);

  /**
   * 根据编号查找公司的招聘信息
   * @param id
   * @return
   */
  RecruitJob findById(String id);

  /**
   * 根据公司编号查找招聘职位信息
   * @param recId
   * @return
   */
  List<RecruitJob> findByRecId(String recId);

  /**
   * 修改审核状态,审核人,审核时间,未通过原因
   * @param id 主键
   * @param auditStatus 状态
   * @param auditPerson 审核人
   * @param auditTime 审核时间
   * @param auditFailReason  审核失败原因
   * @return
   */
  String updateAudit(String id , String auditStatus,
                           String auditPerson, LocalDateTime auditTime,
                           String auditFailReason);

  /**
   * 删除招聘职位信息
   * @return
   */
  String deleteById(String id);
}
