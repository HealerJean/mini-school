# Java 代码编写标准

请参考[Google Java Code Style](https://google.github.io/styleguide/javaguide.html)