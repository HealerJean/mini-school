<template>
    <el-dialog title="请选择所属部门" v-model="selectDepartmentVisible" :close-on-click-modal="false" :close-on-press-escape="false" @close="closeModal">
        <div>
            <div class="department-tree">
                <el-tree :data="departmentTree" :props="defaultProps" :highlight-current="true" node-key="deptId" ref="tree" :default-expand-all="true" show-checkbox :check-strictly="true"></el-tree>
            </div>
        </div>
        <div slot="footer" class="dialog-footer">
            <el-button type="primary" @click="getChecked">确 定</el-button>
            <el-button @click="closeModal">取 消</el-button>
        </div>
    </el-dialog>
</template>

<script type="text/babel">
import eventBus from '../../js/shared/eventBus';

    export default {
        data() {
            return {
                departmentTree: [{
                    "id": "1ab28b34-4c36-4e5d-8092-1f1189d2f4e1",
                    "deptId": '10',
                    "name": "迷你校测试公司",
                    "createdOn": "20170304185637",
                    "updatedOn": "20170304185637",
                    "children": [{
                        "id": "58ebf871-d914-4e24-8f1d-c0c57176dfca",
                        "deptId": "1000",
                        "name": "迷你校上海分公司",
                        "createdOn": "20170304190041",
                        "updatedOn": "20170304190213",
                    }]
                }],
                departmentArray:[

                ],
                defaultProps:{
                    children: 'children',
                    label: 'name'
                }
            }
        },
        computed: {
            selectDepartmentVisible(){
                return this.isSelectDepartment;
            },
            userId(){
                return this.$store.getters.userId
            },
            userName(){
                return this.$store.getters.userName
            },
            recId(){
                return this.$store.getters.recId
            }
        },
        methods: {
            modalConfirm(checkedKeys) {
                this.$emit('modal:select-department', checkedKeys.join(','));
                this.$emit('modal:select-department-closing');
            },
            closeModal() {
                this.$emit('modal:select-department-closing');
            },
            //获取选定的部门名数组
            getChecked() {
                let checkedKeys = this.$refs.tree.getCheckedKeys();
                let arr = new Array();
                let _this = this
                for(let i=0 ;i<checkedKeys.length;i++){

                    for(let j=0;j<_this.departmentArray.length;j++){
                        if(checkedKeys[i]===_this.departmentArray[j].deptId){
                            arr.push(_this.departmentArray[j].name);
                        }
                    }
                }
                this.modalConfirm(arr);
            },
            getDepartmentList(){
                this.$http.get('/company/departments').then(response =>{
                    let a = response.body;
                    this.departmentArray = a;
                    this.departmentTree = arrayToTree(this.departmentArray,'');
                })
            }
        },
        props: {
            isSelectDepartment: {
                type: Boolean,
                default: false
            }
        },
        mounted(){
            this.getDepartmentList();
        },
    }
    function arrayToTree(data,pid){
        let result = [];
        let temp;
        for(let i=0;i<data.length;i++){
            if(data[i].deptId.slice(0,-2) === pid){
                let obj = {"id":data[i].id,"deptId":data[i].deptId,"name":data[i].name,"createdOn":data[i].createdOn,"updatedOn":data[i].updatedOn};
                temp = arrayToTree(data,data[i].deptId);
                if(temp.length>0){
                    obj.children = temp;
                }
                result.push(obj);
            }
        }
        return result;
    }

</script>

<style lang="less">

</style>
