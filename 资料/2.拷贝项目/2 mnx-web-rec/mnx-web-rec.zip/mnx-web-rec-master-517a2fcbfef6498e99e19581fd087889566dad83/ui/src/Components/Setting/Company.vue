<template>
    <div class="company-model">
        <div>我的位置：
            <el-breadcrumb separator=">">
                <el-breadcrumb-item>系统设置</el-breadcrumb-item>
                <el-breadcrumb-item>公司信息</el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        <div class="company">
            <div class="company-header">
                <el-row >
                    <el-col :span="12"><div class="c-p-left">公司信息</div></el-col>
                    <el-col :span="12"><div class="c-p-right"><i class="icon-red-star"></i><span>为必填</span>     </div></el-col>

                </el-row>

            </div>
            <div class="company-body">
                <el-row >
                    <el-col :span="12" class="company-profile-left">
                        <el-row >
                            <el-col :span="6"><div ><i class="icon-red-star"></i>公司名称</div></el-col>
                            <el-col :span="15"><div >{{fullName}}</div></el-col>
                            <!-- <el-col :span="3"><div ><el-button type="text">编辑</el-button></div></el-col> -->
                        </el-row>
                        <el-row v-if="!isEditorNature">
                            <el-col :span="6">
                                <div ><i class="icon-red-star"></i>公司性质</div>
                            </el-col>
                            <el-col :span="15"><div >{{nature}}</div></el-col>
                            <el-col :span="3"><div ><el-button type="text" @click="editorNature">编辑</el-button></div></el-col>
                        </el-row>
                        <el-row v-if="isEditorNature" class="editorMode">
                            <el-col :span="6">
                                <div ><i class="icon-red-star"></i>公司性质</div>
                            </el-col>
                            <el-col :span="18">
                                <div >
                                    <!-- <el-input size="small"></el-input> -->
                                    <el-select v-model="modifyNature" size="small" placeholder="请选择公司性质" >
                                        <el-option v-for="item in natureItems" :label="item" :value="item">
                                        </el-option>
                                    </el-select>
                                    <el-button @click="saveNature" size="small" type="primary">保存</el-button>
                                    <el-button @click="cancelEditorNature" size="small" type="text">取消</el-button>
                                </div>
                            </el-col>
                        </el-row>
                        <el-row v-if="!isEditorIndustry1">
                            <el-col :span="6"><div ><i class="icon-red-star"></i>行业类别1</div></el-col>
                            <el-col :span="15"><div >{{primary}}</div></el-col>
                            <el-col :span="3"><div ><el-button type="text" @click="editorIndustry1">编辑</el-button></div></el-col>
                        </el-row>
                        <el-row v-if="isEditorIndustry1" class="editorMode">
                            <el-col :span="6">
                                <div ><i class="icon-red-star"></i>行业类别1</div>
                            </el-col>
                            <el-col :span="18">
                                <div >
                                    <el-input size="small" v-model="primaryModify" @focus="isSelectPrimary=true" readonly placeholder="请选择行业类别"></el-input>
                                    <el-button @click="saveIndustry1" size="small" type="primary">保存</el-button>
                                    <el-button @click="cancelEditorIndustry1" size="small" type="text">取消</el-button>
                                </div>
                            </el-col>
                        </el-row>
                        <!-- 选择行业类别1选择框 -->
                        <select-industry-modal :isSelectingIndustry="isSelectPrimary" @modal:select-industry-closing="closeSelectPrimary" @modal:emit-selected-industries="selectedPrimary" :max="max"></select-industry-modal>
                        <el-row v-if="!isEditorCity">
                            <el-col :span="6"><div ><i class="icon-red-star"></i>所在城市</div></el-col>
                            <el-col :span="15"><div >{{city}}</div></el-col>
                            <el-col :span="3"><div ><el-button type="text" @click="editorCity">编辑</el-button></div></el-col>
                        </el-row>
                        <el-row v-if="isEditorCity" class="editorMode">
                            <el-col :span="6">
                                <div ><i class="icon-red-star"></i>所在城市</div>
                            </el-col>
                            <el-col :span="18">
                                <div >
                                    <el-input size="small" v-model="cityModify" @focus="isSelectCity=true" readonly placeholder="请选择城市"></el-input>
                                    <el-button @click="saveCity" size="small" type="primary">保存</el-button>
                                    <el-button @click="cancelEditorCity" size="small" type="text">取消</el-button>
                                </div>
                            </el-col>
                        </el-row>
                        <!-- 选择城市弹出框 -->
                        <select-city-modal :isSelectingCity="isSelectCity" @modal:select-city-closing="closeSelectCity" @modal:emit-selected-cities="selectedCity" :max="max"></select-city-modal>
                        <el-row v-if="!isEditorAddress">
                            <el-col :span="6"><div ><i class="icon-red-star"></i>详细地址</div></el-col>
                            <el-col :span="15"><div >{{address}}</div></el-col>
                            <el-col :span="3"><div ><el-button type="text" @click="editorAddress">编辑</el-button></div></el-col>
                        </el-row>
                        <el-row v-if="isEditorAddress" class="editorMode">
                            <el-col :span="6">
                                <div ><i class="icon-red-star"></i>详细地址</div>
                            </el-col>
                            <el-col :span="18">
                                <div >
                                    <el-input size="small" v-model="modifyAddress"></el-input>
                                    <el-button @click="saveAddress" size="small" type="primary">保存</el-button>
                                    <el-button @click="cancelEditorAddress" size="small" type="text">取消</el-button>
                                </div>
                            </el-col>
                        </el-row>

                    </el-col>
                    <el-col :span="12" class="company-profile-right">
                        <el-row >
                            <el-col :span="6"><div ><i class="icon-red-star"></i>公司简称</div></el-col>
                            <el-col :span="15"><div >{{shortName}}</div></el-col>
                            <!-- <el-col :span="3"><div ><el-button type="text">编辑</el-button></div></el-col> -->
                        </el-row>
                        <el-row v-if="!isEditorSize">
                            <el-col :span="6"><div ><i class="icon-red-star"></i>公司规模</div></el-col>
                            <el-col :span="15"><div >{{size}}</div></el-col>
                            <el-col :span="3"><div ><el-button type="text" @click="editorSize">编辑</el-button></div></el-col>
                        </el-row>
                        <el-row v-if="isEditorSize" class="editorMode">
                            <el-col :span="6">
                                <div ><i class="icon-red-star"></i>公司规模</div>
                            </el-col>
                            <el-col :span="18">
                                <div >
                                    <el-select v-model="modifySize" size="small" placeholder="请选择公司规模" >
                                        <el-option v-for="item in SizeItems" :label="item" :value="item">
                                        </el-option>
                                    </el-select>
                                    <el-button @click="saveSize" size="small" type="primary">保存</el-button>
                                    <el-button @click="cancelEditorSize" size="small" type="text">取消</el-button>
                                </div>
                            </el-col>
                        </el-row>
                        <el-row v-if="!isEditorIndustry2">
                            <el-col :span="6"><div class="no-star">行业类别2</div></el-col>
                            <el-col :span="15"><div>{{slave}}&nbsp;</div></el-col>
                            <el-col :span="3"><div ><el-button type="text" @click="editorIndustry2">编辑</el-button></div></el-col>
                        </el-row>
                        <el-row v-if="isEditorIndustry2" class="editorMode">
                            <el-col :span="6">
                                <div class="no-star">行业类别2</div>
                            </el-col>
                            <el-col :span="18">
                                <div >
                                    <el-input size="small" v-model="slaveModify" @focus="isSelectSlave=true" readonly placeholder="请选择行业类别"></el-input>
                                    <el-button @click="saveIndustry2" size="small" type="primary">保存</el-button>
                                    <el-button @click="cancelEditorIndustry2" size="small" type="text">取消</el-button>
                                </div>
                            </el-col>
                        </el-row>
                        <!-- 选择行业类别2选择框 -->
                        <select-industry-modal :isSelectingIndustry="isSelectSlave" @modal:select-industry-closing="closeSelectSlave" @modal:emit-selected-industries="selectedSlave" :max="max"></select-industry-modal>
                        <el-row v-if="!isEditorUrl">
                            <el-col :span="6"><div ><i class="icon-red-star"></i>公司官网</div></el-col>
                            <el-col :span="15"><div >{{website}}</div></el-col>
                            <el-col :span="3"><div ><el-button type="text" @click="editorUrl">编辑</el-button></div></el-col>
                        </el-row>
                        <el-row v-if="isEditorUrl" class="editorMode">
                            <el-col :span="6">
                                <div ><i class="icon-red-star"></i>公司官网</div>
                            </el-col>
                            <el-col :span="18">
                                <div >
                                    <el-input v-model="modifyWebsite" size="small"></el-input>
                                    <el-button @click="saveUrl" size="small" type="primary">保存</el-button>
                                    <el-button @click="cancelEditorUrl" size="small" type="text">取消</el-button>
                                </div>
                            </el-col>
                        </el-row>
                    </el-col>
                </el-row>
                <div class="company-tag">
                    <el-row >
                        <el-col :span="3"><div ><i class="icon-red-star"></i>公司标签</div></el-col>
                        <el-col :span="21">
                            <div >
                                <el-tag v-for="(tag,index) in tags" :closable="true" type="warning" @close="removeTag(index)">{{tag}}
                                </el-tag>
                                <el-button type="text" @click="isAddingTags=true">+添加标签</el-button>
                            </div>
                        </el-col>
                    </el-row>
                    <add-tag-modal :isAddingTags="isAddingTags"></add-tag-modal>
                </div>
                <div class="company-logo">
                    <el-row >
                        <el-col :span="3"><div ><i class="icon-red-star"></i>公司logo</div></el-col>
                        <el-col :span="21">
                            <div >
                                <el-upload
                                  class="company-logo-uploader"
                                  action="//jsonplaceholder.typicode.com/posts/"
                                  :show-file-list="false"
                                  :on-success="handleAvatarScucess"
                                  :before-upload="beforeAvatarUpload">
                                  <img v-if="imageUrl" :src="imageUrl" class="avatar">
                                  <i v-else class="el-icon-upload2 company-logo-uploader-icon"></i>
                                </el-upload>
                                <div class="company-logo-uploader-text">
                                    (请上传文件小于1M的图片，尺寸160px*160px，支持格式jpg、gif、png)
                                </div>
                            </div>
                        </el-col>
                    </el-row>
                </div>
                <div class="company-slogan">
                    <el-row v-if="!isEditorSlogan">

                        <el-col :span="3"><div ><i class="icon-red-star"></i>一句话介绍</div></el-col>
                        <el-col :span="19"><div >{{slogan}}</div>
                        </el-col>
                        <el-col :span="2"><div ><el-button type="text" @click="editorSlogan" class="el-button-editor">编辑</el-button></div></el-col>
                    </el-row>
                    <el-row class="editorSloganMode" v-if="isEditorSlogan">
                        <el-col :span="3"><div ><i class="icon-red-star"></i>一句话介绍</div></el-col>
                        <el-col :span="21">
                            <div >
                                <el-input type="textarea" :rows="2" placeholder="请输入内容" v-model="sloganModify"></el-input>
                                <div class="slogan-count-div">
                                    <span class="slogan-count" >{{sloganCount}}/50</span>
                                </div>
                                <el-button @click="saveSlogan" size="small" type="primary">保存</el-button>
                                <el-button @click="cancelEditorSlogan" size="small" type="text">取消</el-button>
                            </div>
                        </el-col>
                    </el-row>
                </div>
                <div class="company-description">
                    <el-row v-if="!isEditorDescription">
                        <el-col :span="3"><div ><i class="icon-red-star"></i>公司简介</div></el-col>
                        <el-col :span="19">
                            <p>{{description}}</p>
                        </el-col>
                        <el-col :span="2"><div ><el-button type="text" class="el-button-editor" @click="editorDescription">编辑</el-button></div></el-col>
                    </el-row>
                    <el-row class="editorDescriptionMode" v-if="isEditorDescription">
                        <el-col :span="3"><div ><i class="icon-red-star"></i>公司简介</div></el-col>
                        <el-col :span="21">
                            <div >
                                <el-input type="textarea" :rows="4" placeholder="请输入内容" v-model="descriptionModify"></el-input>
                                <div class="description-count-div">
                                    <span class="description-count" >{{descriptionCount}}/10000</span>
                                </div>
                                <el-button @click="saveDescription" size="small" type="primary">保存</el-button>
                                <el-button @click="cancelEditorDescription" size="small" type="text">取消</el-button>
                            </div>
                        </el-col>
                    </el-row>
                </div>
                <div class="company-picture">
                    <el-row >
                        <el-col :span="3"><div >公司图片</div></el-col>
                        <el-col :span="21">
                            <div class="company-picture-body">
                                <el-upload
                                  action="//jsonplaceholder.typicode.com/posts/"
                                  list-type="picture-card"
                                  :on-preview="handlePictureCardPreview"
                                  :on-remove="handleRemove"
                                  class="company-picture-upload" >
                                  <i class="el-icon-plus company-picture-upload-icon"></i>
                                </el-upload>
                                <el-dialog v-model="dialogVisible" size="tiny">
                                  <img width="100%" :src="dialogImageUrl" alt="">
                                </el-dialog>
                                <p>上传</p>
                                <p>(公司图片最多可上传6张，请上传文件小于1M的图片，尺寸480px*340px，支持格式jpg、gif、png)</p>
                            </div>
                        </el-col>
                    </el-row>
                </div>
            </div>
        </div>
    </div>
</template>

<script type="text/babel">

    import AddTagModal from '../Modal/AddTagModal'
    import eventBus from '../../js/shared/eventBus';
    import SelectCityModal from '../Modal/SelectCityModal'
    import SelectIndustryModal from '../Modal/SelectIndustryModal'

    export default {
        data:function(){
            return{
                max:1,
                modifyAddress:'',
                modifyNature:'',
                modifySize:'',
                modifyWebsite:'',
                sloganModify:'',
                descriptionModify:'',
                primaryModify:'',
                slaveModify:'',
                cityModify:'',
                imageUrl: '',
                isEditorNature: false,
                isEditorIndustry1: false,
                isEditorCity: false,
                isEditorAddress: false,
                isEditorSize: false,
                isEditorIndustry2: false,
                isEditorUrl: false,
                isEditorSlogan: false,
                isEditorDescription: false,
                isAddingTags: false,

                isSelectPrimary:false,
                isSelectSlave: false,
                isSelectCity: false,
                natureItems:[ "私营/民营企业",
                    "中外合资企业",
                    "外商独资企业",
                    "上市公司",
                    "国有企业",
                    "政府/事业单位",
                    "非营利性组织"
                ],
                SizeItems:[ "1-49人", "50-99人", "100-499人", "500-999人", "1000-2000人", "2000-5000人", "5000-10000人" ],
                companyTags:[]
            }
        },
        methods: {
             getCompanyInfo: function(){
                this.$http.get('/company').then(response =>{
                    let a = response.body;
                    this.$store.commit('updateCompanyInformation' , a);
                })
            },
            removeTag(tagIndex){
                let tags = this.tags;
                tags.splice(tagIndex,1);
                let modifyTags = tags.join(',');
                this.$http.put('/company/modification/tags?tags='+ modifyTags).then(
                    response => {
                        this.getCompanyInfo();
                    });
            },
            selectedCity: function(value){
                this.cityModify = value.join(',');
            },
            closeSelectCity: function(){
                this.isSelectCity = false;
            },
            selectedPrimary: function(value){
                this.primaryModify = value.join(',');
            },
            closeSelectPrimary: function(){
                this.isSelectPrimary = false;
            },
            selectedSlave: function(value){
                this.slaveModify = value.join(',');
            },
            closeSelectSlave: function(){
                this.isSelectSlave = false;
            },
            //公司性质
            editorNature: function() {
                this.isEditorNature = true;
                this.modifyNature = this.nature;
            },
            cancelEditorNature: function () {
                this.isEditorNature = false;

            },
            saveNature: function () {
                this.isEditorNature = false;
                this.$http.put('/company/modification/nature?nature='+this.modifyNature).then(
                    response => {
                        this.getCompanyInfo();
                    });
            },

            //行业类别1
            editorIndustry1: function() {
                this.isEditorIndustry1 = true;
                this.primaryModify = this.primary;
            },
            cancelEditorIndustry1: function () {
                this.isEditorIndustry1 = false;
            },
            saveIndustry1: function () {
                this.isEditorIndustry1 = false;
                this.$http.put('/company/modification/primaryIndustry?primaryIndustry='+this.primaryModify).then(
                    response => {
                        this.getCompanyInfo();
                    });
            },
            //所在城市
            editorCity: function() {
                this.isEditorCity = true;
                this.cityModify = this.city;
            },
            cancelEditorCity: function () {
                this.isEditorCity = false;
            },
            saveCity: function () {
                this.isEditorCity = false;
                this.$http.put('/company/modification/city?city='+this.cityModify).then(
                    response => {
                        this.getCompanyInfo();
                    });
            },
            //详细地址
            editorAddress: function() {
                this.isEditorAddress = true;
                this.modifyAddress = this.address;
            },
            cancelEditorAddress: function () {
                this.isEditorAddress = false;
            },
            saveAddress: function () {
                this.isEditorAddress = false;
                this.$http.put('/company/modification/detailAddress?detailAddress='+this.modifyAddress).then(
                    response => {
                        this.getCompanyInfo();
                    });
            },
            //公司规模
            editorSize: function() {
                this.isEditorSize = true;
                this.modifySize = this.size;
            },
            cancelEditorSize: function () {
                this.isEditorSize = false;
            },
            saveSize: function () {
                this.isEditorSize = false;
                this.$http.put('/company/modification/size?size='+this.modifySize).then(
                    response => {
                        this.getCompanyInfo();
                    });
            },
            //行业类别2
            editorIndustry2: function() {
                this.isEditorIndustry2 = true;
                this.slaveModify = this.slave;
            },
            cancelEditorIndustry2: function () {
                this.isEditorIndustry2 = false;
            },
            saveIndustry2: function () {
                this.isEditorIndustry2 = false;
                this.$http.put('/company/modification/slaveIndustry?slaveIndustry='+this.slaveModify).then(
                    response => {
                        this.getCompanyInfo();
                    });
            },
            //公司官网
            editorUrl: function() {
                this.isEditorUrl = true;
                this.modifyWebsite = this.website;
            },
            cancelEditorUrl: function () {
                this.isEditorUrl = false;
            },
            saveUrl: function () {
                this.isEditorUrl = false;
                this.$http.put('/company/modification/website?website='+this.modifyWebsite).then(
                    response => {
                        this.getCompanyInfo();
                    });
            },
            //一句话介绍
            editorSlogan: function() {
                this.isEditorSlogan = true;
                this.sloganModify = this.slogan;
            },
            cancelEditorSlogan: function () {
                this.isEditorSlogan = false;
            },
            saveSlogan: function () {
                this.isEditorSlogan = false;
                this.$http.put('/company/modification/slogan?slogan='+this.sloganModify).then(
                    response => {
                        this.getCompanyInfo();
                    });
            },
            //公司简介
            editorDescription: function() {
                this.isEditorDescription = true;
                this.descriptionModify = this.description;
            },
            cancelEditorDescription: function () {
                this.isEditorDescription = false;
            },
            saveDescription: function () {
                this.isEditorDescription = false;
                this.$http.put('/company/modification/description?description='+this.descriptionModify).then(
                    response => {
                        this.getCompanyInfo();
                    });
            }
        },

        computed: {
            userId(){
                return this.$store.getters.userId
            },
            userName(){
                return this.$store.getters.userName
            },
            recId(){
                return this.$store.getters.recId
            },
            sloganCount() {
                if(this.sloganModify.length>51){
                    this.sloganModify = this.sloganModify.substr(0,50);
                }

                return this.sloganModify.length;
            },
            descriptionCount() {
                if(this.descriptionModify.length>10001){
                    this.descriptionModify = this.descriptionModify.substr(0,10000);
                    /* eslint-disable */
                    console.log(this.descriptionModify);
                    /* eslint-disable */
                }
                return this.descriptionModify.length;
            },
            companyInformation() {
                return this.$store.state.company.companyInformation;
            },
            fullName() {
                return this.companyInformation.fullName;
            },
            shortName() {
                return this.companyInformation.shortName;
            },
            slogan() {
                return this.companyInformation.slogan;
            },
            description() {
                return this.companyInformation.description;
            },
            nature() {
                return this.companyInformation.nature;
            },
            primary() {
                return this.companyInformation.primaryIndustry;
            },
            slave() {
                return this.companyInformation.slaveIndustry;
            },
            size() {
                return this.companyInformation.size;
            },
            city() {
                return this.companyInformation.city;
            },
            address() {
                return this.companyInformation.detailAddress;
            },
            website() {
                return this.companyInformation.website;
            },
            tags() {
                return this.companyInformation.tags.replace(/，/g,',').split(',');

            }

        },
        mounted() {
            eventBus.$on('modal:add-tags-closing',()=> {
                this.isAddingTags=false;

            });
            eventBus.$on('modal:emit-added-tags',(val)=> {
                //提交保存标签
                let modifyTags = val.join(',');
                console.log(modifyTags+'修改标签');
                this.$http.put('/company/modification/tags?tags='+ modifyTags).then(
                    response => {
                        this.getCompanyInfo();
                    });
            });
            this.getCompanyInfo();

        },

        components: {
            AddTagModal,
            SelectCityModal,
            SelectIndustryModal
        }


    }

</script>

<style lang="less">
    .company-model {
        font-size: 14px;
        .el-input,.el-select {
            width:200px;
        }
        .no-star {
            padding-left: 6px;
        }
        .el-button--text {
            color:#15a3ff;
            font-size: 14px;
        }
        .editorMode {
            line-height: 56px;
            background-color: #fcf6f1;
        }
        .editorSloganMode,.editorDescriptionMode {
            background-color: #fcf6f1;
            .el-textarea {
                width: 680px;
            }
            .el-button {
                float: left;
            }
        }
        .icon-red-star {
            width:6px;
            height:6px;
            background: url(../../img/company/star.png) no-repeat;

            display: inline-block;
            // position: absolute;
            // left: 40px;
            // top: 22px;
        }
        .el-breadcrumb {
            display: inline-block;
        }

        .company {

            background-color: #fff;
            width: 1180px;
            margin-top: 20px;

            .company-header {
                width:1140px;
                height: 50px;
                border-bottom: 1px solid #e2e2e2;
                padding: 0 20px;
                overflow: hidden;
                .el-row {
                    margin-bottom: 0;
                    line-height: 50px;
                }
                .c-p-left {
                    font-size: 20px;
                }
                .c-p-right {
                    text-align: right;
                    font-size: 15px;
                }
            }
            // .company-body>.el-row {
            //     margin-left: 40px;
            // }
            .company-body {
                margin-top:20px;
                .company-profile-left {

                    border-right: 1px dashed #eeeeee;

                    .el-row {
                        // margin-left: 40px;
                        padding-left: 40px;
                        margin-bottom: 0;
                        line-height: 42px;
                    }
                }
                .company-profile-right {

                    .el-row {
                       // margin-left: 30px;
                        padding-left: 30px;
                        margin-bottom: 0px;
                        line-height: 42px;
                    }
                }
                .company-tag {
                    margin-bottom:20px;

                    .el-row {
                        // margin-left: 40px;
                        padding-left: 40px;
                        margin-bottom: 0px;
                    }
                }
                .company-logo {
                    margin-bottom:20px;
                    .company-logo-uploader-text {
                        display: inline-block;
                    }
                    .el-row {
                        // margin-left: 40px;
                        padding-left: 40px;
                        margin-bottom: 0px;
                    }
                    .company-logo-uploader {
                        width:120px;
                        height:120px;
                        background-color: #eeeeee;

                        border: 1px dashed #eeeeee;
                        cursor: pointer;
                        display: inline-block;
                        .company-logo-uploader-icon {
                            width:118px;
                            height:118px;
                            text-align: center;
                            line-height: 118px;
                        }
                    }
                }
                .company-slogan {
                    margin-bottom:20px;

                    .el-row {
                        // margin-left: 40px;
                        padding-left: 40px;
                        margin-bottom: 0px;
                        padding-top: 24px;
                        .el-button-editor{
                            float: right;
                        }
                        .slogan-count-div{
                            text-align: right;
                            width: 680px;
                            .slogan-count {
                            font-size: 10px;

                            }
                        }

                    }
                }
                .company-description {
                    margin-bottom:20px;

                    .el-row {
                        // margin-left: 40px;
                        padding-left: 40px;
                        margin-bottom: 0px;
                        padding-top: 24px;
                        p {
                            line-height: 2em;
                        }
                        .el-button-editor{
                            float: right;
                        }
                        .description-count-div{
                            text-align: right;
                            width: 680px;
                            .description-count {
                            font-size: 10px;

                            }
                        }
                    }
                }
                .company-picture {
                    margin-bottom:20px;
                    .company-picture-body{
                        p {
                            line-height: 1em;
                        }
                    }
                    .el-row {
                        // margin-left: 40px;
                        padding-left: 40px;
                        margin-bottom: 0px;
                         .el-button{
                            float: right;
                         }
                    }
                    .company-picture-upload {
                        width: 50px;
                        height: 50px;
                        background-color: #eeeeee;
                        border: 1px dashed #eeeeee;
                        cursor: pointer;

                        .company-picture-upload-icon {
                            width: 48px;
                            height: 48px;
                            text-align: center;
                            line-height: 48px;

                        }
                    }
                }
            }


        }
    }
</style>
