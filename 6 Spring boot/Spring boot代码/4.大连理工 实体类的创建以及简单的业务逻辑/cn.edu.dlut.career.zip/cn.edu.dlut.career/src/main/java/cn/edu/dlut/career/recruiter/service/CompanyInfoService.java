package cn.edu.dlut.career.recruiter.service;

import cn.edu.dlut.career.recruiter.domain.CompanyInfo;

import java.util.List;

/**
 * Created by wei on 2017/3/23.
 */
public interface CompanyInfoService {
  /**
   * 注册公司
   * @param companyInfo
   */
  void saveCompany(CompanyInfo companyInfo);

  /**
   * 登录
   * @param email
   * @param pwd
   * @return
   */
  CompanyInfo login(String email, String pwd);

  CompanyInfo update(CompanyInfo companyInfo);

  void delete(String id);

  List<CompanyInfo> findAll();

  CompanyInfo findOne(String id);


  CompanyInfo findByEmail(String email);
}
