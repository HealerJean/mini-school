package com.minixiao.web.controller;

import com.minixiao.apiauth.client.HeaderUtil;
import com.minixiao.web.dto.recruiters.UserDTO;
import com.minixiao.web.utils.YmlConfig;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * @Description .
 * @Author JiangYh
 * @CreateTime 2017/2/13 11:09
 */
@Controller
@RequestMapping(value = "/requisitions")
public class JobRequistionStatisticsController {

    @Autowired
    private YmlConfig ymlConfig;
    RestTemplate restTemplate = new RestTemplate();

    /**
     * @return
     */
    @GetMapping("/{jobId}/count")
    @ResponseBody
    public String jobStatisticsCount(@PathVariable UUID jobId) {
        Subject subject = SecurityUtils.getSubject();
        if (subject != null) {
            UserDTO user = (UserDTO) subject.getSession().getAttribute(ymlConfig.getSession_current_user());
            if (user != null) {
                String url = ymlConfig.getUrl_api_recruiter() + "requisitions/" + jobId + "/count";
                UUID recId = user.getRecId();
                UUID optUid = user.getId();
                String optName = user.getRealName();
                String recName = user.getRecName();
                HttpHeaders requestHeaders = HeaderUtil.getHeader(optUid, optName, "COMPANY", recId,
                    recName);
                HttpEntity<String> request = new HttpEntity<String>(null, requestHeaders);
                ResponseEntity<String> rEntity = restTemplate.exchange(url, HttpMethod.GET,
                    request, String.class);
                return rEntity.getBody();
            }
        }
        return null;
    }

}
