package cn.edu.dlut.career.recruiter.service.impl;

import cn.edu.dlut.career.recruiter.domain.CompanyInfo;
import cn.edu.dlut.career.recruiter.repository.CompanyInfoRepository;
import cn.edu.dlut.career.recruiter.service.CompanyInfoService;
import cn.edu.dlut.career.recruiter.util.MD5Util;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by wei on 2017/3/23.
 */
@Service
@Transactional
public class CompanyInfoServiceImpl implements CompanyInfoService {
  @Autowired
  private CompanyInfoRepository companyInfoRepository;

  /**
   * 注册公司
   * @param companyInfo
   */
  @Override
  public void saveCompany(CompanyInfo companyInfo) {

      String pwd = companyInfo.getPwd();
      pwd = MD5Util.getEncryptString(pwd);
      companyInfo.setPwd(pwd);
      companyInfoRepository.save(companyInfo);

  }

  /**
   * 登录
   * @param email
   * @param pwd
   * @return
   */
  @Override
  public CompanyInfo login(String email, String pwd) {
    CompanyInfo companyInfo = null;
    CompanyInfo companyInfoLogin =  companyInfoRepository.findByEmail(email);
    if(MD5Util.compare(pwd,companyInfo.getPwd())){
      companyInfo = companyInfoLogin;
    }
    return companyInfo;

  }

  @Override
  public CompanyInfo update(CompanyInfo companyInfo) {
    return companyInfoRepository.save(companyInfo);
  }

  @Override
  public void delete(String id) {
    companyInfoRepository.delete(id);
  }

  @Override
  public List<CompanyInfo> findAll() {
    return companyInfoRepository.findAll();
  }

  @Override
  public CompanyInfo findOne(String id) {
    return companyInfoRepository.findOne(id);
  }

  @Override
  public CompanyInfo findByEmail(String email) {
    CompanyInfo companyInfo = companyInfoRepository.findByEmail(email);
    return companyInfo;
  }
}
