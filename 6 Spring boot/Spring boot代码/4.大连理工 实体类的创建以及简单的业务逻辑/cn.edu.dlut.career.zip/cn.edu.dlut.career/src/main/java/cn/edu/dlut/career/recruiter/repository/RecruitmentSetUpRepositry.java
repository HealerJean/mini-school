package cn.edu.dlut.career.recruiter.repository;

import cn.edu.dlut.career.recruiter.domain.RecruitmentSetUp;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

/**
 * Created by wei on 2017/3/27.
 */
public interface RecruitmentSetUpRepositry extends CrudRepository<RecruitmentSetUp,String> {
  List<RecruitmentSetUp> findAll();
}
