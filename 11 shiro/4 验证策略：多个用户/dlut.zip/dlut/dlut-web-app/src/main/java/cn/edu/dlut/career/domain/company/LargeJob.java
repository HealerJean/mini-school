package cn.edu.dlut.career.domain.company;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 大型招聘会 预约职位表
 * Created by HealerJean on 2017/3/23.
 */
@Entity
@Table(name="rec_large_job")
public class LargeJob {
   //职位编号id
    @Id
    @GenericGenerator(name = "idGenerator", strategy = "uuid")
    @GeneratedValue(generator = "idGenerator")
    private  String id;

   //预约Id
    private String orderId;

 public String getOrderId() {
  return orderId;
 }

 public void setOrderId(String orderId) {
  this.orderId = orderId;
 }

 public String getJobId() {
  return jobId;
 }

 public void setJobId(String jobId) {
  this.jobId = jobId;
 }

 //职位编号 jobId
    private  String jobId;


   public LargeJob() {
   }


 public String getId() {
  return id;
 }

 public void setId(String id) {
  this.id = id;
 }


}
