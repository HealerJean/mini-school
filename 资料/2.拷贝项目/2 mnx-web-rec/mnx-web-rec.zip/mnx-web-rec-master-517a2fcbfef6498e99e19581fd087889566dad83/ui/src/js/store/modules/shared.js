
// initial state
const state = {
    //用户信息
    userInfor:{
        admin: false,
        deptId:"",
        deptName:"",
        email:"",
        id:"",
        realName:"",
        recId:"",
        recName:""
    }
}

//getters
const getters = {
    recId(state) {
        return state.userInfor.recId;
    },
    recName(state){
        return state.userInfor.recName
    },
    userId(state){
        return state.userInfor.id;
    },
    userName(state){
        return state.userInfor.realName
    },
    admin(state){
        return state.userInfor.admin
    },
    email(state){
        return state.userInfor.email
    },

    deptId(state){
        return state.userInfor.deptId
    },
    deptName(state){
        return state.userInfor.deptName
    }
}

//actions
const actions = {

}

//mutations
const mutations = {
    //更新用户信息
    updateUserInfor (state,value) {
        state.userInfor = value;
    }

}


export default {
  state,
  getters,
  actions,
  mutations
}
