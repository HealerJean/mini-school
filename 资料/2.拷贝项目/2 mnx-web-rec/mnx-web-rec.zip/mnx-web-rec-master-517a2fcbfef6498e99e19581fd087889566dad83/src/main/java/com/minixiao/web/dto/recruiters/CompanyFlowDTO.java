package com.minixiao.web.dto.recruiters;

/**
 * 公司招聘流程dto.
 * Created by xiachao on 2017/3/2.
 */
public class CompanyFlowDTO {

    //流程类型
    private String type;

    //流程名称
    private String name;

    //流程次序
    private Integer flowOrder;

    //候选人个数
    private Integer candidateCount;

    public CompanyFlowDTO() {
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getFlowOrder() {
        return flowOrder;
    }

    public void setFlowOrder(Integer flowOrder) {
        this.flowOrder = flowOrder;
    }

    public Integer getCandidateCount() {
        return candidateCount;
    }

    public void setCandidateCount(Integer candidateCount) {
        this.candidateCount = candidateCount;
    }
}
