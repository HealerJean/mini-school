// initial file for passport
import Vue from 'vue';
import About from '../../Components/Shared/About.vue';
import ElementUI from 'element-ui';

// styles
import 'element-ui/lib/theme-default/index.css';

Vue.use(ElementUI);

new Vue({
    components: {
        About
    }
}).$mount('#app');