<template>
    <el-dialog title="确认发布"
               v-model="publishModalVisible"
               size="tiny"
               :close-on-click-modal="false"
               :close-on-press-escape="false"
               @close="closeModal">
        当前职位需要进行审核，我们将在2个工作日内完成审核，通过后即可上线！
        <div slot="footer" class="dialog-footer">
            <el-button type="primary" @click="modalConfirm">确定</el-button>
            <el-button @click="closeModal">取消</el-button>
        </div>
    </el-dialog>
</template>

<script type="text/babel">
    export default {
        name: 'publish-modal',
        data() {
            return {};
        },
        computed: {
            publishModalVisible() {
                return this.isPublishModal;
            }
        },
        props: {
            isPublishModal: {
                type: Boolean,
                default: false
            }
        },
        methods: {
            closeModal() {
                this.$emit('modal:publish-closing');
            },
            modalConfirm() {
                this.$emit('modal:publish-confirm');
                this.$emit('modal:publish-closing');
            }
        }
    }

</script>

<style lang="less" scoped>

    @import "../../less/shared/variables";

    .change-time-main{
        display:inline-block;
        text-align: left;
    }
    .change-time-label{
        margin-right:10px;
        font-size:@size-lg;
        float: left;
        line-height: 36px;
    }
    .change-time-tip{
        margin-top:18px;
        margin-bottom:0;
        font-size:@size-sm;
        color:@highlight-color;
    }


</style>
