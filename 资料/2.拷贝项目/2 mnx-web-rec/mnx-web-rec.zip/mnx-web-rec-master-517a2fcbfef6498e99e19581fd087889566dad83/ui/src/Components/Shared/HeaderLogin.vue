<template>
    <header class="header">
        <div class="inner">
            <el-row>
                <el-col :span="3">
                    <img class="header-logo" src="../../img/common/minixiao-logo.png" alt="迷你校LOGO"/>
                </el-col>
                <el-col :span="21" class="head-login-r">
                    <div class="head-login-r">
                        <el-row type="flex" class="row-bg" justify="space-between">
                            <el-col :span="18">
                                <div class="head-company">{{recName}}</div>
                                <div class="nav-wrap">
                                    <nav-bar></nav-bar>
                                </div>
                            </el-col>
                            <el-col :span="6">
                                <ul class="head-icon-group">
                                    <li>
                                        <el-dropdown trigger="hover">
                                            <div class="el-dropdown-link">
                                                <div class="user-wrap">
                                                    <span class="userImg" :style="colorBg" v-if="userImgInit">{{userImg}}</span>
                                                    <span class="userImg" v-else><img src="../../img/common/QR_com_t.png"/></span>
                                                </div>
                                            </div>
                                            <el-dropdown-menu slot="dropdown">
                                                <el-dropdown-item>
                                                    <router-link to="/setting/account">账号管理</router-link>
                                                </el-dropdown-item>
                                                <el-dropdown-item>
                                                    <router-link to="/setting/filter">筛选器管理</router-link>
                                                </el-dropdown-item>
                                                <el-dropdown-item ><a href="/logout.html">退出</a></el-dropdown-item>
                                            </el-dropdown-menu>
                                        </el-dropdown>
                                    </li>
                                    <li class="setting-select">
                                        <el-menu default-active="1" class="el-menu-demo" mode="horizontal" :router="true">
                                            <el-submenu index="/setting">
                                                <template slot="title"><i class="el-icon-setting"></i></template>
                                                <el-menu-item :index="item.url" v-for="item in settingDrops">{{item.name}}</el-menu-item>
                                            </el-submenu>
                                        </el-menu>
                                    </li>
                                    <li>
                                        <router-link to="/job/add"><i class="el-icon-plus"></i></router-link>
                                    </li>
                                </ul>
                            </el-col>
                        </el-row>
                    </div>
                </el-col>
            </el-row>
        </div>
    </header>
</template>

<script type="text/babel">
    import NavBar from './NavBar.vue'
    import { strChineseFirstPY , oMultiDiff } from '../../js/shared/pinyin'

    export default {
        components: {
            NavBar
        },

        data: function () {
            return {

                userImgInit: true,
                settingDrops: [
                    {url: '/setting/company', name: '公司信息'},
                    {url: '/setting/department', name: '部门管理'},
                    {url: '/setting/workflow', name: '流程设置'},
                    {url: '/setting/users', name: '用户管理'},
                    {url: '/setting/tags', name: '标签管理'},
                    {url: '/setting/infro', name: '通知模板'}
                ]
            }
        },

        computed: {
            userId(){
                return this.$store.getters.userId
            },
            userName(){
                return this.$store.getters.userName
            },
            recId(){
                return this.$store.getters.recId
            },
            recName(){
               return this.$store.getters.recName;
            },
            userImg: function () {
                return this.userName.charAt(this.userName.length-1)
            },
            colorBg: function () {
                let colorArr = ['#e9573e', '#3eb7e9', '#e99b3e', '#a1a1ff', '#21b99b', '#ec5d85', '#ddd'],
                    charStr = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
                    num;
                let str = makePy(this.userName.charAt(this.userName.length-1)),
                    strNum = charStr.indexOf(str) + 1;
                switch (true) {
                    case strNum > 0 && strNum <= 5:
                        num = 0;
                        break;
                    case strNum > 5 && strNum <= 10:
                        num = 1;
                        break;
                    case strNum > 10 && strNum <= 15:
                        num = 2;
                        break;
                    case strNum > 15 && strNum <= 18:
                        num = 3;
                        break;
                    case strNum > 18 && strNum <= 22:
                        num = 4;
                        break;
                    case strNum > 22 && strNum <= 26:
                        num = 5;
                        break;
                    default:
                        num = 6;
                }
                return {
                    backgroundColor: colorArr[num]
                }
            }
        }
    };

    function checkCh(ch) {
        let uni = ch.charCodeAt(0);
        //如果不在汉字处理范围之内,返回原字符,也可以调用自己的处理函数
        if (uni > 40869 || uni < 19968) return ch;
        //检查是否是多音字,是按多音字处理,不是就直接在strChineseFirstPY字符串中找对应的首字母
        return (oMultiDiff[uni] ? oMultiDiff[uni] : (strChineseFirstPY.charAt(uni - 19968)));
    }

    function makePy(str) {
        if (typeof(str) != "string") throw new Error(-1, "函数makePy需要字符串类型参数!");
        let firstStr = str.charAt(0),
            newStr = checkCh(firstStr);
        return newStr;
    }
</script>

<style lang="less" scoped>
    .el-dropdown-menu{
        position: absolute;
        top: 0;
        left: 0;
        z-index: 50!important;
        min-width: 66px;
        margin: 0;
        padding: 0;
        background-color: #fff;
        border: 1px solid #ddd;
        box-shadow: none;
        font-size: 12px;
        transform: translate(18px,13px);
        border-top: 1px solid #fff;
    }
    .el-dropdown-menu__item {
        line-height: 28px;
        text-align: center;
        > a {
            color:#555;
            text-decoration: none;
        }> a:hover {
             color:#fff;
         }
    }
    .el-dropdown-menu__item:hover {
        background-color: #049cff;
        color:#fff;
    }
</style>
