package cn.edu.dlut.career.service.company;


import cn.edu.dlut.career.domain.company.ApplicationProcessing;

import java.util.List;

/**
 * Created by wei on 2017/3/24.
 */
public interface ApplicationProcessingService {
  ApplicationProcessing save(ApplicationProcessing applicationProcessing);

  void delete(String id);

  ApplicationProcessing update(ApplicationProcessing applicationProcessing);

  List<ApplicationProcessing> findAll();

  ApplicationProcessing findOne(String id);
}
