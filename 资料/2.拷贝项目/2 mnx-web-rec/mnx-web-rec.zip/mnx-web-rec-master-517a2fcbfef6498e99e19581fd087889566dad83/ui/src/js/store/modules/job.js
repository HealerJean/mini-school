const state = {
    //过滤器状态obj
    jobQueryFormStatus:{},
    //jobList的容器
    jobListsStatus:{},
    //职位列表过滤器
    jobQueryForm:{
        name: '',
        type: '',
        region: [],
        department:'',
        beginDate: '',
        overDate: ''
    },
    activeJobTabName:'open',

    //tabNameCount
    tabNameCount: {
        open: 0,
        waiting: 0,
        notThrough: 0,
        onHold: 0
    },
    //招聘职位名称列表
    jobNameList:[]

//{
//    "content": [
//    {
//        "id": "92c87f1f-5b02-4edf-9593-a3a9c183f0a1",
//        "title": "jjj",
//        "description": "aaaaaaaaaaaaaaaaaaaaaa",
//        "status": "open",
//        "jobType": "full_time",
//        "headcount": 2,
//        "jobCategory": "IT/互联网/软件/通信-测试/QA-产品评测/质量分析",
//        "careerLevel": "硕士",
//        "jobArea": "库尔勒",
//        "department": {
//            "id": null,
//            "name": "sa"
//        },
//        "sarlary": {
//            "type": "month",
//            "start": 6000,
//            "end": 10000
//        },
//        "applyPeriod": {
//            "applyBeginDate": "20170307",
//            "applyEndDate": "20170430"
//        },
//        "audit": {
//            "status": "waiting",
//            "time": null,
//            "failReason": null
//        },
//        "applyUrl": "http://git.minixiao.com/mnx-web/mnx-web-rec/merge_requests/75",
//        "innerNo": "aa",
//        "createdOn": "20170312165953",
//        "updatedOn": "20170313093619",
//        "applicationNum": 0
//    },
//],
//    "totalElements": 6,
//    "number": 0,
//    "size": 20,
//}
};

const getters = {};

const actions = {};

const mutations = {
    //tabCountMinus减1
    tabCountMinus(state,val){
        console.log(val);
        state.tabNameCount[state.activeJobTabName] = val-1 ;
        console.log(state.tabNameCount);
    },

    //更换tabJobName
    changeActiveJobTabName(state,val){
        state.activeJobTabName = val ;
        //console.log(state.activeJobTabName);
        //console.log(state.jobQueryFormStatus);
    },

    //更换tabJobList
    changeActiveJobList(state,val){
        state.jobListsStatus[state.activeJobTabName] = val ;
        //console.log(state.activeJobTabName);
        //console.log(state.jobQueryFormStatus);
    },

    ////更改页码
    //changeJobPage(state,val){
    //    state.jobListPage[state.activeJobTabName] = val ;
    //    //console.log(state.jobQueryFormStatus);
    //},

    //更改过滤器输入值
    changeJobQueryVal(state,val){
        state.jobQueryFormStatus[state.activeJobTabName] = val ;
        //console.log(state.jobQueryFormStatus);
    },
    upDateJobNameList(state,val){
        state.jobNameList = val;
    }
};


export default {
    state,
    getters,
    actions,
    mutations
}
