package cn.edu.dlut.career.repository.company;


import cn.edu.dlut.career.domain.school.ConsultationArrangement;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

/**
 * Created by liang on 2017/3/30.
 */
public interface ConsultationArrangementRepository extends CrudRepository<ConsultationArrangement,String> {
    List<ConsultationArrangement> findAll();
}
