package com.minixiao.web.email;

import com.minixiao.web.dto.candidate.AppStageListDTO;
import com.minixiao.web.dto.candidate.UpdateStatusDTO;
import io.jstack.sendcloud4j.SendCloud;
import io.jstack.sendcloud4j.mail.Email;
import io.jstack.sendcloud4j.mail.Result;

import java.util.List;

/**
 * @Author wangyj.
 * @Date 2017/3/15  15:42.
 */
public class RefusedEventEmail {

    public static void refuesdEmail(List<AppStageListDTO> appStageListDTOs,String recName){

        //发送邮件账号密码
        String apiUser = "sendminixiaouser";
        String apiKey = "7d46vXYviEv4gHnB";
        for (AppStageListDTO dto:appStageListDTOs) {
            if (!"".equals(dto.getEmail())) {
                String emailContent = HtmlUtils.getRefuesdEmail(dto.getCandidateName(), recName);
                SendCloud webapi = SendCloud.createWebApi(apiUser, apiKey);
                Email email = Email.general()
                    .from("webadmin@minixiao.com")
                    .fromName("迷你校")
                    .html(emailContent)
                    .subject("不合适")
                    .to(dto.getEmail());
                Result resultSend = webapi.mail().send(email);
            }
        }
    }
}
