package cn.edu.dlut.career.service.company;


import cn.edu.dlut.career.domain.company.LargeSign;

import java.util.List;

/**
 * 大招签到 服务层 接口
 * Created by HealerJean on 2017/3/24.
 */
public interface LargeSignService {
    //保存，添加 YardOrder
    LargeSign saveLargeSign(LargeSign largeSign) ;

    //根据id查询
    LargeSign findById(String id);

    // 更新
    LargeSign updateLargeSign(LargeSign largeSign);

   //根据id删除 删除成功返回 ok ，否则 null
    String deleteLargeSign(String id);

    //查询所有的数据
    List<LargeSign> findAllLargeSign();
}
