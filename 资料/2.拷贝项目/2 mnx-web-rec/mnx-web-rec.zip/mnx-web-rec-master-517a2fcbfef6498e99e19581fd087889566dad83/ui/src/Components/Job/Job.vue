<template>
    <router-view></router-view>
</template>

<script type="text/babel">
    export default {
        name: 'job',
        data() {
            return {
            }
        }
    }
</script>
