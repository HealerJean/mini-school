<template>
    <div class="modify-department">
        <el-dialog title="修改部门名称"
            v-model="modifyDepartmentModelVisible"
            size="tiny"
            :close-on-click-modal="false"
            :close-on-press-escape="false"
            @close="closeModal">
            部门名称<el-input v-model="modifiedDepartmentName" class="department-name"></el-input>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" @click="modifyDepartment">确 定</el-button>
                <el-button @click="closeModal">取 消</el-button>
            </div>
        </el-dialog>


    </div>
</template>

<script type="text/babel">

    export default {
        name: 'modify-depart',
        data:function(){
            return{
                modifiedDepartmentName:this.departmentName
            }
        },
        computed: {
           modifyDepartmentModelVisible() {
                return this.isModifyDepartment;
            }
        },
        props:{
            isModifyDepartment: {
                type: Boolean,
                default: false
            },
            departmentName:{
                type:String,
                default:''
            }
        },

        methods: {
            closeModal() {
                this.$emit('closeModifyDepartment');
            },
            modifyDepartment() {
                this.$emit('modifyDepartment', this.modifiedDepartmentName);
                this.$emit('closeModifyDepartment');
            }

        }
    }
</script>

<style lang="less">
.modify-department{
    .department-name {
        width: 240px;
    }
    .el-dialog__header {
        text-align: center;
    }
    .el-dialog__body {
            text-align: center;
        }
}

</style>
