package cn.edu.dlut.career.repository.company;

import cn.edu.dlut.career.domain.company.LargePerson;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 大型招聘会企业代表人 数据访问层操作
 * Created by HealerJean on 2017/3/24.
 */
@Repository
public interface LargePersonRepository extends CrudRepository<LargePerson, String> {
    //根据id进行查找
    LargePerson findById(String id);
    //查找全部信息
    List<LargePerson> findAll();

}
