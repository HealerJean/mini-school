// initial file for passport
import Vue from 'vue';
import Guide from '../../Components/Shared/Guide.vue';
import ElementUI from 'element-ui';
import AppHeader from '../../Components/Shared/HeaderNoLogin.vue';
import AppFooter from '../../Components/Shared/FooterNoLogin.vue';
import VueResource from 'vue-resource';

// styles
import 'element-ui/lib/theme-default/index.css';
import 'less/shared/shared.less';
import 'less/reset/reset.less';
import 'less/mixins/mixins.less';
import 'less/shared/common.less';

import store from '../store';

Vue.use(ElementUI);
Vue.use(VueResource);

new Vue({
    components: {
        Guide,
        AppHeader,
        AppFooter
    },
    store
}).$mount('#app');
