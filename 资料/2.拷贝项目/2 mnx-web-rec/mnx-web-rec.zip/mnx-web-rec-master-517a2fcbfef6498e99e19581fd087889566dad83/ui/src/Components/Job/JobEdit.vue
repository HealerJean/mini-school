<template>
    <div class="add-job">
        <breadcrumb :breadcrumbs="breadcrumbs"></breadcrumb>
        <h1 class="title">编辑{{ disabledForm.name }}职位</h1>
        <div class="add-job-con input-size-lg">
            <el-form :model="addJobForm" ref="addJobForm" :rules="rules" label-width="100px">
                <el-row :gutter="20">
                    <el-col :span="10">
                        <el-form-item label="职位名称：">
                            <span>{{ disabledForm.name }}</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="10">
                        <el-form-item label="职位类别：" prop="jobCategory">
                            <span>{{ disabledForm.jobCategory }}</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="10">
                        <el-form-item label="内部编号：" prop="jobID">
                            <el-input v-model="addJobForm.jobID" placeholder="请输入内部编号"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="14">
                        <div class="form-add-tip">（内部编号可根据企业招聘规则进行自定义）</div>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="10">
                        <el-form-item label="所属部门：" prop="department">
                            <el-input
                                readonly
                                v-model="addJobForm.department"
                                placeholder="请选择所属部门"
                                icon="caret-bottom"
                                @focus="isSelectDepartment = true"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="14">

                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="10">
                        <el-form-item label="工作地区：">
                            <span>{{ disabledForm.place }}</span>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="10">
                        <el-form-item label="招聘人数：" prop="headcount" required>
                            <el-input-number v-model="addJobForm.headcount" :min="0"></el-input-number>
                        </el-form-item>
                    </el-col>
                    <el-col :span="14">
                        <div class="form-add-tip">（单位为(个)，必须为数字，若填0表示若干）</div>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="10">
                        <el-form-item label="网申日期：" required>
                            <el-col :span="11">
                                <el-form-item prop="beginDate">
                                    <el-date-picker
                                        v-model="addJobForm.beginDate"
                                        type="date"
                                        placeholder="选择网申开始日期"
                                        :picker-options="pickerBeginDate">
                                    </el-date-picker>
                                </el-form-item>
                            </el-col>
                            <el-col :span="2" style="text-align:center">-</el-col>
                            <el-col :span="11">
                                <el-form-item prop="endDate">
                                    <el-date-picker
                                        v-model="addJobForm.endDate"
                                        type="date"
                                        placeholder="选择网申结束时间"
                                        :picker-options="pickerEndDate">
                                    </el-date-picker>
                                </el-form-item>
                            </el-col>
                        </el-form-item>
                    </el-col>
                    <el-col :span="14">
                        <div class="form-add-tip">（网申日期过期后，将无法进行投递）</div>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="10">
                        <el-form-item label="薪酬范围：" prop="salary">
                            <el-select v-model="addJobForm.salary" clearable>
                                <el-option v-for="item in salaryRange"
                                           :label="item.label"
                                           :value="item.value"></el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="14">
                        <div class="form-add-tip">
                            <el-button type="primary" size="small" @click="openSalaryCustom">自定义</el-button>
                        </div>
                    </el-col>
                </el-row>
                <el-row :gutter="20" class="salary-custom-group" v-if="isSalaryCustom">
                    <el-col :span="10">
                        <el-form-item>
                            <div class="salary-custom-box">
                                <el-input v-model="salaryCustomMin" placeholder="最低薪资"
                                          :class="{'is-error':salaryMinError}" @blur="addSalaryCustom"></el-input>
                                <span class="salary-custom-error">{{ salaryMinStr }}</span>
                            </div>
                            <span>~</span>
                            <div class="salary-custom-box">
                                <el-input v-model="salaryCustomMax" placeholder="最高薪资"
                                          :class="{'is-error':salaryMaxError}" @blur="addSalaryCustom"></el-input>
                                <span class="salary-custom-error">{{ salaryMaxStr }}</span>
                            </div>
                        </el-form-item>
                    </el-col>
                    <el-col :span="14">
                        <div class="form-add-tip">（最高月薪不能大于最低月薪的2倍，当即选择下拉薪资梯度，又填写自定义薪资则，只展示自定义薪资）</div>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="10">
                        <el-form-item label="学历要求：" prop="education">
                            <el-select v-model="addJobForm.education" clearable>
                                <el-option v-for="item in education" :label="item.label"
                                           :value="item.value"></el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="14">
                        <div class="form-add-tip">及以上</div>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="17" class="relative">
                        <el-form-item label="职位描述：" prop="description">
                            <el-input type="textarea"
                                      v-model="addJobForm.description"
                                      :autosize="{ minRows: 10, maxRows: 20}"
                                      placeholder="请输入5000个汉字或单词以内的职位描述"
                                      @change="descriptionStrNum"
                            ></el-input>
                        </el-form-item>
                        <div class="form-add-tip description-tip">
                            <i class="el-icon-information"></i>
                            职位描述再次进行修改发布需要审核
                        </div>
                        <div class="description-num">
                            <span :class="{'is-error':descriptionNumError}">
                                {{ descriptionNum }}/5000
                            </span>
                        </div>
                    </el-col>
                </el-row>
                <el-row :gutter="20">
                    <el-col :span="10">
                        <el-form-item label="投递链接：" prop="link">
                            <el-input v-model="addJobForm.link"
                                      placeholder="请输入网址，如：http://www.minixiao.com"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="14">
                        <div class="form-add-tip">（<i class="el-icon-information"></i>职位描述再次进行修改发布需要审核）</div>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="24" class="btn-group-left-lg btn-size-lg">
                        <el-button type="primary" @click="onSubmit('addJobForm')">发布</el-button>
                        <el-button @click="cancleJobFrom">取消</el-button>
                    </el-col>
                </el-row>
            </el-form>
        </div>

        <select-one-department
            :isSelectDepartment="isSelectDepartment"
            @modal:select-department-closing="closeSelectDepartmentModal"
            @modal:select-department="makeSureSelectDepartment"></select-one-department>
        <publish-modal
            :isPublishModal="isPublishModal"
            @modal:publish-closing="closePublishModal"
            @modal:publish-confirm="submitJobEditFrom"></publish-modal>
    </div>
</template>

<script type="text/babel">
    import PublishModal from "../Modal/PublishModal.vue"
    import SelectOneDepartment from '../Modal/SelectOneDepartmentModal.vue';
    import Breadcrumb from "../Shared/Breadcrumb.vue"


    export default {
        name: 'edit',
        components: {
            SelectOneDepartment,
            PublishModal,
            Breadcrumb
        },
        data () {
            let personInt = (rule, value, callback) => {
                if (value === 0) {
                    callback();
                }else if(value === ''){
                    callback(new Error('招聘人数不能为空'));
                }else{
                    if (!Number.isInteger(value)) {
                        callback(new Error('请输入整数'));
                    }else{
                        callback();
                    }
                }
            };
            let urlRule = (rule, value, callback) => {
                let reg=/^(http:|https:)\/\/.+\..+/i;
                if(value && !reg.test(value)){
                    callback(new Error('请输入正确网址链接,格式如http://wwww.minixiao.com'));
                }else{
                    callback();
                }
            };
            return {
                pickerBeginDate: {
                    disabledDate: (time) => {
                        let endDateVal = this.addJobForm.endDate;
                        if (endDateVal) {
                            return time.getTime() > endDateVal;
                        }
                    }
                },
                pickerEndDate: {
                    disabledDate: (time) => {
                        let beginDateVal = this.addJobForm.beginDate;
                        if (beginDateVal) {
                            return time.getTime() < beginDateVal;
                        }
                    }
                },
                //弹出窗组件
                isChoosingJobType: false,
                isSelectingCity: false,
                isSelectDepartment: false,
                isPublishModal:false,
                cityMax:20,

                tempStr:{
                    description: '',
                    link: ''
                },

                //面包屑
                breadcrumbs: [
                    {'router': 'list', 'text': '职位管理'},
                    {'router': '', 'text': '编辑职位'}
                ],

                //自定义薪资
                isSalaryCustom: false,
                salaryCustomMin: '',
                salaryCustomMax: '',
                salaryMinError: false,
                salaryMaxError: false,
                salaryMinStr: '',
                salaryMaxStr: '',

                //职位描述字数限制
                descriptionNum: 0,
                descriptionNumError: false,

                salaryRange: [
                    {value: "0~0", label: "面谈"},
                    {value: "0~2000", label: "2000元以下"},
                    {value: "2000~3000", label: "2000~3000元"},
                    {value: "3000~6000", label: "3000~6000元"},
                    {value: "6000~10000", label: "6000~10000元"},
                    {value: "10000~15000", label: "10000~15000元"},
                    {value: "15000~25000", label: "15000~25000元"},
                    {value: "25000~50000", label: "25000~50000元"},
                    {value: "50000~0", label: "50000元以上"}
                ],
                education: [
                    {value: "不限", label: "不限"},
                    {value: "大专", label: "大专"},
                    {value: "本科", label: "本科"},
                    {value: "硕士", label: "硕士"},
                    {value: "博士", label: "博士"}
                ],

                disabledForm:{
                    name: '',
                    jobCategory:'',
                    place: ''
                },
                addJobForm: {
                    jobID: '',
                    department: '',
                    departmentId:'',
                    headcount: 0,
                    beginDate: '',
                    endDate: '',
                    salary: '',
                    education: '',
                    description: '',
                    link: ''
                },
                rules: {
                    jobID: [
                        {}
                    ],
                    department: [
                        {required: true, message: '请选择所属部门', trigger: 'change'}
                    ],
                    headcount:[
                        { validator: personInt, type: 'number', trigger: 'change' }
                    ],
                    beginDate: [
                        { type: 'date', required: true, message: '请选择网申开始日期', trigger: 'change' }
                    ],
                    endDate: [
                        { type: 'date', required: true, message: '请选择网申结束时间', trigger: 'change' }
                    ],
                    salary: [
                        {required: true, message: '请选择薪资范围', trigger: 'change'}
                    ],
                    education: [
                        {required: true, message: '请选择学历要求', trigger: 'change'}
                    ],
                    description: [
                        {required: true, message: '请填写职位描述', trigger: 'change'},
                        {max: 5000, message: '职位描述文字个数不能超过5000个', trigger: 'change'}
                    ],
                    link:[
                        { validator: urlRule, trigger: 'change' }
                    ]
                }
            }
        },
        watch: {},
        methods: {
            //获取职位编辑数据
            getJobEditData: function () {
                this.$http.get('/requisitions/'+this.$route.params.id).then(response => {
                    let newData = response.body;
                    console.log(newData);
                    let beginDateF=new Date(newData.applyPeriod.applyBeginDate.replace(/(\d{4})(\d{2})(\d{2})/, "$1-$2-$3"));
                    let endDateF=new Date(newData.applyPeriod.applyEndDate.replace(/(\d{4})(\d{2})(\d{2})/, "$1-$2-$3"));
                    this.disabledForm={
                        name: newData.title,
                        jobCategory:newData.jobCategory,
                        place: newData.jobArea
                    };
                    this.addJobForm = {
                        jobID: newData.innerNo,
                        department: newData.department.name,
                        departmentId:newData.department.id,
                        headcount: newData.headcount,
                        beginDate: beginDateF,
                        endDate: endDateF,
                        salary: newData.sarlary.start+'~'+newData.sarlary.end,
                        education: newData.careerLevel,
                        description: newData.description,
                        link: newData.applyUrl,
                    };
                    this.tempStr={
                        description: newData.description,
                        link:newData.applyUrl
                    };
                }, response => {
                    /* eslint-disable */
                    console.log('error');
                    /* eslint-disable */
                });
            },
            //当选tabName
            activeJobTabName(){
                return this.$store.state.job.activeJobTabName;
            },
            closeSelectDepartmentModal(){
                this.isSelectDepartment = false;
            },
            makeSureSelectDepartment(val1,val2){
                this.addJobForm.department = val1;
                this.addJobForm.departmentId = val2;
            },
            closePublishModal:function(){
                this.isPublishModal = false;
            },
            formatDate(date) {
                let newDate = '';
                if(date){
                    newDate = new Date(date);
                }else{
                    newDate = new Date();
                }
                let year = newDate.getFullYear(),
                    month = newDate.getMonth() >= 9 ? newDate.getMonth() + 1 : '0' + (newDate.getMonth() + 1),
                    day = newDate.getDate() >= 10 ? newDate.getDate() : '0' + newDate.getDate();
                return year + '-' + month + '-' + day
            },
            //提交编辑数据
            submitJobEditFrom:function(){
                let formData = {
                    innerNo: this.addJobForm.jobID,
                    department: {
                        name: this.addJobForm.department,
                        id:this.addJobForm.departmentId
                    },
                    headcount: this.addJobForm.headcount,
                    applyPeriod: {
                        applyBeginDate: this.formatDate(this.addJobForm.beginDate),
                        applyEndDate: this.formatDate(this.addJobForm.endDate)
                    },
                    sarlary: {
                        type: 'month',
                        start: this.addJobForm.salary.split('~')[0],
                        end: parseInt(this.addJobForm.salary.split('~')[1]).toString()
                    },
                    careerLevel: this.addJobForm.education,
                    description: this.addJobForm.description,
                    applyUrl: this.addJobForm.link
                };
                /* eslint-disable */
                console.log(formData);
                /* eslint-disable */
                let self=this;
                self.$http.put('/requisitions/'+this.$route.params.id, formData).then(response => {
                    self.$store.commit('changeActiveJobTabName', 'waiting');
                }, response => {
                    /* eslint-disable */
                    console.log('error');
                    /* eslint-disable */
                });
                this.$router.push({ path: '/job'})

            },
            cancleJobFrom:function(){
                //this.$router.push({ path: '/job'})
                this.$router.go(-1);
            },
            //自定义薪资
            addSalaryCustom(){
                let minNum = parseInt(this.salaryCustomMin),
                    maxNum = parseInt(this.salaryCustomMax);
                if (minNum && maxNum) {
                    if (minNum >= maxNum) {
                        this.salaryMinError = true;
                        this.salaryMinStr = "不能大于等于最高月薪";
                        this.salaryMaxError = false;
                        this.salaryMaxStr = "";
                    } else if (maxNum > minNum * 2) {
                        this.salaryMaxError = true;
                        this.salaryMaxStr = "不能大于最低月薪的2倍";
                        this.salaryMinError = false;
                        this.salaryMinStr = "";
                    } else {
                        this.addJobForm.salary = minNum + '~' + maxNum + '元';
                        this.isSalaryCustom = false;
                        this.salaryMinError = false;
                        this.salaryMaxError = false;
                        this.salaryMinStr = '';
                        this.salaryMaxStr = '';
                    }
                }
            },
            openSalaryCustom() {
                this.isSalaryCustom = !this.isSalaryCustom;
                this.salaryCustomMin = '';
                this.salaryCustomMax = '';
            },

            //职位描述字数提示
            descriptionStrNum(){
                this.descriptionNum = this.addJobForm.description.length;

                if (this.descriptionNum > 5000) {
                    this.descriptionNumError = true;
                } else {
                    this.descriptionNumError = false;
                }
            },

            onSubmit(formName) {
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        if(this.addJobForm.description == this.tempStr.description && this.addJobForm.link == this.tempStr.link){
                            let formData = {
                                innerNo: this.addJobForm.jobID,
                                department: {
                                    name: this.addJobForm.department,
                                    id: this.addJobForm.departmentId
                                },
                                headcount: this.addJobForm.headcount,
                                applyPeriod: {
                                    applyBeginDate: this.formatDate(this.addJobForm.beginDate),
                                    applyEndDate: this.formatDate(this.addJobForm.endDate)
                                },
                                sarlary: {
                                    type: 'month',
                                    start: this.addJobForm.salary.split('~')[0],
                                    end: parseInt(this.addJobForm.salary.split('~')[1]).toString()
                                },
                                careerLevel: this.addJobForm.education,
                                description: this.addJobForm.description,
                                applyUrl: this.addJobForm.link
                            };
                            this.$http.put('/requisitions/'+this.$route.params.id, formData).then(response => {
                                console.log('提交修改成功');
                                this.$router.go(-1);
                            }, response => {
                                /* eslint-disable */
                                console.log('error');
                                /* eslint-disable */
                            });
                        }else{
                            this.isPublishModal = true;
                        }

                    } else {
                        return false;
                    }
                });
            },
            //submitForm(formName) {
            //    this.$refs[formName].validate((valid) => {
            //        if (valid) {
            //            alert('submit!');
            //        } else {
            //            console.log('error submit!!');
            //            return false;
            //        }
            //    });
            //},
            //resetForm(formName) {
            //    this.$refs[formName].resetFields();
            //}
        },
        mounted() {
            this.getJobEditData();
        }
    }
</script>

<style lang="less">
    @import "../../less/shared/variables.less";

    .add-job {
        .title {
            margin: 0;
            padding: 0 20px;
            font-size: @size-xxlg;
            line-height: 50px;
            font-weight: 400;
            color: extract(@gray-group, 1);
            border-bottom: @border-gray;
            background-color: @white;
        }
    }

    .add-job-con {
        margin: 0 0 40px;
        padding: 20px 20px 50px;
        background-color: @white;
        .el-form-item {
            margin-bottom: 10px;
        }
        .el-form-item.is-required .el-form-item__label:before {
            color: @error-color;
            position: absolute;
            left: 0;
            top: 13px;
        }
        .el-input-number {
            width: 100%;
            overflow: initial;
        }
        .el-input-number__decrease, .el-input-number__increase {
            line-height: 32px;
        }
        .el-form-item.is-error + .description-tip {
            margin: 12px 0 0;
        }
        .el-textarea {
            width: 100%;
        }
    }

    .form-add-tip {
        line-height: 34px;
        color: extract(@gray-group, 7);
        & > i {
            margin-right: 5px;
        }
        &.description-tip {
            padding-left: 100px;
            margin: -10px 0 0;
        }
    }

    .description-num {
        position: absolute;
        right: 0;
        top: 100%;
        color: extract(@gray-group, 7);
        transform: translateY(-25px);
    }

    .description-num {
        .is-error {
            color: @error-color;
        }
    }

    .salary-custom-group {
        .el-input {
            width: 100%;
        }
        span {
            float: left;
            padding: 0 6px 0 5px;
        }
        .salary-custom-box {
            float: left;
            position: relative;
            width: 47%;
            .salary-custom-error {
                display: none;
                color: #ff4949;
                font-size: 12px;
                line-height: 1;
                padding-top: 4px;
                position: absolute;
                top: 100%;
                left: 0;
            }

            .is-error {
                .el-input__inner {
                    border-color: #ff4949;
                }
                & + .salary-custom-error {
                    display: block;
                }
            }
        }
    }

    .btn-group-left-lg {
        padding-top: 18px;
        padding-left: 100px;
    }
</style>

