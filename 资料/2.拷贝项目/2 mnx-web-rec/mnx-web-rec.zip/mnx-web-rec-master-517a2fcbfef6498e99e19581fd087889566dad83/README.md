# mnx-web-rec
迷你校企业端WEB项目，使用spring boot重构。

## 技术栈
### 前端技术栈
- [vuejs](http://vuejs.org)
- [vuex]()
- [vue-router]()
- [webpack]()

### 后端技术栈
- [SpringBoot](http://projects.spring.io/spring-boot/)
- [Thymeleaf](http://www.thymeleaf.org/)
- [logback](http://)

## 相关标准规范
- [设计标准](docs/standard-design.md)
- [Java代码编写规范](docs/standard-java.md)
- [JavaScript代码编写规范](docs/standard-javascript.md)
- [数据库设计规范](docs/standard-db-design.md)

## 相关业务领域模型
- [职位需求](docs/Domain-JobRequisition.md)
- [招聘单位](#)
- [候选人](#)

## 前端路由结构
- [路由整理文档](docs/router-ui-doc.md)

## 运行方式

### 开发环境
开发过程中可以直接使用gradle编译并直接运行：

``` shell
gradle bootRun
```
当 Spring-Boot 启动成功之后，在浏览器中输入 `http://localhost:8080` 即可访问。

### 生产环境
需要先将程序打包成jar文件：
``` shell
gradle build
```
然后直接使用java环境运行：
```shell
java -jar mnx-web-rec.jar
```
