<template>
    <el-dialog title="选择城市"
               v-model="selectCityModalVisible"
               size="small"
               :close-on-click-modal="false"
               :close-on-press-escape="false"
               @close="closeModal">
        <div class="container-city-selection">
            <div class="city-selection-header">
                <h4 class="city-selection-title">最多选择{{max}}项</h4>
                <div class="city-selected-body">
                    <template v-for="(city,index) in selectedCities">
                        <span class="selected-city" @click="delCity(index)">{{ city }}</span>
                    </template>
                </div>
            </div>
            <div class="city-selection-body">
                <h4 class="title-city-type">热门城市</h4>
                <el-checkbox-group v-model="selectedCities">
                    <el-checkbox
                        v-for="city in cityDefault.hot"
                        :label="city"
                        :disabled="selectedCities.length >= max && !selectedCities.includes(city)">
                        {{ city }}
                    </el-checkbox>
                </el-checkbox-group>
                <h4 class="title-city-type">全国各省<span class="title-city-type-sm">（按首字母排序）</span></h4>
                <ul class="province-list">
                    <li v-if="typeof item.name === 'string'"
                        v-for="item in cityDefault.provinces">
                        <div class="province-wrap">
                            <span class="province-name">{{ item.name }}</span>
                            <div class="province-box">
                                <el-checkbox-group v-model="selectedCities">
                                    <el-checkbox
                                        :label="city"
                                        v-for="city in item.citys"
                                        :disabled="selectedCities.length >= max && !selectedCities.includes(city)">
                                        {{ city }}
                                    </el-checkbox>
                                </el-checkbox-group>
                            </div>
                        </div>
                    </li>
                </ul>
                <h4 class="title-city-type">港澳台</h4>
                <el-checkbox-group v-model="selectedCities">
                    <el-checkbox
                        v-for="city in cityDefault.abroad"
                        :label="city"
                        :disabled="selectedCities.length >= max && !selectedCities.includes(city)">
                        {{ city }}
                    </el-checkbox>
                </el-checkbox-group>
            </div>
        </div>
        <div slot="footer" class="dialog-footer btn-size-md">
            <el-button type="primary" @click="modalConfirm">确定</el-button>
            <el-button @click="closeModal" :plain="true">取消</el-button>
        </div>
    </el-dialog>
</template>

<script type="text/babel">
    export default {
        name: 'select-city-modal',

        data() {
            return {
                selectedCities: [],
                cityDefault:{
                    hot:'',
                    provinces:'',
                    abroad:''
                }
            };
        },

        computed: {
            selectCityModalVisible() {
                return this.isSelectingCity
            }
        },

        props: {
            isSelectingCity: {
                type: Boolean,
                default: false
            },
            max: {
                type:Number,
                default:1
            },
            cityData: {
                type: Object,
                default() {
                    return {
                    };
                }
            }
        },

        methods: {
            closeModal() {
                this.$emit('modal:select-city-closing');
            },
            modalConfirm() {
                this.$emit(
                    'modal:emit-selected-cities',
                    this.selectedCities
                );
                this.$emit('modal:select-city-closing');
            },
            delCity:function(index){
                this.selectedCities.splice(index,1);
            }
        },
        mounted(){
            this.$http.get('../static/json/city.json').then(response => {
            //this.$http.jsonp('http://www.minixiao.com/st/json/city.json').then(response => {
                let newData = response.body;
                this.cityDefault = newData;
            }, response => {
                /* eslint-disable */
                console.log('error');
                /* eslint-disable */
            });
        }
    }


</script>

<style lang="less" scoped>

    @import "../../less/shared/variables";

    .container-city-selection {
        line-height: 24px;
        .city-selection-header{
            min-height:32px;
            margin-bottom:2px;
        }
        .city-selection-title {
            margin:0;
            font-weight: 400;
            float: left;
        }
        .city-selected-body {
            margin-left: 90px;
            .selected-city {
                display: inline-block;
                margin-right:6px;
                margin-bottom:8px;
                padding: 0 10px;
                color: @white;
                background: @primary-color;
                border-radius: 24px;
                height:24px;
                cursor:pointer;
            }
        }

        .city-selection-body {
            padding: 20px;
            background: @background-color-base;
            border:1px solid #ddd;
            box-sizing: border-box;
            width:100%;
            .title-city-type {
                margin: 16px 0 10px;
                font-weight:600;
                &:first-child{
                    margin: 0 0 10px;
                }

            }
            .title-city-type-sm{
                font-size: @size-sm;
                color:extract(@gray-group,5);
            }
            .el-checkbox{
                width:96px;
            }

            .province-box{
                .el-checkbox{
                    width: 85px;
                }
            }
            .province-list{
                &>li:nth-child(5n-1),
                &>li:nth-child(5n){
                    .province-box{
                        .el-checkbox{
                            text-align: right;
                        }
                    }
                }
            }
        }
    }



</style>

<style lang="less">

    @import "../../less/shared/variables";

    .container-city-selection {
        .city-selection-body {
            .el-checkbox {
                margin: 0;
                color:extract(@gray-group,3);
                .el-checkbox__input {
                    display: none;
                }
                .el-checkbox__label {
                    display: inline-block;
                    height: 24px;
                    margin: 0 0 4px 0;
                    padding: 0 10px;
                    line-height: 24px;
                    background: transparent;
                    box-sizing: border-box;
                    white-space: nowrap;
                    &:hover{
                        background-color:extract(@gray-group,11);
                    }
                }

                .is-checked + .el-checkbox__label {
                    background-color: @primary-color;
                    color: @white;
                }
            }
            .el-checkbox__input.is-disabled+.el-checkbox__label{
                color:extract(@gray-group,3);
            }
        }
        .province-list{
            margin: 0;
            padding: 0;
            &>li{
                width: 90px;
                display: inline-block;
                margin: 0 0 4px 0;
                position: relative;
                box-sizing: border-box;
                cursor:pointer;
            }
            &>li:nth-child(5n-1),
            &>li:nth-child(5n){
                .province-box{
                    right: 0;
                    left:auto;
                }
            }
            &>li.is-disabled{
                color:#bbb;
                cursor:pointer;
                .province-box{
                    display:none;
                }
            }
        }
        .province-wrap{
            display:inline-block;
            position: relative;
        }
        .province-name{
            display:inline-block;
            padding:0 10px;
            border:1px solid extract(@gray-group,12);
            background-color:extract(@gray-group,12);
            box-sizing: border-box;
            position: relative;
            z-index: 3;
        }
        .province-box{
            display:none;
            position:absolute;
            left: 0;
            top: 25px;
            z-index: 2;
            border: @border-gray;
            padding: 10px 10px 6px 10px;
            background-color: extract(@gray-group,13);
            .el-checkbox-group{
                width:340px;
            }
        }
        .province-wrap:hover{
            z-index: 10;
            .province-name{
                border-color:extract(@gray-group,9);
                border-bottom-color:extract(@gray-group,13);
                background-color: extract(@gray-group,13);
            }
            .province-box{
                display:block;
            }
        }
    }



</style>
