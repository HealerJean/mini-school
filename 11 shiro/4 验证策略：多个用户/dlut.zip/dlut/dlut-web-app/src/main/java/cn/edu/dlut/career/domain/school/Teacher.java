package cn.edu.dlut.career.domain.school;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

/**
 * Created by wei on 2017/4/5.
 */
@Entity
@Table(name = "teacher")
public class Teacher {
    //编号，主键UUID
    @Id
    @GenericGenerator(name = "idGenerator", strategy = "uuid")
    @GeneratedValue(generator = "idGenerator")
    private String id;

    //教师姓名
    @Column(length = 20,nullable = false)
    private String name;

    //所在院系/部门编号
    @Column(length = 20,nullable = false)
    private String department_id;

    //所在院系/部门
    @Column(length = 30,nullable = false)
    private String department;

    //用户名
    @Column(length = 50,nullable = false)
    private String username;

    //密码
    @Column(length = 30,nullable = false)
    private String pwd;

    //电子邮件
    @Column(length = 20,nullable = false)
    private String email;
    // 联系电话
    @Column(length = 20,nullable = false)
    private String tel;

    // 是否是管理员
    @Column(length = 1,nullable = false)
    private String isAdmin;

    // 是否冻结
    @Column(length = 1,nullable = false)
    private String isFrozen;

    // 创建时间
    @Column(nullable = false)
    private String createOn;

    // 最后修改时间
    @Column(nullable = true)
    private String lastUpdateTime;

    // 最后登陆时间
    @Column(nullable = true)
    private String lastLoginTime;

    // 功能模块
    @Column(nullable = true)
    private String functionalModule;

    // 权限级别
    @Column(nullable = true)
    private String jurisdiction;

    public Teacher() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDepartment_id() {
        return department_id;
    }

    public void setDepartment_id(String department_id) {
        this.department_id = department_id;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getIsAdmin() {
        return isAdmin;
    }

    public void setIsAdmin(String isAdmin) {
        this.isAdmin = isAdmin;
    }

    public String getIsFrozen() {
        return isFrozen;
    }

    public void setIsFrozen(String isFrozen) {
        this.isFrozen = isFrozen;
    }

    public String getCreateOn() {
        return createOn;
    }

    public void setCreateOn(String createOn) {
        this.createOn = createOn;
    }

    public String getLastUpdateTime() {
        return lastUpdateTime;
    }

    public void setLastUpdateTime(String lastUpdateTime) {
        this.lastUpdateTime = lastUpdateTime;
    }

    public String getLastLoginTime() {
        return lastLoginTime;
    }

    public void setLastLoginTime(String lastLoginTime) {
        this.lastLoginTime = lastLoginTime;
    }

    public String getFunctionalModule() {
        return functionalModule;
    }

    public void setFunctionalModule(String functionalModule) {
        this.functionalModule = functionalModule;
    }

    public String getJurisdiction() {
        return jurisdiction;
    }

    public void setJurisdiction(String jurisdiction) {
        this.jurisdiction = jurisdiction;
    }
}
