<template>
    <div class="create-department">
        <el-dialog title="创建部门"
            v-model="createDepartmentModelVisible"
            size="tiny"
            :close-on-click-modal="false"
            :close-on-press-escape="false"
            @close="closeModal">
            部门名称<el-input v-model="departmentName" class="department-name"></el-input>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" @click="createDepartment">确 定</el-button>
                <el-button @click="closeModal">取 消</el-button>
            </div>
        </el-dialog>


    </div>
</template>

<script type="text/babel">

    export default {
        name: 'creat-depart',
        data:function(){
            return{
               departmentName:"",
            }
        },
        computed: {
           createDepartmentModelVisible() {
                return this.isCreateDepartment;
            }
        },
        props:{
            isCreateDepartment: {
                type: Boolean,
                default: false

            }
        },

        methods: {
            closeModal() {
                this.$emit('closeCreateDepartment');
            },
            createDepartment() {
                this.$emit('createDepartment', this.departmentName);
                this.$emit('closeCreateDepartment');
            }

        }
    }
</script>

<style lang="less">
.create-department{
    .department-name {
        width: 240px;
    }
    .el-dialog__header {
        text-align: center;
    }
    .el-dialog__body {
            text-align: center;
        }
}

</style>
