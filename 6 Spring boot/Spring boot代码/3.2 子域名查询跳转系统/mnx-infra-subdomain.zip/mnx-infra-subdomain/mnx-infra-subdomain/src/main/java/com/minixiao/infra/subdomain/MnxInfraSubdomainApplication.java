package com.minixiao.infra.subdomain;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MnxInfraSubdomainApplication {

	public static void main(String[] args) {
		SpringApplication.run(MnxInfraSubdomainApplication.class, args);
	}
}
