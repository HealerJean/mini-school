// routers for settings
import Account from '../../Components/Setting/Account.vue';
import Company from '../../Components/Setting/Company.vue';
import Department from '../../Components/Setting/Department.vue';
import Workflow from '../../Components/Setting/Workflow.vue';
import Users from '../../Components/Setting/Users.vue';
import UsersList from '../../Components/Setting/UsersList.vue';
import UsersAdd from '../../Components/Setting/UsersAdd.vue';
import UsersEdit from '../../Components/Setting/UsersEdit.vue';
import Filter from '../../Components/Setting/Filter.vue';
import Tags from '../../Components/Setting/Tags.vue';
import Infro from '../../Components/Setting/Infro.vue';


export default [{
    path: '',
    redirect: 'account'
}, {
    path: 'account',
    component: Account
}, {
    path: 'company',
    component: Company
}, {
    path: 'department',
    component: Department
}, {
    path: 'workflow',
    component: Workflow
}, {
    path: 'users',
    component: Users,
    children: [{
        path: '',
        redirect: 'list'
    }, {
        path: 'list',
        component: UsersList
    }, {
        path: 'add',
        component: UsersAdd
    }, {
        path: 'edit/:id',
        component: UsersEdit
    }]
},{
    path: 'filter',
    component: Filter
},{
    path: 'tags',
    component: Tags
},{
    path: 'infro',
    component: Infro
}];
