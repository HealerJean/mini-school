<template>
    <el-dialog title="修改网申时间"
               v-model="changeTimeModalVisible"
               size="tiny"
               :close-on-click-modal="false"
               :close-on-press-escape="false"
               @close="closeModal">
        <div class="change-time-main">
            <span class="change-time-label">网申时间</span>
            <el-date-picker
                range-separator="至"
                v-model="changedTime"
                type="daterange"
                placeholder="修改网申时间范围"
                :editable="false">
            </el-date-picker>
            <p class="change-time-tip">注意：到达网申日期如果职位已通过审核将自动上线</p>
        </div>
        <div slot="footer" class="dialog-footer">
            <el-button type="primary" @click="modalConfirm">确定</el-button>
            <el-button @click="closeModal">取消</el-button>
        </div>
    </el-dialog>
</template>

<script type="text/babel">
    //import eventBus from '../../js/shared/eventBus';
    export default {
        name: 'change-time-modal',
        data() {
            return {
                changedTime: ""
            };
        },
        computed: {
            changeTimeModalVisible() {
                return this.isChangeTime;
            }
        },
        props: {
            isChangeTime: {
                type: Boolean,
                default: false
            }
        },
        methods: {
            closeModal() {
                this.$emit('modal:change-time-closing');
            },
            modalConfirm() {
                this.$emit('modal:emit-change-time', this.changedTime);
                this.$emit('modal:change-time-closing');
                this.changedTime = '';
            }
        }
    }

</script>

<style lang="less" scoped>

    @import "../../less/shared/variables";

    .change-time-main{
        display:inline-block;
        text-align: left;
    }
    .change-time-label{
        margin-right:10px;
        font-size:@size-lg;
        float: left;
        line-height: 36px;
    }
    .change-time-tip{
        margin-top:18px;
        margin-bottom:0;
        font-size:@size-sm;
        color:@highlight-color;
    }


</style>
