# 迷你校管理系统

## 前端项目的安装与构建

### 0、安装环境依赖

前端构建系统依赖 [JavaScript 运行环境 Node.js](nodejs.org)（v6.9.x） 和
[包管理工具 npm](https://npmjs.com/) （v3.x.x），可以到
[这里](https://nodejs.org/en/download/) 下载安装包。

### 1、配置运行环境

程序会自动根据不同的运行环境，进行不同的逻辑，比如在生产环境会进行 uglify、在开
发环境会进行 lint 等。所以我们需要预先配置运行环境。

在 `build` 文件夹中有 `.env.{{environment}}` 文件，分别用于配置运行环境的环境变
量，在初始化项目时，可以使用 `ln` 命令来指定运行环境的配置文件，比如指定当前环境
为本地环境：

```shell
cd build
ln -sf .env.dev .env
```

### 2、安装项目依赖

在项目根目录下使用如下命令来进行安装：

```shell
npm install
```

### 3、构建静态资源

我们使用 [webpack](https://webpack.github.io/docs/) 来编写构建系统，你可以通过执
行如下命令进行构建：

```shell
npm run build
```

该命令会自动根据 `.env` 配置执行不同的逻辑。

如果希望在每次修改代码并保存之后，构建系统能自动再次构建，可以使用 `-w` 参数：

```shell
npm run build -- -w
```

### 4、代码规范检查

我们在构建系统中加入了 [ESLint](http://eslint.org/)，它会在每次进行构建时——也
就是上面第 3 步——预先进行一次检查，不符合团队规范的将不能进行构建。

如果你希望手动进行检查，可以使用：

```shell
npm run lint
```

如果需要修改团队规范，可以对 `.eslintrc.js` 进行修改，配置详情请查阅 ESLint 的文
档：

- [ESLint Documentation](http://eslint.org)
- [ESLint 中文文档](http://eslint.cn/)

### 5、编辑器配置

我们使用了 `.eidtorconfig` 来适应我们的规范，这样我们就可以让编辑器自动读取该项
目的规范，让我们可以非常方便地在多个项目之间切换。可以在
[editorconfig 官网](http://editorconfig.org/) 下载到主流编辑器能够读取该配置文件
的插件。点击直接打开 [插件下载页](http://editorconfig.org/#download)。

## Alias

我们在构建系统中添加了一些 alias，这可以让我们在 `import` 时有一个更简洁的路径：

- src: `${FRONT_END_ROOT}/src`
- js: `${FRONT_END_ROOT}/src/js`
- less: `${FRONT_END_ROOT}/src/less`
- img: `${FRONT_END_ROOT}/src/img`
- Components: `${FRONT_END_ROOT}/src/Components`

## 添加入口

默认只提供 `app.html` 和 `mobile.html` 以及它们的 `.js` 文件作为入口。最终它们会
根据 `.env.{environment}` 中的配置项把最终编译结果放到配置的地方。

如果需要添加其它入口：

- 添加 JS 入口文件：可以在 `webpack.config.js` 中的 `entry` 配置项中
- 添加 HTML 入口页面：可以在 `webpack.config.js` 中的 `plugins` 中的
`HtmlPlugin` 插件中添加。

相关文档：

- Webpack 文档：http://webpack.github.io/docs/
- Multiple Entry points：http://webpack.github.io/docs/multiple-entry-points.html
- html-webpack-plugin：https://www.npmjs.com/package/html-webpack-plugin
