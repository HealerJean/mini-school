<template>
    <div class="modify-department">
        <el-dialog title="邮件模板消息"
            v-model="createEmailModelVisible"
            size="large"
            :close-on-click-modal="false"
            :close-on-press-escape="false"
            @close="closeModal">


            <el-row >
                <el-col :span="6">模板名称:</el-col>
                <el-col :span="18"><el-input v-model="name"></el-input></el-col>
            </el-row>
            <el-row >
                <el-col :span="6">邮件标题:</el-col>
                <el-col :span="18"><el-input v-model="title"></el-input></el-col>
            </el-row>
            <el-row >
                <el-col :span="6">邮件内容:</el-col>
                <el-col :span="18">
                    <div>
                        可插入：<el-button type="text" @click="insertName">&lt;申请者姓名&gt;</el-button><el-button type="text" @click="insertJob">&lt;申请职位名称&gt;</el-button>
                    </div>
                    <el-input v-model="content" type="textarea" :rows="6" placeholder="">
                    </el-input>
                </el-col>
            </el-row>





            <div slot="footer" class="dialog-footer">
                <el-button type="primary" @click="createEmail">保 存</el-button>
                <el-button @click="closeModal">取 消</el-button>
            </div>
        </el-dialog>


    </div>
</template>

<script type="text/babel">

    export default {
        name: 'email-template',
        data:function(){
            return{
                name:'',
                title:'',
                content:''
            }
        },
        computed: {
            userId(){
                return this.$store.getters.userId
            },
            userName(){
                return this.$store.getters.userName
            },
            recId(){
                return this.$store.getters.recId
            },
            createEmailModelVisible() {
                return this.iscreateEmail;
            },
            emailTemplate(){
                return {
                    name:this.name,
                    title: this.title,
                    content: this.content,
                    type: "email"
                }
            },
            id(){
                return this.modifyingId
            }
        },
        props:{
            iscreateEmail: {
                type: Boolean,
                default: false
            },
            modifyingId: {
                type: String,
                default: ''
            }

        },
        watch: {
            id(){
                this.getTemplateById();
            }
        },
        methods: {
            insertName() {
                this.content = this.content + '%candidateName%'
            },
            insertJob() {
                this.content = this.content + '%jobName%'
            },
            closeModal() {
                this.$emit('closecreateEmail');
            },
            createEmail() {
                this.$emit('createEmail',this.emailTemplate );
                this.$emit('closecreateEmail');
            },
            //获取模板详细信息
            getTemplateById() {
                if(this.id){
                    console.log('获取邮件模板详细信息')
                    this.$http.get('company/template/email/'+this.id).then(response =>{
                        let a = response.body;
                        console.log(a);
                        //存到状态库中
                        this.name = a.name;
                        this.title = a.title;
                        this.content = a.content;
                    })
                }
            }

        }
    }
</script>

<style lang="less">
.modify-department{
    .el-inpute {
        width: 240px;
    }
    .el-dialog__header {
        text-align: center;
    }
    .el-dialog__body {
            text-align: center;
        }
}

</style>
