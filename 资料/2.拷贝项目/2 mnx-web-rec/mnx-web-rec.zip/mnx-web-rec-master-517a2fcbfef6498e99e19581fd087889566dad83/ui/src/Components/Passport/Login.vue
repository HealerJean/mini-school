
<template>
    <div class="login-content">
        <el-carousel height="600px">
            <el-carousel-item v-for="item in banner">
                <img v-bind:src="item">
            </el-carousel-item>
        </el-carousel>
        <div class="cp-login-box">
            <a href="" class="company-entry">
                <div class="trapezoid"></div>
                <div class="tra-txt text-right">
                    学生入口<i class="login-arrow"></i>
                </div>
            </a>
            <h2 class="cp-login-tit">企业HR登录</h2>
            <div class="cp-login-con" id="login">
                <el-form :model="userForm" ref="userForm" :rules="rules">
		            <el-form-item class="form-group cpL-user" prop="username">
                        <el-input
                                placeholder="请输入登录账号"
                                autocomplete="off"
                                v-model="userForm.username"
                            ></el-input>
                    </el-form-item>
                    <el-form-item class="form-group cpL-password" prop="password">
		                <el-input
                            type="password"
                            autocomplete="off"
                            placeholder="请输入密码"
                            v-model="userForm.password"
                        >
                        </el-input>
                    </el-form-item>
		            <div class="text-right forgetP">
		                <a href="/forgetPwd/step1">忘记密码？</a>
		            </div>
		            <div class="form-group">
		                <el-button type="primary" @click="doLogin('userForm')" class="btn register-btn">登录</el-button>
		            </div>
		        </el-form>
                <div class="cp-login-bottom">
                    <div class="cp-login-bp pull-left">尚无帐号</div>
                    <div class="pull-left bottom-group">
                         <button
                            type="button"
                            class="btn btn-orange btn-block"
                            role="button"
                            id="toRegister"
                            onclick="window.location.href='/register.html'"
                        >立即开通，免费做校招 ></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script type="text/babel">

import ajaxRequest from '../../js/shared/ajaxRequest';
export default {
        name: 'login',
        data () {
            return {
                banner: ['http://passport.minixiao.com/static/img/login/qy-banner.png', 'http://passport.minixiao.com/static/img/login/qy-banner2.png'],
                userForm: {
                  username: '',
                  password: '',
                },
                rules: {
                  username: [
                    { required: true, message: '请输入用户名', trigger: 'blur' },
                    { type: 'email', message: '请输入正确的用户名', trigger: 'blur' }
                  ],
                  password: [
                    { required: true, message: '请输入密码', trigger: 'blur' },
                    { min: 6, max: 18, message: '长度在 6 到 18 个字符', trigger: 'blur' }
                  ]
                }
          }
        },
        watch: {},
        methods: {
            doLogin(formName) {
            this.$refs[formName].validate((valid) => {
                if (valid) {
                    var vm = this;
                    this.$http({
                            method: 'POST',
                            url: '/doLogin?username='+ vm.userForm.username +'&password='+ vm.userForm.password +'',
                            headers: {'Content-Type':'application/json'},
                            emulateJSON: false
                        }).then(function (data) {//es5写法
                            const res = data.body;
                            if (res == "success") {
                                window.location.href = '/index.html';
                            } else if (res == "userError") {
                                alert("账号不存在，请输入正确的账号");
                                new Error("账号不存在，请输入正确的账号");
                            } else if (res == "pwdError") {
                                alert("密码不正确");
                                new Error("密码不正确");
                            } else if (res == "error") {
                                alert("用户名或密码不正确，请重新输入");
                                new Error("用户名或密码不正确，请重新输入");
                            }
                        }, function (error) {
                            //error
                            console.log(error);
                        })
                }
            });
            }
        }
    }
</script>


<style lang="less" scoped>
    .el-carousel__item img {
        color: #475669;
        font-size: 18px;
        opacity: 0.75;
        line-height: 600px;
        margin: 0;
        width: 100%;
    }
    .el-carousel__item:nth-child(2n) {
        background-color: #99a9bf;
    }
    .el-carousel__item:nth-child(2n+1) {
        background-color: #d3dce6;
    }
    /*company-login*/
    a:link {
        text-decoration: none;
    }
    a:visited {
        text-decoration: none;
    }
    .register-btn {
        border-radius: 3px;
        outline: 0 !important;
        height: 50px;
	    font-size: 16px;
        color: #fff;
        background-color: #049cff;
        border-color: #049cff;
        width: 100%;
        border: 1px solid transparent;
        cursor: pointer;
    }
    .cp-login-nav {
        height:80px; margin-top:0;
    }
    .cp-login-nav li {
            float: right;
            margin-left: 15px;
        }
     .cp-login-nav   i {
            display: inline-block;
            height: 16px;
            background: url("../../img/common/cp-login-icon.png") no-repeat;
            margin-right: 5px;
            margin-bottom: -2px;
        }
      .cp-login-nav  .cpL-tel {
            width: 18px;
            background-position: -3px 0;
        }
       .cp-login-nav .cpL-email {
            width: 19px;
            background-position: -32px 0;
        }
    .cp-login-nav .cpL-wx {
        width: 18px;
        background-position: -60px 0;
    }
    .cpL-ewm {
        position: relative;
        cursor: pointer;
    }

    .cpL-ewm a, .cpL-ewm a:hover {
        color: #666;
    }
    .cpL-ewm a img {
        position: absolute;
        top: 53px;
        left: -12px;
        z-index: 1000;
        display: none;
    }
    .cpL-ewm a:hover img {
        display: block;
    }
    .cpL-qz {
        position: relative;
        padding-left: 15px;
    }
    .cpL-qz::after {
        content: '';
        display: inline-block;
        width: 0;
        height: 14px;
        border-left: 1px solid #333;
        position: absolute;
        left: 0;
        top: 33px;
    }
    .cpL-qz a {
        color: #333;
    }
    .cpL-qz a:hover {
        color: #049cff;
    }
    .cp-login-box {
        position: absolute;
        top: 120px;
        left: 50%;
        margin-left: 206px;
        background: #fff;
        border-radius: 3px;
        width: 302px;
        height: 435px;
        padding: 0 24px 30px 24px;
        z-index: 2;
    }
    .cp-login-tit {
        font-size: 16px;
        color: #555;
        border-bottom: 1px solid #ddd;
        line-height: 50px;
        margin: 0 0 30px;
        text-align: center;
    }
    .cp-login-bottom {
        padding-top: 30px;
        border-top: 1px solid #ddd;
        margin-top: 30px;
    }
    .cp-login-bottom .cp-login-bp {
        height: 32px;
        padding: 8px 0;
        margin-right: 15px;
        float: left;
        font-size: 14px;
    }
    .cp-login-bottom .bottom-group {
        width: 230px;
    }
    .btn-orange {
        color: #fff;
        background-color: #ff9900;
        border-color: #ff9900;
        height: 32px;
        font-size: 14px;
        padding: 0;
        border-radius: 3px;
        outline: 0 !important;
        cursor: pointer;
    }
    .btn-block {
        display: block;
        width: 100%;
        border: 1px solid transparent;
    }
    .btn-orange:hover, .btn-orange:focus {
        color: #fff;
        background: #ffb84d;
        border-color: #ffb84d;
        background-image: none;
        -webkit-box-shadow: none;
        box-shadow: none;
    }
    .btn-orange:active, .btn-orange.active {
        color: #fff;
        background-color: #ff9900;
        border-color: #ff9900;
        outline: 0;
        background-image: none;
        -webkit-box-shadow: none;
        box-shadow: none;
    }
    .cpL-user {
        position: relative;
    }
    .cpL-user::after {
        content: '';
        display: inline-block;
        width: 20px;
        height: 20px;
        background: url("../../img/common/cp-login-icon.png") no-repeat -2px -29px;
        position: absolute;
        top: 14px;
        left: 18px;
    }
    .cpL-user .el-input input,
    .cpL-password .el-input input {
        padding-left: 50px;
        box-sizing: border-box;
    }
    .cpL-password {
        position: relative;
    }

    .cpL-password::after {
        content: '';
        display: inline-block;
        width: 22px;
        height: 21px;
        background: url("../../img/common/cp-login-icon.png") no-repeat -31px
            -28px;
        position: absolute;
        top: 14px;
        left: 18px;
    }
    .cpL-password input {
        padding-left: 50px;
    }
    .trapezoid {
        display: block;
        border-bottom: 25px solid rgba(0, 0, 0, 0.2);
        border-left: 16px solid transparent;
        height: 0;
        width: 115px;
        position: absolute;
        top: 0;
        right: 0;
        z-index: 30;
    }
    .tra-txt {
        position: absolute;
        top: 0;
        right: 0;
        z-index: 40;
        width: 115px;
        text-align: right;
    }
    .login-arrow {
        display: inline-block;
        width: 12px;
        height: 12px;
        background: url(../../img/login-icon.png) no-repeat;
        margin: 0 10px;
    }
    .forgetP {
        margin-bottom: 20px;
        text-align: right;
        font-size: 14px;
    }
    .forgetP a, .forgetP a:hover {
        color: #049cff;
    }
    .pull-left {
        float: left;
    }
    .company-entry {
        position: absolute;
        top: -25px;
        right: 0;
        line-height: 25px;
        color: #fff;
    }
    #login .cpL-user,
    #login .cpL-password {
        margin-bottom: 20px;
    }
    .el-form .el-input__inner:focus {
        border-color: #049cff;
        outline: 0;
        -webkit-box-shadow: none;
        box-shadow: none;
    }

    .app-main {
        width: 100%;
    }

    .footer {
        margin-top: 30px;
    }

    .el-carousel__container .el-carousel__item img {
        position: absolute;
            top: 0px;
            left: 0px;
            width: 100%;
            height: 600px;
    }

</style>

<style lang="less">
    .login-content  {
        .el-input__inner {
            color: #555;
                    border-radius: 3px;
                    -webkit-box-shadow: none;
                    box-shadow: none;
                    -webkit-transition: border-color ease-in-out .15s;
                    -o-transition: border-color ease-in-out .15s;
                    transition: border-color ease-in-out .15s;
                        padding-left: 50px !important;
                    display: block;
                            height: 50px;
                            font-size: 14px;
                            line-height: 50px;
                            color: #464646;
                            background-color: #f8f8f8;
                            background-image: none;
                            border: 1px solid #f8f8f8;
                            -webkit-box-shadow: none;
                            box-shadow: none;
         }
    }

    .header {
            position: relative;
            min-width: 1024px;
            background: #fff;
            height: 80px;
            .inner {
                .el-row {
                     padding-top: 10px;
                }
            }
        }

</style>
