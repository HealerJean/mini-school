<template>
    <div class="email-manage">
        <div>我的位置：
            <el-breadcrumb separator=">">
                <el-breadcrumb-item>系统设置</el-breadcrumb-item>
                <el-breadcrumb-item>通知模板</el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        <div class="email-body">
            <div class="email-add">
                <el-button type="primary" @click="createInfro">+新建通知模板</el-button>
                    <div v-on:keyup.enter="search" class="email-search">
                        <el-input placeholder="请输入模板名称" icon="search" v-model="emailName" :on-icon-click="search" >
                    </el-input>
                </div>
            </div>
            <email-message-modal :iscreateEmail="iscreateEmail" :modifyingId="modifyingId" @closecreateEmail="closecreateEmail" @createEmail="createEmail"></email-message-modal>
            <el-table :data="emailList" style="width:100%" :row-style="rowStyle">
                <el-table-column  label="序号" type="index" width="100" header-align="center" align="center">
                </el-table-column>
                <el-table-column prop="name" label="模板名称" header-align="center" align="center">
                </el-table-column>
                <el-table-column prop="userName" label="创建人" header-align="center" align="center">
                </el-table-column>
                <el-table-column prop="updatedOn" label="创建/修改时间" header-align="center"  align="center" :formatter="formatDate">
                </el-table-column>
                <el-table-column label="操作" header-align="center" align="center">
                    <template scope="scope">
                        <span style="line-height: 58px;">
                            <el-button type="text" @click="modify(scope.row)">修改</el-button>
                            <el-button type="text" @click="remove(scope.row)">删除</el-button>
                        </span>
                    </template>
                </el-table-column>
            </el-table>

        </div>
    </div>
</template>

<script type="text/babel">
import EmailMessageModal from '../Modal/EmailMessageModal.vue';

    export default {
        name: 'email',
        data:function(){
            return{
                iscreateEmail:false,
                modifyingId:'',
                emailName:''
            }
        },
        methods:{
            rowStyle(row){
                if(!row.name.includes(this.emailName)){
                    return "display:none;";
                }
            },
            //修改模板
            modify(value){
                this.modifyingId = value.id;
                this.iscreateEmail = true;
            },
            //删除模板
            remove(value){
                console.log(value);
                this.$http.delete('company/template/email/'+value.id).then(response =>{
                    if(response.status==200){
                        this.$message({
                            message: '操作成功',
                            duration:2000
                        });
                    }else{
                        this.$message({
                            message: '操作失败',
                            duration:2000
                        });
                    }
                    this.getemailList();
                })
            },
            //获取模板列表
            getemailList(){
                console.log('获取邮件模板列表')
                this.$http.get('company/template/emails').then(response =>{
                    let a = response.body;
                    console.log(a);
                    //存到状态库中

                    this.$store.commit('updateEmailList' , a);
                })
            },
            //添加
            createInfro(){
                this.iscreateEmail = true;
            },
            //关闭添加
            closecreateEmail(){
                this.iscreateEmail = false;
                this.modifyingId = "";
            },
            //保存模板
            createEmail(value){
                if(this.modifyingId){
                    console.log('修改模板')
                    this.$http.put('company/template/email/'+this.modifyingId,value,{headers: {'Content-Type':'application/json'}}).then(response =>{
                        if(response.status==200){
                            this.$message({
                                message: '操作成功',
                                duration:2000
                            });
                        }else{
                            this.$message({
                                message: '操作失败',
                                duration:2000
                            });
                        }
                        this.getemailList();
                    })

                }else{
                    console.log("创建模板");
                    this.$http.post('company/template/email',value,{headers: {'Content-Type':'application/json'}}).then(response =>{
                        if(response.status==200){
                            this.$message({
                                message: '操作成功',
                                duration:2000
                            });
                        }else{
                            this.$message({
                                message: '操作失败',
                                duration:2000
                            });
                        }
                        this.getemailList();
                    })
                }
            },
            formatDate(val) {
                if(val){
                    return val.updatedOn.substring(0,4)+'-'+val.updatedOn.substring(4,6)+'-'+val.updatedOn.substring(6,8);
                }
            },
        },
        computed:{
            userId(){
                return this.$store.getters.userId
            },
            userName(){
                return this.$store.getters.userName
            },
            recId(){
                return this.$store.getters.recId
            },
            emailList(){
                return this.$store.state.candidate.emailList
            }
        },
        mounted(){
            this.getemailList();
        },
        components:{
            EmailMessageModal
        }
    }

</script>

<style lang="less">
    .email-manage {
        .el-breadcrumb {
            display: inline-block;
        }
        .email-body {
            background-color: #ffffff;
            margin-top: 20px;

            .email-add {
                //background-color: #dddddd;
                margin-top: 20px;
                margin-bottom: 20px;
                .email-search {
                    float: right;
                    width:286px;
                    height:34px;
                    .el-input__inner {
                        height:34px;
                        padding-left: 30px;
                    }
                    .el-input__icon {
                        cursor: pointer;
                        left:0;
                    }
                }
            }
            // .email-hint {
            //     padding: 10px;
            //     background-color: #ffd86f;
            // }
            .el-table {
                .el-button {
                    padding:0;
                }
            }
        }
    }
</style>
