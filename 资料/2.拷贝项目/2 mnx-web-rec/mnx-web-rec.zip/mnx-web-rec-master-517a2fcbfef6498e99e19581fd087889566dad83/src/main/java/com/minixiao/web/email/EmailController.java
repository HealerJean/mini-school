package com.minixiao.web.email;

import com.minixiao.apiauth.client.HeaderUtil;
import com.minixiao.web.dto.candidate.AppStageListDTO;
import com.minixiao.web.dto.candidate.UpdateStatusDTO;
import com.minixiao.web.dto.recruiters.UserDTO;
import com.minixiao.web.utils.YmlConfig;
import io.jstack.sendcloud4j.SendCloud;
import io.jstack.sendcloud4j.mail.Email;
import io.jstack.sendcloud4j.mail.Result;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * 发送邮件接口
 *
 * @Author wangyj.
 * @Date 2017/3/13  14:59.
 */
@Controller
public class EmailController {

    @Autowired
    private YmlConfig ymlConfig;

    private RestTemplate restTemplate = new RestTemplate();

    @PostMapping("candidate/email")
    public ResponseEntity<String> sendEmail(@RequestBody EmailListDTO emailListDTO) {

        //发送邮件账号密码
        String apiUser = "sendminixiaouser";
        String apiKey = "7d46vXYviEv4gHnB";

        String localInfo = emailListDTO.getLocalInfo();
        List<EmailSendDTO> emailSendDTOs = emailListDTO.getEmailSendDTOs();
        Subject subject = SecurityUtils.getSubject();
        if (subject != null) {
            UserDTO user = (UserDTO) subject.getSession().getAttribute(ymlConfig.getSession_current_user());
            if (user != null) {
                UUID recId = user.getRecId();
                UUID optUid = user.getId();
                String optName = user.getRealName();
                String recName = user.getRecName();

                String title = emailListDTO.getTitle();
                String content = emailListDTO.getContent();

                List<AppStageListDTO> appStageListDTOs = new ArrayList<AppStageListDTO>();
                for (EmailSendDTO emailDTO : emailSendDTOs) {
                    if (!"".equals(emailDTO.getEmail())) {
                        String emailAddress = emailDTO.getEmail();
                        String candidateName = emailDTO.getCandidateName();
                        String jobName = emailDTO.getJobName();
                        //替换模板中的变量
                        String emailContent = content;
                        emailContent = emailContent
                            .replace("%candidateName%", candidateName)
                            .replace("%jobName%", jobName)
                            .replace("%localInfo%", localInfo);
                        emailContent = HtmlUtils.getHtml(emailContent);
                        SendCloud webapi = SendCloud.createWebApi(apiUser, apiKey);
                        Email email = Email.general()
                            .from("webadmin@minixiao.com")
                            .fromName("迷你校")
                            .html(emailContent)
                            .subject(title)
                            .to(emailAddress);
                        Result resultSend = webapi.mail().send(email);

                        //封装申请表信息去调用状态改变接口
                        AppStageListDTO appStageListDTO = new AppStageListDTO();
                        appStageListDTO.setId(emailDTO.getCandidateId());
                        appStageListDTO.setCandidateName(emailDTO.getCandidateName());
                        appStageListDTO.setJobId(emailDTO.getJobId());
                        appStageListDTO.setJobName(emailDTO.getJobName());
                        appStageListDTOs.add(appStageListDTO);
                    }
                }
                //改变申请表状态为已通知（并且添加操作历史）
                UpdateStatusDTO updateStatusDTO = new UpdateStatusDTO();//更新申请表状态的值对象
                updateStatusDTO.setStage(emailListDTO.getStage());
                updateStatusDTO.setStatus("已通知");
                updateStatusDTO.setAppStageListDTOs(appStageListDTOs);
//                UUID recId = UUID.fromString("0b5c9f73-6c11-4e0a-a9d8-c1da222a74bf");
//                UUID optUid = recId;
//                String optName = "王迎接";
//                String recName = "迷你校";
                HttpHeaders requestHeaders = HeaderUtil.getHeader(optUid, optName, "COMPANY", recId,
                    recName);
                HttpEntity requestEntity = new HttpEntity(updateStatusDTO, requestHeaders);
                ResponseEntity<String> responseEntity = restTemplate.exchange(
                    ymlConfig.getUrl_api_recruiter() + "candidate/status", HttpMethod.PUT, requestEntity,
                    String.class);
                String result = responseEntity.getBody();
                return ResponseEntity.ok("发送成功！");
            }
        }
        return ResponseEntity.ok("发送失败！");
    }
}
