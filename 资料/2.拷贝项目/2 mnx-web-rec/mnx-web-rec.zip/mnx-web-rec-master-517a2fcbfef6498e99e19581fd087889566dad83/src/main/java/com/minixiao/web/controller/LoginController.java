package com.minixiao.web.controller;

import com.minixiao.web.utils.YmlConfig;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.*;
import org.apache.shiro.subject.Subject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class LoginController {

    @Autowired
    private YmlConfig ymlConfig;

    private static final Logger logger = LoggerFactory.getLogger(LoginController.class);
    /**
     * 显示用户登录页面
     * @return
     */
    @GetMapping("/login.html")
    public String loginForm() {
        return "login";
    }

    /**
     * 处理登录操作
     *
     * @param username
     * @param password
     * @return
     */
    @PostMapping("/doLogin")
    public ResponseEntity<String> loginHandle(String username, String password) {
        if (username != null && password != null) {
            UsernamePasswordToken token = new UsernamePasswordToken(username, password);
            //获取当前的Subject
            Subject currentUser = SecurityUtils.getSubject();
            String reason = "";
            try {
                //在调用了login方法后,SecurityManager会收到AuthenticationToken,并将其发送给已配置的Realm执行必须的认证检查
                currentUser.login(token);
            } catch (UnknownAccountException uae) {
                logger.info("对用户[" + username + "]进行登录验证..验证未通过,未知账户");
                reason = "userError";
            } catch (IncorrectCredentialsException ice) {
                logger.info("对用户[" + username + "]进行登录验证..验证未通过,错误的凭证");
                reason = "pwdError";
            } catch (LockedAccountException lae) {
                logger.info("对用户[" + username + "]进行登录验证..验证未通过,账户已锁定");
                reason = "userLocked";
            } catch (ExcessiveAttemptsException eae) {
                logger.info("对用户[" + username + "]进行登录验证..验证未通过,错误次数过多");
                reason = "excessiveAttemptsError";
            } catch (AuthenticationException ae) {
                //通过处理Shiro的运行时AuthenticationException就可以控制用户登录失败或密码错误时的情景
                logger.info("对用户[" + username + "]进行登录验证..验证未通过,堆栈轨迹如下");
                ae.printStackTrace();
                reason = "error";
            }
            if (currentUser.isAuthenticated()) {
                logger.info("用户[" + username + "]登录认证通过(这里可以进行一些认证通过后的一些系统参数初始化操作)");
                return ResponseEntity.ok("success");
            } else {
                token.clear();
                return ResponseEntity.ok(reason);
            }
        } else {
            return ResponseEntity.ok("userError");
        }
    }

    /**
     * 登出操作
     * @return
     */
    @GetMapping("/logout.html")
    public String logoutHandle() {
        Subject subject = SecurityUtils.getSubject();
        subject.logout();
        return "redirect:login";
    }
}
