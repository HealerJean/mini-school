package com.minixiao.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * 用户未登录时候展示的一系列页面
 */
@Controller
public class PageController {
	/**
	 * 登录前的aboutus / help 等页面
	 * @param pageView
	 * @return
	 */
	@GetMapping("/{pageView}.html")
	public String showPage(@PathVariable  String pageView) {
		return pageView;
	}
}
