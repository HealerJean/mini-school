<template>
    <div class="sent-department">
        <el-dialog title="发送邮件消息"
            v-model="sentEmailModelVisible"
            size="large"
            :close-on-click-modal="false"
            :close-on-press-escape="false"
            @close="closeModal">

            <el-form label-width="150px">
                <el-form-item label="模板名称：">
                    <el-select v-model="emailTemplate" placeholder="不限">
                        <el-option v-for="item in  emailList" :label="item.name" :value="item">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="邮件标题：">
                    <el-input v-model="title" :readonly="true"></el-input>
                </el-form-item>
                <el-form-item label="收件人：">
                    <el-input v-model="candidateNames" :readonly="true"></el-input><span>最多可选择100人，当前已选择{{candidateNamesArray.length}}人</span>
                </el-form-item>
                <el-form-item label="邮件内容：">
                    <el-input type="textarea" :rows="6" v-model="content" :readonly="true"></el-input>
                </el-form-item>
            </el-form>



            <div slot="footer" class="dialog-footer">
                <el-button type="primary" @click="sentEmail">发 送</el-button>
                <el-button @click="closeModal">取 消</el-button>
            </div>
        </el-dialog>


    </div>
</template>

<script type="text/babel">

    export default {
        name: 'sent-email-template',
        data:function(){
            return{
                emailTemplate:{}
            }
        },
        computed: {
            candidateNamesArray(){
                let candidateNamesArray = new Array();
                for(let i=0;i<this.candidates.length;i++){
                    candidateNamesArray.push(this.candidates[i].basic.name);
                }
                return candidateNamesArray
            },
            candidateNames(){
                return this.candidateNamesArray.join(',');
            },
            title(){
                return this.emailTemplate.title;
            },
            content(){
                return this.emailTemplate.content;
            },
            userId(){
                return this.$store.getters.userId
            },
            userName(){
                return this.$store.getters.userName
            },
            recId(){
                return this.$store.getters.recId
            },
            sentEmailModelVisible() {
                return this.isSentEmail;
            },
            emailList(){
                return this.$store.state.candidate.emailList
            }

        },
        props:{
            isSentEmail: {
                type: Boolean,
                default: false
            },
            candidates: {
                type:Array,
                default: []
            }

        },
        methods: {
            closeModal() {
                this.$emit('closeSentEmail');
            },
            sentEmail() {
                if(!this.emailTemplate.name){
                    this.$message({
                        message: "请选择模板",
                        duration:2500
                    });
                    return;
                }

                this.$emit('sentEmail',this.emailTemplate );
                this.$emit('closeSentEmail');
            },

            // //获取模板详细信息
            // getTemplateById() {
            //     if(this.id){
            //         console.log('获取邮件模板详细信息')
            //         this.$http.get('company/template/email/'+this.id).then(response =>{
            //             let a = response.body;
            //             console.log(a);
            //             //存到状态库中
            //             this.name = a.name;
            //             this.title = a.title;
            //             this.content = a.content;
            //         })
            //     }
            // },
            //获取模板列表
            getemailList(){
                console.log('获取邮件模板列表')
                this.$http.get('company/template/emails').then(response =>{
                    let a = response.body;
                    console.log(a);
                    //存到状态库中

                    this.$store.commit('updateEmailList' , a);
                })
            },

        },
        created(){
            this.getemailList();
        }
    }
</script>

<style lang="less">
.sent-department{
    .el-inpute {
        width: 240px;
    }
    .el-dialog__header {
        text-align: center;
    }
    .el-dialog__body {
        text-align: center;
    }
    .el-form-item {
        margin-bottom: 20px;
    }
}

</style>
