<template>
    <div>
        <ul class="job-filter">
            <li>
                <el-checkbox
                    v-model="isFilterChecked"
                    @change="checkedList">
                    {{ checkedText }}
                </el-checkbox>
            </li>
            <template v-if="tabActive.isOnline">
                <li :class="isFilterChecked ? '' : isDisable">
                    <el-button class="jf-up-btn" @click.once="checkOnlineing">
                        <i class="joblist-icon"></i>
                        <span>上线</span>
                    </el-button>
                </li>
            </template>
            <li :class="isFilterChecked ? '' : isDisable">
                <div class="jf-time-btn" @click="openChangeTimeModal">
                    <i class="joblist-icon"></i>
                    <span>修改时间</span>
                </div>
            </li>
            <template v-if="tabActive.isOffline">
                <li :class="isFilterChecked ? '' : isDisable">
                    <el-button class="jf-down-btn" @click.once="checkOfflineing">
                        <i class="joblist-icon"></i>
                        <span>下线</span>
                    </el-button>
                </li>
            </template>
        </ul>
        <template v-if="jobLists.length?true:false">
            <div class="job-list-main">
                <ul>
                    <li v-for="item in jobLists">
                        <div class="jl-top">
                            <el-row>
                                <el-col :span="18">
                                    <label class="check-box-square">
                                        <input type="checkbox" v-model="checkJobList" :value="item.id"
                                               @change="addCheckedList(item)"/>
                                        <span class="el-checkbox__inner"></span>
                                    </label>
                                    <h2 class="jl-name">
                                        <router-link :to="position(item)">{{item.title}}</router-link>
                                    </h2>
                                    <ul class="jl-labels">
                                        <li>{{item.jobArea}}</li>
                                        <li>{{item.department.name}}</li>
                                        <li>{{item.careerLevel}}</li>
                                        <li>
                                            <template v-if="!item.sarlary.start && !item.sarlary.end">
                                                <span>面谈</span>
                                            </template>
                                             <template v-else-if="!item.sarlary.start && item.sarlary.end == 2000">
                                                <span>2000以下</span>
                                            </template>
                                             <template v-else-if="item.sarlary.start == 50000 && !item.sarlary.end">
                                                <span>50000以上</span>
                                            </template>
                                             <template v-else>
                                                <span>{{item.sarlary.start}}-{{item.sarlary.end}}/月</span>
                                            </template>
                                        </li>
                                        <template v-if="item.headcount == 0">
                                            <li>不限</li>
                                        </template>
                                        <template v-else>
                                            <li>{{item.headcount}}人</li>
                                        </template>
                                        <template v-if="item.applyPeriod">
                                            <li>网申时间：{{item.applyPeriod.applyBeginDate | formatDate}} - {{item.applyPeriod.applyEndDate | formatDate}}
                                            </li>
                                        </template>
                                    </ul>
                                </el-col>
                                <el-col :span="6">
                                    简历总数 <span>{{item.applicationNum}}</span>
                                </el-col>
                            </el-row>
                        </div>
                        <div class="jl-bottom">
                            <el-row>
                                <el-col :span="12">
                                    <template v-if="item.status == null">
                                        <span>{{ item.audit.status | statusStr}}</span>
                                    </template>
                                    <template v-else-if="item.status == 'onHold'">
                                        <span>{{ item.status | statusStr}}</span>
                                    </template>
                                    <template v-else>
                                        <span>{{ item.status | statusStr}} （{{ item.audit.status | statusStr}}）</span>
                                    </template>
                                    <span>最后修改时间：{{item.updatedOn | formatDate}}</span>
                                </el-col>
                                <el-col :span="12">
                                    <template v-if="tabActive.isOnline">
                                        <el-button class="jl-up-btn" @click="onlineing(item)">
                                            <i class="joblist-icon"></i>
                                            <span>上线</span>
                                        </el-button>
                                    </template>
                                    <router-link class="jl-edit-btn" :to="edit(item)">
                                        <i class="joblist-icon"></i>
                                        <span>编辑</span>
                                    </router-link>
                                    <template v-if="tabActive.isOffline">
                                        <el-button class="jl-down-btn" @click="offlineing(item)">
                                            <i class="joblist-icon"></i>
                                            <span>下线</span>
                                        </el-button>
                                    </template>
                                </el-col>
                            </el-row>
                        </div>
                    </li>
                </ul>
                <el-pagination
                    @size-change="handleSizeChange"
                    @current-change="handleCurrentChange"
                    :current-page="currentPage"
                    :page-sizes="pageSizes"
                    :page-size="pageSize"
                    layout="total, sizes, prev, pager, next"
                    :total="totalCount">
                </el-pagination>
            </div>
        </template>
        <template v-else>
            <div class="job-anonymous"></div>
        </template>
        <change-time-modal :isChangeTime="isChangeTime" @modal:change-time-closing="closeChangeTimeModal" @modal:emit-change-time="submitChangeTimeModal"></change-time-modal>
    </div>
</template>

<script type="text/babel">
    import ChangeTimeModal from '../Modal/ChangeTimeModal.vue'
    import eventBus from '../../js/shared/eventBus';

    export default {
        components: {
            ChangeTimeModal
        },
        data() {
            return {
                isChangeTime: false,
                //过滤器
                isDisable: 'disabled',
                checkedText: "全选",
                checkJobList: [],
                checkJobListObj: [],
                isFilterChecked:false,
                //pages
                currentPage: 1,
                pageSizes: [10, 20, 30, 40],
                pageSize: 10,
                total: 0
            }
        },
        props: {
            jobLists: {
                type: Array,
                default(){
                    return []
                }
            },
            tabActive: {
                type: Object,
                default(){
                    return {}
                }
            }
        },
        computed: {
            totalCount(){
                return this.total = this.tabNameCount[this.activeJobTabName];
            },
            //当选tabName
            activeJobTabName(){
                return this.$store.state.job.activeJobTabName;
            },
            tabNameCount(){
                console.log(this.$store.state.job.tabNameCount);
                return this.$store.state.job.tabNameCount;
            },
            //筛选容器
            jobQueryFormStatus() {
                return this.$store.state.job.jobQueryFormStatus;
            }
        },
        watch: {
            checkJobList: {
                handler: function () {
                    if (this.checkJobList.length == 0) {
                        this.checkedText = "全选";
                        this.isFilterChecked = false;
                    }else {
                        this.checkedText = "取消选择";
                        this.isFilterChecked = true;
                    }
                },
                deep: true
            }
        },
        filters: {
            formatDate: function (val) {
                if(val){
                    let curDate = val.toString().substring(0, 8);
                    return curDate.replace(/\s/g, '').replace(/(\d{4})(\d{2})(\d{2})/, "$1.$2.$3")
                }
            },
            statusStr: function (val) {
                switch (val) {
                    case 'waiting':
                        return '待审核';
                    case 'notThrough':
                        return '审核未通过';
                    case 'open':
                        return '已上线';
                    case 'onHold':
                        return '已下线';
                    default:
                        return val;
                }
            },
        },
        methods: {
            getJobPage:function(){
                let temp = this.jobQueryFormStatus,
                    tempTab = this.activeJobTabName;
                let params = {
                    jobTitle: temp[tempTab].name,
                    jobCategory: temp[tempTab].type,
                    jobArea: temp[tempTab].region,
                    departmentName: temp[tempTab].department,
                    beginDateFrom: this.jobListFormatDate(temp[tempTab].beginDate[0]),
                    beginDateTo: this.jobListFormatDate(temp[tempTab].beginDate[1]),
                    endDateFrom: this.jobListFormatDate(temp[tempTab].overDate[0]),
                    endDateTo: this.jobListFormatDate(temp[tempTab].overDate[1])
                };
                let urlParams = this.urlencode(params);
                console.log(urlParams);
                if (this.activeJobTabName == 'open' || this.activeJobTabName == 'onHold') {
                    this.$http.get('/requisitions?status=' + this.activeJobTabName + '&' + urlParams+'&page='+(this.currentPage-1)+'&size='+this.pageSize).then(response => {
                        let newData = response.body.content;
                        this.jobLists=[];
                        for (let i = 0; i < newData.length; i++) {
                            this.jobLists.push(newData[i]);
                        }
                    }, response => {
                        /* eslint-disable */
                        console.log(response);
                        /* eslint-disable */
                    });
                } else if (this.activeJobTabName == 'waiting' || this.activeJobTabName == 'notThrough') {
                    this.$http.get('/requisitions/listForAudit?auditStatus=' + this.activeJobTabName + '&' + urlParams+ '&page='+(this.currentPage-1)+'&size='+this.pageSize).then(response => {
                        let newData = response.body.content;
                        this.jobLists=[];
                        for (let i = 0; i < newData.length; i++) {
                            this.jobLists.push(newData[i]);
                        }
                    }, response => {
                        /* eslint-disable */
                        console.log(response);
                        /* eslint-disable */
                    });
                } else {
                    console.log('faidJobList-error')
                }
            },
            //查询路径
            urlencode(data){
                var _result = [];
                for (var key in data) {
                    var value = data[key];
                    if (typeof value == 'undefined' || value == '') {
                        console.log('undefined');
                    } else {
                        if (value instanceof Array) {
                            let strArr = '';
                            value.forEach(function (_value) {
                                strArr += _value + ','
                            });
                            strArr = strArr.substring(0, strArr.length - 1);
                            _result.push(key + "=" + strArr);
                        } else {
                            _result.push(key + '=' + value);
                        }
                    }
                }
                return _result.join('&');
            },
            jobListFormatDate(date) {
                if (date) {
                    let newDate = new Date(date);
                    let year = newDate.getFullYear(),
                        month = newDate.getMonth() >= 9 ? newDate.getMonth() + 1 : '0' + (newDate.getMonth() + 1),
                        day = newDate.getDate() >= 10 ? newDate.getDate() : '0' + newDate.getDate();
                    return year + '-' + month + '-' + day
                } else {
                    return '';
                }
            },
            position(item){
                let jobPath = 'position/'+item.id;
                return jobPath;
            },
            edit(item){
                let jobPath = 'edit/'+item.id;
                return jobPath;
            },
            handleSizeChange(val) {
                this.pageSize = val;
                this.getJobPage();
            },
            handleCurrentChange(val) {
                this.currentPage = val;
                this.checkJobList = [];
                this.checkJobListObj = [];
                this.isFilterChecked = false;
                this.checkedText = "全选";
                this.getJobPage();
            },
            checkedList: function () {
                let _self = this;
                if (this.isFilterChecked) {
                    _self.checkedText = "取消选择";
                    let tempArr=_self.jobLists.slice(0,_self.pageSize);
                    tempArr.forEach(function(item){
                        _self.checkJobListObj.push(item);
                        _self.checkJobList.push(item.id)
                    });
                } else {
                    _self.checkJobList = [];
                    _self.checkJobListObj = [];
                    _self.checkedText = "全选";
                }
            },
            addCheckedList: function (item) {
                if (this.checkJobList.includes(item.id)) {
                    this.checkJobListObj.push(item);
                } else {
                    this.checkJobListObj.splice(item, 1);
                }
            },
            onlineing: function (item) {
                let self=this;
                self.$message({
                    showClose: true,
                    message: '当前职位已成功上线',
                    duration: 1000,
                    iconClass:'success-icon'
                });
                eventBus.$emit(
                    'job-onlineing',
                    item
                );
                // this.$store.commit('tabCountMinus', this.tabNameCount[this.activeJobTabName]);
                self.$http.put('/requisitions/'+item.id+'/online').then(response => {
                    self.getJobPage();
                }, response => {
                    /* eslint-disable */
                    console.log(response);
                    /* eslint-disable */
                });
            },
            offlineing: function (item) {
                let self=this;
                self.$message({
                    showClose: true,
                    message: '当前职位已成功下线',
                    duration: 1000,
                    iconClass:'success-icon'
                });
                eventBus.$emit(
                    'job-offlineing',
                    item
                );
                // this.$store.commit('tabCountMinus', this.tabNameCount[this.activeJobTabName]);
                self.$http.put('/requisitions/'+item.id+'/offline').then(response => {
                    self.getJobPage();
                }, response => {
                    /* eslint-disable */
                    console.log(response);
                    /* eslint-disable */
                });
                // eventBus.$emit(
                //     'job-offlineing',
                //     item
                // );
                // this.$message({
                //     showClose: true,
                //     message: '当前职位已成功下线',
                //     duration: 1000,
                //     iconClass:'success-icon'
                // });
                // // console.log(this.tabNameCount[this.activeJobTabName]);
                // // this.$store.commit('tabCountMinus', this.tabNameCount[this.activeJobTabName]);
                // this.$http.put('/requisitions/'+item.id+'/offline').then(response => {
                //     this.getJobPage();
                // }, response => {
                //     /* eslint-disable */
                //     console.log(response);
                //     /* eslint-disable */
                // });
            },
            checkOnlineing: function () {
                let _self = this;
                if (_self.isFilterChecked) {
                    eventBus.$emit(
                        'job-check-onlineing',
                        _self.checkJobListObj
                    );
                    _self.$message({
                        showClose: true,
                        message: '当前职位已成功上线',
                        duration: 1000,
                        iconClass:'success-icon'
                    });
                    _self.checkJobListObj.forEach(function(item){
                    _self.$store.commit('tabCountMinus', _self.tabNameCount[_self.activeJobTabName]);
                    _self.$http.put('/requisitions/'+item.id+'/online').then(response => {
                            _self.getJobPage();
                        }, response => {
                            /* eslint-disable */
                            console.log(response);
                            /* eslint-disable */
                        });
                    });
                    _self.checkJobList = [];
                    _self.checkJobListObj = [];
                    _self.isFilterChecked = false;
                    _self.checkedText = "全选";
                }
            },
            checkOfflineing: function () {
                let _self = this;
                if (_self.isFilterChecked) {
                    eventBus.$emit(
                        'job-check-offlineing',
                        _self.checkJobListObj
                    );
                    _self.$message({
                        showClose: true,
                        message: '当前职位已成功下线',
                        duration: 1000,
                        iconClass:'success-icon'
                    });
                    _self.checkJobListObj.forEach(function(item){
                    _self.$store.commit('tabCountMinus', _self.tabNameCount[_self.activeJobTabName]);
                    _self.$http.put('/requisitions/'+item.id+'/offline').then(response => {
                            _self.getJobPage();
                        }, response => {
                            /* eslint-disable */
                            console.log(response);
                            /* eslint-disable */
                        });
                    });
                    _self.checkJobList = [];
                    _self.checkJobListObj = [];
                    _self.isFilterChecked = false;
                    _self.checkedText = "全选";
                }
            },
            openChangeTimeModal: function () {
                if (this.isFilterChecked) {
                    this.isChangeTime = true
                } else {
                    return;
                }
            },
            closeChangeTimeModal:function(){
                this.isChangeTime = false;
            },
            submitChangeTimeModal:function(val){
                let time = '', beforeTime = '', afterTime = '';
                for (let i = 0; i < val.length; i++) {
                    time += this.jobQueryFormatDate(val[i]) + '-';
                }
                beforeTime = time.slice(0, 8);
                afterTime = time.slice(9, time.length - 1);
                let _self=this;
                this.checkJobListObj.forEach((item)=> {
                    item.applyPeriod.applyBeginDate = beforeTime;
                    item.applyPeriod.applyEndDate = afterTime;
                    item.createdOn = _self.jobQueryFormatDate();
                    let data={
                        applyPeriod:{
                            applyBeginDate:_self.putFormatDate(beforeTime),
                            applyEndDate:_self.putFormatDate(afterTime)
                        }
                    };
                    _self.$http.put('/requisitions/'+item.id,data).then(response => {
                    }, response => {
                        /* eslint-disable */
                        console.log(response);
                        /* eslint-disable */
                    });
                })
                this.checkJobList = [];
                this.checkJobListObj = [];
                this.isFilterChecked = false;
                this.checkedText = "全选";
            },
            jobQueryFormatDate(date) {
                let newDate = '';
                if(date){
                    newDate = new Date(date);
                }else{
                    newDate = new Date();
                }
                let year = newDate.getFullYear(),
                    month = newDate.getMonth() >= 9 ? newDate.getMonth() + 1 : '0' + (newDate.getMonth() + 1),
                    day = newDate.getDate() >= 10 ? newDate.getDate() : '0' + newDate.getDate();
                return year + month + day
            },
            putFormatDate(date) {
                return date.replace(/(\d{4})(\d{2})(\d{2})/, "$1-$2-$3")
            }
        },
        mounted() {
        }
    }

</script>
<style lang="less">
    @import "../../less/shared/variables.less";

    /*filter*/
    .job-filter {
        list-style: none;
        border: @border-gray;
        background-color: #eee;
        width: 100%;
        padding: 15px 10px;
        box-sizing: border-box;
        overflow: hidden;
        margin: 10px 0 20px;
        & > li {
            float: left;
            margin-right: 30px;
            font-size: @size-lg;
            color: extract(@gray-group, 3);
            cursor: pointer;
            &.active, &:hover {
                color: @primary-color;
                .joblist-icon {
                    background-position-y: -20px;
                }
                .el-button{
                    color: @primary-color;
                }
            }
            &.disabled {
                cursor: not-allowed;
                &:hover {
                    color: extract(@gray-group, 3);
                    .joblist-icon {
                        background-position-y: 0;
                    }
                    .el-button{
                        color: extract(@gray-group, 3);
                        cursor: not-allowed;
                    }
                }
            }
        }
        .el-checkbox__inner {
            width: 12px;
            height: 12px;
            border: 1px solid #b5b5b5;
            border-radius: 1px;
            margin-bottom: 1px;
            background: #eee;
        }
        .el-checkbox__label {
            font-size: @size-lg;
            color: extract(@gray-group, 2);
        }
        .el-checkbox__inner:after {
            height: 6px;
            left: 2px;
            top: 0;
        }
        .el-checkbox__input.is-checked .el-checkbox__inner {
            background-color: @primary-color;
            border-color: @primary-color;
        }
    }

    .jf-up-btn,.jf-down-btn{
        &.el-button {
            padding: 0;
            border-radius: 0;
            border: none;
            color: #555;
            font-size: @size-lg;
        }
        &.el-button--default {
            background-color:initial;
            border-color: @white;
            color: #555;
        }
        &.el-button--default:focus, &.el-button--default:hover {
            background-color: initial;
            border-color: @white;
            color: #555;
        }
    }

    .jf-up-btn {
        .joblist-icon {
            width: 10px;
            height: 14px;
            background-position: -2px 0;
            margin-bottom: -1px;
        }
    }

    .jf-time-btn {
        .joblist-icon {
            width: 14px;
            height: 14px;
            background-position: -20px 0;
            margin-bottom: -1px;
        }
    }

    .jf-down-btn {
        .joblist-icon {
            width: 10px;
            height: 14px;
            background-position: -42px 0;
            margin-bottom: -1px;
        }
    }

    /*jobListMain*/
    .job-list-main {
        & > ul {
            list-style: none;
            padding: 0;
            & > li {
                border: @border-gray;
                background-color: @white;
                margin-bottom: 16px;
            }
        }
    }

    .jl-top {
        position: relative;
        padding: 20px 20px 15px 40px;
        .el-col + .el-col {
            text-align: right;
            color: extract(@gray-group, 5);
            & > span {
                color: extract(@gray-group, 2);
                font-weight:bold;
            }
        }
    }

    .jl-bottom {
        padding: 0 20px 20px 40px;
        color: extract(@gray-group, 6);
        .el-col {
            & > span {
                margin-right: 30px;
                line-height: 16px;
            }
        }
        .el-col + .el-col {
            text-align: right;
            & > div {
                display: inline-block;
                color: extract(@gray-group, 2);
                margin-left: 20px;
                cursor: pointer;
            }
        }
    }

    .jl-checkbox {
        position: absolute;
        left: -26px;
        top: 18px;
        .el-checkbox__inner {
            width: 14px;
            height: 14px;
            border: 1px solid #b5b5b5;
            border-radius: 1px;
            margin-bottom: 1px;
        }
        .el-checkbox__label {
            font-size: @size-lg;
            color: extract(@gray-group, 2);
        }
        .el-checkbox__inner:after {
            height: 6px;
            left: 3px;
            top: 1px;
        }
        .el-checkbox__input.is-checked .el-checkbox__inner {
            background-color: @primary-color;
            border-color: @primary-color;
        }
    }

    .jl-name {
        float: left;
        margin: 0;
        font-weight: normal;
        display: inline-block;
        color: extract(@gray-group, 3);
        font-size: @size-lg;
        overflow: hidden;
        text-overflow: ellipsis;
        max-width: 280px;
        & > a {
            text-decoration: none;
            color: @primary-color;
            &:hover {
                color: @primary-color;
            }
        }
    }

    .jl-labels {
        float: left;
        list-style: none;
        margin: 2px 0 0 25px;
        padding: 0;
        & > li {
            position: relative;
            display: inline-block;
            float: left;
            padding: 0 10px 0 11px;
            color: extract(@gray-group, 4);
            & + li:after {
                content: "";
                position: absolute;
                left: 0;
                top: 3px;
                height: 12px;
                width: 0;
                border-left: @border-gray;
            }
        }
    }

    .jl-up-btn,.jl-down-btn {
        margin-left: 20px;
        &.el-button {
            padding: 0;
            border-radius: 0;
            border: none;
            color: #555;
            font-size: @size-md;
        }
        &.el-button--default {
            background-color: @white;
            border-color: @white;
            color: #555;
        }
        &.el-button--default:focus, &.el-button--default:hover {
            background-color: @white;
            border-color: @white;
            color: #555;
        }
    }

    .jl-up-btn {
        .joblist-icon {
            width: 10px;
            height: 14px;
            background-position: -2px -20px;
            margin-bottom: -2px;
        }
    }

    .jl-edit-btn {
        text-decoration: none;
        display: inline-block;
        color: #464646;
        margin-left: 20px;
        cursor: pointer;
        .joblist-icon {
            width: 14px;
            height: 14px;
            background-position: 0 -40px;
            margin-bottom: -2px;
        }
    }

    .jl-down-btn {
        .joblist-icon {
            width: 10px;
            height: 14px;
            background-position: -42px -20px;
            margin-bottom: -2px;
        }
    }

    /*self_checkbox*/
    .check-box-square {
        cursor: pointer;
        position: absolute;
        left: -26px;
        top: 18px;
        input[type="checkbox"] {
            opacity: 0;
            display: none;
            & + .el-checkbox__inner {
                width: 14px;
                height: 14px;
                border: @border-gray;
                border-radius: 1px;
                margin-bottom: 1px;
                background: @white;
            }
            & + .el-checkbox__inner:after {
                left: 3px;
                top: 0;
            }
            &:checked + .el-checkbox__inner {
                background-color: @primary-color;
                border-color: @primary-color;
            }
            &:checked + .el-checkbox__inner:after {
                -ms-transform: rotate(45deg) scaleY(1);
                transform: rotate(45deg) scaleY(1);
            }
        }
    }

    .el-message {
        min-width: 300px;
        padding: 10px 12px;
        box-sizing: border-box;
        border-radius: 2px;
        position: fixed;
        left: 50%;
        top: 300px;
        border:1px solid #ddd;
        transform: translateX(-50%);
        transition: opacity .3s,transform .4s;
        overflow: hidden;
    }

    .el-message-fade-enter, .el-message-fade-leave-active{
        opacity:0;
        -ms-transform:translate(-50%,-100%);
        transform:translate(-50%,-100%);
    }
    .el-message, .el-time-panel {
        box-shadow: 0 1px 6px rgba(0,0,0,0.2);
    }
    .el-message__group{
        position:relative;
    }
    .el-message__group p{
        padding-left:40px;
    }
    .success-icon{
        position:absolute;
        top:-10px; left:-12px;
        width:40px;
        height:40px;
        background: #34a853;
    }
    .job-anonymous{
        width:100%;
        min-height:400px;
        margin-top:100px;
        background:url(../../img/common/anonymous-2.jpg) no-repeat center top;
    }
</style>
