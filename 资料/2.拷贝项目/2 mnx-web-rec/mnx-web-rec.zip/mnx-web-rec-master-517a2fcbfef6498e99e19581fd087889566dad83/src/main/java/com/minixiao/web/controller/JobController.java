package com.minixiao.web.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/job")
public class JobController {
	@GetMapping({"/","/index.html"})
	public String home(){
		return "job/index";
	}

	@GetMapping("add.vue")
	public String addForm() {
		return "job/add";
	}
}