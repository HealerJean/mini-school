<template>
    <div class="workflow-setting-page">
        <div class="workflow-breadcrumb">我的位置：
            <el-breadcrumb separator=">">
                <el-breadcrumb-item>系统设置</el-breadcrumb-item>
                <el-breadcrumb-item>流程设置</el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        <workflow-modal class="workflow-padding-bottom-40"></workflow-modal>
    </div>
</template>

<script type="text/babel">
import WorkflowModal from '../Setting/WorkflowModal'

    export default {
        data:function(){
            return{

            }
        },
        components: {
            WorkflowModal
        }
    }

</script>

<style lang="less">
    .workflow-breadcrumb {
        .el-breadcrumb {
            display: inline-block;
        }
    }
    .workflow-setting-page {
        width: 1180px;
        .workflow-padding-bottom-40 {
            padding-bottom: 40px;
        }
    }

</style>
