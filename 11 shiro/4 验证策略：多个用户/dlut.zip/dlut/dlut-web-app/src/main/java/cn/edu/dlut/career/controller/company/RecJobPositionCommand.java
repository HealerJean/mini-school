package cn.edu.dlut.career.controller.company;


import cn.edu.dlut.career.domain.company.RecJobPosition;
import cn.edu.dlut.career.dto.company.RecJobPositionDTO;
import cn.edu.dlut.career.service.company.RecJobPositionService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

/**
 * Created by 史念念 on 2017/3/27.
 *
 * 招聘职位 增删改
 */
@Controller
@RequestMapping("/recruitJob")
@Transactional
public class RecJobPositionCommand {
  @Autowired
  private RecJobPositionService recruitJobService;

  private Logger logger = LoggerFactory.getLogger(RecJobPositionCommand.class);

  /**
   * 添加招聘职位
   * @param recJobPositionDTO
   * @return
   */
  @PostMapping
  @ResponseBody
  public String saveRecJob(@RequestBody RecJobPositionDTO recJobPositionDTO){
      RecJobPosition recJobPosition = new RecJobPosition();

    String result = "error";
    try {
      result = recruitJobService.saveRecJobPosition(recJobPosition,recJobPositionDTO);

    } catch (Exception e) {
      e.printStackTrace();
      result = "error";
    }
    logger.info(result);
    return result;
  }

    /**
     * 删除 招聘职位信息
     * @param id
     * @return
     */
  @DeleteMapping("/{id}")
  public String deleteRecJob(@PathVariable String id){
      String result="";
      try {
          result = recruitJobService.deleteById(id);
      } catch (Exception e) {
          e.printStackTrace();
          result = "error";
      }

      return result;
  }

}
