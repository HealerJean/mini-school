package cn.edu.dlut.career.recruiter.domain;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Created by wei on 2017/3/23.
 * offer处理表
 */
@Entity
@Table(name = "rec_require_deal")
public class ApplicationProcessing {
  public ApplicationProcessing() {
  }

  //编号，主键UUID
  @Id
  @GenericGenerator(name = "idGenerator",strategy = "uuid")
  @GeneratedValue(generator = "idGenerator")
  private String id;

  //申请编号
  @GenericGenerator(name = "uuid",strategy = "uuid")
  @GeneratedValue(generator = "uuid")
  @Column(nullable = false)
  private String reqId;

  //offer状态
  /**
   * 0待审核
   * 1通过
   * 2未通过
   */
  @Column(length = 100)
  private String status;

  //处理时间
  @Column(nullable = false)
  private LocalDateTime processingTime;

  //备注
  @Column(length = 500)
  private String remarks;

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getReqId() {
    return reqId;
  }

  public void setReqId(String reqId) {
    this.reqId = reqId;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public LocalDateTime getProcessingTime() {
    return processingTime;
  }

  public void setProcessingTime(LocalDateTime processingTime) {
    this.processingTime = processingTime;
  }

  public String getRemarks() {
    return remarks;
  }

  public void setRemarks(String remarks) {
    this.remarks = remarks;
  }
}
