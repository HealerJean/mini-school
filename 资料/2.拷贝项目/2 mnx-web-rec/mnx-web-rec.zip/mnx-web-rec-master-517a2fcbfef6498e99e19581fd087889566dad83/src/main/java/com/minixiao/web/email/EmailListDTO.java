package com.minixiao.web.email;

import java.util.List;
import java.util.UUID;

/**
 * @Author wangyj.
 * @Date 2017/3/13  15:16.
 */
public class EmailListDTO {
    private List<EmailSendDTO> emailSendDTOs;

    private String localInfo;

    private String title;

    private String content;

     private  String stage;

     private  String status;

    public EmailListDTO() {
    }

    public List<EmailSendDTO> getEmailSendDTOs() {
        return emailSendDTOs;
    }

    public void setEmailSendDTOs(List<EmailSendDTO> emailSendDTOs) {
        this.emailSendDTOs = emailSendDTOs;
    }

    public String getLocalInfo() {
        return localInfo;
    }

    public void setLocalInfo(String localInfo) {
        this.localInfo = localInfo;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getStage() {
        return stage;
    }

    public void setStage(String stage) {
        this.stage = stage;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
