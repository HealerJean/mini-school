<template>
    <div v-if="footerLogin">
        <footer-login></footer-login>
    </div>
    <div v-else>
        <footer-nologin></footer-nologin>
    </div>
</template>
<script>
import FooterNologin from './FooterNoLogin'
import FooterLogin from './FooterLogin'

export default {
    name: 'footer',
    data:function(){
        return {
            footerLogin:true
        }
    },
    components: {
        FooterNologin,
        FooterLogin
    }
}
</script>