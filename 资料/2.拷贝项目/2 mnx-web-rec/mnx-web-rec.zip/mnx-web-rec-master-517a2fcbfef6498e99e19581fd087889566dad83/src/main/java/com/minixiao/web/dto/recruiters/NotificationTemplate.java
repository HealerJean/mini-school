package com.minixiao.web.dto.recruiters;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * @Description 邮件通知模板 .
 * @Author xiachao
 * @CreateTime 2017/2/13 15:22
 * @Param
 * @Return
 */

public class NotificationTemplate implements Serializable {
  private static final long serialVersionUID = 9171113504124018759L;
  //模版ID
  private UUID id;
  //模版名
  private String name;

  //公司ID

  private RecruiterInfo recruiterInfo;

  //用户Id

  private RecruiterUser recruiterUser;

  //用户姓名
  private String userName;

  //模板类型
  private String type;

  //通知模版标题
  private String title;

  //通知模版内容
  //其他变量全部存储于content中，无需再额外定义address,telephone等变量
  private String content;
  //创建时间

  private LocalDateTime createdOn;
  //修改时间

  private LocalDateTime updatedOn;

  public static enum Type {
    EMAIL("邮件"), SMS("短信");
    public String value;

    /**
     * .
     *
     * @param value value
     */
    private Type(String value) {
      this.value = value;
    }
  }

  /**
   * .
   */
  public NotificationTemplate() {
  }

  public UUID getId() {
    return id;
  }

  public void setId(UUID id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public RecruiterUser getRecruiterUser() {
    return recruiterUser;
  }

  public void setRecruiterUser(RecruiterUser recruiterUser) {
    this.recruiterUser = recruiterUser;
  }

  public RecruiterInfo getRecruiterInfo() {
    return recruiterInfo;
  }

  public void setRecruiterInfo(RecruiterInfo recruiterInfo) {
    this.recruiterInfo = recruiterInfo;
  }

  public String getUserName() {
    return userName;
  }

  public void setUserName(String userName) {
    this.userName = userName;
  }

  public String getTitle() {
    return title;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public String getContent() {
    return content;
  }

  public void setContent(String content) {
    this.content = content;
  }

  public LocalDateTime getCreatedOn() {
    return createdOn;
  }

  public void setCreatedOn(LocalDateTime createdOn) {
    this.createdOn = createdOn;
  }

  public LocalDateTime getUpdatedOn() {
    return updatedOn;
  }

  public void setUpdatedOn(LocalDateTime updatedOn) {
    this.updatedOn = updatedOn;
  }
}
