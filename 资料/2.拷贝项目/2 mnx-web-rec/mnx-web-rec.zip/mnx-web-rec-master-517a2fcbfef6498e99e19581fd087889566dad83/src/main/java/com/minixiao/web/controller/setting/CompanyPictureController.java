package com.minixiao.web.controller.setting;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.minixiao.apiauth.client.HeaderUtil;
import com.minixiao.web.dto.recruiters.CompanyPictureDTO;
import com.minixiao.web.dto.recruiters.UserDTO;
import com.minixiao.web.utils.YmlConfig;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.UUID;

/**
 * Created by xiachao on 2017/3/1.
 */
@Controller
public class CompanyPictureController {

    private RestTemplate restTemplate = new RestTemplate();

    private ObjectMapper objectMapper = new ObjectMapper();

    @Autowired
    private YmlConfig ymlConfig;

    /**
     * @Description 公司logo上传.
     * @Author xiachao
     * @CreateTime 2017/3/1 13:49
     * @Param
     * @Return
     */
    @PostMapping("company/upload/logo")
    @ResponseBody
    public String uploadRecruiterLogo(@RequestParam MultipartFile filePic) {
        if (!filePic.isEmpty() ) {
            Subject subject = SecurityUtils.getSubject();
            if (subject != null) {
                UserDTO user = (UserDTO) subject.getSession().getAttribute(
                    ymlConfig.getSession_current_user());
                if (user != null) {
                    UUID userId2 = user.getId();
                    String userName = user.getRealName();
                    UUID recId2 = user.getRecId();
                    String recName = user.getRecName();
                    HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                        recId2, recName);
                    try {
                        byte[] fileByte = filePic.getBytes();
                        String fileName = filePic.getOriginalFilename();
                        String fileSuffix = fileName.substring(fileName.indexOf("."));
                        String contentType = filePic.getContentType().trim();
                        if ("image/jpeg".equals(contentType) || "image/png".equals(contentType) ||
                            "image/gif".equals(contentType) || "image/bmp".equals(contentType)) {
                            CompanyPictureDTO pictureDto = new CompanyPictureDTO();
                            pictureDto.setFileByte(fileByte);
                            pictureDto.setFileSuffix(fileSuffix);
                            pictureDto.setFileType("logo");
                            String requestBody = objectMapper.writeValueAsString(pictureDto);
                            httpHeaders.setContentType(MediaType.APPLICATION_JSON);
                            HttpEntity<String> httpEntity = new HttpEntity(requestBody, httpHeaders);
                            ResponseEntity<String> responseEntity = restTemplate.exchange(
                                ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2 + "/upload/logo",
                                HttpMethod.POST, httpEntity, String.class);
                            if (responseEntity != null) {
                                return responseEntity.getBody();
                            }
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        return null;
    }

    /**
     * @Description 公司图片上传.
     * @Author xiachao
     * @CreateTime 2017/3/1 13:49
     * @Param
     * @Return
     */
    @PostMapping("company/upload/picture")
    @ResponseBody
    public String uploadRecruiterPicture(@RequestParam MultipartFile filePic) {
        if (!filePic.isEmpty() ) {
            Subject subject = SecurityUtils.getSubject();
            if (subject != null) {
                UserDTO user = (UserDTO) subject.getSession().getAttribute(
                    ymlConfig.getSession_current_user());
                if (user != null) {
                    UUID userId2 = user.getId();
                    String userName = user.getRealName();
                    UUID recId2 = user.getRecId();
                    String recName = user.getRecName();
                    HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                        recId2, recName);
                    try {
                        byte[] fileByte = filePic.getBytes();
                        String fileName = filePic.getOriginalFilename();
                        String fileSuffix = fileName.substring(fileName.indexOf("."));
                        String contentType = filePic.getContentType().trim();
                        if ("image/jpeg".equals(contentType) || "image/png".equals(contentType) ||
                            "image/gif".equals(contentType) || "image/bmp".equals(contentType)) {
                            CompanyPictureDTO pictureDto = new CompanyPictureDTO();
                            pictureDto.setFileByte(fileByte);
                            pictureDto.setFileSuffix(fileSuffix);
                            pictureDto.setFileType("pic");
                            String requestBody = objectMapper.writeValueAsString(pictureDto);
                            httpHeaders.setContentType(MediaType.APPLICATION_JSON);
                            HttpEntity<String> httpEntity = new HttpEntity(requestBody, httpHeaders);
                            ResponseEntity<String> responseEntity = restTemplate.exchange(
                                ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2 + "/upload/picture",
                                HttpMethod.POST, httpEntity, String.class);
                            if (responseEntity != null) {
                                return responseEntity.getBody();
                            }
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        return null;
    }


    /**
     * @Description 公司图片删除.
     * @Author xiachao
     * @CreateTime 2017/3/1 17:38
     * @Param
     * @Return
     */
    @DeleteMapping("company/pictures/{id}")
    @ResponseBody
    public void deleteRecruiterPicture(@PathVariable UUID id, String picURL) {
        if ( id != null && picURL != null) {
            Subject subject = SecurityUtils.getSubject();
            if (subject != null) {
                UserDTO user = (UserDTO) subject.getSession().getAttribute(
                    ymlConfig.getSession_current_user());
                if (user != null) {
                    UUID userId2 = user.getId();
                    String userName = user.getRealName();
                    UUID recId2 = user.getRecId();
                    String recName = user.getRecName();
                    HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                        recId2, recName);
                    HttpEntity<String> httpEntity = new HttpEntity(null, httpHeaders);
                    restTemplate.exchange(
                        ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2 + "/pictures/" + id + "?picURL=" + picURL,
                        HttpMethod.DELETE, httpEntity, String.class);
                }
            }
        }
    }

}
