package cn.edu.dlut.career.recruiter.controller;

/**
 * Created by 史念念 on 2017/3/27.
 *
 * 招聘职位 查询
 */
public class RecruitJobQuery {
}
