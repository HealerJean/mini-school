// main modules routers
import Candidate from '../Components/Candidate/Candidate.vue';
import Dashboard from '../Components/Dashboard.vue';
import Setting from '../Components/Setting/Setting.vue';
import Report from '../Components/Report/Report.vue';
import Task from '../Components/Task/Task.vue';
import Job from '../Components/Job/Job.vue';
import Help from '../Components/Shared/Help.vue';
import About from '../Components/Shared/About.vue';

// module routers
import settingRouter from './setting/router.js';
import candidateRouter from './candidate/router.js';
import jobRouter from './job/router.js';

export default [{
    path: '/',
    component: Dashboard
}, {
    path: '/setting',
    component: Setting,
    children: settingRouter
}, {
    path: '/candidate',
    component: Candidate,
    children: candidateRouter
}, {
    path: '/report',
    component: Report
}, {
    path: '/task',
    component: Task
}, {
    path: '/job',
    component: Job,
    children: jobRouter
}, {
    path: '/help',
    component: Help
}, {
    path: '/about',
    component: About
}];
