<template>
    <el-dialog title="请选择所属部门" v-model="selectDepartmentVisible" :close-on-click-modal="false" :close-on-press-escape="false" @close="closeModal">
        <div>
            <div class="department-tree">
                <el-tree :data="departmentTree" :props="defaultProps" :highlight-current="true" node-key="deptId" ref="tree" :default-expand-all="true" @node-click="selectDepartment"></el-tree>
            </div>
        </div>
        <div slot="footer" class="dialog-footer">
            <el-button type="primary" @click="modalConfirm">确 定</el-button>
            <el-button @click="closeModal">取 消</el-button>
        </div>
    </el-dialog>
</template>

<script type="text/babel">
import eventBus from '../../js/shared/eventBus';

    export default {
        data() {
            return {
                departmentTree: [{
                    "id": "1ab28b34-4c36-4e5d-8092-1f1189d2f4e1",
                    "deptId": '10',
                    "name": "迷你校测试公司",
                    "createdOn": "20170304185637",
                    "updatedOn": "20170304185637",
                    "children": [{
                        "id": "58ebf871-d914-4e24-8f1d-c0c57176dfca",
                        "deptId": "1000",
                        "name": "迷你校上海分公司",
                        "createdOn": "20170304190041",
                        "updatedOn": "20170304190213",
                    }]
                }],
                checkedDepartmentName:'',
                checkedDepartmentId:'',
                departmentArray:[],
                defaultProps:{
                    children: 'children',
                    label: 'name'
                }
            }
        },
        computed: {
            selectDepartmentVisible(){
                return this.isSelectDepartment;
            },
            userId(){
                return this.$store.getters.userId
            },
            userName(){
                return this.$store.getters.userName
            },
            recId(){
                return this.$store.getters.recId
            }
        },
        methods: {
            selectDepartment(value) {
                this.checkedDepartmentName = value.name;
                this.checkedDepartmentId = value.id;
                console.log(this.checkedDepartmentName+this.checkedDepartmentId);
            },
            modalConfirm(checkedKeys) {
                if(this.checkedDepartmentId===''){
                    this.$message({
                        message: '请选择部门',
                        type: 'warning',
                        duration:2000
                    });
                    return;
                }
                this.$emit('modal:select-department', this.checkedDepartmentName,this.checkedDepartmentId);
                this.$emit('modal:select-department-closing');
            },
            closeModal() {
                this.$emit('modal:select-department-closing');
                this.checkedDepartmentName = '';
                this.checkedDepartmentId = '';
            },
            getDepartmentList(){
                this.$http.get('/company/departments').then(response =>{
                    let a = response.body;
                    this.departmentArray = a;
                    this.departmentTree = arrayToTree(this.departmentArray,'');
                })
            }
        },
        props: {
            isSelectDepartment: {
                type: Boolean,
                default: false
            }
        },
        mounted(){
            this.getDepartmentList();
        },
    }
    function arrayToTree(data,pid){
        let result = [];
        let temp;
        for(let i=0;i<data.length;i++){
            if(data[i].deptId.slice(0,-2) === pid){
                let obj = {"id":data[i].id,"deptId":data[i].deptId,"name":data[i].name,"createdOn":data[i].createdOn,"updatedOn":data[i].updatedOn};
                temp = arrayToTree(data,data[i].deptId);
                if(temp.length>0){
                    obj.children = temp;
                }
                result.push(obj);
            }
        }
        return result;
    }

</script>

<style lang="less">

</style>
