##  mnx数据库设计规范
### 数据库命名规范
1.  尽量简洁明义，能够一眼看出来这个数据库是用来做什么的；
2.  使用名词作为数据库名称，并且只用英文，不用中文拼音；
3.  使用英文字母，全部小写，如果有多个单词，则使用下划线隔开，不建义驼峰命名。

```sql
    create database notification default character set=utf8;
```
### 表命名规范
1. 表名用tb_开头
2. 具备统一前缀，对相关功能的表应当使用相同前缀，如stu_xxx，jpt_xxx；其中前缀通常为这个表的模块或依赖主实体对象的名字；
3. 表名使用英文小写单词，如果有多个单词则使用下划线隔开；
4.  默认使用utf8字符集

```sql
    CREATE TABLE tb_jpt_log (
        id uuid PRIMARY KEY  NOT NULL
    );
    COMMENT ON TABLE tb_jpt_log is '职位公告日志表';
```
### 字段命名规范
1. 数据库字段命名与表名命名类似,使用英文小写单词，如果有多个单词则使用下划线隔开
2. 字段应当有注释，描述该字段的用途及可能存储的内容，如枚举值则建议将该字段中使用的内容都定义出来
3. 建议均使用uuid类型的id作为主键；
4. 约定使用id字段作为主键字段，外键字段约定使用外键相关表名_id，或表名缩写_id。例如rec_id



```sql
    CREATE TABLE tb_jpt_log (
        id uuid PRIMARY KEY  NOT NULL,
        job_posting_id uuid NOT NULL,
        user_agent varchar NOT NULL,
        user_ip varchar NOT NULL,
        user_cookies varchar,
        access_time timestamp(6),
    );
    COMMENT ON COLUMN  "tb_jpt_log"."id" IS  '职位公告日志的唯一识别ID';
    COMMENT ON COLUMN  "tb_jpt_log"."job_posting_id" IS  '职位公告的唯一识别ID';
    COMMENT ON COLUMN  "tb_jpt_log"."user_agent" IS  '访问用户信息';
    COMMENT ON COLUMN  "tb_jpt_log"."user_ip" IS  '访问用户IP';
    COMMENT ON COLUMN  "tb_jpt_log"."user_cookies" IS  '访问用户cookie信息';
    COMMENT ON COLUMN  "tb_jpt_log"."access_time" IS  '访问时间';
```
### 视图命名规范
1. 视图用v_开头

### 序列命名规范
1. 序列用seq_开头

### 一般字段的名称参考
*   创建时间：created_on
*   更新时间：updated_on
