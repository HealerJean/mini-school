<template>

    <router-view></router-view>

</template>

<script type="text/babel">

    export default {
        name: 'setting',
        data:function(){
            return{

            }
        }
    }

</script>

<style>

</style>
