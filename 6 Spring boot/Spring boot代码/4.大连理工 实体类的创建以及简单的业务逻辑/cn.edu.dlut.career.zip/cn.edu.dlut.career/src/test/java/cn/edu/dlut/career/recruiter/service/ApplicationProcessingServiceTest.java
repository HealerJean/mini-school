package cn.edu.dlut.career.recruiter.service;

import cn.edu.dlut.career.recruiter.domain.ApplicationProcessing;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

import static org.junit.Assert.*;

/**
 * Created by wei on 2017/3/24.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class ApplicationProcessingServiceTest {
  @Resource ApplicationProcessingService applicationProcessingService;
  @Test
  public void save() throws Exception {
    DateTimeFormatter ymd = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    LocalDateTime localDate =LocalDateTime.parse("2015-11-23 11:00:00", ymd);
    ApplicationProcessing applicationProcessing  =new ApplicationProcessing();
    applicationProcessing.setId(UUID.randomUUID().toString());
    applicationProcessing.setReqId(UUID.randomUUID().toString());
    applicationProcessing.setProcessingTime(localDate);
    applicationProcessing.setRemarks("这是一条测试数据");
    applicationProcessing.setStatus("1");
    applicationProcessingService.save(applicationProcessing);
  }

  @Test
  public void delete() throws Exception {
    applicationProcessingService.delete("402881b55afe3f62015afe3f774f0000");
  }

  @Test
  public void update() throws Exception {
    ApplicationProcessing applicationProcessing = applicationProcessingService.findOne("402881b55afe3f62015afe3f774f0000");
applicationProcessing.setStatus("0");
applicationProcessing.setRemarks("修改了");
applicationProcessingService.update(applicationProcessing);
  }

  @Test
  public void findAll() throws Exception {
    applicationProcessingService.findAll();
  }

}