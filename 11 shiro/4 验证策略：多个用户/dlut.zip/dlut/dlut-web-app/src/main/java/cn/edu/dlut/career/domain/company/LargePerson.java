package cn.edu.dlut.career.domain.company;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 大型招聘会企业代表人
 * Created by HealerJean on 2017/3/23.
 */
@Entity
@Table(name="rec_large_person")
public class LargePerson {

    // 编号id
    @Id
    @GenericGenerator(name = "idGenerator", strategy = "uuid")
    @GeneratedValue(generator = "idGenerator")
    private  String id;

    //预约编号orderId
    private String orderId;

    //姓名
    @Column(length = 20)
     private  String name;

    //职务rank
    @Column(length = 20)
    private  String rank;

    //手机号phone
     @Column(length = 20)
    private String phone;

     //房间号roomNumber
     @Column(length = 20)
     private String roomNumber;

    public LargePerson() {
    }


    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }



    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }
}
