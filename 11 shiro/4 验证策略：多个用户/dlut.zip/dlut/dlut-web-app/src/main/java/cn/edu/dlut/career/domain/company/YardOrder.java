package cn.edu.dlut.career.domain.company;

/**
 * Created by HealerJean on 2017/3/23.
 */


import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * 场地预约表
* Created by 张宇晋 on 2017/3/23.
 */

@Entity
@Table(name = "rec_yard_order")
public class YardOrder implements Serializable {

    private static final long SERIVALVERSIONUID = 876280513342148585L;

    //编号id
    @Id
    @GenericGenerator(name = "idGenerator", strategy = "uuid")
    @GeneratedValue(generator = "idGenerator")
    private String id;

    //企业编号 recId
    private UUID recId;

    //场地要求 requirements
    @Column(length = 100)
    private String requirements;

    //场地数量quantity
    private int quantity;

    //场地规模scale
    @Column(length = 50)
    private String scale;

    //场地用途use
    @Column(length = 300)
    private String use;

    //场地地址address
    @Column(length = 100)
    private String address;

    //预约提交时间orderSubmissionTime
    @CreationTimestamp
    private LocalDateTime orderSubTime ;

    //使用开始时间useStartTime
    private LocalDateTime useStartTime  ;

    //使用结束时间useEndTime
    private LocalDateTime useEndTime  ;

    //接待人recepPerson
    @Column(length = 20)
    private String recepPerson;

    //审核状态auditState
    @Column(length = 10)
    private String auditState;

    //审核时间auditTime
    private LocalDateTime auditTime   ;

    //审核人auditPerson
    @Column(length = 32)
    private String auditPerson;

    //展厅名称
    @Column(length = 30)
    private String exhName;

    public String getExhName() {
        return exhName;
    }

    public void setExhName(String exhName) {
        this.exhName = exhName;
    }

    public UUID getRecId() {
        return recId;
    }

    public void setRecId(UUID recId) {
        this.recId = recId;
    }



    public YardOrder() {
    }

    public String getRequirements() {
        return requirements;
    }

    public void setRequirements(String requirements) {
        this.requirements = requirements;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getScale() {
        return scale;
    }

    public void setScale(String scale) {
        this.scale = scale;
    }

    public String getUse() {
        return use;
    }

    public void setUse(String use) {
        this.use = use;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAuditState() {
        return auditState;
    }

    public void setAuditState(String auditState) {
        this.auditState = auditState;
    }

    public String getAuditPerson() {
        return auditPerson;
    }

    public void setAuditPerson(String auditPerson) {
        this.auditPerson = auditPerson;
    }

    public static long getSERIVALVERSIONUID() {
        return SERIVALVERSIONUID;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }


    public LocalDateTime getOrderSubTime() {
        return orderSubTime;
    }

    public void setOrderSubTime(LocalDateTime orderSubTime) {
        this.orderSubTime = orderSubTime;
    }

    public LocalDateTime getUseStartTime() {
        return useStartTime;
    }

    public void setUseStartTime(LocalDateTime useStartTime) {
        this.useStartTime = useStartTime;
    }

    public LocalDateTime getUseEndTime() {
        return useEndTime;
    }

    public void setUseEndTime(LocalDateTime useEndTime) {
        this.useEndTime = useEndTime;
    }

    public String getRecepPerson() {
        return recepPerson;
    }

    public void setRecepPerson(String recepPerson) {
        this.recepPerson = recepPerson;
    }


    public LocalDateTime getAuditTime() {
        return auditTime;
    }

    public void setAuditTime(LocalDateTime auditTime) {
        this.auditTime = auditTime;
    }


}

