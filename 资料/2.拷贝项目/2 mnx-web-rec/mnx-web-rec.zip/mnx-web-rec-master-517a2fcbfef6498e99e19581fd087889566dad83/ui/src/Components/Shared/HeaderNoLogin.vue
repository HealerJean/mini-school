<template>
    <header class="header">
        <div class="inner">
            <el-row>
                <el-col :span="3">
                    <img class="header-logo" src="../../img/common/minixiao-logo.png" alt="迷你校LOGO"/>
                </el-col>
                <el-col :span="21" class="head-login-r">
                    <ul class="head-nologin-r">
                        <li v-for="item in headerRight">
                            <i :class='item.className'></i>
                            {{item.txt}}
                            <div v-if="item.className === 'cpL-wx'" class="qr-img">
                                <img src='../../img/common/QR_com_t.png'>
                            </div>
                        </li>
                    </ul>
                </el-col>
            </el-row>
        </div>
    </header>
</template>

<script>
  export default {
    data:function(){
      return {
        headerRight:[
          {className:'cpL-wx',txt:'企业服务微信'},
          {className:'cpL-email',txt:'bd@minixiao.com'},
          {className:'cpL-tel',txt:'010-56261180 (销售热线)'}
        ]
      }
    }
  }
</script>
