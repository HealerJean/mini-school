package cn.edu.dlut.career.service.company;


import cn.edu.dlut.career.domain.company.RecruitmentSetUp;

import java.util.List;

/**
 * Created by wei on 2017/3/27.
 */
public interface RecruitmentSetUpService {
  void save(RecruitmentSetUp recruitmentSetUp);

  void delete(String id);

  List<RecruitmentSetUp> findAll();

  RecruitmentSetUp finOne(String id);

}
