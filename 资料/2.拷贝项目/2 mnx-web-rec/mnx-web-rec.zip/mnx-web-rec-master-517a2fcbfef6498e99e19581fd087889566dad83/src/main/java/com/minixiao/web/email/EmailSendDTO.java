package com.minixiao.web.email;

import java.util.UUID;

/**
 *
 * @Author wangyj.
 * @Date 2017/3/13  15:10.
 */
public class EmailSendDTO {

    private UUID candidateId;

    private String candidateName;

    private UUID jobId;

    private String jobName;

    private String email;

    public EmailSendDTO() {
    }

    public String getCandidateName() {
        return candidateName;
    }

    public void setCandidateName(String candidateName) {
        this.candidateName = candidateName;
    }

    public String getJobName() {
        return jobName;
    }

    public void setJobName(String jobName) {
        this.jobName = jobName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public UUID getCandidateId() {
        return candidateId;
    }

    public void setCandidateId(UUID candidateId) {
        this.candidateId = candidateId;
    }

    public UUID getJobId() {
        return jobId;
    }

    public void setJobId(UUID jobId) {
        this.jobId = jobId;
    }
}
