<template>
    <div class="tags-manage">
        <div>我的位置：
            <el-breadcrumb separator=">">
                <el-breadcrumb-item>系统设置</el-breadcrumb-item>
                <el-breadcrumb-item>标签管理</el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        <div class="tags-body">
            <div class="tags-hint">
                <p>提示1：已被使用的标签将无法被删除，未被使用的标签可以进行删除操作；</p>
                <p>提示2：已被使用的标签可进行“停用”操作。“停用”后，该标签将在简历打标签时自动隐藏，所有人都不可使用该标签。</p>
            </div>
            <div class="filter-add">
                <el-button type="primary" @click="createTag">+添加标签</el-button>
                    <div v-on:keyup.enter="search" class="filter-search">
                        <el-input placeholder="请输入标签名称" icon="search" v-model="tagName" :on-icon-click="search" >
                    </el-input>
                </div>
            </div>
            <create-candidate-tag-modal :iscreateTag="iscreateTag" @createTag="makeSureCreateTag" @closeCreatetag="closeCreatetag"></create-candidate-tag-modal>

            <el-table :data="tagsList" style="width:100%" :row-style="rowStyle">
                <el-table-column  label="序号" type="index" width="100" header-align="center" align="center">
                </el-table-column>
                <el-table-column prop="name" label="标签" header-align="center" align="center">
                </el-table-column>
                <el-table-column prop="status" label="状态" header-align="center" align="center" :formatter="statusFormatter">
                </el-table-column>
                <el-table-column prop="updatedOn" label="创建/修改时间" header-align="center"  align="center" :formatter="formatDate">
                </el-table-column>
                <el-table-column label="操作" header-align="center" align="center">
                    <template scope="scope">
                        <span style="line-height: 58px;">
                            <el-button type="text" @click="startUseing(scope.row)" :disabled="scope.row.status">启用</el-button>
                            <el-button type="text" @click="serviceOut(scope.row)" :disabled="!scope.row.status">停用</el-button>
                            <el-button type="text" @click="remove(scope.row)">删除</el-button>
                        </span>
                    </template>
                </el-table-column>
            </el-table>

        </div>
    </div>
</template>

<script type="text/babel">
import CreateCandidateTagModal from '../Modal/CreateCandidateTagModal.vue';
    export default {
        name: 'tags',
        data:function(){
            return{
                tagName:'',
                iscreateTag:false
            }
        },
        methods:{
            rowStyle(row){
                if(!row.name.includes(this.tagName)){
                    return "display:none;";
                }
            },
            getTagsList(){
                console.log('获取候选人标签列表')
                this.$http.get('company/labels').then(response =>{
                    let a = response.body;
                    console.log(a);
                    //存到状态库中

                    this.$store.commit('updateTagsList' , a);
                })
            },
            createTag(){
                this.iscreateTag = true;
            },
            //创建标签请求
            makeSureCreateTag(value){
                this.$http.post('company/label?name='+value).then(response =>{
                    if(response.status==200){
                        this.$message({
                            message: '操作成功',
                            duration:2000
                        });
                    }else{
                        this.$message({
                            message: '操作失败',
                            duration:2000
                        });
                    }
                    this.getTagsList();
                })
            },
            closeCreatetag(){
                this.iscreateTag = false;
            },
            search(){
                console.log('搜索标签')
            },
            startUseing(value){
                console.log('启用标签')
                this.$http.put('company/labels/'+value.id+'/status?status='+true).then(response =>{
                    if(response.status==200){
                        this.$message({
                            message: '操作成功',
                            duration:2000
                        });
                    }else{
                        this.$message({
                            message: '操作失败',
                            duration:2000
                        });
                    }
                    this.getTagsList();
                })
            },
            serviceOut(value){
                console.log('停用标签')
                this.$http.put('company/labels/'+value.id+'/status?status='+false).then(response =>{
                    if(response.status==200){
                        this.$message({
                            message: '操作成功',
                            duration:2000
                        });
                    }else{
                        this.$message({
                            message: '操作失败',
                            duration:2000
                        });
                    }
                    this.getTagsList();
                })
            },
            //删除标签
            remove(value){
                this.$http.delete('company/labels/'+value.id).then(response =>{
                    if(response.status==200){
                        this.$message({
                            message: '操作成功',
                            duration:2000
                        });
                    }else{
                        this.$message({
                            message: '操作失败',
                            duration:2000
                        });
                    }
                    this.getTagsList();
                })

            },
            statusFormatter(row){
                if(row.status){
                    return "正常"
                }else{
                    return "停用"
                }
            },
            formatDate(val) {
                if(val){
                    return val.updatedOn.substring(0,4)+'-'+val.updatedOn.substring(4,6)+'-'+val.updatedOn.substring(6,8);
                }
            },
        },
        computed:{
            tagsList(){
                return this.$store.state.candidate.tagsList
            },
            userId(){
                return this.$store.getters.userId
            },
            userName(){
                return this.$store.getters.userName
            },
            recId(){
                return this.$store.getters.recId
            }
        },
        mounted(){
            this.getTagsList();
        },
        components:{
            CreateCandidateTagModal
        }
    }

</script>

<style lang="less">
    .tags-manage {
        .el-breadcrumb {
            display: inline-block;
        }
        .tags-body {
            background-color: #ffffff;
            margin-top: 20px;

            .filter-add {
               // background-color: #dddddd;
                margin-top: 20px;
                margin-bottom: 20px;
                .filter-search {
                    float: right;
                    width:286px;
                    height:34px;
                    .el-input__inner {
                        height:34px;
                        padding-left: 30px;
                    }
                    .el-input__icon {
                        cursor: pointer;
                        left:0;
                    }
                }
            }
            .tags-hint {
                padding: 10px;
                background-color: #ffd86f;
            }
            .el-table {
                .el-button {
                    padding:0;
                }
            }
        }
    }
</style>
