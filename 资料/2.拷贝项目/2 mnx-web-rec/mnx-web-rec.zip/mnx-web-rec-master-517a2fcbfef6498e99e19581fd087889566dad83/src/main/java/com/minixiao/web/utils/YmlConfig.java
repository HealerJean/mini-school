package com.minixiao.web.utils;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * 读取yml文件中的配置
 *
 * @Author JiangYh.
 * @Date 2017/3/7  10:15.
 */
@Component
@ConfigurationProperties(prefix="mnxProps") //application.yml中的mnxProps下的属性
public class YmlConfig {
    private String session_current_user;

    private String url_api_recruiter;

    private String url_api_recruit_info;

    public String getSession_current_user() {
        return session_current_user;
    }

    public void setSession_current_user(String session_current_user) {
        this.session_current_user = session_current_user;
    }

    public String getUrl_api_recruiter() {
        return url_api_recruiter;
    }

    public void setUrl_api_recruiter(String url_api_recruiter) {
        this.url_api_recruiter = url_api_recruiter;
    }

    public String getUrl_api_recruit_info() {
        return url_api_recruit_info;
    }

    public void setUrl_api_recruit_info(String url_api_recruit_info) {
        this.url_api_recruit_info = url_api_recruit_info;
    }
}
