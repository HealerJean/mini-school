package com.minixiao.web.controller.candidate;

import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.draw.LineSeparator;
import com.minixiao.apiauth.client.HeaderUtil;
import com.minixiao.web.dto.candidate.ApplicationListDTO;
import com.minixiao.web.dto.candidate.Basic;
import com.minixiao.web.dto.candidate.Education;
import com.minixiao.web.dto.candidate.Language;
import com.minixiao.web.dto.candidate.Skills;
import com.minixiao.web.dto.candidate.AppDetailDTO;
import com.minixiao.web.dto.recruiters.UserDTO;
import com.minixiao.web.utils.YmlConfig;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.client.RestTemplate;

import javax.servlet.http.HttpServletResponse;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.Date;
import java.util.Map;
import java.util.UUID;

/**
 * 以pdf形式导出申请表
 *
 * @Author wangyj.
 * @Date 2017/3/7  10:15.
 */
@Controller
public class AppExportPdfController {

    @Autowired
    private YmlConfig ymlConfig;

    private RestTemplate restTemplate = new RestTemplate();


    @GetMapping("candidate/{id}/application/pdf")
    public void exportPdf(@PathVariable UUID id, HttpServletResponse response) throws Exception {

        ApplicationListDTO responseEntity = null;
        Subject subject = SecurityUtils.getSubject();
        AppDetailDTO appDetailDTO = null;
        if (subject != null) {
            UserDTO user = (UserDTO) subject.getSession().getAttribute(ymlConfig.getSession_current_user());
            if (user != null) {
                UUID recId = user.getRecId();
                UUID optUid = user.getId();
                String optName = user.getRealName();
                String recName = user.getRecName();
                HttpHeaders requestHeaders = HeaderUtil.getHeader(optUid, optName, "COMPANY", recId,
                    recName);
                HttpEntity requestEntity = new HttpEntity(null, requestHeaders);
                appDetailDTO = restTemplate.exchange(
                    ymlConfig.getUrl_api_recruiter() + "candidate/{id}", HttpMethod.GET, requestEntity,
                    AppDetailDTO.class, id).getBody();
            }
        }
        response.setCharacterEncoding("UTF-8");
        response.setHeader("content-Type", "application/pdf");
        // 下载文件的默认名称
        String pdfName = appDetailDTO.getBasic().getName() + "简历" + new Date().getTime() + ".pdf";
        response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(pdfName, "UTF-8"));
        if (appDetailDTO != null) {
            PdfPCell cell1 = null;

            // 1.新建document对象
            // 第一个参数是页面大小。接下来的参数分别是左、右、上和下页边距。

            Document document = new Document(PageSize.A4, 50, 50, 50, 50);
            OutputStream out =response.getOutputStream();
            PdfWriter.getInstance(document, response.getOutputStream());
            // 2.建立一个书写器(Writer)与document对象关联，通过书写器(Writer)可以将文档写入到磁盘中。
            //PdfWriter writer = PdfWriter.getInstance(document,new FileOutputStream(outFile));
            // 3.打开文档
            document.open();
            BaseFont baseFontChinese = BaseFont.createFont("STSong-Light", "UniGB-UCS2-H", BaseFont.NOT_EMBEDDED);
            Font fontChinese = new Font(baseFontChinese, 11, Font.NORMAL);
            Font font_2 = new Font(baseFontChinese, 12, Font.BOLD);
            Font font = new Font(baseFontChinese, 14, Font.BOLD);

            // 4.向文档中添加内容
            Paragraph paragraph = new Paragraph(appDetailDTO.getBasic().getName() + "个人简历", new Font(baseFontChinese, 18, Font.BOLD));
            paragraph.setAlignment(1); //  设置段落居中
            paragraph.setLeading(7.0f);
            ;  //设置段落与其上方的距离
            document.add(paragraph);
            document.add(new Paragraph("\n"));
            document.add(new Paragraph("基本信息", font));
        /*
             * 基本信息
			 */
            Paragraph p1 = new Paragraph();
            p1.add(new Chunk(new LineSeparator()));  //输出分隔线
            document.add(p1);
            document.add(new Paragraph("\n"));
            //输出一个表格
            PdfPTable table = new PdfPTable(6);
            Basic basic = appDetailDTO.getBasic();
            //第一行
            cell1 = new PdfPCell(new Phrase("姓名", fontChinese));
            cell1.setBorderWidth(0);
            cell1.setPadding(6.5f);
            table.addCell(cell1);
            cell1 = new PdfPCell(new Phrase((String) ((basic.getName() != null) ? (basic.getName()) : ""), fontChinese));
            cell1.setPadding(6.5f);
            cell1.setBorderWidth(0);
            table.addCell(cell1);
            cell1 = new PdfPCell(new Phrase(""));
            cell1.setBorderWidth(0);
            cell1.setPadding(6.5f);
            table.addCell(cell1);
            cell1 = new PdfPCell(new Phrase(""));
            cell1.setBorderWidth(0);
            cell1.setPadding(6.5f);
            table.addCell(cell1);

            cell1 = new PdfPCell(new Phrase(""));
            cell1.setBorderWidth(0);
            cell1.setPadding(6.5f);
            table.addCell(cell1);
            cell1 = new PdfPCell(new Phrase(""));
            cell1.setBorderWidth(0);
            cell1.setPadding(6.5f);
            table.addCell(cell1);
            //第二行
            cell1 = new PdfPCell(new Phrase("性别", fontChinese));
            cell1.setBorderWidth(0);
            cell1.setPadding(6.5f);
            table.addCell(cell1);
            cell1 = new PdfPCell(new Phrase((String) ((basic.getGender() != null) ? (basic.getGender()) : ""), fontChinese));
            cell1.setBorderWidth(0);
            cell1.setPadding(6.5f);
            table.addCell(cell1);
            cell1 = new PdfPCell(new Phrase("出生日期", fontChinese));
            cell1.setBorderWidth(0);
            cell1.setPadding(6.5f);
            table.addCell(cell1);
            cell1 = new PdfPCell(new Phrase((String) ((basic.getBirthday() != null) ? (basic.getBirthday()) : ""), fontChinese));
            cell1.setBorderWidth(0);
            cell1.setPadding(6.5f);
            table.addCell(cell1);
            cell1 = new PdfPCell(new Phrase("政治面貌", fontChinese));
            cell1.setBorderWidth(0);
            cell1.setPadding(6.5f);
            table.addCell(cell1);
            cell1 = new PdfPCell(new Phrase((String) ((basic.getPolitical() != null) ? (basic.getPolitical()) : ""), fontChinese));
            cell1.setBorderWidth(0);
            cell1.setPadding(6.5f);
            table.addCell(cell1);
            //第三行
            cell1 = new PdfPCell(new Phrase("家庭住址", fontChinese));
            cell1.setBorderWidth(0);
            cell1.setPadding(6.5f);

            table.addCell(cell1);
            cell1 = new PdfPCell(new Phrase((String) ((basic.getCity() != null) ? (basic.getCity()) : ""), fontChinese));
            cell1.setBorderWidth(0);
            cell1.setPadding(6.5f);
            table.addCell(cell1);
            cell1 = new PdfPCell(new Phrase("", fontChinese));
            cell1.setBorderWidth(0);
            cell1.setPadding(6.5f);
            table.addCell(cell1);
            cell1 = new PdfPCell(new Phrase("", fontChinese));
            cell1.setBorderWidth(0);
            cell1.setPadding(6.5f);
            table.addCell(cell1);
            cell1 = new PdfPCell(new Phrase("", fontChinese));
            cell1.setBorderWidth(0);
            cell1.setPadding(6.5f);
            table.addCell(cell1);
            cell1 = new PdfPCell(new Phrase("", fontChinese));
            cell1.setBorderWidth(0);
            cell1.setPadding(6.5f);
            table.addCell(cell1);
            //第四行
            cell1 = new PdfPCell(new Phrase("手机号码", fontChinese));
            cell1.setBorderWidth(0);
            cell1.setPadding(6.5f);
            table.addCell(cell1);
            cell1 = new PdfPCell(new Phrase((String) ((basic.getMobile() != null) ? (basic.getMobile()) : ""), fontChinese));
            cell1.setBorderWidth(0);
            cell1.setPadding(6.5f);
            table.addCell(cell1);
            cell1 = new PdfPCell(new Phrase("常用邮箱", fontChinese));
            cell1.setBorderWidth(0);
            cell1.setPadding(6.5f);
            table.addCell(cell1);
            PdfPCell cell_e = new PdfPCell(new Phrase((String) ((basic.getEmail() != null) ? (basic.getEmail()) : ""), fontChinese));
            cell_e.setBorderWidth(0);
            cell_e.setPadding(6.5f);
            cell_e.setColspan(2);
            table.addCell(cell_e);
            cell1 = new PdfPCell(new Phrase(""));
            cell1.setBorderWidth(0);
            cell1.setPadding(6.5f);
            table.addCell(cell1);
            cell1 = new PdfPCell(new Phrase(""));
            cell1.setBorderWidth(0);
            cell1.setPadding(6.5f);
            table.addCell(cell1);
            //99%
            table.setWidthPercentage(99);
            document.add(table);

            /**
             * 教育经历
             */
            document.add(new Paragraph("\n"));
            document.add(new Paragraph("教育经历", font));
            document.add(p1);
            document.add(new Paragraph("\n"));
            Education[] educations = appDetailDTO.getEducation();

            for (Education edu : educations) {
                PdfPTable edu_table = new PdfPTable(4);
                cell1 = new PdfPCell(
                    new Phrase(((edu.getStartDate() != null) ? (edu.getStartDate()) : "") + "至"
                        + ((edu.getEndDate() != null) ? (edu.getEndDate()) : ""), fontChinese));
                cell1.setBorderWidth(0);
                cell1.setPadding(6.5f);
                edu_table.addCell(cell1);
                cell1 = new PdfPCell(new Phrase((String) ((edu.getSchool() != null) ? (edu.getSchool()) : ""), fontChinese));
                cell1.setBorderWidth(0);
                cell1.setPadding(6.5f);
                edu_table.addCell(cell1);
                cell1 = new PdfPCell(new Phrase((String) ((edu.getMajor() != null) ? (edu.getMajor()) : ""), fontChinese));
                cell1.setBorderWidth(0);
                cell1.setPadding(6.5f);
                edu_table.addCell(cell1);
                cell1 = new PdfPCell(new Phrase((String) ((edu.getRank() != null) ? (edu.getRank()) : ""), fontChinese));
                cell1.setBorderWidth(0);
                cell1.setPadding(6.5f);
                edu_table.addCell(cell1);
                cell1.setBorderWidth(0);
                cell1.setPadding(6.5f);
                edu_table.addCell(cell1);
                edu_table.setWidthPercentage(99);
                document.add(edu_table);
            }
            /**
             * 实习经历
             */
            document.add(new Paragraph("\n"));
            document.add(new Paragraph("实习经历", font));
            document.add(p1);
            document.add(new Paragraph("\n"));

            PdfPTable work_table = new PdfPTable(1);
            PdfPCell cell_d1 = new PdfPCell(new Phrase((String) ((appDetailDTO.getWork() != null) ? (appDetailDTO.getWork()) : ""), fontChinese));
            cell_d1.setBorderWidth(0);
            //cell_d1.setPadding(6.5f);
            work_table.addCell(cell_d1);
            document.add(work_table);
            /**
             * 项目经验
             */
            document.add(new Paragraph("\n"));
            document.add(new Paragraph("项目经验", font));
            document.add(p1);
            document.add(new Paragraph("\n"));

            PdfPTable prac_table = new PdfPTable(1);
            PdfPCell cell_d2 = new PdfPCell(new Phrase((String) ((appDetailDTO.getPractices() != null) ? (appDetailDTO.getPractices()) : ""), fontChinese));
            cell_d2.setBorderWidth(0);
            //cell_d1.setPadding(6.5f);
            prac_table.addCell(cell_d2);
            document.add(prac_table);


            /**
             * 获奖荣誉
             */
            if (appDetailDTO.getReward() != null) {
                document.add(new Paragraph("\n"));
                document.add(new Paragraph("获奖荣誉", font));
                document.add(p1);
                document.add(new Paragraph("\n"));
                PdfPTable rewardTable = new PdfPTable(1);
                PdfPCell cell_d3 = new PdfPCell(new Phrase((String) ((appDetailDTO.getReward() != null) ? (appDetailDTO.getReward()) : ""), fontChinese));
                cell_d3.setBorderWidth(0);
                rewardTable.addCell(cell_d3);
                document.add(rewardTable);
            }

            /**
             * 技能/证书
             */
            document.add(new Paragraph("\n"));
            document.add(new Paragraph("技能/证书", font));
            document.add(p1);
            document.add(new Paragraph("\n"));
            //语言能力
            document.add(new Paragraph("   | 语言能力", font_2));
            document.add(new Paragraph("\n"));
            Language[] language = appDetailDTO.getLanguage();
            for (Language lan : language) {
                PdfPTable languageTable = new PdfPTable(2);
                PdfPCell cell4 = new PdfPCell(new Phrase((String) ((lan.getType() != null) ? (lan.getType()) : ""), fontChinese));
                cell4.setBorderWidth(0);
                cell4.setPadding(6.5f);
                languageTable.addCell(cell4);
                cell4 = new PdfPCell(new Phrase((String) ((lan.getLevel() != null) ? (lan.getLevel()) : ""), fontChinese));
                cell4.setBorderWidth(0);
                cell4.setPadding(6.5f);
                languageTable.addCell(cell4);
                document.add(languageTable);
            }
            //技能
            if (appDetailDTO.getSkills() != null) {
                document.add(new Paragraph("   | 技能", font_2));
                document.add(new Paragraph("\n"));
                Skills[] skills = appDetailDTO.getSkills();
                for (Skills skill : skills) {
                    PdfPTable languageTable = new PdfPTable(2);
                    PdfPCell cell4 = new PdfPCell(new Phrase((String) ((skill.getType() != null) ? (skill.getType()) : ""), fontChinese));
                    cell4.setBorderWidth(0);
                    cell4.setPadding(6.5f);
                    languageTable.addCell(cell4);
                    cell4 = new PdfPCell(new Phrase((String) ((skill.getLevel() != null) ? (skill.getLevel()) : ""), fontChinese));
                    cell4.setBorderWidth(0);
                    cell4.setPadding(6.5f);
                    languageTable.addCell(cell4);
                    document.add(languageTable);
                }
            }

            //证书
            if (appDetailDTO.getCertificate() != null) {
                document.add(new Paragraph("   | 证书", font_2));
                document.add(new Paragraph("\n"));
                PdfPTable certificateTable = new PdfPTable(1);
                PdfPCell cell5 = new PdfPCell(new Phrase((String) ((appDetailDTO.getCertificate() != null) ? (appDetailDTO.getCertificate()) : ""), fontChinese));
                cell5.setBorderWidth(0);
                cell5.setPadding(6.5f);
                certificateTable.addCell(cell5);
                document.add(certificateTable);
            }

            /**
             * 定制信息
             */
            document.add(new Paragraph("\n"));
            document.add(new Paragraph("定制信息", font));
            document.add(p1);
            document.add(new Paragraph("\n"));
            if (appDetailDTO.getMetaData() != null) {
                Map<String, String> map = (Map<String, String>) appDetailDTO.getMetaData();
                for (String key : map.keySet()) {
                    PdfPTable metedateTable = new PdfPTable(2);
                    PdfPCell cell5 = new PdfPCell(new Phrase((String) (key), fontChinese));
                    cell5.setBorderWidth(0);
                    cell5.setPadding(6.5f);
                    metedateTable.addCell(cell5);
                    cell5 = new PdfPCell(new Phrase((String) (map.get(key)), fontChinese));
                    cell5.setBorderWidth(0);
                    cell5.setPadding(6.5f);
                    metedateTable.addCell(cell5);
                    document.add(metedateTable);
                }
            }
            //文档关闭
            document.close();
            out.flush();
            out.close();
        }
    }


}
