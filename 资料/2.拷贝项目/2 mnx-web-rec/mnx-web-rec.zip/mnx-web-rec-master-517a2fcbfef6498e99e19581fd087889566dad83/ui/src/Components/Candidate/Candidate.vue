<template>

    <router-view></router-view>

</template>

<script type="text/babel">

    export default {
        name: 'candidate',
        data() {
            return  {};
        }
    }

</script>

<style>

</style>