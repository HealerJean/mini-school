<template>
    <div class="candidate-modal" >

        <div class="candidate-filter">
            <el-form label-width="100px">
                <el-row :gutter="70">
                    <el-col :span="8">
                        <p style="line-height:30px; margin:0;">条件查询</p>
                    </el-col>
                    <el-col :span="8" :offset="8">
                        <el-form-item label="筛选器">
                            <el-select v-model="sizer" placeholder="请选择" size="small">
                                <el-option label="不限" :value="nullFilter"></el-option>
                                <el-option v-for="item in filterList" :label="item.name" :value="item" >
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                </el-row>
            </el-form>
        </div>
        <el-form ref="" :model="CandidateQueryForm" label-width="100px">
            <div class= "select-default-preliminary input-size-md" v-if="!isOpened">
                <el-row :gutter="70">
                    <el-col :span="8">
                        <el-form-item label="投递职位">
                            <el-select v-model="position" placeholder="不限" >
                                <el-option v-for="item in jobList" :label="item" :value="item">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="最高学历">
                            <el-select v-model="degree" placeholder="不限" >
                                <el-option v-for="item in degreeItems" :label="item.label" :value="item.value">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="毕业院校">
                            <el-input v-model="school" @focus="isSelectUniversity=true" readonly placeholder="请选择"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>

                <el-row :gutter="70">

                    <el-col :span="8">
                        <el-form-item label="专业">
                            <el-input v-model="major"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="处理状态">
                            <el-select v-model="status" placeholder="不限" >
                                <el-option v-for="item in statusItems" :label="item.label" :value="item.value">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="简历标签">
                            <el-select v-model="label" placeholder="不限" multiple>
                                <el-option v-for="item in tagsList" :label="item.name" :value="item.name" v-if="item.status">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                </el-row>

                <el-row :gutter="70">

                    <el-col :span="8">
                        <el-form-item label="性别">
                            <el-select v-model="gender" placeholder="不限" >
                                <el-option v-for="item in genderItems" :label="item.label" :value="item.value">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="聘用部门">
                            <el-input v-model="department" @focus="selectDepartment" readonly placeholder="请选择"></el-input>
                        </el-form-item>

                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="专业排名">
                            <el-select v-model="rank" placeholder="不限">
                                <el-option v-for="item in rankItems" :label="item.label" :value="item.value">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                </el-row>

                <div class="button-preliminary">
                    <el-button type="primary" class="my-button" @click='findCandidates'>查询</el-button>
                    <el-button class="my-button gray-button" @click="resetFilter">重置</el-button>
                    <el-button type="text"  class="saveSizer" @click="saveSizer">存为筛选器</el-button>

                    <el-button type="text" @click="isOpened=true" class="openMore">更多</el-button>

                </div>
            </div>
            <!-- 弹出窗 -->
            <!-- 存为筛选器 -->
            <save-sizer :isSaveSizer="isSaveSizer" @saveSizer="makeSureSaveSizer" @closeSizer="closeSizer"></save-sizer>
            <!-- 选择部门 -->
            <select-department-modal :isSelectDepartment="isSelectDepartment" @modal:select-department-closing="closeSelectDepartmentModal" @modal:select-department="makeSureSelectDepartment" ></select-department-modal>
            <!-- 选择大学 -->
            <select-university-modal :isSelectUniversity="isSelectUniversity" @modal:select-university-closing="closeSelectUniversity" @modal:emit-selected-universities="selectedUniversity" :max="maxUniversity"></select-university-modal>
            <!-- 选择家庭所在地 -->
            <select-city-modal :isSelectingCity="isSelectCity" @modal:select-city-closing="closeSelectCity" @modal:emit-selected-cities="selectedCity" :max="maxCity"></select-city-modal>
            <!-- 展开查询条件 -->
            <!-- <all-options :isOpened="isOpened" :optionsData="optionsData"></all-options> -->
            <div class="options-all input-size-md" v-if="allOptionsModelVisible">

                <el-row :gutter="70">
                    <el-col :span="8">
                        <el-form-item label="投递职位">
                            <el-select v-model="position" placeholder="不限" >
                                <el-option v-for="item in jobList" :label="item" :value="item">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="最高学历">
                            <el-select v-model="degree" placeholder="不限" >
                                <el-option v-for="item in degreeItems" :label="item.label" :value="item.value">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="毕业院校">
                            <el-input v-model="school" @focus="isSelectUniversity=true" readonly placeholder="请选择"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>

                <el-row :gutter="70">
                    <el-col :span="8">
                        <el-form-item label="专业">
                            <el-input v-model="major"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="处理状态">
                            <el-select v-model="status" placeholder="不限" >
                                <el-option v-for="item in statusItems" :label="item.label" :value="item.value">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="简历标签">
                            <el-select v-model="label" placeholder="不限" multiple>
                                <el-option v-for="item in tagsList" :label="item.name" :value="item.name" v-if="item.status">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                </el-row>

                <el-row :gutter="70">
                    <el-col :span="8">
                        <el-form-item label="性别">
                            <el-select v-model="gender" placeholder="不限" >
                                <el-option v-for="item in genderItems" :label="item.label" :value="item.value">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="聘用部门">
                            <el-input v-model="department" @focus="selectDepartment" readonly placeholder="请选择"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="专业排名">
                            <el-select v-model="rank" placeholder="不限" >
                                <el-option v-for="item in rankItems" :label="item.label" :value="item.value">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                </el-row>

                <el-row :gutter="70">
                    <el-col :span="8">
                        <el-form-item label="英语等级">
                            <el-select v-model="englishLevel" placeholder="不限" multiple>
                                <el-option v-for="item in englishLevelItems" :label="item.label" :value="item.value">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="获奖荣誉">
                            <el-select v-model="reward" placeholder="不限" >
                                <el-option v-for="item in rewardItems" :label="item.label" :value="item.value">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="姓名">
                            <el-input v-model="name"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>

                <el-row :gutter="70">
                    <el-col :span="8">
                        <el-form-item label="手机号码">
                            <el-input v-model="mobile"></el-input>
                        </el-form-item>
                    </el-col>
                   <el-col :span="8">
                        <el-form-item label="家庭所在地">
                            <el-input v-model="city" @focus="isSelectCity=true" readonly placeholder="请选择家庭所在地"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="出生年份" class="jq-date-group">
                            <el-col :span="11">
                                <el-date-picker v-model="birthFrom" align="right" type="year" placeholder="不限" :picker-options="pickerOptionsStartBirth" :editable="false" :clearable="false">
                                </el-date-picker>
                            </el-col>
                            <el-col class="line" :span="2" style="padding:1px 0 0 2px;">~</el-col>
                            <el-col :span="11">
                                <el-date-picker v-model="birthTo" align="right" type="year" placeholder="不限" style="float:right;" :picker-options="pickerOptionsEndBirth" :editable="false" :clearable="false">
                                </el-date-picker>
                            </el-col>
                        </el-form-item>
                    </el-col>
                </el-row>

                <el-row :gutter="70">
                    <el-col :span="8">
                        <el-form-item label="毕业时间" class="jq-date-group">
                            <el-col :span="11">
                                <el-date-picker v-model="graduateFrom" align="right" type="year" placeholder="不限" :picker-options="pickerOptionsgraduateFrom" :editable="false" :clearable="false">
                                </el-date-picker>
                            </el-col>
                            <el-col class="line" :span="2" style="padding:1px 0 0 2px;">~</el-col>
                            <el-col :span="11">
                                <el-date-picker v-model="graduateTo" align="right" type="year" placeholder="不限" :picker-options="pickerOptionsgraduateTo"  style="float:right;" :editable="false" :clearable="false">
                                </el-date-picker>
                            </el-col>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="投递日期" class="jq-date-group">
                            <el-col :span="11">
                                <el-date-picker v-model="deliveryFrom" type="date" placeholder="不限" :picker-options="pickerOptionsSendStart" format="yy-MM-dd" :editable="false" :clearable="false">
                                </el-date-picker>
                            </el-col>
                           <el-col class="line" :span="2" style="padding:1px 0 0 2px;">~</el-col>
                           <el-col :span="11">
                                <el-date-picker v-model="deliveryTo" type="date" placeholder="不限" :picker-options="pickerOptionsSendEnd"  format="yy-MM-dd" style="float:right;" :editable="false" :clearable="false">
                                </el-date-picker>
                            </el-col>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="附件简历">
                            <el-select v-model="attachment" placeholder="不限" >
                                <el-option v-for="item in attachmentItems" :label="item.label" :value="item.value">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                </el-row>



                <div class="button-list">
                    <el-button type="primary" class="my-button" @click="findCandidates">查询</el-button>
                    <el-button class="my-button gray-button" @click="resetFilter">重置</el-button>
                    <el-button class="my-button" @click="closeMore">取消</el-button>

                    <el-button type="text"  class="saveSizer" @click="saveSizer" >存为筛选器</el-button>
                    <el-button type="text" @click="closeMore" class="close-more">收起</el-button>
                </div>
            </div>
        </el-form>
        <!-- 操作按钮区 -->

        <div class="controller-body">
            <ul class="con-ul">
                <li v-if="isShowWrittenBtn">
                    <el-dropdown trigger="click">
                        <el-button type="text">安排笔试</el-button>
                        <el-dropdown-menu slot="dropdown">
                            <el-dropdown-item>修改笔试安排</el-dropdown-item>
                            <el-dropdown-item>取消笔试</el-dropdown-item>
                        </el-dropdown-menu>
                    </el-dropdown>
                </li>
                <li v-if="isShowInterviewBtn">
                    <el-dropdown trigger="click">
                        <el-button type="text">安排面试</el-button>
                        <el-dropdown-menu slot="dropdown">
                            <el-dropdown-item>修改面试安排</el-dropdown-item>
                            <el-dropdown-item>取消面试</el-dropdown-item>
                        </el-dropdown-menu>
                    </el-dropdown>
                </li>
                <li v-if="isShowOfferBtn">
                    <el-button type="text" @click="confirmOffer">确认offer</el-button>
                </li>
                <li v-if="isShowPassBtn">
                    <el-button type="text" @click="pass">通过</el-button>
                </li>
                <li v-if="isShowNotPassBtn">
                    <el-button type="text" @click="noPass">不通过</el-button>
                </li>
                <li v-if="isShowUndeterminedBtn">
                    <el-button type="text" @click="undetermined">待定</el-button>
                </li>
                <li v-if="isShowWeedOutBtn">
                    <el-button type="text" @click="weedOut">淘汰</el-button>
                </li>
                <li>
                    <el-dropdown trigger="click" @command="stageJump">
                        <el-button type="text">阶段跳转</el-button>
                        <el-dropdown-menu slot="dropdown">
                            <el-dropdown-item v-for="item in recruiterFlows" :command="item.name">{{item.name}}</el-dropdown-item>

                        </el-dropdown-menu>
                    </el-dropdown>
                </li>
                <li>
                    <el-dropdown trigger="click" @command="batchAddTag">
                        <el-button type="text">打标签</el-button>
                        <el-dropdown-menu slot="dropdown" >
                            <el-dropdown-item v-for="item in tagsList" :command="item.name" v-if="item.status">{{item.name}}</el-dropdown-item>
                        </el-dropdown-menu>
                    </el-dropdown>
                </li>
                <li>
                    <el-button type="text" v-if="isShowEmailBtn" @click="email">发邮件</el-button>
                </li>
                <sent-email-message-modal :isSentEmail="showEmailModal" :candidates="multipleSelection" @closeSentEmail="closeSentEmail" @sentEmail="sentEmail"></sent-email-message-modal>
                <li>
                    <!-- <el-popover ref="popoverExportPage" placement="right" width="400" trigger="click">
                        <div>请输入导出指定导出页</div>
                        <div>
                            <el-row>
                                <el-col :span="2">导出第</el-col>
                                <el-col :span="8"><el-input></el-input></el-col>
                                <el-col :span="8"><el-input></el-input></el-col>
                                <el-col :span="6">页<el-button type="primary">导出</el-button></el-col>
                            </el-row>
                        </div>
                    </el-popover> -->
                    <el-dropdown trigger="click">
                        <el-button type="text">导出</el-button>
                        <el-dropdown-menu slot="dropdown">
                            <el-dropdown-item><a :href="exprotCurrentPage">导出当前页</a></el-dropdown-item>
                            <!-- <el-dropdown-item ><el-button type="text" v-popover:popoverExportPage>导出指定页</el-button></el-dropdown-item> -->
                            <el-dropdown-item><a :href="exportAll">导出全部</a></el-dropdown-item>
                        </el-dropdown-menu>
                    </el-dropdown>
                </li>
            </ul>
            <el-popover ref="popover" :visible-arrow="false"  trigger="click">
                <ul>
                    <li><el-checkbox v-model="isShowGender" checked>性别</el-checkbox></li>
                    <li> <el-checkbox v-model="isShowJob" >投递职位</el-checkbox></li>
                    <li><el-checkbox v-model="isShowDepartment" >招聘部门</el-checkbox></li>
                    <li><el-checkbox v-model="isShowXueli" >最高学历</el-checkbox></li>
                    <li><el-checkbox v-model="isShowSchool" >毕业学校</el-checkbox></li>
                    <li><el-checkbox v-model="isShowZhuanye" >专业</el-checkbox></li>
                    <li><el-checkbox v-model="isShowResumeStatus" >处理状态</el-checkbox></li>
                    <li><el-checkbox v-model="isShowTag" >简历标签</el-checkbox></li>

                </ul>
            </el-popover>
            <el-button class="show-set" v-popover:popover >显示设置<div class="sanjiao-xia"></div></el-button>



        </div>

        <!-- 表格展示简历 -->
        <!-- <resume-table></resume-table> -->
        <div class="resume-table-model">
        <div>
            <el-table :data="resumes" style="width:100%;" @selection-change="handleSelectionChange" @sort-change="sortChange">
                <el-table-column type="selection" width="50" label="全选">
                </el-table-column>
                <!-- <el-table-column v-for="com in columns" v-bind:prop="com.prop" v-bind:min-width="com.width" v-bind:label="com.label" align="center" header-align="center">
                </el-table-column> -->
                <el-table-column label="姓名" width="120" >
                    <template scope="scope">
                        <!-- <span v-if="scope.row.headerUrl"><img :src="scope.row.headerUrl"class="headerImg"></span>
                        <span class="userImg headerImg" :style="colorBg(scope.row.name)" v-else>{{headerImg(scope.row.name)}}</span> -->

                        <a :href="scope.row.resume.fileURL" v-if="scope.row.resume&&scope.row.resume.contentType==='application/ms-photo' "><span class="acc-photo cursor_pointer" ></span></a>
                        <a :href="scope.row.resume.fileURL" v-else-if="scope.row.resume&&scope.row.resume.contentType==='application/ms-pdf' "><span class="acc-pdf cursor_pointer" ></span></a>
                        <a :href="scope.row.resume.fileURL" v-else-if="scope.row.resume&&scope.row.resume.contentType==='application/ms-word' "><span class="acc-word cursor_pointer" ></span></a>
                        <router-link :to="candidateDetailPath(scope.row)" class="router-link">
                            <span style="line-height: 58px;">{{ scope.row.basic.name }}</span>
                        </router-link>
                        <!-- <a href="#/candidate/detail" target="_blank">
                            <span style="line-height: 58px;">{{ scope.row.name }}</span>
                        </a> -->

                    </template>

                </el-table-column>
                <el-table-column label="性别" min-width="80" align="center" header-align="center" v-if="isShowGender">
                    <template scope="scope">
                        <span style="line-height: 58px;">{{ scope.row.basic.gender }}</span>
                    </template>

                </el-table-column>

                <el-table-column label="投递职位" min-width="140" align="center" header-align="center" v-if="isShowJob" :show-overflow-tooltip="true">
                    <template scope="scope">
                        <span style="line-height: 58px;">{{ scope.row.jobTarget[0].job_name }}</span>
                    </template>

                </el-table-column>
                <el-table-column label="招聘部门" min-width="140" align="center" header-align="center" v-if="isShowDepartment" :show-overflow-tooltip="true">
                    <template scope="scope">
                        <span style="line-height: 58px;">{{ scope.row.jobTarget[0].department }}</span>
                    </template>

                </el-table-column>
                <el-table-column label="最高学历" min-width="80" align="center" header-align="center" v-if="isShowXueli" :show-overflow-tooltip="true" :sortable="custom">
                    <template scope="scope">
                        <span style="line-height: 58px;">{{ scope.row.education[0].degree }}</span>
                    </template>

                </el-table-column>
                <el-table-column label="毕业学校" min-width="140" align="center" header-align="center" v-if="isShowSchool" :show-overflow-tooltip="true">
                    <template scope="scope">
                        <span style="line-height: 58px;">{{ scope.row.education[0].school }}</span>
                    </template>

                </el-table-column>
                <el-table-column label="专业" min-width="110" align="center" header-align="center" v-if="isShowZhuanye" :show-overflow-tooltip="true">
                    <template scope="scope">
                        <span style="line-height: 58px;">{{ scope.row.education[0].major }}</span>
                    </template>

                </el-table-column>

                <el-table-column label="处理状态" min-width="90" align="center" header-align="center" v-if="isShowResumeStatus" :show-overflow-tooltip="true">
                    <template scope="scope">
                        <span style="line-height: 58px;">{{ scope.row.status }}</span>
                    </template>

                </el-table-column>

                <el-table-column label="标签" min-width="170" align="center" header-align="center" v-if="isShowTag" :show-overflow-tooltip="false">
                    <template scope="scope">


                        <!-- 无标签 -->
                        <span style="line-height: 58px;"v-if="scope.row.tags==null || scope.row.tags.length==0">
                        </span>

                        <!-- 两个及以上 -->
                        <span  v-else-if="scope.row.tags.length>2">
                            <el-tag  type="warning" >
                                {{scope.row.tags[0].tag}}
                            </el-tag>
                            <el-tag type="warning" >
                                {{scope.row.tags[1].tag}}
                            </el-tag>
                            <el-tag type="warning" >
                                {{scope.row.tags[2].tag}}
                            </el-tag>
                        </span>
                        <!-- 一，两个标签 -->
                        <span v-else>
                            <el-tag v-for="tag in scope.row.tags" type="warning" >
                                {{tag.tag}}
                            </el-tag>
                        </span>
                    </template>

                </el-table-column>
            </el-table>
        </div>
    </div>
            <!-- 分页 -->
            <div class="pagination">
                <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage" :page-sizes="pageSizes" :page-size="pageSize" layout="total, sizes, prev, pager, next" :total="total">
                </el-pagination>
            </div>
    </div>
</template>

<script type="text/babel">
import eventBus from '../../js/shared/eventBus';
//import { strChineseFirstPY , oMultiDiff } from '../../js/shared/pinyin';
import SelectDepartmentModal from '../Modal/SelectDepartmentModal.vue';
import SelectCityModal from '../Modal/SelectCityModal.vue';
import SelectUniversityModal from '../Modal/SelectUniversityModal';
import SaveSizer from './SaveSizerModel.vue';
import SentEmailMessageModal from '../Modal/SentEmailMessageModal.vue';

    export default {
        name: 'candidate-modal',

        data() {
            return{
                //todo
                pageSize:5,
                total:0,
                currentPage: 1,
                pageSizes:[2, 5, 10, 30,50,100],
                sort:'',
                sizer:null,
                nullFilter:null,
                name:'',
                // 投递职位
                position:'',
                // 最高学历
                degree:'',
                // 毕业院校
                school:'',
                // 专业
                major:'',
                // 处理状态
                status:'',
                // 简历标签
                label:[],
                // 性别
                gender:'',
                // 聘用部门
                department:'',
                // 实习经历
                practices:'',
                // 项目经验
                work:'',
                // 专业排名
                rank:'',
                // 英语等级
                englishLevel:[],
                // 奖学金
                reward:'',
                // 参赛经历
                competition:'',
                // 附件简历
                attachment:'',
                // 手机号码
                mobile:'',
                // 家庭所在地
                city:'',
                // 出生年份开始时间
                birthFrom:'',
                // 出生年份截止时间
                birthTo:'',
                // 毕业时间开始
                graduateFrom:'',
                // 毕业时间截止
                graduateTo:'',
                // 投递日期开始
                deliveryFrom:'',
                // 投递日期截止
                deliveryTo:'',

                maxCity:5,
                maxUniversity:6,
                isSelectCity:false,
                isSelectUniversity:false,

                showEmailModal:false,

                custom:'custom',
                tags:[
                    {label:'一般',value:'一般'},
                    {label:'还可以',value:'还可以'},
                    {label:'优秀',value:'优秀'},
                    {label:'待定',value:'待定'}
                ],

                optionsData: [],
                isOpened: false,
                isSaveSizer: false,
                isAddTag: false,
                isSelectDepartment: false,

                positions: [],

                statusItems: [],
                statusItemss:{
                    '筛选类型': [
                        {label:'不限' ,value:''},
                        {label:'未处理',value:'1___'},
                        {label:'待定',value:'2___'},
                        {label:'未通过',value:'3___'}],
                    '笔试类型': [
                        {label:'不限' ,value:''},
                        {label:'未处理',value:'11__'},
                        {label:'已安排笔试（未通知）',value:'121_'},
                        {label:'已安排笔试（已通知）',value:'122_'},
                        {label:'未通过',value:'3___'}
                        ],
                    '面试类型': [
                        {label:'不限' ,value:''},
                        {label:'未处理',value:'11__'},
                        {label:'已安排面试（未通知）',value:'121_'},
                        {label:'已安排面试（已通知）',value:'122_'},
                        {label:'未通过',value:'3___'}
                        ],
                    '录用类型': [
                        {label:'不限' ,value:''},
                        {label:'未处理',value:'1_1_'},
                        {label:'已发offer',value:'5_2_'},
                        {label:'已淘汰（未通知）',value:'4_1_'},
                        {label:'已淘汰（已通知）',value:'4_2_'}]
                },

                degreeItems:[
                    {label:'不限' ,value:''},
                    {label:'大专' ,value:'1'},
                    {label:'本科' ,value:'2'},
                    {label:'研究生' ,value:'3'},
                    {label:'博士' ,value:'4'},
                    ],
                englishLevelItems: [
                    {label:'四级',value:'四级'},
                    {label:'六级',value:'六级'},
                    {label:'专业四级',value:'专业四级'},
                    {label:'专业八级',value:'专业八级'},
                    {label:'其他',value:'其他'},
                ],
                genderItems:[
                    {label:'不限',value:''},
                    {label:'男',value:'男'},
                    {label:'女',value:'女'}
                ],
                rankItems:[
                    {label:'不限',value:''},
                    {label:'前5%',value:'1'},
                    {label:'前10%',value:'2'},
                    {label:'前20%',value:'3'},
                    {label:'前50%',value:'4'},
                ],
                // workItems: [
                //     {label:'不限',value:''},
                //     {label:'有',value:'有'},
                //     {label:'无',value:'无'}
                // ],

                practicesItems: [
                    {label:'不限',value:''},
                    {label:'有',value:'Y'},
                    {label:'无',value:'N'}
                ],

                rewardItems: [
                    {label:'不限',value:''},
                    {label:'有',value:'Y'},
                    {label:'无',value:'N'}
                ],

                competitionItems: [
                    {label:'不限',value:''},
                    {label:'有',value:'Y'},
                    {label:'无',value:'N'}
                ],

                attachmentItems: [
                    {label:'不限',value:''},
                    {label:'有',value:'Y'},
                    {label:'无',value:'N'}
                ],

                pickerOptionsSendEnd:{
                    disabledDate:(time)=> {
                        return time.getTime() <= new Date(this.deliveryFrom).getTime() - 8.64e7;
                    }
                },
                pickerOptionsSendStart:{
                    disabledDate:(time)=> {
                        let disTime = Date.now() - 8.64e7 + 24*60*60*1000;
                        if(!(this.deliveryTo==='') && this.deliveryTo<disTime){
                            disTime = new Date(this.deliveryTo).getTime() - 8.64e7;
                        }
                        return time.getTime() >  disTime;
                    }
                },

                pickerOptionsStartBirth: {
                    disabledDate: (time) => {
                        let disTime = Date.now() - 8.64e7 + 24*60*60*1000;
                        if(!(this.birthTo === '') && this.birthTo < disTime){
                            disTime = new Date(this.birthTo).getTime() - 8.64e7;
                        }
                        return time.getTime() >  disTime;
                    }
                },
                pickerOptionsEndBirth: {
                    disabledDate: (time) => {
                        return time.getTime() <= new Date(this.birthFrom).getTime() - 8.64e7;
                    }
                },

                pickerOptionsgraduateFrom: {
                    disabledDate: (time) => {
                        let disTime = Date.now() - 8.64e7 + 24*60*60*1000;
                        if(!(this.graduateTo === '') && this.graduateTo < disTime){
                            disTime = new Date(this.graduateTo).getTime() - 8.64e7;
                        }
                        return time.getTime() >  disTime;
                    }
                },
                pickerOptionsgraduateTo: {
                    disabledDate:(time)=> {
                        return time.getTime() <= new Date(this.graduateFrom).getTime() - 8.64e7;
                    }
                },
                isShowOfferBtn:false,
                isShowWrittenBtn:true,
                isShowInterviewBtn:true,
                isShowNotPassBtn:true,
                isShowPassBtn:true,
                isShowUndeterminedBtn:true,
                isShowWeedOutBtn:true,
                isShowEmailBtn:true,

                allSelect: false,
                select: false,
                true: true,
                false: false,
                isShowGender: true,
                isShowJob:true,
                isShowXueli:true,
                isShowSchool:true,
                isShowZhuanye:true,
                isShowDepartment: false,

                isShowResumeStatus: true,
                isShowTag: true,
                isShowAge: false,
                isShowHuanjie:false,

                resumes:[
                    // {
                    //   "id": "b9aa0c00-bac7-40ad-9eaf-44df0ce62857",
                    //   "stuId": "354bdb8f-ecd6-4c82-80fe-5f42db62d0a1",
                    //   "recId": "354bdb8f-ecd6-4c82-80fe-5f42db62d0a1",
                    //   "recName": "今日头条",
                    //   "jobTarget": [
                    //     {
                    //       "id": "354bdb8f-ecd6-4c82-80fe-5f42db62d0a1",
                    //       "stuId": null,
                    //       "area": "上海",
                    //       "department": "北京分公司",
                    //       "score": 20,
                    //       "job_name": "Java工程师",
                    //       "job_category": "技术开发类",
                    //       "is_current": true,
                    //       "current_status": "init"
                    //     }
                    //   ],
                    //   "basic": {
                    //     "name": "李1",
                    //     "gender": "男",
                    //     "email": "1126971653@qq.com",
                    //     "mobile": "13520115645",
                    //     "birthday": "1992-12-14",
                    //     "province": "澳门",
                    //     "city": "内蒙古-阿拉善盟",
                    //     "political": "共青团员"
                    //   },
                    //   "education": [
                    //     {
                    //       "rank": "2",
                    //       "major": "计算机系统结构",
                    //       "degree": "3",
                    //       "school": "北京工业大学",
                    //       "end_date": "2002-11",
                    //       "is_highest": true,
                    //       "start_date": "2000-10"
                    //     }
                    //   ],
                    //   "stageId": null,
                    //   "status": "3313",
                    //   "tags": [
                    //     {
                    //       "id": "efdbec2a-289c-4442-b8e9-d80e172046e4",
                    //       "applicationId": "b9aa0c97-bac7-40ad-9eaf-3ddf0ce62857",
                    //       "tag": "待定",
                    //       "optId": "693f8256-082b-46c9-b9e4-f24aad84b911",
                    //       "optName": "图图",
                    //       "creatDate": "20170304062614"
                    //     }
                    //   ],
                    //   "applyDate": "20170301054309"
                    // }

                ],
                //已选候选人名单
                multipleSelection: []



            }
        },
        props:{
            modalName:String,
            currentRecruiterFlowIndex:Number
        },

        watch:{
            activeRecruiterFlowTab : function(){
                if(this.currentModalName===this.activeRecruiterFlowName){
                    this.statusItems=this.statusItemss[this.activeRecruiterFlowType];
                    this.activeControllerButton();
                    this.regainStatus();
                    this.findCandidates();
                }
            },
            sizer: function(){
                if(this.sizer){
                    // 投递职位
                    this.position=this.sizer.candidateProfile.position;
                    // 最高学历
                    this.degree=this.sizer.candidateProfile.degree;
                    // 毕业院校
                    this.school=this.sizer.candidateProfile.school;
                    // 专业
                    this.major=this.sizer.candidateProfile.major;
                    // 处理状态
                    this.status=this.sizer.candidateProfile.status;
                    // 简历标签
                    if(this.sizer.candidateProfile.label.split(",")){
                        this.label = [];
                    }else{
                        this.label=this.sizer.candidateProfile.label.split(",");
                    }
                    // 性别
                    this.gender=this.sizer.candidateProfile.gender;
                    // 聘用部门
                    this.department=this.sizer.candidateProfile.department;


                    // 专业排名
                    this.rank=this.sizer.candidateProfile.rank;
                    // 英语等级
                    if(this.sizer.candidateProfile.englishLevel.split(",")){
                        this.englishLevel = [];
                    }else{
                        this.englishLevel=this.sizer.candidateProfile.englishLevel.split(",");
                    }
                    // 奖学金
                    this.reward=this.sizer.candidateProfile.reward;

                    // 附件简历
                    this.attachment=this.sizer.candidateProfile.attachment;
                    // 手机号码
                    this.mobile=this.sizer.candidateProfile.mobile;
                    // 家庭所在地
                    this.city=this.sizer.candidateProfile.city;
                    // 出生年份开始时间
                    this.birthFrom=this.sizer.candidateProfile.birthFrom;
                    // 出生年份截止时间
                    this.birthTo=this.sizer.candidateProfile.birthTo;
                    // 毕业时间开始
                    this.graduateFrom=this.sizer.candidateProfile.graduateFrom;
                    // 毕业时间截止
                    this.graduateTo=this.sizer.candidateProfile.graduateTo;
                    // 投递日期开始
                    this.deliveryFrom=this.sizer.candidateProfile.deliveryFrom;
                    // 投递日期截止
                    this.deliveryTo=this.sizer.candidateProfile.deliveryTo;
                    }
            }
        },

        computed: {
            jobList(){
                return this.$store.state.job.jobNameList
            },
            tagsList(){
                return this.$store.state.candidate.tagsList
            },
            filterList(){
                return this.$store.state.candidate.filterList
            },
            userId(){
                return this.$store.getters.userId
            },
            userName(){
                return this.$store.getters.userName
            },
            recId(){
                return this.$store.getters.recId
            },
            currentModalName(){
                return this.modalName
            },

            //导出当前页链接地址
            exprotCurrentPage(){
                let data = this.objTofilterStr(this.sentFilter());
                return '/candidate/excel?filter='+ data;
            },
            //导出全部链接地址
            exportAll(){
                let selectAllfilter = this.sentFilter();
                    selectAllfilter.no=1;
                    selectAllfilter.sz=999999;
                   // console.log(selectAllfilter+'导出全部')
                    let data = this.objTofilterStr(selectAllfilter);
                return '/candidate/excel?filter='+ data;
            },
            // name(){
            //     return this.$store.state.candidate.searchContent;
            // },
            recruiterFlowsIndex(){
                return this.currentRecruiterFlowIndex
            },
            recruiterFlows(){
                return this.$store.state.candidate.recruiterFlows
            },
            activeRecruiterFlowId () {
                return this.$store.getters.activeRecruiterFlow.id
            },
            activeRecruiterFlowTab() {
                    return this.$store.state.candidate.activeRecruiterFlowTab
            },
            statusStore() {
                return this.$store.state.candidate.statusStore;
            },

            candidateDate() {
                return this.$store.state.candidate.candidateDate;
            },
            activeRecruiterFlowType () {
                return this.$store.getters.activeRecruiterFlow.type
            },
            activeRecruiterFlowName(){
                return this.$store.getters.activeRecruiterFlow.name
            },
            initFilter() {
                 if(this.statusStore[this.activeRecruiterFlowTab]===undefined){
                    return {
                        sizer:'',
                        // 投递职位
                        position:'',
                        // 最高学历
                        degree:'',
                        // 毕业院校
                        school:'',
                        // 专业
                        major:'',
                        // 处理状态
                        status:'',
                        // 简历标签
                        label:[],
                        // 性别
                        gender:'',
                        // 聘用部门
                        department:'',
                        // 实习经历
                        practices:'',
                        // 项目经验
                        work:'',
                        // 专业排名
                        rank:'',
                        // 英语等级
                        englishLevel:[],
                        // 奖学金
                        reward:'',
                        // 参赛经历
                        competition:'',
                        // 附件简历
                        attachment:'',
                        // 手机号码
                        mobile:'',
                        // 家庭所在地
                        city:'',
                        // 出生年份开始时间
                        birthFrom:'',
                        // 出生年份截止时间
                        birthTo:'',
                        // 毕业时间开始
                        graduateFrom:'',
                        // 毕业时间截止
                        graduateTo:'',
                        // 投递日期开始
                        deliveryFrom:'',
                        // 投递日期截止
                        deliveryTo:'',
                        //名字
                        name:''
                     }
                 }else{
                     return this.statusStore[this.activeRecruiterFlowTab]
                 }
            },
            activeFilter() {

                return {
                    sizer:this.sizer,
                    // 投递职位
                    position:this.position,
                    // 最高学历
                    degree:this.degree,
                    // 毕业院校
                    school:this.school,
                    // 专业
                    major:this.major,
                    // 处理状态
                    status:this.status,
                    // 简历标签
                    label:this.label,
                    // 性别
                    gender:this.gender,
                    // 聘用部门
                    department:this.department,
                    // 实习经历
                    practices:this.practices,
                    // 项目经验
                    work:this.work,
                    // 专业排名
                    rank:this.rank,
                    // 英语等级
                    englishLevel:this.englishLevel,
                    // 奖学金
                    reward:this.reward,
                    // 参赛经历
                    competition:this.competition,
                    // 附件简历
                    attachment:this.attachment,
                    // 手机号码
                    mobile:this.mobile,
                    // 家庭所在地
                    city:this.city,
                    // 出生年份开始时间
                    birthFrom:this.birthFrom,
                    // 出生年份截止时间
                    birthTo:this.birthTo,
                    // 毕业时间开始
                    graduateFrom:this.graduateFrom,
                    // 毕业时间截止
                    graduateTo:this.graduateTo,
                    // 投递日期开始
                    deliveryFrom:this.deliveryFrom,
                    // 投递日期截止
                    deliveryTo:this.deliveryTo,
                    //名字
                    name:this.name
                }
            },
            allOptionsModelVisible() {
                return this.isOpened;
            }
            // position: {
            //     get () {
            //         return this.$store.state.candidate.position
            //     },
            //     set (value) {
            //         this.$store.commit('updatePosition' , value)
            //     }
            // },
        },

        methods: {
            //获取职位列表
            getJobList(){
                console.log('获取职位列表')
                this.$http.get('/requisitions/jobTitle').then(response =>{
                    let a = response.body;
                    console.log(a);
                    //存到状态库中
                    this.$store.commit('upDateJobNameList' , a);

                })
            },
            //刷新流程
            refreshWorkFlow(){
                console.log('分发刷新事件')
                this.$emit('refresh-workflow');
            },
            // /candidate?filter="rid": "354bdb8f-ecd6-4c82-80fe-5f42db62d0a1", "pst": "", "dgr": "","scl": "", "mj": "","sta": "","lb": "","gd": "","dp": "","rank": "","egL": "","rd": "","att": "","nm": "", "mb": "13520115645","ct": "","brF": "","brT": "","gdF": "","gdT": "","dlF": null,"dlT":null,"no": 0,"sz": 15,"st": ""
            getCandidateList(){
                this.$http.get('/candidate?filter='+this.objTofilterStr(this.sentFilter())).then(response =>{
                    let a = response.body;
                    console.log(a);
                    //存到状态库中
                   // console.log(typeof(a))
                    this.$store.commit('updateCandidateDate' , a);
                    this.formatCandidateList();
                },response => {
                    console.log(response);
                })
            },
            //获取筛选器列表
            getFilterList(){
                console.log('获取筛选器列表')
                this.$http.get('company/users/filter/candidate').then(response =>{
                    let a = response.body;
                    console.log(a);
                    //存到状态库中

                    this.$store.commit('updateFilterList' , a);
                })
            },
            getTagsList(){
                console.log('获取候选人标签列表')
                this.$http.get('company/labels').then(response =>{
                    let a = response.body;
                    console.log(a);
                    //存到状态库中

                    this.$store.commit('updateTagsList' , a);
                })
            },

            //简历详情路由路径
            candidateDetailPath(candidate){
                let candidatePath = "/candidate/detail/"+candidate.id;
                return candidatePath;
            },
            // 从状态库中获取候选人列表
            formatCandidateList(){
                this.resumes = this.candidateDate.applicationDTOList
                this.total = this.candidateDate.total;
            },
            //选择部门
            selectDepartment(){
                this.isSelectDepartment = true;
            },
            closeSelectDepartmentModal(){
                this.isSelectDepartment = false;
            },
            makeSureSelectDepartment(value){
                this.department = value;
            },
            selectedCity: function(value){
                this.city = value.join(',');
            },
            closeSelectCity: function(){
                this.isSelectCity = false;
            },
            selectedUniversity: function(value){
                this.school = value.join(',');
            },
            //关闭大学选择框
            closeSelectUniversity: function(){
                this.isSelectUniversity = false;
            },
            //监听排序事件
            sortChange:function (value){
                if(value.column!==null){
                    let sortStr = value.order;
                    if(sortStr==="ascending"){
                        sortStr="edu.degree,ASC"
                    }
                    if(sortStr==="descending"){
                        sortStr="edu.degree,DESC"
                    }
                    this.sort = sortStr;
                    console.log(this.sort);
                    this.findCandidates();
                }
            },
            //监听分页size变化
            handleSizeChange(val) {
                this.pageSize=val;
                 this.findCandidates();
            },
            //监听当前页变化
            handleCurrentChange(val) {
                this.currentPage = val;
                this.findCandidates();
            },
            //重置筛选条件
            resetFilter(){

                this.sizer = null;
                // 投递职位
                this.position='';
                // 最高学历
                this.degree='';
                // 毕业院校
                this.school='';
                // 专业
                this.major='';
                // 处理状态
                this.status='';
                // 简历标签
                this.label=[];
                // 性别
                this.gender='';
                // 聘用部门
                this.department='';
                // 实习经历
                this.practices='';
                // 项目经验
                this.work='';
                // 专业排名
                this.rank='';
                // 英语等级
                this.englishLevel=[];
                // 奖学金
                this.reward='';
                // 参赛经历
                this.competition='';
                // 附件简历
                this.attachment='';
                // 手机号码
                this.mobile='';
                // 家庭所在地
                this.city='';
                // 出生年份开始时间
                this.birthFrom='';
                // 出生年份截止时间
                this.birthTo='';
                // 毕业时间开始
                this.graduateFrom='';
                // 毕业时间截止
                this.graduateTo='';
                // 投递日期开始
                this.deliveryFrom='';
                // 投递日期截止
                this.deliveryTo='';
                //名字
                this.name='';

            },
            //恢复状态
            regainStatus(){
                this.sizer = this.initFilter.sizer;
                // 投递职位
                this.position=this.initFilter.position;
                // 最高学历
                this.degree=this.initFilter.degree;
                // 毕业院校
                this.school=this.initFilter.school;
                // 专业
                this.major=this.initFilter.major;
                // 处理状态
                this.status=this.initFilter.status;
                // 简历标签
                this.label=this.initFilter.label;
                // 性别
                this.gender=this.initFilter.gender;
                // 聘用部门
                this.department=this.initFilter.department;
                // 实习经历
                this.practices=this.initFilter.practices;
                // 项目经验
                this.work=this.initFilter.work;
                // 专业排名
                this.rank=this.initFilter.rank;
                // 英语等级
                this.englishLevel=this.initFilter.englishLevel;
                // 奖学金
                this.reward=this.initFilter.reward;
                // 参赛经历
                this.competition=this.initFilter.competition;
                // 附件简历
                this.attachment=this.initFilter.attachment;
                // 手机号码
                this.mobile=this.initFilter.mobile;
                // 家庭所在地
                this.city=this.initFilter.city;
                // 出生年份开始时间
                this.birthFrom=this.initFilter.birthFrom;
                // 出生年份截止时间
                this.birthTo=this.initFilter.birthTo;
                // 毕业时间开始
                this.graduateFrom=this.initFilter.graduateFrom;
                // 毕业时间截止
                this.graduateTo=this.initFilter.graduateTo;
                // 投递日期开始
                this.deliveryFrom=this.initFilter.deliveryFrom;
                // 投递日期截止
                this.deliveryTo=this.initFilter.deliveryTo;
                //名字
                this.name=this.initFilter.name;

            },
            //控制按钮按流程显示
            activeControllerButton(){
                if(this.activeRecruiterFlowType==='筛选类型'){
                    this.isShowWrittenBtn =false;
                    this.isShowInterviewBtn =false;
                    this.isShowNotPassBtn =true;
                    this.isShowPassBtn =true;
                    this.isShowUndeterminedBtn = true;
                    this.isShowEmailBtn = false;
                    this.isShowWeedOutBtn = false;
                    this.isShowOfferBtn = false;
                }
                if(this.activeRecruiterFlowType==='笔试类型'){
                    this.isShowWrittenBtn =true;
                    this.isShowInterviewBtn =false;
                    this.isShowNotPassBtn =true;
                    this.isShowPassBtn =true;
                    this.isShowUndeterminedBtn = false;
                    this.isShowEmailBtn = true;
                    this.isShowWeedOutBtn = false;
                    this.isShowOfferBtn = false;
                }
                if(this.activeRecruiterFlowType==='面试类型'){
                    this.isShowWrittenBtn =false;
                    this.isShowInterviewBtn =true;
                    this.isShowNotPassBtn =true;
                    this.isShowPassBtn =true;
                    this.isShowUndeterminedBtn = false;
                    this.isShowEmailBtn = true;
                    this.isShowWeedOutBtn = false;
                    this.isShowOfferBtn = false;
                }
                if(this.activeRecruiterFlowType==='录用类型'){
                    this.isShowWrittenBtn =false;
                    this.isShowInterviewBtn =false;
                    this.isShowNotPassBtn =false;
                    this.isShowPassBtn =false;
                    this.isShowUndeterminedBtn = false;
                    this.isShowEmailBtn = true;
                    this.isShowWeedOutBtn = true;
                    this.isShowOfferBtn = true;
                }
            },
            //查询事件
            findCandidates:function(){
                let filterStr = this.objTofilterStr(this.sentFilter());
                console.log(filterStr);

                this.$store.commit('updateStatusStore' , this.activeFilter);

                //获取并存到状态库
                this.getCandidateList();

            },
            //存为筛选器
            makeSureSaveSizer: function(value){
                let saveingSizer ={
                    "position": this.position,
                    "degree": this.degree,
                    "school": this.school,
                    "major": this.major,
                    "status": this.status,
                    "label": this.label.join(','),
                    "gender": this.gender,
                    "department": this.department,
                    "rank": this.rank,
                    "englishLevel": this.englishLevel.join(','),
                    "reward": this.reward,
                    "attachment": this.attachment,
                    "mobile": this.mobile,
                    "city": this.city,
                    "birthFrom": this.birthFrom,
                    "birthTo": this.birthTo,
                    "graduateFrom": this.graduateFrom,
                    "graduateTo": this.graduateTo,
                    "deliveryFrom": this.deliveryFrom,
                    "deliveryTo": this.deliveryTo
                }
                let filterData = {
                    name: value,
                    candidateProfile: saveingSizer,
                }
                console.log('创建筛选器')
               this.$http.post('company/users/filter/candidate',filterData,{headers: {'Content-Type':'application/json'}}).then(response =>{
                    if(response.status==200){
                        this.$message({
                            message: '创建成功',
                            duration:2000
                        });
                    }else{
                        this.$message({
                            message: '操作失败',
                            duration:2000
                        });
                    }

                    this.getFilterList();

                },response =>{

                });
            },
            saveSizer: function(){
                this.isSaveSizer=true;
            },
            closeSizer: function(){
                this.isSaveSizer = false;
            },
            closeMore: function(){
                this.isOpened=false;
            },
            //取消发邮件
            closeSentEmail(){
                this.showEmailModal = false;
            },
            //发邮件
            email(){
                console.log('发邮件')
                let candidates = this.multipleSelection;
                if(candidates.length===0){
                    this.$message({
                        message: '请选择操作的候选人',
                        type: 'warning',
                        duration:2000
                    });
                    return;
                };
                if(candidates.length>100){
                    this.$message({
                        message: '每次最多发送100份',
                        type: 'warning',
                        duration:2000
                    });
                };
                let noEmail = new Array();
                for(let i=0;i<candidates.length;i++ ){
                    if(!candidates[i].basic.email){
                        noEmail.push(candidates[i]);
                    }
                }
                if(noEmail.length>0){
                    this.$message({
                        message: '列表中'+noEmail[0].basic.name+'等'+noEmail.length+'人没有邮箱',
                        type: 'warning',
                        duration:2000
                    });
                    return;
                }
                this.showEmailModal = true;
            },
            //发送邮件
            sentEmail(val){
                let candidates = this.multipleSelection;
                console.log(val);
                let checkedCandidateList = new Array();
                for(let i=0;i<candidates.length;i++){
                    let a = {
                        "candidateId": candidates[i].id,
                        "candidateName" : candidates[i].basic.name,
                        "jobId": candidates[i].jobTarget[0].id,
                        "jobName": candidates[i].jobTarget[0].job_name,
                        "email":candidates[i].basic.email

                    }
                    checkedCandidateList.push(a);
                }
                let checkedCandidateLData = {
                    "emailSendDTOs":checkedCandidateList,
                    "stage":this.activeRecruiterFlowName,
                    "status":"已通知",
                    "localInfo":"",
                    "content": val.content,
                    "title": val.title
                };

                this.$http.post('/candidate/email',checkedCandidateLData,{headers: {'Content-Type':'application/json'}}).then(response =>{
                    if(response.status==200){
                        this.$message({
                            message: '操作成功',
                            duration:2000
                        });
                    }else{
                        this.$message({
                            message: '操作失败',
                            duration:2000
                        });
                    }

                //刷新招聘流程简历数
                this.findCandidates();
                    console.log(response.body);
                },response =>{

                });
            },
            //通过操作
            pass(){
                console.log('通过')
                let candidates = this.multipleSelection;
                if(candidates.length===0){
                    this.$message({
                        message: '请选择操作的候选人',
                        type: 'warning',
                        duration:2000
                    });
                    return;
                }
                let toStage =this.recruiterFlows[this.recruiterFlowsIndex+1].name;
                let jumpStageList = new Array();
                for(let i=0;i<candidates.length;i++){
                    let a = {
                        "id": candidates[i].id,
                        "stuId":candidates[i].stuId,
                        "jobId": candidates[i].jobTarget[0].id,
                        "jobName": candidates[i].jobTarget[0].job_name,
                        "candidateName" : candidates[i].basic.name
                    }
                    jumpStageList.push(a);
                }
                let jumpStageData = {
                    "appStageListDTOs":jumpStageList,
                    "fromStage":this.activeRecruiterFlowName,
                    "toStage":toStage
                };

                this.$http.put('/candidate/stage/pass',jumpStageData,{headers: {'Content-Type':'application/json'}}).then(response =>{
                    if(response.status==200){
                        this.$message({
                            message: '操作成功',
                            duration:2000
                        });
                    }else{
                        this.$message({
                            message: '操作失败',
                            duration:2000
                        });
                    }
                    console.log(response.body);
                //刷新招聘流程简历数
                this.findCandidates();
                this.refreshWorkFlow();
                    console.log(response.body);

                },response =>{

                });


            },
            //不通过
            noPass(){
                console.log('不通过')
                let candidates = this.multipleSelection;
                if(candidates.length===0){
                    this.$message({
                        message: '请选择操作的候选人',
                        type: 'warning',
                        duration:2000
                    });
                    return;
                }
                let checkedCandidateList = new Array();
                for(let i=0;i<candidates.length;i++){
                    let a = {
                        "id": candidates[i].id,
                        "stuId":candidates[i].stuId,
                        "jobId": candidates[i].jobTarget[0].id,
                        "jobName": candidates[i].jobTarget[0].job_name,
                        "candidateName" : candidates[i].basic.name
                    }
                    checkedCandidateList.push(a);
                }
                let checkedCandidateLData = {
                    "appStageListDTOs":checkedCandidateList,
                    "stage":this.activeRecruiterFlowName,
                    "status":"不通过"
                };

                this.$http.put('/candidate/status',checkedCandidateLData,{headers: {'Content-Type':'application/json'}}).then(response =>{
                    if(response.status==200){
                        this.$message({
                            message: '操作成功',
                            duration:2000
                        });
                    }else{
                        this.$message({
                            message: '操作失败',
                            duration:2000
                        });
                    }
                //刷新招聘流程简历数
                this.findCandidates();
                this.refreshWorkFlow();
                },response =>{

                    console.log(response.body);
                });
            },
            //确认offer
            confirmOffer(){
                console.log('确认offer')
                let candidates = this.multipleSelection;
                if(candidates.length===0){
                    this.$message({
                        message: '请选择操作的候选人',
                        type: 'warning',
                        duration:2000
                    });
                    return;
                }
                let checkedCandidateList = new Array();
                for(let i=0;i<candidates.length;i++){
                    let a = {
                        "id": candidates[i].id,
                        "stuId":candidates[i].stuId,
                        "jobId": candidates[i].jobTarget[0].id,
                        "jobName": candidates[i].jobTarget[0].job_name,
                        "candidateName" : candidates[i].basic.name
                    }
                    checkedCandidateList.push(a);
                }
                let checkedCandidateLData = {
                    "appStageListDTOs":checkedCandidateList,
                    "stage":this.activeRecruiterFlowName,
                    "status":"确定OFFER"
                };

                this.$http.put('/candidate/status',checkedCandidateLData,{headers: {'Content-Type':'application/json'}}).then(response =>{
                    if(response.status==200){
                        this.$message({
                            message: '操作成功',
                            duration:2000
                        });
                    }else{
                        this.$message({
                            message: '操作失败',
                            duration:2000
                        });
                    }

                //刷新招聘流程简历数
                this.findCandidates();
                this.refreshWorkFlow();
                    console.log(response.body);
                },response =>{

                });
            },
            //淘汰
            weedOut(){
                console.log('淘汰')
                let candidates = this.multipleSelection;
                if(candidates.length===0){
                    this.$message({
                        message: '请选择操作的候选人',
                        type: 'warning',
                        duration:2000
                    });
                    return;
                }
                let checkedCandidateList = new Array();
                for(let i=0;i<candidates.length;i++){
                    let a = {
                        "id": candidates[i].id,
                        "stuId":candidates[i].stuId,
                        "jobId": candidates[i].jobTarget[0].id,
                        "jobName": candidates[i].jobTarget[0].job_name,
                        "candidateName" : candidates[i].basic.name
                    }
                    checkedCandidateList.push(a);
                }
                let checkedCandidateLData = {
                    "appStageListDTOs":checkedCandidateList,
                    "stage":this.activeRecruiterFlowName,
                    "status":"淘汰"
                };

                this.$http.put('/candidate/status',checkedCandidateLData,{headers: {'Content-Type':'application/json'}}).then(response =>{
                    if(response.status==200){
                        this.$message({
                            message: '操作成功',
                            duration:2000
                        });
                    }else{
                        this.$message({
                            message: '操作失败',
                            duration:2000
                        });
                    }

                //刷新招聘流程简历数
                this.findCandidates();
                this.refreshWorkFlow();
                    console.log(response.body);
                },response =>{

                });
            },
            //待定
            undetermined(){
                console.log('待定')
                let candidates = this.multipleSelection;
                if(candidates.length===0){
                    this.$message({
                        message: '请选择操作的候选人',
                        type: 'warning',
                        duration:2000
                    });
                    return;
                }
                let checkedCandidateList = new Array();
                for(let i=0;i<candidates.length;i++){
                    let a = {
                        "id": candidates[i].id,
                        "stuId":candidates[i].stuId,
                        "jobId": candidates[i].jobTarget[0].id,
                        "jobName": candidates[i].jobTarget[0].job_name,
                        "candidateName" : candidates[i].basic.name
                    }
                    checkedCandidateList.push(a);
                }
                let checkedCandidateLData = {
                    "appStageListDTOs":checkedCandidateList,
                    "stage":this.activeRecruiterFlowName,
                    "status":"待定"
                };

                this.$http.put('/candidate/status',checkedCandidateLData,{headers: {'Content-Type':'application/json'}}).then(response =>{
                    if(response.status==200){
                        this.$message({
                            message: '操作成功',
                            duration:2000
                        });
                    }else{
                        this.$message({
                            message: '操作失败',
                            duration:2000
                        });
                    }
                //刷新招聘流程简历数
                this.findCandidates();
                this.refreshWorkFlow();
                    console.log(response.body);
                },response =>{

                });
            },
            //阶段跳转
            stageJump(toStage){
                //console.log('跳转到'+toStage);
                let candidates = this.multipleSelection;
                if(candidates.length===0){
                    this.$message({
                        message: '请选择操作的候选人',
                        type: 'warning',
                        duration:3000
                    });
                    return;
                }
                let jumpStageList = new Array();
                for(let i=0;i<candidates.length;i++){
                    let a = {
                        "id": candidates[i].id,
                        "stuId":candidates[i].stuId,
                        "jobId": candidates[i].jobTarget[0].id,
                        "jobName": candidates[i].jobTarget[0].job_name,
                        "candidateName" : candidates[i].basic.name
                    }
                    jumpStageList.push(a);
                }
                let jumpStageData = {
                    "appStageListDTOs":jumpStageList,
                    "fromStage":this.activeRecruiterFlowName,
                    "toStage":toStage
                };
                console.log(jumpStageData);

                this.$http.put('/candidate/stage/skip',jumpStageData,{headers: {'Content-Type':'application/json'}}).then(response =>{
                    if(response.status==200){
                        this.$message({
                            message: '操作成功',
                            duration:2000
                        });
                    }else{
                        this.$message({
                            message: '操作失败',
                            duration:2000
                        });
                    }
                //刷新招聘流程简历数
                this.findCandidates();
                this.refreshWorkFlow();
                },response =>{
                    console.log(response.body);

                });
            },
            batchAddTag(tag){
                console.log('打标签'+tag);
                let candidates = this.multipleSelection;
                if(candidates.length===0){
                    this.$message({
                        message: '请选择操作的候选人',
                        type: 'warning',
                        duration:2000
                    });
                    return;
                }
                // for(let i=0;i<candidates.length;i++){
                //     let ownTags = new Array();
                //     let cts = candidates[i].tags
                //     for(let j=0;j<cts.length;i++){
                //         if(cts[j].optId === this.userId){
                //             ownTags.push(cts[j]);
                //         }
                //     }
                //     if(ownTags.length>=3){
                //         this.$message({
                //             message: '您已经对'+candidates[i].basic.name+'打过3个标签',
                //             type: 'warning',
                //             duration:2000
                //         });
                //         return;
                //     }
                //     if(ownTags.find(tag)){
                //         this.$message({
                //             message: '您已经对'+candidates[i].basic.name+'打过此标签',
                //             type: 'warning',
                //             duration:2000
                //         });
                //         return;
                //     }
                // }

                let addTagList = new Array();
                for(let i=0;i<candidates.length;i++){
                    let a = {
                        "id": candidates[i].id,
                        "jobId": candidates[i].jobTarget[0].id,
                        "jobName": candidates[i].jobTarget[0].job_name,
                        "candidateName" : candidates[i].basic.name
                    }
                    addTagList.push(a);

                }

                let addTagData = {
                    "tags":tag,
                    "appTagList":addTagList,
                    "optId":this.userId,
                    "optName":this.userName,
                    "stage":this.activeRecruiterFlowName
                }




                this.$http.post('/candidate/tags',addTagData,{headers: {'Content-Type':'application/json'}}).then(response =>{
                    if(response.status==200){
                        this.$message({
                            message: '操作成功',
                            duration:2000
                        });
                    }else{
                        this.$message({
                            message: '操作失败',
                            duration:2000
                        });
                    }
                    this.findCandidates();
                })
            },
            handleSelectionChange(val) {
                this.multipleSelection = val;
                // /* eslint-disable */
                // console.log(this.multipleSelection[0].basic.name);
                // /* eslint-disable */

            },
            objTofilterStr(obj){
                //console.log(obj);
                let str = JSON.stringify(obj);
               // console.log(str+'这错了')
                let filterStr = str.substr(1,str.length-2);
                return filterStr;
            },
            //发送的筛选条件
            sentFilter:function (){
                return {
                    "rid": this.recId,
                    // 投递职位
                    "pst":this.position,
                    // 最高学历
                    "dgr": this.degree,
                    // 毕业院校
                    "scl": this.school,
                    // 专业
                    "mj": this.major,
                   //流程
                    "stg": this.activeRecruiterFlowId,
                    // 处理状态
                    "sta": this.status,
                    // 简历标签
                    "lb": this.label.join(','),
                    // 性别
                    "gd": this.gender,
                    // 聘用部门
                    "dp": this.department,
                    // // 实习经历
                    // "pts": this.practices,
                    // 项目经验
                    // "wk": this.work,
                    // // 专业排名
                    "rank": this.rank,
                    // 英语等级
                    "egL": this.englishLevel.join(','),
                    // 奖学金
                    "rd": this.reward,
                    // 参赛经历
                    //"cmpt": this.competition,
                    // 附件简历
                    "att": this.attachment,
                     //名字
                    "nm": this.name,
                    // 手机号码
                    "mb": this.mobile,
                    // 家庭所在地
                    "ct": this.city,
                    // 出生年份开始时间
                    "brF": this.birthFrom,
                    // 出生年份截止时间
                    "brT": this.birthTo,
                    // 毕业时间开始
                    "gdF": this.graduateFrom,
                    // 毕业时间截止
                    "gdT": this.graduateTo,
                    // 投递日期开始
                    "dlF":this.deliveryFrom,
                    // 投递日期截止
                    "dlT":this.deliveryTo,
                    "no": this.currentPage,
                    "sz": this.pageSize,
                    "st": this.sort,

                }
            }
            // headerImg: function (CandidateStr) {
            //     return CandidateStr.charAt(CandidateStr.length - 1);
            // },
            // colorBg: function (CandidateStr) {
            //     let colorArr = ['#e9573e', '#3eb7e9', '#e99b3e', '#a1a1ff', '#21b99b', '#ec5d85', '#ddd'],
            //         charStr = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
            //         num;
            //     let str = makePy(CandidateStr),
            //         strNum = charStr.indexOf(str) + 1;
            //     switch (true) {
            //         case strNum > 0 && strNum <= 5:
            //             num = 0;
            //             break;
            //         case strNum > 5 && strNum <= 10:
            //             num = 1;
            //             break;
            //         case strNum > 10 && strNum <= 15:
            //             num = 2;
            //             break;
            //         case strNum > 15 && strNum <= 18:
            //             num = 3;
            //             break;
            //         case strNum > 18 && strNum <= 22:
            //             num = 4;
            //             break;
            //         case strNum > 22 && strNum <= 26:
            //             num = 5;
            //             break;
            //         default:
            //             num = 6;
            //     }
            //     return {
            //         backgroundColor: colorArr[num]
            //     }
            // },

            // headerClick(column,event) {
            //     /* eslint-disable */
            //     console.log(column.label);
            //     /* eslint-disable */
            // }
        },
        created(){
            this.statusItems=this.statusItemss[this.activeRecruiterFlowType];
            this.activeControllerButton();
            this.regainStatus();
            if(this.currentModalName===this.activeRecruiterFlowName){
                this.getFilterList();
                this.findCandidates();
                this.getTagsList();
                this.getJobList()
            }

        },

        mounted() {


        },

        components: {
            SaveSizer,
            SelectDepartmentModal,
            SelectCityModal,
            SelectUniversityModal,
            SentEmailMessageModal

        }
    }

    // function checkCh(ch) {
    //     let uni = ch.charCodeAt(0);
    //     //如果不在汉字处理范围之内,返回原字符,也可以调用自己的处理函数
    //     if (uni > 40869 || uni < 19968) return ch;
    //     //检查是否是多音字,是按多音字处理,不是就直接在strChineseFirstPY字符串中找对应的首字母
    //     return (oMultiDiff[uni] ? oMultiDiff[uni] : (strChineseFirstPY.charAt(uni - 19968)));
    // }

    // function makePy(str) {
    //     if (typeof(str) != "string") throw new Error(-1, "函数makePy需要字符串类型参数!");
    //     let lastStr = str.charAt(str.length-1),
    //         newStr = checkCh(lastStr);
    //     return newStr;
    //}

</script>

<style lang="less" scoped>

@import "../../less/shared/variables.less";
    .candidate-modal {

        .candidate-filter {
            border: 1px solid transparent;
            width: 100%;
            background: #f6f8fc;
            padding: 10px 20px;
            box-sizing: border-box;
        }

        .select-default-preliminary {
            width: 100%;
            border: @border-gray;
            background: @white;
            padding: 20px 20px;
            margin-bottom: 15px;
            box-sizing: border-box;

            .button-preliminary {
                text-align: center;
               margin-top: 30px;
               margin-bottom: 10px;
                width: 1140px;
                .openMore {
                    position: absolute;
                    right: 0px;
                }

                .gray-button {
                    background-color: #eeeeee;
                }
            }
        }
        .el-row {
            margin-bottom: 12px;
            &:last-child {
                margin-bottom: 0;
            }
        }

        .el-form-item {
            margin-bottom: 0;
        }

        .options-all {
            width: 100%;
            border: @border-gray;
            background: @white;
            padding: 20px 20px;
            margin-bottom: 15px;
            box-sizing: border-box;

            .button-list {
                text-align: center;
                width: 1140px;
                margin-top:30px;
                margin-bottom: 10px;
                .close-more {
                    position: absolute;
                    right: 0px;
                    }
                .my-button {
                        width:90px;
                        height:34px;
                    }
                .gray-button {
                    background-color: #eeeeee;
                }

            }
        }

        .controller-body {
            border: 1px solid transparent;
            width: 1178px;
            height:50px;
            background: #eeeeee;
            margin-top: 22px;
            margin-bottom: 22px;
            position:relative;

            .my-select-list {
                float: right;
                position: relative;

                right:25px;
                top:50px;
            }
            .show-set {
                background-color: #fff;
                position: absolute;
                right: 20px;
                width: 110px;
                height: 30px;
                margin:0;
                top:10px;
            }
            .con-ul {
                padding:0;
                margin:0;
                li{
                    list-style-type:none;
                    display: inline-block;
                    float: left;
                    height:30px;
                    margin:10px 0px;
                    text-align:center;
                    line-height: 30px;

                }
            }

        }

        .resume-table-model {
            border: 1px solid transparent;
            width: 1180px;
            background: #fff;
            .router-link {
                text-decoration: none;
            }
            .el-checkbox__inner {
                margin-left: 20px;
                width:12px;
                height: 12px;
            }
            .el-table .cell {
                position:relative;
                .headerImg {
                border-radius: 50%;
                width:30px;
                height:30px;
                position:absolute;
                top:50%;
                left:0px;
                transform:translateY(-50%);
                }
                .acc-photo {

                    display:inline-block;
                    overflow:hidden;
                    background: url(../../img/candidate/photo.png) no-repeat;
                    position:absolute;
                    float:right;
                    text-align:center;
                    line-height: 30px;
                    width:15px;
                    height:15px;
                    top:50%;
                    right: 15px;
                    transform:translateY(-50%);
                }
                .acc-pdf {

                    display:inline-block;
                    overflow:hidden;
                    background: url(../../img/candidate/pdf.png) no-repeat;
                    position:absolute;
                     float:right;
                    display:inline-block;
                    width:15px;
                    height:15px;
                    top:50%;
                    right: 15px;
                    transform:translateY(-50%);
                }
                .acc-word {
                    float:right;
                    display:inline-block;
                    overflow:hidden;
                    background: url(../../img/candidate/word.png) no-repeat;
                    position:absolute;
                    width:15px;
                    height:15px;
                    top:50%;
                    right: 15px;
                    transform:translateY(-50%);
                }

            }

        }
        .sanjiao {
            border-right: 4px solid #555555;
            border-bottom: 4px solid #555555;
            border-left: 4px solid transparent;
            border-top: 4px solid transparent;
            width: 0;
            height: 0;
            display:inline-block;
            cursor: pointer;
        }
        .sanjiao-xia {
            border-right: 5px solid transparent;
            border-bottom: 5px solid transparent;
            border-left: 5px solid transparent;
            border-top: 5px solid #b5b5b5;
            width: 0;
            height: 0;
            display:inline-block;
            position: absolute;
            right:6px;
            top:12px;
        }
    }
    .cursor_pointer {
            cursor: pointer;
    }
    .el-popover li {
            list-style-type:none;
        }
</style>
<style lang="less">

    .select-default-preliminary {
        .el-input__inner {
            height: 34px;
        }
        .my-button {
            width:90px;
            height:34px;
        }

    }
    .options-all {
        .el-input__inner {
            height: 34px;
        }

    }
    .controller-body {
        a {
            color:#dbdbdb;
            text-decoration: none;
        }
    }
    .jq-date-group {
                & > .el-form-item__content {
                    width: 234px;
                }
                .el-date-editor--date,.el-date-editor--year {
                    width: 95%;
                    float: left;
                    cursor: pointer;
                    .el-input__inner {
                        cursor: pointer;
                    }
                }
            }
        .resume-table-model, .el-popover{
            .el-table .cell, .el-table th>div{
            padding-left: 0;
            padding-right: 0;
            }
            .el-tag {
                margin:2px;
                border-radius: 10px;
                height: 20px;
                line-height: 18px;
                background-color: #ffd86f;
                color: #464646;
                border-color: #ffbc05;
            }
        }

    .resume-table-model .el-checkbox__inner {
        margin-left: 20px;
        border-radius:0;
    }
    .el-button--text {
        color:#000000;
        }
    .pagination {
        width:1180px;
        height:90px;
    }
</style>
