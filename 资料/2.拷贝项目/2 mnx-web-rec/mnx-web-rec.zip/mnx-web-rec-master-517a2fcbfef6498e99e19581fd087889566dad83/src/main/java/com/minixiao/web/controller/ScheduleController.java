package com.minixiao.web.controller;

import com.minixiao.apiauth.client.HeaderUtil;
import com.minixiao.web.dto.ScheduleDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Controller
@RequestMapping(value = "/candidate")
public class ScheduleController {
    private static final Logger logger = LoggerFactory.getLogger(ScheduleController.class);

    RestTemplate restTemplate = new RestTemplate();

    /**
     * @return
     */
    @GetMapping("/schedule")
    @ResponseBody
    public Page<ScheduleDTO> findList(Pageable pageable) {
        String url = "http://192.168.1.156:9112/candidate/schedule?";
        int page = pageable.getPageNumber();
        url += "page=" + page;
        int size = pageable.getPageSize();
        url += "&size=" + size;
        UUID optUid = UUID.fromString("354bdb8f-ecd6-4c82-80fe-5f42db62d0a1");
        String optName = "小米";
        UUID recId = UUID.fromString("dcb765d9-b394-4258-9d5b-371bf88483e2");
        String recName = "迷你校";
        HttpHeaders requestHeaders = HeaderUtil.getHeader(optUid, optName, "COMPANY", recId,
            recName);
        HttpEntity<String> request = new HttpEntity<String>(null, requestHeaders);
        ResponseEntity<Map> rEntity = restTemplate.exchange(url, HttpMethod.GET,
            request, Map.class);
        Object obj = rEntity.getBody().get("content");
        Object total = rEntity.getBody().get("totalElements");
        if (obj instanceof ArrayList<?>) {
            List list = (ArrayList) obj;
            return new PageImpl(list, pageable, Long.valueOf(total.toString()));
        }
        return null;
    }

    @PostMapping("/schedule")
    @ResponseBody
    public UUID saveSchedule(@RequestBody ScheduleDTO scheduleDTO) {
        String url = "http://192.168.1.156:9112/candidate/schedule";
        UUID optUid = UUID.fromString("354bdb8f-ecd6-4c82-80fe-5f42db62d0a1");
        String optName = "小米";
        UUID recId = UUID.fromString("354bdb8f-ecd6-4c82-80fe-5f42db62d0a1");
        String recName = "迷你校";
        HttpHeaders requestHeaders = HeaderUtil.getHeader(optUid, optName, "COMPANY", recId,
            recName);
        requestHeaders.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<ScheduleDTO> request = new HttpEntity<ScheduleDTO>(scheduleDTO, requestHeaders);
        ResponseEntity<UUID> rEntity = restTemplate.exchange(url, HttpMethod.POST,
            request, UUID.class);
        return rEntity.getBody();
    }

    @PutMapping("/schedule/{scheduleId}")
    @ResponseBody
    public String modifySchedule(@RequestBody ScheduleDTO scheduleDTO, @PathVariable UUID scheduleId) {
        String url = "http://192.168.1.156:9112/candidate/schedule/"+scheduleId;
        UUID optUid = UUID.fromString("354bdb8f-ecd6-4c82-80fe-5f42db62d0a1");
        String optName = "小米";
        UUID recId = UUID.fromString("354bdb8f-ecd6-4c82-80fe-5f42db62d0a1");
        String recName = "迷你校";
        HttpHeaders requestHeaders = HeaderUtil.getHeader(optUid, optName, "COMPANY", recId,
            recName);
        requestHeaders.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<ScheduleDTO> request = new HttpEntity<ScheduleDTO>(scheduleDTO, requestHeaders);
        ResponseEntity<String> rEntity = restTemplate.exchange(url, HttpMethod.PUT,
            request, String.class);
        return rEntity.getBody();
    }

    @DeleteMapping ("/schedule/{scheduleId}")
    @ResponseBody
    public String cancelSchedule(@PathVariable UUID scheduleId) {
        String url = "http://192.168.1.156:9112/candidate/schedule/"+scheduleId;
        UUID optUid = UUID.fromString("354bdb8f-ecd6-4c82-80fe-5f42db62d0a1");
        String optName = "小米";
        UUID recId = UUID.fromString("354bdb8f-ecd6-4c82-80fe-5f42db62d0a1");
        String recName = "迷你校";
        HttpHeaders requestHeaders = HeaderUtil.getHeader(optUid, optName, "COMPANY", recId,
            recName);
        requestHeaders.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> request = new HttpEntity<String>(null, requestHeaders);
        ResponseEntity<String> rEntity = restTemplate.exchange(url, HttpMethod.DELETE,
            request, String.class);
        return rEntity.getBody();
    }
}
