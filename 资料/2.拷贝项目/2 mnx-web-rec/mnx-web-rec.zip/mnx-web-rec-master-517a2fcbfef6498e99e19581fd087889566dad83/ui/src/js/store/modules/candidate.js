


// initial state
const state = {
    //用于存储招聘流程中筛选状态
    statusStore:{},
    //  搜索
    searchContent:'',
    //筛选器列表
    filterList:[],
     //获取的流程列表
    recruiterFlows:[],
    //当前查看流程
    activeRecruiterFlowTab:'recruiterFlow0',
    candidateDate:{
      // "total": 120,
      // "pageNumber": 0,
      // "pageSize": 15,
      // "applicationDTOList": [
        // {
        //   "id": "b9aa0c00-bac7-40ad-9eaf-44df0ce62857",
        //   "stuId": "354bdb8f-ecd6-4c82-80fe-5f42db62d0a1",
        //   "recId": "354bdb8f-ecd6-4c82-80fe-5f42db62d0a1",
        //   "recName": "今日头条",
        //   "jobTarget": [
        //     {
        //       "id": "354bdb8f-ecd6-4c82-80fe-5f42db62d0a1",
        //       "stuId": null,
        //       "area": "上海",
        //       "department": "北京分公司",
        //       "score": 20,
        //       "job_name": "Java工程师",
        //       "job_category": "技术开发类",
        //       "is_current": true,
        //       "current_status": "init"
        //     }
        //   ],
        //   "basic": {
        //     "name": "李1",
        //     "gender": "男",
        //     "email": "1126971653@qq.com",
        //     "mobile": "13520115645",
        //     "birthday": "1992-12-14",
        //     "province": "澳门",
        //     "city": "内蒙古-阿拉善盟",
        //     "political": "共青团员"
        //   },
        //   "education": [
        //     {
        //       "rank": "2",
        //       "major": "计算机系统结构",
        //       "degree": "2",
        //       "school": "北京工业大学",
        //       "end_date": "2002-11",
        //       "is_highest": true,
        //       "start_date": "2000-10"
        //     }
        //   ],
        //   "stageId": null,
        //   "status": "3313",
        //   "tags": [
        //     {
        //       "id": "efdbec2a-289c-4442-b8e9-d80e172046e4",
        //       "applicationId": "b9aa0c97-bac7-40ad-9eaf-3ddf0ce62857",
        //       "tag": "待定",
        //       "optId": "693f8256-082b-46c9-b9e4-f24aad84b911",
        //       "optName": "图图",
        //       "creatDate": "20170304062614"
        //     }
        //   ],
        //   "applyDate": "20170301054309"
        // },{
        //   "id": "b9aa0c00-bac7-40ad-9eaf-44df0ce62857",
        //   "stuId": "354bdb8f-ecd6-4c82-80fe-5f42db62d0a1",
        //   "recId": "354bdb8f-ecd6-4c82-80fe-5f42db62d0a1",
        //   "recName": "今日头条",
        //   "jobTarget": [
        //     {
        //       "id": "354bdb8f-ecd6-4c82-80fe-5f42db62d0a1",
        //       "stuId": null,
        //       "area": "上海",
        //       "department": "北京分公司",
        //       "score": 20,
        //       "job_name": "Java工程师",
        //       "job_category": "技术开发类",
        //       "is_current": true,
        //       "current_status": "init"
        //     }
        //   ],
        //   "basic": {
        //     "name": "李1",
        //     "gender": "男",
        //     "email": "1126971653@qq.com",
        //     "mobile": "13520115645",
        //     "birthday": "1992-12-14",
        //     "province": "澳门",
        //     "city": "内蒙古-阿拉善盟",
        //     "political": "共青团员"
        //   },
        //   "education": [
        //     {
        //       "rank": "2",
        //       "major": "计算机系统结构",
        //       "degree": "4",
        //       "school": "北京工业大学",
        //       "end_date": "2002-11",
        //       "is_highest": true,
        //       "start_date": "2000-10"
        //     }
        //   ],
        //   "stageId": null,
        //   "status": "3313",
        //   "tags": [
        //     {
        //       "id": "efdbec2a-289c-4442-b8e9-d80e172046e4",
        //       "applicationId": "b9aa0c97-bac7-40ad-9eaf-3ddf0ce62857",
        //       "tag": "待定",
        //       "optId": "693f8256-082b-46c9-b9e4-f24aad84b911",
        //       "optName": "图图",
        //       "creatDate": "20170304062614"
        //     }
        //   ],
        //   "applyDate": "20170301054309"
        // },{
        //   "id": "b9aa0c00-bac7-40ad-9eaf-44df0ce62857",
        //   "stuId": "354bdb8f-ecd6-4c82-80fe-5f42db62d0a1",
        //   "recId": "354bdb8f-ecd6-4c82-80fe-5f42db62d0a1",
        //   "recName": "今日头条",
        //   "jobTarget": [
        //     {
        //       "id": "354bdb8f-ecd6-4c82-80fe-5f42db62d0a1",
        //       "stuId": null,
        //       "area": "上海",
        //       "department": "北京分公司",
        //       "score": 20,
        //       "job_name": "Java工程师",
        //       "job_category": "技术开发类",
        //       "is_current": true,
        //       "current_status": "init"
        //     }
        //   ],
        //   "basic": {
        //     "name": "李1",
        //     "gender": "男",
        //     "email": "1126971653@qq.com",
        //     "mobile": "13520115645",
        //     "birthday": "1992-12-14",
        //     "province": "澳门",
        //     "city": "内蒙古-阿拉善盟",
        //     "political": "共青团员"
        //   },
        //   "education": [
        //     {
        //       "rank": "2",
        //       "major": "计算机系统结构",
        //       "degree": "1",
        //       "school": "北京工业大学",
        //       "end_date": "2002-11",
        //       "is_highest": true,
        //       "start_date": "2000-10"
        //     }
        //   ],
        //   "stageId": null,
        //   "status": "3313",
        //   "tags": [
        //     {
        //       "id": "efdbec2a-289c-4442-b8e9-d80e172046e4",
        //       "applicationId": "b9aa0c97-bac7-40ad-9eaf-3ddf0ce62857",
        //       "tag": "待定",
        //       "optId": "693f8256-082b-46c9-b9e4-f24aad84b911",
        //       "optName": "图图",
        //       "creatDate": "20170304062614"
        //     }
        //   ],
        //   "applyDate": "20170301054309"
        // },{
        //   "id": "b9aa0c00-bac7-40ad-9eaf-44df0ce62857",
        //   "stuId": "354bdb8f-ecd6-4c82-80fe-5f42db62d0a1",
        //   "recId": "354bdb8f-ecd6-4c82-80fe-5f42db62d0a1",
        //   "recName": "今日头条",
        //   "jobTarget": [
        //     {
        //       "id": "354bdb8f-ecd6-4c82-80fe-5f42db62d0a1",
        //       "stuId": null,
        //       "area": "上海",
        //       "department": "北京分公司",
        //       "score": 20,
        //       "job_name": "Java工程师",
        //       "job_category": "技术开发类",
        //       "is_current": true,
        //       "current_status": "init"
        //     }
        //   ],
        //   "basic": {
        //     "name": "李1",
        //     "gender": "男",
        //     "email": "1126971653@qq.com",
        //     "mobile": "13520115645",
        //     "birthday": "1992-12-14",
        //     "province": "澳门",
        //     "city": "内蒙古-阿拉善盟",
        //     "political": "共青团员"
        //   },
        //   "education": [
        //     {
        //       "rank": "2",
        //       "major": "计算机系统结构",
        //       "degree": "3",
        //       "school": "北京工业大学",
        //       "end_date": "2002-11",
        //       "is_highest": true,
        //       "start_date": "2000-10"
        //     }
        //   ],
        //   "resume": {
        //         "id": null,
        //         "fileURL": "www.bai.com",
        //         "fileName": "我的技术类简历.doc",
        //         "contentType": "application/ms-word",
        //         "contentSize": 123456
        //       },
        //   "stageId": null,
        //   "status": "3313",
        //   "tags": [
        //     {
        //       "id": "efdbec2a-289c-4442-b8e9-d80e172046e4",
        //       "applicationId": "b9aa0c97-bac7-40ad-9eaf-3ddf0ce62857",
        //       "tag": "待定",
        //       "optId": "693f8256-082b-46c9-b9e4-f24aad84b911",
        //       "optName": "图图",
        //       "creatDate": "20170304062614"
        //     }
        //   ],
        //   "applyDate": "20170301054309"
        // }]
    },
    //管理标签列表
    tagsList:[
        // {
        //     "id" : "37f73fb1-7069-4597-927e-51d5fd81bcef",
        //     "recId":"27f73fb1-7069-4597-927e-51d5fd81bcef",
        //     "name" : "优秀",
        //     "useCount": 20,
        //     "createOn": "20170203042034",
        //     "updatedOn": "20170203042034",
        //     "status":true
        // },
        // {
        //    "id" : "37f73fb1-7069-4597-927e-51d5fd81bcef",
        //     "recId":"27f73fb1-7069-4597-927e-51d5fd81bcef",
        //     "name" : "优秀",
        //     "useCount": 20,
        //     "createOn": "20170203042034",
        //     "updatedOn": "20170203042034",
        //     "status":true
        // },
        // {
        //     "id" : "37f73fb1-7069-4597-927e-51d5fd81bcef",
        //     "recId": "27f73fb1-7069-4597-927e-51d5fd81bcef",
        //     "name" : "优秀",
        //     "useCount": 20,
        //     "createOn": "20170203042034",
        //     "updatedOn": "20170203042034",
        //     "status":true
        // },
        // {
        //     "id" : "37f73fb1-7069-4597-927e-51d5fd81bcef",
        //     "recId":"27f73fb1-7069-4597-927e-51d5fd81bcef",
        //     "name" : "优秀",
        //     "useCount": 20,
        //     "createOn": "20170203042034",
        //     "updatedOn": "20170203042034",
        //     "status":false
        // }
    ],
    emailList:[
        // {
        //     name:'录用邮件',
        //     createdPeople:'张与',
        //     "createdOn": "20170207073647",
        //     "updatedOn": "20170207073647"

        // },
        // {
        //     name:'录用邮件',
        //     createdPeople:'张与',
        //     "createdOn": "20170207073647",
        //     "updatedOn": "20170207073647"

        // },
        // {
        //     name:'录用邮件',
        //     createdPeople:'张与',
        //     "createdOn": "20170207073647",
        //     "updatedOn": "20170207073647"

        // },
        // {
        //     name:'录用邮件',
        //     createdPeople:'张与',
        //     "createdOn": "20170207073647",
        //     "updatedOn": "20170207073647"

        // }
    ]
}

//getters
const getters = {
    activeRecruiterFlow(state) {

            let str = state.activeRecruiterFlowTab.substring(13);
            return state.recruiterFlows[str]
    },
}

//actions
const actions = {

}

//mutations
const mutations = {
    //更改招聘流程
    updateRecruiterFlows (state,value) {
        state.recruiterFlows = value;
    },

    //更改招聘流程显示页
    updateActiveRecruiterFlowTab (state,value) {
        state.activeRecruiterFlowTab = value;
    },

    //更改筛选条件存储
    updateStatusStore (state,filter) {
        state.statusStore[state.activeRecruiterFlowTab] = filter;
    },

    //更改候选人表格数据
    updateCandidateDate (state,value) {
        state.candidateDate = value;
    },

    //搜索
    updateSearchContent(state,value){
        state.searchContent = value;
    },
    //更新筛选器
    updateFilterList(state,value){
        state.filterList = value;
    },
    //更改标签列表
    updateTagsList(state,value){
        state.tagsList = value;
    },
    //更改邮件模板列表
    updateEmailList(state,value){
        state.emailList = value;
    },

}


export default {
  state,
  getters,
  actions,
  mutations
}
