// routers for candidate
import CandidateManage from '../../Components/Candidate/CandidateManage.vue';
import CandidateDetail from '../../Components/Candidate/CandidateDetail.vue';

export default [{
    path: '',
    redirect: 'manage'
}, {
    path: 'manage',
    component: CandidateManage
},{
    path: 'detail/:id',
    component: CandidateDetail
}];
