package cn.edu.dlut.career.service.company;


import cn.edu.dlut.career.domain.company.ExhPlaceOrder;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Created by HealerJean on 2017/3/27.
 */
public interface ExhPlaceOrderService {



    //保存，添加
    ExhPlaceOrder saveExHallOrder(ExhPlaceOrder exhPlaceOrder) ;

    //根据id查询
    ExhPlaceOrder findById(String id);

    // 更新
    ExhPlaceOrder updateExHallOrder(ExhPlaceOrder exhPlaceOrder);

    //根据id删除 删除成功返回 ok ，否则 null
    String deleteExHallOrder(String id);

    //查询所有的数据
    List<ExhPlaceOrder> findAllExHallOrder();

    //根据Id进行更新审核状态，审核时间，审核人
    int updateExhPlaceOrderAudit(String id, String auditState, LocalDateTime auditTime, String auditPerson);

}
