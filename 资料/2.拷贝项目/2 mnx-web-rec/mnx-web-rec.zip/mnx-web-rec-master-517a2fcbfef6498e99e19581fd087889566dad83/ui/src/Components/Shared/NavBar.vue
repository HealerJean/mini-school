<template>
    <el-menu default-active="1" class="el-menu-demo" mode="horizontal" :router="true">
        <el-menu-item :index="item.navUrl" v-for="item in navCons">{{ item.navName }}</el-menu-item>
    </el-menu>
</template>

<script>
export default {
    name: "nav-bar",
    data:function(){
      return {
        navCons:[
          {navUrl:'/', navName:'首页'},
          {navUrl:'/job', navName:'职位管理'},
          {navUrl:'/candidate/manage', navName:'简历管理'}
        ]
      }
    }
};
</script>
