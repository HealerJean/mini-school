package com.minixiao.web.dto.jobrequistion.embedment;

import java.time.LocalDateTime;

/**
 * @Description 审核实体类.
 * @Author JiangYh
 * @CreateTime 2017/2/13 12:05
 */
public class Audit {

  //审核状态
  private String status;

  //审核时间
  private LocalDateTime time;

  //失败原因
  private String failReason;

  //审核状态数据项
  public static enum Status {
    STATUS_WAITING("waiting"), STATUS_PASS("pass"), STATUS_NOT_THROUGH("notThrough");
    private String value;

    /**
     * .
     */
    private Status(String value) {
      this.value = value;
    }

    @Override
    public String toString() {
      return this.value;
    }
  }

  public Audit(String status, LocalDateTime time, String failReason) {
    this.status = status;
    this.time = time;
    this.failReason = failReason;
  }

  public Audit() {
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public LocalDateTime getTime() {
    return time;
  }

  public void setTime(LocalDateTime time) {
    this.time = time;
  }

  public String getFailReason() {
    return failReason;
  }

  public void setFailReason(String failReason) {
    this.failReason = failReason;
  }
}
