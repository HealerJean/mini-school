package com.minixiao.infra.subdomain.controller;

import com.minixiao.infra.subdomain.domain.Subdomain;
import com.minixiao.infra.subdomain.repository.SubdomainRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;
import java.util.List;
import java.util.UUID;

/**
 * Created by wei on 2017/3/21.
 */
@Controller
@Transactional
public class AdminController {
  private Logger logger = LoggerFactory.getLogger(HomeController.class);
  @Autowired
  private HttpServletRequest request;
  @Autowired
  private SubdomainRepository subdomianRepository;

  @GetMapping("index.html")
  public String home() {
      logger.info("index");
    return "index";
  }


  @ResponseBody
  @GetMapping("list.json")
  public List<Subdomain> find(String keyword) {
    //TODO:
    List<Subdomain> subdomains = null;
    if(StringUtils.hasLength(keyword)){
      subdomains = subdomianRepository.findByKeywords(keyword);
 }
    subdomains = subdomianRepository.findAll();
    return subdomains;
  }

  @DeleteMapping("delete.json")
  public String delete(int id) {
    subdomianRepository.delete(id);
    return "index";
  }

  @ResponseBody
  @PostMapping("add.json")
  public int add(@RequestBody Subdomain subdomain) {
    subdomianRepository.save(subdomain);
    int id = 1;
    return id;
  }

  @PutMapping("update.json")
  public String update(@RequestBody Subdomain subdomain) {
    subdomianRepository.save(subdomain);
    return "index";
  }

}
