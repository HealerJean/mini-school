package cn.edu.dlut.career.domain.student;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * Created by wei on 2017/4/5.
 * 空白协议申请表信息
 */
@Entity
@Table(name = "blank_protocol")
public class BlankProtocol {
    //编号，主键UUID
    @Id
    @GenericGenerator(name = "idGenerator",strategy = "uuid")
    @GeneratedValue(generator = "idGenerator")
    private String id;
    //学号
    @Column(length = 32,nullable = false)
    private String stuId;
    //姓名
    @Column(length=30,nullable = false)
    private String name;
    //学历层次（关联字典）
    @Column(length = 20,nullable = false)
    private String education;
    //所在年级
    @Column(length=20,nullable = false)
    private String grade;
    //所属院系
    @Column(length=20,nullable = false)
    private String department;
    //所学专业
    @Column(length=20,nullable = false)
    private String major;
    //联系电话
    @Column(length=20,nullable = false)
    private String tel;
    //电子邮件
    @Column(length=20,nullable = false)
    private String email;
    //毕业时间
    @Column(nullable = false)
    private LocalDateTime graduationTime;
    //申请原因
    @Column(length = 10,nullable = false)
    private String applicationReason;
    //申请原因备注
    @Column(length = 100,nullable = true)
    private String applicationReasonRemarks;
    //申请状态
    @Column(length =20,nullable = true)
    private String applicationStatus;
    //院系审批人
    @Column(length = 30,nullable = true)
    private String deptApprover;
    //院系审批时间
    @Column(nullable = true)
    private LocalDateTime deptApprovalTime;
    //院系审核是否同意
    @Column(length = 1,nullable = true)
    private String deptOpinion;
    //院系审核不同意原因
    @Column(length = 100,nullable = true)
    private String deptRejectionReason;
    //学校审批人
    @Column(length = 30,nullable = true)
    private String schoolApprover;
    //学校审批时间
    @Column(nullable = true)
    private LocalDateTime schoolApprovalTime;
    //学校审核是否同意
    @Column(length = 1,nullable = true)
    private String schoolOpinion;
    //学校审核不同意原因
    @Column(length = 100,nullable = true)
    private String schoolRejectionReason;
    //申请时间
    @Column(nullable = false)
    private LocalDateTime applicationTime;
    //生成协议书编号
    @Column(length = 40,nullable = true)
    private String agreementId;
    //空白协议书打印时间
    @Column(nullable = true)
    private LocalDateTime greementPrintingTtime;

    public BlankProtocol() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStuId() {
        return stuId;
    }

    public void setStuId(String stuId) {
        this.stuId = stuId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEducation() {
        return education;
    }

    public void setEducation(String education) {
        this.education = education;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public LocalDateTime getGraduationTime() {
        return graduationTime;
    }

    public void setGraduationTime(LocalDateTime graduationTime) {
        this.graduationTime = graduationTime;
    }

    public String getApplicationReason() {
        return applicationReason;
    }

    public void setApplicationReason(String applicationReason) {
        this.applicationReason = applicationReason;
    }

    public String getApplicationReasonRemarks() {
        return applicationReasonRemarks;
    }

    public void setApplicationReasonRemarks(String applicationReasonRemarks) {
        this.applicationReasonRemarks = applicationReasonRemarks;
    }

    public String getApplicationStatus() {
        return applicationStatus;
    }

    public void setApplicationStatus(String applicationStatus) {
        this.applicationStatus = applicationStatus;
    }

    public String getDeptApprover() {
        return deptApprover;
    }

    public void setDeptApprover(String deptApprover) {
        this.deptApprover = deptApprover;
    }

    public LocalDateTime getDeptApprovalTime() {
        return deptApprovalTime;
    }

    public void setDeptApprovalTime(LocalDateTime deptApprovalTime) {
        this.deptApprovalTime = deptApprovalTime;
    }

    public String getDeptOpinion() {
        return deptOpinion;
    }

    public void setDeptOpinion(String deptOpinion) {
        this.deptOpinion = deptOpinion;
    }

    public String getDeptRejectionReason() {
        return deptRejectionReason;
    }

    public void setDeptRejectionReason(String deptRejectionReason) {
        this.deptRejectionReason = deptRejectionReason;
    }

    public String getSchoolApprover() {
        return schoolApprover;
    }

    public void setSchoolApprover(String schoolApprover) {
        this.schoolApprover = schoolApprover;
    }

    public LocalDateTime getSchoolApprovalTime() {
        return schoolApprovalTime;
    }

    public void setSchoolApprovalTime(LocalDateTime schoolApprovalTime) {
        this.schoolApprovalTime = schoolApprovalTime;
    }

    public String getSchoolOpinion() {
        return schoolOpinion;
    }

    public void setSchoolOpinion(String schoolOpinion) {
        this.schoolOpinion = schoolOpinion;
    }

    public String getSchoolRejectionReason() {
        return schoolRejectionReason;
    }

    public void setSchoolRejectionReason(String schoolRejectionReason) {
        this.schoolRejectionReason = schoolRejectionReason;
    }

    public LocalDateTime getApplicationTime() {
        return applicationTime;
    }

    public void setApplicationTime(LocalDateTime applicationTime) {
        this.applicationTime = applicationTime;
    }

    public String getAgreementId() {
        return agreementId;
    }

    public void setAgreementId(String agreementId) {
        this.agreementId = agreementId;
    }

    public LocalDateTime getGreementPrintingTtime() {
        return greementPrintingTtime;
    }

    public void setGreementPrintingTtime(LocalDateTime greementPrintingTtime) {
        this.greementPrintingTtime = greementPrintingTtime;
    }
}
