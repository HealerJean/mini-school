package com.minixiao.web.dto.candidate;


import com.fasterxml.jackson.annotation.JsonFormat;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;
import java.util.UUID;

/**
 * @Author 王迎接 【wangyj@minixiao.com】.
 * @Date 2017/2/22  11:11.
 */

public class Tags {


  private UUID id;

  private UUID applicationId;

  private String tag;

  private UUID optId;

  private String optName;

  @JsonFormat(pattern = "yyyyMMddhhmmss")
  private LocalDateTime creatDate;

  public Tags() {
  }

  public Tags(UUID id, UUID applicationId, String tag, UUID optId, String optName, LocalDateTime creatDate) {
    this.id = id;
    this.applicationId = applicationId;
    this.tag = tag;
    this.optId = optId;
    this.optName = optName;
    this.creatDate = creatDate;
  }

  public UUID getId() {
    return id;
  }

  public void setId(UUID id) {
    this.id = id;
  }


  public String getTag() {
    return tag;
  }

  public void setTag(String tag) {
    this.tag = tag;
  }

  public UUID getOptId() {
    return optId;
  }

  public void setOptId(UUID optId) {
    this.optId = optId;
  }

  public String getOptName() {
    return optName;
  }

  public void setOptName(String optName) {
    this.optName = optName;
  }

  public LocalDateTime getCreatDate() {
    return creatDate;
  }

  public void setCreatDate(LocalDateTime creatDate) {
    this.creatDate = creatDate;
  }

  public UUID getApplicationId() {
    return applicationId;
  }

  public void setApplicationId(UUID applicationId) {
    this.applicationId = applicationId;
  }
}
