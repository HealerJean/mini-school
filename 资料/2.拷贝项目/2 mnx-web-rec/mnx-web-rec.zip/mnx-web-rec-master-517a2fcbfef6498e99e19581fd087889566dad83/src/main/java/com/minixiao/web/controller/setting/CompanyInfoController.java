package com.minixiao.web.controller.setting;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.minixiao.apiauth.client.HeaderUtil;
import com.minixiao.web.dto.recruiters.RecruiterInfo;
import com.minixiao.web.dto.recruiters.UserDTO;
import com.minixiao.web.utils.YmlConfig;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * @Description 修改公司信息相关controller.
 * @Author xiachao
 * @CreateTime 2017/2/27 11:35
 */
@Controller
public class CompanyInfoController {
    private Logger logger = LoggerFactory.getLogger(CompanyInfoController.class);

    private RestTemplate restTemplate = new RestTemplate();

    @Autowired
    private YmlConfig ymlConfig;

    private ObjectMapper objectMapper = new ObjectMapper();

    /**
     * @Description 根据公司Id查询公司详细信息 返回json串.
     * @Author xiachao
     * @CreateTime 2017/2/27 11:46
     * @Param
     * @Return
     */
    @RequestMapping("/company")
    @ResponseBody
    public String getRecruiterInfo() {
            Subject subject = SecurityUtils.getSubject();
            if (subject != null) {
                UserDTO user = (UserDTO) subject.getSession().getAttribute(
                    ymlConfig.getSession_current_user());
                if (user != null) {
                    UUID userId2 = user.getId();
                    String userName = user.getRealName();
                    UUID recId2 = user.getRecId();
                    String recName = user.getRecName();
                    HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                        recId2, recName);
                    HttpEntity requestEntity = new HttpEntity(null, httpHeaders);
                    ResponseEntity<String> companyInfo = restTemplate.exchange(
                        ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2, HttpMethod.GET, requestEntity,
                        String.class);
                    if (companyInfo.getBody() != null) {
                        return companyInfo.getBody();
                    }
                }
        }
        return null;
    }

    /**
     * @Description 根据公司Id查询公司详细信息 返回json串.
     * @Author xiachao
     * @CreateTime 2017/2/27 11:46
     * @Param
     * @Return
     */
    @RequestMapping("/company/detail")
    @ResponseBody
    public String getRecruiter() {
        Subject subject = SecurityUtils.getSubject();
        if (subject != null) {
            UserDTO user = (UserDTO) subject.getSession().getAttribute(
                ymlConfig.getSession_current_user());
            if (user != null) {
                UUID userId2 = user.getId();
                String userName = user.getRealName();
                UUID recId2 = user.getRecId();
                String recName = user.getRecName();
                HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                    recId2, recName);
                HttpEntity requestEntity = new HttpEntity(null, httpHeaders);
                ResponseEntity<String> companyInfo = restTemplate.exchange(
                    ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2, HttpMethod.GET, requestEntity,
                    String.class);
                if (companyInfo.getBody() != null) {
                    return companyInfo.getBody();
                }
            }
        }
    return null;
    }

    /**
     * @Description 修改公司性质 .
     * @Author xiachao
     * @CreateTime 2017/2/28 12:03
     * @Param
     * @Return
     */
    @PutMapping("/company/modification/nature")
    @ResponseBody
    public String modifyRecruiterNature(String nature) {
        if (nature != null ) {
            Subject subject = SecurityUtils.getSubject();
            if (subject != null) {
                UserDTO user = (UserDTO) subject.getSession().getAttribute(
                    ymlConfig.getSession_current_user());
                if (user != null) {
                    UUID userId2 = user.getId();
                    String userName = user.getRealName();
                    UUID recId2 = user.getRecId();
                    String recName = user.getRecName();
                    HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                        recId2, recName);
                    Map<String, String> map = new HashMap<String, String>();
                    map.put("nature", nature);
                    String requestBody = "";
                    try {
                        requestBody = objectMapper.writeValueAsString(map);
                    } catch (JsonProcessingException e) {
                        e.printStackTrace();
                    }
                    httpHeaders.setContentType(MediaType.APPLICATION_JSON_UTF8);
                    HttpEntity requestEntity = new HttpEntity(requestBody, httpHeaders);
                    ResponseEntity<String> responseEntity = restTemplate.exchange(
                        ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2, HttpMethod.PUT, requestEntity,
                        String.class);
                    if (responseEntity != null) {
                        return responseEntity.getBody();
                    }
                }
            }
        }
        return null;
    }


    /**
     * @Description 修改公司规模 .
     * @Author xiachao
     * @CreateTime 2017/2/28 12:03
     * @Param
     * @Return
     */
    @PutMapping("/company/modification/size")
    @ResponseBody
    public String modifyRecruiterSize(String size) {
        if (size != null ) {
            Subject subject = SecurityUtils.getSubject();
            if (subject != null) {
                UserDTO user = (UserDTO) subject.getSession().getAttribute(
                    ymlConfig.getSession_current_user());
                if (user != null) {
                    UUID userId2 = user.getId();
                    String userName = user.getRealName();
                    UUID recId2 = user.getRecId();
                    String recName = user.getRecName();
                    HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                        recId2, recName);
                    Map<String, String> map = new HashMap<String, String>();
                    map.put("size", size);
                    String requestBody = "";
                    try {
                        requestBody = objectMapper.writeValueAsString(map);
                    } catch (JsonProcessingException e) {
                        e.printStackTrace();
                    }
                    httpHeaders.setContentType(MediaType.APPLICATION_JSON_UTF8);
                    HttpEntity requestEntity = new HttpEntity(requestBody, httpHeaders);
                    ResponseEntity<String> responseEntity = restTemplate.exchange(
                        ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2, HttpMethod.PUT, requestEntity,
                        String.class);
                    if (responseEntity != null) {
                        return responseEntity.getBody();
                    }
                }
            }
        }
        return null;
    }

    /**
     * @Description 修改公司一级行业类别 .
     * @Author xiachao
     * @CreateTime 2017/2/28 12:03
     * @Param
     * @Return
     */
    @PutMapping("company/modification/primaryIndustry")
    @ResponseBody
    public String modifyRecruiterPrimary(String primaryIndustry) {
        if (primaryIndustry != null) {
            Subject subject = SecurityUtils.getSubject();
            if (subject != null) {
                UserDTO user = (UserDTO) subject.getSession().getAttribute(
                    ymlConfig.getSession_current_user());
                if (user != null) {
                    UUID userId2 = user.getId();
                    String userName = user.getRealName();
                    UUID recId2 = user.getRecId();
                    String recName = user.getRecName();
                    HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                        recId2, recName);
                    Map<String, String> map = new HashMap<String, String>();
                    map.put("primaryIndustry", primaryIndustry);
                    String requestBody = "";
                    try {
                        requestBody = objectMapper.writeValueAsString(map);
                    } catch (JsonProcessingException e) {
                        e.printStackTrace();
                    }
                    httpHeaders.setContentType(MediaType.APPLICATION_JSON_UTF8);
                    HttpEntity requestEntity = new HttpEntity(requestBody, httpHeaders);
                    ResponseEntity<String> responseEntity = restTemplate.exchange(
                        ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2, HttpMethod.PUT, requestEntity,
                        String.class);
                    if (responseEntity != null) {
                        return responseEntity.getBody();
                    }
                }
            }
        }
        return null;
    }

    /**
     * @Description 修改公司二级行业类别 .
     * @Author xiachao
     * @CreateTime 2017/2/28 12:03
     * @Param
     * @Return
     */
    @PutMapping("company/modification/slaveIndustry")
    @ResponseBody
    public String modifyRecruiterSlave(String slaveIndustry) {
        if (slaveIndustry != null ) {
            Subject subject = SecurityUtils.getSubject();
            if (subject != null) {
                UserDTO user = (UserDTO) subject.getSession().getAttribute(
                    ymlConfig.getSession_current_user());
                if (user != null) {
                    UUID userId2 = user.getId();
                    String userName = user.getRealName();
                    UUID recId2 = user.getRecId();
                    String recName = user.getRecName();
                    HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                        recId2, recName);
                    Map<String, String> map = new HashMap<String, String>();
                    map.put("slaveIndustry", slaveIndustry);
                    String requestBody = "";
                    try {
                        requestBody = objectMapper.writeValueAsString(map);
                    } catch (JsonProcessingException e) {
                        e.printStackTrace();
                    }
                    httpHeaders.setContentType(MediaType.APPLICATION_JSON_UTF8);
                    HttpEntity requestEntity = new HttpEntity(requestBody, httpHeaders);
                    ResponseEntity<String> responseEntity = restTemplate.exchange(
                        ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2, HttpMethod.PUT, requestEntity,
                        String.class);
                    if (responseEntity != null) {
                        return responseEntity.getBody();

                    }
                }
            }
        }
        return null;
    }

    /**
     * @Description 修改公司所在省市 .
     * @Author xiachao
     * @CreateTime 2017/2/28 12:03
     * @Param
     * @Return
     */
    @PutMapping("company/modification/city")
    @ResponseBody
    public String modifyRecruiterCity(String city) {
        if (city != null ) {
            Subject subject = SecurityUtils.getSubject();
            if (subject != null) {
                UserDTO user = (UserDTO) subject.getSession().getAttribute(
                    ymlConfig.getSession_current_user());
                if (user != null) {
                    UUID userId2 = user.getId();
                    String userName = user.getRealName();
                    UUID recId2 = user.getRecId();
                    String recName = user.getRecName();
                    HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                        recId2, recName);
                    Map<String, String> map = new HashMap<String, String>();
                    map.put("city", city);
                    String requestBody = "";
                    try {
                        requestBody = objectMapper.writeValueAsString(map);
                    } catch (JsonProcessingException e) {
                        e.printStackTrace();
                    }
                    httpHeaders.setContentType(MediaType.APPLICATION_JSON_UTF8);
                    HttpEntity requestEntity = new HttpEntity(requestBody, httpHeaders);
                    ResponseEntity<String> responseEntity = restTemplate.exchange(
                        ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2, HttpMethod.PUT, requestEntity,
                        String.class);
                    if (responseEntity != null) {
                        return responseEntity.getBody();
                    }
                }
            }
        }
        return null;
    }

    /**
     * @Description 修改公司官方网站 .
     * @Author xiachao
     * @CreateTime 2017/2/27 17:19
     * @Param
     * @Return
     */
    @PutMapping("company/modification/website")
    @ResponseBody
    public String modifyRecruiterWebsite(String website) {
        if (website != null ) {
            Subject subject = SecurityUtils.getSubject();
            if (subject != null) {
                UserDTO user = (UserDTO) subject.getSession().getAttribute(
                    ymlConfig.getSession_current_user());
                if (user != null) {
                    UUID userId2 = user.getId();
                    String userName = user.getRealName();
                    UUID recId2 = user.getRecId();
                    String recName = user.getRecName();
                    HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                        recId2, recName);
                    Map<String, String> map = new HashMap<String, String>();
                    map.put("website", website);
                    String requestBody = "";
                    try {
                        requestBody = objectMapper.writeValueAsString(map);
                    } catch (JsonProcessingException e) {
                        e.printStackTrace();
                    }
                    httpHeaders.setContentType(MediaType.APPLICATION_JSON_UTF8);
                    HttpEntity requestEntity = new HttpEntity(requestBody, httpHeaders);
                    ResponseEntity<String> responseEntity = restTemplate.exchange(
                        ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2, HttpMethod.PUT, requestEntity,
                        String.class);
                    if (responseEntity != null) {
                        return responseEntity.getBody();
                    }
                }
            }
        }
        return null;
    }


    /**
     * @Description 修改公司详细地址 .
     * @Author xiachao
     * @CreateTime 2017/2/28 12:03
     * @Param
     * @Return
     */
    @PutMapping("company/modification/detailAddress")
    @ResponseBody
    public String modifyRecruiterAddress(String detailAddress) {
        if (detailAddress != null ) {
            Subject subject = SecurityUtils.getSubject();
            if (subject != null) {
                UserDTO user = (UserDTO) subject.getSession().getAttribute(
                    ymlConfig.getSession_current_user());
                if (user != null) {
                    UUID userId2 = user.getId();
                    String userName = user.getRealName();
                    UUID recId2 = user.getRecId();
                    String recName = user.getRecName();
                    HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                        recId2, recName);
                    Map<String, String> map = new HashMap<String, String>();
                    map.put("detailAddress", detailAddress);
                    String requestBody = "";
                    try {
                        requestBody = objectMapper.writeValueAsString(map);
                    } catch (JsonProcessingException e) {
                        e.printStackTrace();
                    }
                    httpHeaders.setContentType(MediaType.APPLICATION_JSON_UTF8);
                    HttpEntity requestEntity = new HttpEntity(requestBody, httpHeaders);
                    ResponseEntity<String> responseEntity = restTemplate.exchange(
                        ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2, HttpMethod.PUT, requestEntity,
                        String.class);
                    if (responseEntity != null) {
                        return responseEntity.getBody();
                    }
                }
            }
        }
        return null;
    }

    /**
     * @Description 修改公司标签 .
     * @Author xiachao
     * @CreateTime 2017/2/28 12:03
     * @Param
     * @Return
     */
    @PutMapping("company/modification/tags")
    @ResponseBody
    public String modifyRecruiterTags(String tags) {
        if (tags != null ) {
            Subject subject = SecurityUtils.getSubject();
            if (subject != null) {
                UserDTO user = (UserDTO) subject.getSession().getAttribute(
                    ymlConfig.getSession_current_user());
                if (user != null) {
                    UUID userId2 = user.getId();
                    String userName = user.getRealName();
                    UUID recId2 = user.getRecId();
                    String recName = user.getRecName();
                    HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                        recId2, recName);
                    Map<String, String> map = new HashMap<String, String>();
                    map.put("tags", tags);
                    String requestBody = "";
                    try {
                        requestBody = objectMapper.writeValueAsString(map);
                    } catch (JsonProcessingException e) {
                        e.printStackTrace();
                    }
                    httpHeaders.setContentType(MediaType.APPLICATION_JSON_UTF8);
                    HttpEntity requestEntity = new HttpEntity(requestBody, httpHeaders);
                    ResponseEntity<String> responseEntity = restTemplate.exchange(
                        ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2, HttpMethod.PUT, requestEntity,
                        String.class);
                    if (responseEntity != null) {
                        return responseEntity.getBody();
                    }
                }
            }
        }
        return null;
    }


    /**
     * @Description 修改公司logo .
     * @Author xiachao
     * @CreateTime 2017/2/28 12:01
     * @Param
     * @Return
     */
    @PutMapping("company/modification/logo")
    @ResponseBody
    public String modifyRecruiterLogo(String logo) {
        if (logo != null ) {
            Subject subject = SecurityUtils.getSubject();
            if (subject != null) {
                UserDTO user = (UserDTO) subject.getSession().getAttribute(
                    ymlConfig.getSession_current_user());
                if (user != null) {
                    UUID userId2 = user.getId();
                    String userName = user.getRealName();
                    UUID recId2 = user.getRecId();
                    String recName = user.getRecName();
                    HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                        recId2, recName);
                    Map<String, String> map = new HashMap<String, String>();
                    map.put("logo", logo);
                    String requestBody = "";
                    try {
                        requestBody = objectMapper.writeValueAsString(map);
                    } catch (JsonProcessingException e) {
                        e.printStackTrace();
                    }
                    httpHeaders.setContentType(MediaType.APPLICATION_JSON_UTF8);
                    HttpEntity requestEntity = new HttpEntity(requestBody, httpHeaders);
                    ResponseEntity<String> responseEntity = restTemplate.exchange(
                        ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2, HttpMethod.PUT, requestEntity,
                        String.class);
                    if (responseEntity != null) {
                        return responseEntity.getBody();
                    }
                }
            }
        }
        return null;
    }

    /**
     * @Description 修改公司一句话介绍 .
     * @Author xiachao
     * @CreateTime 2017/2/28 12:03
     * @Param
     * @Return
     */
    @PutMapping("company/modification/slogan")
    @ResponseBody
    public String modifyRecruiterSlogan(String slogan) {
        if (slogan != null) {
            Subject subject = SecurityUtils.getSubject();
            if (subject != null) {
                UserDTO user = (UserDTO) subject.getSession().getAttribute(
                    ymlConfig.getSession_current_user());
                if (user != null) {
                    UUID userId2 = user.getId();
                    String userName = user.getRealName();
                    UUID recId2 = user.getRecId();
                    String recName = user.getRecName();
                    HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                        recId2, recName);
                    Map<String, String> map = new HashMap<String, String>();
                    map.put("slogan", slogan);
                    String requestBody = "";
                    try {
                        requestBody = objectMapper.writeValueAsString(map);
                    } catch (JsonProcessingException e) {
                        e.printStackTrace();
                    }
                    httpHeaders.setContentType(MediaType.APPLICATION_JSON_UTF8);
                    HttpEntity requestEntity = new HttpEntity(requestBody, httpHeaders);
                    ResponseEntity<String> responseEntity = restTemplate.exchange(
                        ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2, HttpMethod.PUT, requestEntity,
                        String.class);
                    if (responseEntity != null) {
                        return responseEntity.getBody();
                    }
                }
            }
        }
        return null;
    }


    /**
     * @Description 修改公司简介 .
     * @Author xiachao
     * @CreateTime 2017/2/28 12:03
     * @Param
     * @Return
     */
    @PutMapping("company/modification/description")
    @ResponseBody
    public String modifyRecruiterDescription(String description) {
        if (description != null) {
            Subject subject = SecurityUtils.getSubject();
            if (subject != null) {
                UserDTO user = (UserDTO) subject.getSession().getAttribute(
                    ymlConfig.getSession_current_user());
                if (user != null) {
                    UUID userId2 = user.getId();
                    String userName = user.getRealName();
                    UUID recId2 = user.getRecId();
                    String recName = user.getRecName();
                    HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                        recId2, recName);
                    Map<String, String> map = new HashMap<String, String>();
                    map.put("description", description);
                    String requestBody = "";
                    try {
                        requestBody = objectMapper.writeValueAsString(map);
                    } catch (JsonProcessingException e) {
                        logger.error("jackson序列化出错");
                        e.printStackTrace();
                    }
                    httpHeaders.setContentType(MediaType.APPLICATION_JSON_UTF8);
                    HttpEntity requestEntity = new HttpEntity(requestBody, httpHeaders);
                    ResponseEntity<String> responseEntity = restTemplate.exchange(
                        ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2, HttpMethod.PUT, requestEntity,
                        String.class);
                    if (responseEntity != null) {
                        return responseEntity.getBody();
                    }
                }
            }
        }
        return null;
    }

    /**
     * @Description 修改公司信息 .
     * @Author JiangYh
     * @CreateTime 2017/3/12 12:03
     * @Param
     * @Return
     */
    @PutMapping("company/modification")
    @ResponseBody
    public String modifyRecruiterInfo(@RequestBody RecruiterInfo recruiterInfoDto) {
        if (recruiterInfoDto != null) {
            Subject subject = SecurityUtils.getSubject();
            if (subject != null) {
                UserDTO user = (UserDTO) subject.getSession().getAttribute(
                    ymlConfig.getSession_current_user());
                if (user != null) {
                    UUID userId2 = user.getId();
                    String userName = user.getRealName();
                    UUID recId2 = user.getRecId();
                    String recName = user.getRecName();
                    HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                        recId2, recName);
                    httpHeaders.setContentType(MediaType.APPLICATION_JSON_UTF8);
                    HttpEntity requestEntity = new HttpEntity(recruiterInfoDto, httpHeaders);
                    ResponseEntity<String> responseEntity = restTemplate.exchange(
                        ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2, HttpMethod.PUT, requestEntity,
                        String.class);
                    if (responseEntity != null) {
                        return responseEntity.getBody();
                    }
                }
            }
        }
        return null;
    }
}
