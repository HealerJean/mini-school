// routers for job
import JobList from '../../Components/Job/JobList.vue';
import JobAdd from '../../Components/Job/JobAdd.vue';
import JobEdit from '../../Components/Job/JobEdit.vue';
import JobPosition from '../../Components/Job/JobPosition.vue';

export default [{
    path: '',
    redirect: 'list'
}, {
    path: 'list',
    component: JobList
}, {
    path: 'add',
    component: JobAdd
},
{
    path: 'edit/:id',
    component: JobEdit
},
{
    path: 'position/:id',
    component: JobPosition
}];
