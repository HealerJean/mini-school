package cn.edu.dlut.career.recruiter.domain;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.UUID;

/**
 * 展位 表
 * Created by HealerJean on 2017/3/24.
 */
@Entity
@Table(name="rec_exhibite_place")
public class ExhPlace {

    //编号id
    @Id
    @GenericGenerator(name = "idGenerator", strategy = "uuid")
    @GeneratedValue(generator = "idGenerator")
    private String id;

    //展厅编号ExhId
    private UUID exhId;

    //名称name
    @Column(length = 20)
    private String name;

    //面积acreage
    @Column(length=15)
    private String acreage;

    //费用：金额
    private Double cost;

    //状态
    @Column(length=10)
    private String status;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public UUID getExhId() {
        return exhId;
    }

    public void setExhId(UUID exhId) {
        this.exhId = exhId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAcreage() {
        return acreage;
    }

    public void setAcreage(String acreage) {
        this.acreage = acreage;
    }

    public Double getCost() {
        return cost;
    }

    public void setCost(Double cost) {
        this.cost = cost;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
