<template>
    <div class="cp-open-main">
        <h1>请提供贵公司的基本信息，我们将为您免费开通服务</h1>
        <div class="cp-open-form">
            <form role="form" class="form-horizontal">
                <ul class="list-unstyled clearfix">
                    <li>
                        <el-row>
                            <el-col :span="4">
                                <label for="companyName" class="control-label"><span class="red-star">*</span>公司名称</label>
                            </el-col>
                            <el-col :span="20">
                                <input 
                                    type="text" 
                                    class="form-control" 
                                    name="corpName" 
                                    id="companyName" 
                                    placeholder="您为哪家公司开通服务" 
                                    required 
                                    autocomplete="off"
                                >
                            </el-col>
                        </el-row>
                    </li>
                    <li>
                        <el-row>
                            <el-col :span="4">
                                <label for="companyTel" class="control-label">
                                    <span class="red-star">*</span>联系电话
                                </label>
                            </el-col>
                            <el-col :span="20">
                                <input type="text" 
                                    class="form-control" 
                                    id="companyTel" 
                                    name="mobile" 
                                    placeholder="您的办公电话号码" 
                                    regex="(((0\d{2,3}-\d{7,8}$))|((0\d{2,3}\d{7,8}$))|(((13[0-9])|(15[^4,\D])|(18[0-9])|(17[0,7,8,9])|(147))\d{8}$))" 
                                    autocomplete="off" 
                                    required
                                >
                            </el-col>
                        </el-row>
                    </li>
                    <li>
                        <el-row>
                            <el-col :span="4">
                                <label for="companyEmail" class="control-label">
                                    <span class="red-star">*</span>联系邮箱
                                </label>
                            </el-col>
                            <el-col :span="20">
                                <input 
                                    type="text" 
                                    class="form-control" 
                                    id="companyEmail" 
                                    name="email" 
                                    placeholder="您的公司邮箱地址" 
                                    regType="email" 
                                    required 
                                    autocomplete="off"
                                >
                            </el-col>
                        </el-row>
                    </li>
                </ul>
                <div class="btn-group btn-cpL">
                    <input type="button" id="submit" class="btn btn-register" value="申请开通"/>
                </div>
            </form>
            <p class="text-right cpL-p">
            	已开通服务，点这里<a href="/login.html">登录</a>
            </p>
            <p class="text-center cpL-pf">申请开通即视为您已阅读并同意<a href="/register/st/privacy.html" target="_blank">《迷你校客户协议》</a></p>
        </div>
    </div>
</template>

<script type="text/babel">
    export default {
        data() {
            return {};
        }
    }

</script>

<style lang="less" scoped>

    a:link,
    a:visited,
    a:active,
    a:hover {
	    text-decoration: none;
    }
    a, 
    button, 
    a:focus {
        outline: none;
        -moz-outline: none;
    }
    body {
        background: #fafafa;
    }
    .list-unstyled {
        padding-left: 0;
        list-style: none;
    }
    .el-row {
        margin: 0 0 30px;
    }
    .el-row .el-col-4 {
        width: 90px;
        padding: 0 16px 0 0;
    }
    .el-row .el-col-20 {
         padding: 0;
    }
    .el-row .el-col-20 input {
        width: 90%;
    }
    .btn-register {
        color: #fff;
        background-color: #049cff;
        border-color: #049cff;
        cursor: pointer;
        border-radius: 3px;
        outline: 0 !important;
        border: 1px solid transparent;
    }
    .text-right {
        text-align: right;
    }
    .cp-open-main {
        background: #e7f6fe url("../../img/cp-open-bg.jpg") right top
            no-repeat;
        width: 1200px;
        margin: 30px auto;
        padding: 75px 0 20px;
        min-height: 576px;
    }
    .cp-open-main h1 {
        font-size: 18px;
        text-align: center;
        margin: 0 0 30px 0;
        text-indent: 60px;
    }
    .cp-open-main .form-horizontal .col-xs-2 {
        width: 90px;
        padding: 0 16px 0 0;
    }
    .cp-open-main .form-horizontal .form-group {
        margin: 0 0 30px;
    }
    .cp-open-main label {
        font-weight: 400;
    }
    .cp-open-main .control-label, .cp-open-main .form-control {
        line-height: 50px;
        height: 50px;
        font-size: 16px;
        padding: 0;
        color: #464646 !important;
    }
    .cp-open-main .form-control {
        padding: 0 20px;
        margin: 0;
    }
    .cp-open-main .red-star {
        height: 50px;
        background: url("../../img/red-star.png") no-repeat left 21px;
        margin-top: 0;
    }
    .cp-open-main .btn-group.btn-cpL {
        margin: 0 0 0 93px;
    }
    .cp-open-main .btn {
        width: 450px;
        height: 50px;
        line-height: 50px;
        padding: 0;
        font-size: 16px;
    }
    .cp-open-form {
        width: 540px;
        margin: 0 auto;
        overflow: hidden;
    }
    .cpL-p {
        color: #666;
        font-size: 16px;
        line-height: 2;
    }
    .cpL-p a, .cpL-p a:hover {
        color: #049cff;
    }
    .cpL-pf {
        margin-top: 70px;
        font-size: 14px;
        color: #999;
        text-indent: 80px;
    }
    .cpL-pf a{
        color:#049cff;
    }
    .cp-open-main h2 {
        font-size: 30px;
        color: #438eff;
        text-align: center;
        margin-top: 90px;
        margin-left: -67px;
    }
    .cp-open-main h3 {
        font-size: 26px;
        color: #438eff;
        text-align: center;
        margin: 65px auto 25px;
    }
    .cp-open-main .cp-open-succ {
        width: 255px;
        margin: 0 auto;
        color: #666;
        line-height: 1;
    }
    .cp-open-main .cp-open-succ li {
        margin-bottom: 10px;
    }
    .cp-open-main .cpO-li1 {
        font-size: 16px;
    }
    .cp-open-main .cpO-li2 {
        font-size: 14px;
        text-indent: 17px;
    }
    .cp-open-main .cpL-dot {
        display: inline-block;
        width: 6px;
        height: 6px;
        background: #666;
        margin-right: 10px;
        margin-bottom: 2px;
    }
    .has-error .form-control {
        border-color: #ccc !important;
    }
    .help-warning {
        margin: 5px 0px 10px;
        display: block;
        color: #737373;
        font-size: 13px;
        font-family: "Open Sans", sans-serif;
        direction: ltr;
    }
    .has-error .help-warning {
        padding-left: 20px;
        color: #ff6a6a;
        background: transparent url("../../img/error.png") no-repeat
            scroll 0 0;
    }
    .btn-primary.disabled, 
    .btn-primary[disabled], 
    fieldset[disabled] .btn-primary, 
    .btn-primary.disabled:hover, 
    .btn-primary[disabled]:hover, 
    fieldset[disabled] .btn-primary:hover, 
    .btn-primary.disabled:focus, 
    .btn-primary[disabled]:focus, 
    fieldset[disabled] .btn-primary:focus, 
    .btn-primary.disabled:active, 
    .btn-primary[disabled]:active, 
    fieldset[disabled] .btn-primary:active, 
    .btn-primary.disabled.active, 
    .btn-primary[disabled].active, 
    fieldset[disabled] .btn-primary.active {
        background-color: #d5d5d5;
        border-color: #d5d5d5;
    }
</style>
