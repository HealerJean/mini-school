package com.minixiao.web.dto.jobrequistion.embedment;


/**
 * @Description 部门.
 * @Author JiangYh
 * @CreateTime 2017/2/13 12:05
 */
public class Department {

  //部门ID
  private String id;

  //部门名称
  private String name;

  public Department(String id, String name) {
    this.id = id;
    this.name = name;
  }

  public Department() {
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }
}
