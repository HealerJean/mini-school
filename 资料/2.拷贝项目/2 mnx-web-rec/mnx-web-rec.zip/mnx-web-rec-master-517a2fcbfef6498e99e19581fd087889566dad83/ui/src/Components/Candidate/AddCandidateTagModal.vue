<template>
    <div class="add-candidate-tag">
        <el-dialog title="添加标签"
            v-model="AddCandidatreTagModalVisible"
            size="tiny"
            :close-on-click-modal="false"
            :close-on-press-escape="false"
            @close="closeModal">
            <el-form :inline="true" :model="formInline" class="demo-form-inline">
                <el-form-item>
                    <el-input v-model="customTag" class=""></el-input>
                </el-form-item>
                <el-form-item>
                    <el-button @click="addTag">添加标签</el-button>
                </el-form-item>
                <p>（最多可添加5个标签，每个标签不可超过4个字符）</p>
            </el-form>
            <el-tag v-for="tag in addedTags"
                        :closable="true"
                        :close-transition="true"
                        @close="removeTag(tag)"
                        type="warning"
                >
                    {{ tag }}
                </el-tag>
            </el-tag>

            <div slot="footer" class="dialog-footer">
                <el-button type="primary" @click="saveAddTags">确 定</el-button>
                <el-button @click="closeModal">取 消</el-button>
            </div>
        </el-dialog>


    </div>
</template>

<script type="text/babel">
    import eventBus from '../../js/shared/eventBus';

    export default {
        name: 'add-candidate-tag',
        data:function(){
            return{
                customTag: '',
                addedTags:['通过','待沟通']
            }
        },
        computed: {
           AddCandidatreTagModalVisible() {
                return this.isAddTag;
            }
        },
        props:{
            isAddTag: {
                type: Boolean,
                default: false

            }
        },

        methods: {
            closeModal() {
                eventBus.$emit('modal:close-add-tag');
            },
            saveAddTags() {
                eventBus.$emit('add-tag', this.tags);
                eventBus.$emit('modal:close-add-tag');
            },
            addTag() {
                this.addedTags.push(this.customTag);
                this.customTag='';
            },
            removeTag(tag) {
                this.addedTags.splice(this.addedTags.indexOf(tag), 1);
            }

        }
    }
</script>

<style lang="less" >
    .add-candidate-tag {
        .el-dialog__header {
            text-align: center;
        }
        .el-dialog__body {
            text-align: center;
        }
        .el-input {
            height: 32px;
        }
        .el-input__inner {
            height: 32px;
        }
    }
</style>
