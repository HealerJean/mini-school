<template>
    <div class="users-wrap">
        <breadcrumb :breadcrumbs="breadcrumbs"></breadcrumb>
        <div class="users-main">
            <el-row>
                <el-col :span="12"><el-button type="primary" @click="toUsersAdd">添加用户</el-button></el-col>
                <el-col :span="12" style="text-align:right">
                    <div v-on:keyup.enter="searchUser">
                        <el-input placeholder="请输入姓名" icon="search" v-model="usersName" :on-icon-click="search" style="width:250px;">
                    </el-input>
                </el-col>
            </el-row>
            <el-table :data="usersList" border style="width: 100%" align="center">
                <el-table-column type="index" label="序号" width="50">
                </el-table-column>
                <el-table-column prop="realName" label="姓名" width="80">
                </el-table-column>
                <el-table-column prop="email" label="邮箱">
                </el-table-column>
                <el-table-column prop="mobile" label="手机号" width="140">
                </el-table-column>
                <el-table-column prop="tel" label="固话" width="120">
                </el-table-column>
                <el-table-column prop="deptName" label="所属部门" width="120">
                </el-table-column>
                <el-table-column prop="updatedOn" label="创建/修改时间" width="180" :formatter="formatTime">
                </el-table-column>
                <el-table-column prop="status" label="状态" width="80" :formatter="formatStatus">
                </el-table-column>
                <el-table-column label="操作" width="190">
                    <template scope="scope">
                        <el-button @click.native.prevent="editUsers(scope.row)" :plain="true" type="info" size="mini">修改</el-button>
                        <template v-if="scope.row.status == 'using'">
                            <el-button @click.native.prevent="stopUsers(scope.row)" :plain="true" size="mini">停用</el-button>
                        </template>
                        <template v-else-if="scope.row.status == 'disabled'">
                            <el-button @click.native.prevent="openUsers(scope.row)" :plain="true" type="success" size="mini">启用</el-button>
                        </template>
                        <el-button @click.native.prevent="deleteUsers(scope.$index,scope.row,usersList)" :plain="true" type="danger" size="mini">删除</el-button>
                    </template>
                </el-table-column>
            </el-table>
        </div>
    </div>
</template>

<script type="text/babel">
    import Breadcrumb from "../Shared/Breadcrumb.vue"

    export default {
        name: 'users',
        components: {
            Breadcrumb
        },
        data:function(){
            return{
                //面包屑
                breadcrumbs: [
                    {'router': '', 'text': '系统设置'},
                    {'router': '', 'text': '用户管理'}
                ],
                usersName:'',
                usersList: [
                   // {
                   //      "id" : "aaa-7069-4597-927e-51d5fd81bcef",
                   //      "email":"lis@minixiao.com",
                   //      "realName":"l李四",
                   //      "tel":"020-88975372" ,
                   //      "mobile":"139409206342",
                   //      "deptName":"运营组",
                   //      "isAdmin": false,
                   //      "status":"stop",
                   //      "createdOn": "20170118120600",
                   //      "updatedOn" : "20170122120600"
                   // }
                ]
            }
        },
        methods:{
            toUsersAdd(){
                this.$router.push({ path: 'add'})
            },
            formatStatus(val){
                console.log(val);
                let type = val.status;
                switch (type) {
                    case 'using':
                        return '正常';
                    case 'disabled':
                        return '已停用';
                    default:
                        return type;
                }
            },
            formatTime(val){
                let curTime = val.updatedOn;
                return curTime.replace(/\s/g, '').replace(/(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})/, "$1/$2/$3 $4:$5:$6");
            },
            deleteUsers(index,row,rows){
                rows.splice(index, 1);
                this.$http.delete('/company/users/'+row.id).then(response => {
                }, response => {
                    /* eslint-disable */
                    console.log('error');
                    /* eslint-disable */
                });
            },
            getUserList() {
                this.$http.get('/company/users').then(response =>{
                    console.log(newData);
                    let newData = response.body;
                    this.usersList = newData;
                })
            },
            editUsers(row){
                this.$router.push({ path: 'edit/'+row.id})
                
            },
            stopUsers(row){
                this.$http.put('/company/users/'+row.id+'/status?status=disabled').then(response => {
                    this.getUserList();
                }, response => {
                    /* eslint-disable */
                    console.log('error');
                    /* eslint-disable */
                });
            },
            openUsers(row){
                this.$http.put('/company/users/'+row.id+'/status?status=using').then(response => {
                    this.getUserList();
                }, response => {
                    /* eslint-disable */
                    console.log('error');
                    /* eslint-disable */
                });
            },
            searchUser(){
                console.log('searchUser');
                this.$http.get('/company/users&realName='+this.usersName).then(response =>{
                    let newData = response.body;
                    this.usersList = newData;
                })
            }
        },
        mounted(){
            let self=this;
            setTimeout(function(){
                self.getUserList();
            },500)
        }
    }

</script>

<style lang="less">
@import "../../less/shared/variables.less";
.users-main{
    background-color: @white;
    color: extract(@gray-group, 5);
    line-height: 50px;
    padding: 20px;
    margin-bottom: 20px;
    min-height:500px;
    .el-table {
        width:90%; margin:30px auto;
        border: none;
        color: extract(@gray-group, 3);
    }
    .el-table:before {
        height: 0;
    }
    .el-table:after {
        width: 0;
    }
    .el-table th.is-leaf {
        /*border-bottom: none;*/
    }
    .el-table--border td, .el-table--border th {
        border-right: none;
    }
    .el-table th {
        background-color: initial;
    }
    .el-table__fixed-header-wrapper thead div, .el-table__header-wrapper thead div {
        color: extract(@gray-group, 2);
        background-color: initial;
        text-align: center;
    }
    .el-table td {
        border-bottom: 1px dotted #ddd;
        padding: 8px 0 7px;
        text-align: center;
    }
    .el-table--enable-row-hover tr:hover > td {
        background-color: extract(@gray-group, 13);
    }
    .el-table .cell, .el-table th>div {
        padding-left: 10px;
        padding-right: 10px;
    }

    .el-button--mini.el-button{
        padding: 6px 8px;
        font-size: 14px;
        border-radius: 4px;
    }
    .el-button--default.is-plain {
        background-color: #fff;
        border-color: #aaa;
        color: #aaa;
    }
    .el-button--default.is-plain:focus, .el-button--default.is-plain:hover {
        background-color: #fff;
        border-color: #ccc;
        color: #ccc;
    }
    .el-button--info.is-plain{
        background: #fff;
        border: 1px solid #049cff;
        color: #049cff;
    }
    .el-button--info.is-plain:focus, .el-button--info.is-plain:hover {
        background: #fff;
        border-color: #73ccff;
        color: #73ccff;
    }
    .el-button--success.is-plain{
        background: #fff;
        border: 1px solid #13ce66;
        color: #13ce66;
    }
    .el-button--success.is-plain:focus, .el-button--success.is-plain:hover {
        background: #fff;
        border-color: #42d885;
        color: #42d885;
    }
    .el-button--danger.is-plain{
        background: #fff;
        border: 1px solid #ff4949;
        color: #ff4949;
    }
    .el-button--danger.is-plain:focus, .el-button--danger.is-plain:hover {
        background: #fff;
        border-color: #ff7e7e;
        color: #ff7e7e;
    }
    .el-button+.el-button {
        margin-left: 5px;
    }
}
</style>