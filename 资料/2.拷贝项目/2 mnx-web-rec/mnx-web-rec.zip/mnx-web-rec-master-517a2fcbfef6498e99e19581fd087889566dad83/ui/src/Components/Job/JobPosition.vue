<template>
    <div class="job-position-wrap">
        <el-row class="job-position-header">
            <el-col :span="12">
                <h1 class="job-position-title">{{ jobPosition.title }}</h1>
            </el-col>
            <el-col :span="12">
                <template v-if="isStatus && jobPosition.status != null">
                    <div class="jl-up-btn" @click="isOnlineing">
                        <i class="joblist-icon"></i>
                        <span>上线</span>
                    </div>
                </template>
                <router-link class="jl-edit-btn" :to="edit(jobPosition.id)">
                    <i class="joblist-icon"></i>
                    <span>编辑</span>
                </router-link>
                <template v-if="!isStatus && jobPosition.status != null">
                    <div class="jl-down-btn" @click="isOfflineing">
                        <i class="joblist-icon"></i>
                        <span>下线</span>
                    </div>
                </template>
            </el-col>
        </el-row>
        <el-row :gutter="35">
            <el-col :span="18" class="job-position-section">
                <template>
                    <el-tabs v-model="activeName">
                        <el-tab-pane label="职位详情" name="jobPosition">
                            <template v-if="jobPosition.status == 'open' && jobPosition.audit.status == 'waiting'">
                                <div class="job-position-tip">
                                    <ul>
                                        <li>提示：当前修改信息正在审核中审核通过后将自动替换已上线信息</li>
                                        <li>修改提交时间：{{ jobPosition.updatedOn | formatDate }}</li>
                                    </ul>
                                    <a class="job-preview-btn">
                                        <i class="joblist-icon"></i>
                                        <span>预览已上线信息</span>
                                    </a>
                                </div>
                            </template>
                            <template v-else-if="jobPosition.status == 'open' && jobPosition.audit.status == 'notThrough'">
                                <div class="job-position-tip">
                                    <ul>
                                        <li>提示：当前修改信息审核未通过</li>
                                        <li>修改提交时间：{{ jobPosition.updatedOn | formatDate }}</li>
                                    </ul>
                                    <p>审核未通过原因：{{ jobPosition.audit.failReason }}</p>
                                    <a class="job-preview-btn">
                                        <i class="joblist-icon"></i>
                                        <span>预览已上线信息</span>
                                    </a>
                                </div>
                            </template>
                            <template v-else-if="jobPosition.status == null && jobPosition.audit.status == 'notThrough'">
                                <div class="job-position-tip">
                                    <ul>
                                        <li>提示：当前信息审核未通过</li>
                                        <li>修改提交时间：{{ jobPosition.updatedOn | formatDate }}</li>
                                    </ul>
                                    <p>审核未通过原因：{{ jobPosition.audit.failReason }}</p>
                                </div>
                            </template>
                            <template v-else-if="jobPosition.status == null && jobPosition.audit.status == 'waiting'">
                                <div class="job-position-tip">
                                    <ul>
                                        <li>提示：当前职位信息正在审核中，我们将在1~2个工作日内完成审核</li>
                                        <li>修改提交时间：{{ jobPosition.updatedOn | formatDate }}</li>
                                    </ul>
                                </div>
                            </template>
                            <div class="job-position-info">
                                <el-row :gutter="20">
                                    <el-col :span="8">职位类别：
                                        <span>{{ jobPosition.jobCategory }}</span></el-col>
                                    <el-col :span="8">所属部门：
                                        <span>{{ jobPosition.department.name }}</span></el-col>
                                    <el-col :span="8">内部编号：
                                        <span>{{ jobPosition.innerNo }}</span></el-col>
                                </el-row>
                                <el-row :gutter="20">
                                    <el-col :span="8">工作地区：
                                        <span>{{ jobPosition.jobArea }}</span></el-col>
                                    <el-col :span="8">招聘人数：
                                        <span>{{ jobPosition.headcount | headcountFormat}}</span>
                                    </el-col>
                                    <el-col :span="8">薪酬范围：
                                        <template v-if="!jobPosition.sarlary.start && !jobPosition.sarlary.end">
                                            <span>面谈</span>
                                        </template>
                                         <template v-else-if="!jobPosition.sarlary.start && jobPosition.sarlary.end == 2000">
                                            <span>2000以下</span>
                                        </template>
                                         <template v-else-if="jobPosition.sarlary.start == 50000 && !jobPosition.sarlary.end">
                                            <span>50000以上</span>
                                        </template>
                                         <template v-else>
                                            <span>{{jobPosition.sarlary.start}}-{{jobPosition.sarlary.end}}/月</span>
                                        </template>
                                    </el-col>
                                </el-row>
                                <el-row :gutter="20">
                                    <el-col :span="8">学历要求：
                                        <span>{{ jobPosition.careerLevel }}</span></el-col>
                                    <el-col :span="8">网申时间：
                                        <span>{{ jobPosition.applyPeriod.applyBeginDate | formatDate }} - {{jobPosition.applyPeriod.applyEndDate | formatDate }}</span>
                                    </el-col>
                                </el-row>
                            </div>
                            <h2 class="job-desc-title">职位描述</h2>
                            <div class="job-position-article">
                                {{ jobPosition.description }}
                            </div>
                        </el-tab-pane>
                        <el-tab-pane label="操作历史" name="operationsHistory">
                            <el-table :data="jobOperationsHistory" border style="width: 100%" align="center">
                                <el-table-column prop="createdOn" label="日期" width="270px" :formatter="formatTime">
                                </el-table-column>
                                <el-table-column prop="optUname" label="操作人" width="270px">
                                </el-table-column>
                                <el-table-column prop="optType" label="操作类型" :formatter="optFormatType">
                                </el-table-column>
                            </el-table>
                            <el-pagination
                                @size-change="handleSizeChange"
                                @current-change="handleCurrentChange"
                                :current-page="currentPage"
                                :page-sizes="pageSizes"
                                :page-size="pageSize"
                                layout="total, sizes, prev, pager, next"
                                :total="total">
                            </el-pagination>
                        </el-tab-pane>
                    </el-tabs>
                </template>
            </el-col>
            <el-col :span="6">
                <div class="job-position-status">
                    <h2 class="jp-aside-title">职位状态</h2>
                    <p>状态
                        <template v-if="jobPosition.status == null">
                            <span>{{ jobPosition.audit.status | statusStr}}</span>
                        </template>
                        <template v-else-if="jobPosition.status == 'onHold'">
                            <span>{{ jobPosition.status | statusStr}}</span>
                        </template>
                        <template v-else>
                            <span>{{ jobPosition.status | statusStr}} （{{ jobPosition.audit.status | statusStr}}）</span>
                        </template>
                    </p>
                </div>
                <div class="job-position-recruitment">
                    <h2 class="jp-aside-title">招聘概况</h2>
                    <p>单位：份</p>
                    <ul class="jp-recruitment-list">
                        <li class="jp-recruitment-employed">
                            录用: {{ conditionStat.offerCount | toThousands }}
                        </li>
                        <li class="jp-recruitment-interview">
                            面试：{{ conditionStat.interviewCount | toThousands }}
                        </li>
                        <li class="jp-recruitment-test">
                            笔试：{{ conditionStat.writtenCount | toThousands }}
                        </li>
                        <li class="jp-recruitment-beginscreen">
                            初筛：{{ conditionStat.screenCount | toThousands }}
                        </li>
                    </ul>
                </div>
            </el-col>
        </el-row>
    </div>
</template>

<script type="text/babel">
    import echarts from 'echarts'
    export default {
        name: 'job-position',
        data() {
            return {
                activeName: 'jobPosition',
                status: false,
                jobFilter: {
                    date: '',
                    user: '',
                    type: ''
                },
                jobOperationsHistory: null,
                jobPosition: {
                    id: "",
                    title: "",
                    description: "",
                    status: null,
                    jobType: "",
                    headcount: "",
                    jobCategory: "",
                    careerLevel: "",
                    jobArea: "",
                    department: {
                        id: "",
                        name: ""
                    },
                    sarlary: {
                        type: "",
                        start: '',
                        end: ''
                    },
                    applyPeriod: {
                        applyBeginDate: '',
                        applyEndDate: ''
                    },
                    audit: {
                        status: null,
                        time: null,
                        failReason: ''
                    },
                    applyUrl: null,
                    innerNo: '',
                    createdOn: '',
                    updatedOn: '',
                    statistics: null
                },
                conditionStat:{
                    totalCount:null,
                    screenCount:null,
                    interviewCount:null,
                    writtenCount:null,
                    declineCount:null,
                    offerCount:null
                },
                //pages
                currentPage: 2,
                pageSizes: [1, 2, 3, 4],
                pageSize: 4,
                total: null
            };
        },
        computed: {
            isStatus: function () {
                let status = this.jobPosition.status;
                if (status == 'onHold') {
                    return this.status = true;
                } else if (status == 'open') {
                    return this.status = false;
                }
            }
        },
        methods: {
            edit(id){
                let jobPath = '/job/edit/'+id;
                return jobPath;
            },
            formatTime(val){
                let curTime = val.createdOn;
                return curTime.replace(/\s/g, '').replace(/(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})/, "$1/$2/$3 $4:$5:$6");
            },
            optFormatType(val){
                let type = val.optType;
                switch (type) {
                    case 'create':
                        return '创建';
                    case 'update':
                        return '修改';
                    case 'online':
                        return '已上线';
                    case 'offline':
                        return '已下线';
                    default:
                        return type;
                }
            },
            isOnlineing(){
                this.$http.put('/requisitions/'+this.$route.params.id+'/online').then(response =>{
                    this.getJobPosition();
                },response =>{
                    /* eslint-disable */
                    console.log(response);
                    /* eslint-disable */
                })
            },
            isOfflineing(){
                this.$http.put('/requisitions/'+this.$route.params.id+'/offline').then(response =>{
                    this.getJobPosition();
                },response =>{
                    /* eslint-disable */
                    console.log(response);
                    /* eslint-disable */
                })
            },
            handleSizeChange(val) {
                this.pageSize = val;
                this.getJobHistory();
            },
            handleCurrentChange(val) {
                this.currentPage = val;
                this.getJobHistory();
            },
            getJobHistory:function(){
                this.$http.get('/requisitionLog/'+this.$route.params.id+'?page='+(this.currentPage-1)+'&size='+this.pageSize).then(response => {
                    let newData = response.body.content;
                    this.jobOperationsHistory = newData;
                    this.total=response.body.totalElements;
                }, response => {
                    /* eslint-disable */
                    console.log('error');
                    /* eslint-disable */
                });
            },
            getJobPosition: function () {
                console.log(this.$route.params.id);
                this.$http.get('/requisitions/'+this.$route.params.id).then(response => {
                    let newData = response.body;
                    this.jobPosition = newData;
                }, response => {
                    /* eslint-disable */
                    console.log('error');
                    /* eslint-disable */
                });
                this.$http.get('/requisitions/'+this.$route.params.id+'/count').then(response => {
                    let newData = response.body;
                    this.conditionStat = newData;
                }, response => {
                    /* eslint-disable */
                    console.log('error');
                    /* eslint-disable */
                });
            }
        },
        filters: {
            formatDate: function (val) {
                if(val){
                    let curDate = val.toString().substring(0, 8);
                    return curDate.replace(/\s/g, '').replace(/(\d{4})(\d{2})(\d{2})/, "$1.$2.$3")
                }
            },
            statusStr: function (val) {
                switch (val) {
                    case 'waiting':
                        return '待审核';
                    case 'notThrough':
                        return '审核未通过';
                    case 'open':
                        return '已上线';
                    case 'onHold':
                        return '已下线';
                    default:
                        return val;
                }
            },
            headcountFormat: function (val) {
                switch (val) {
                    case 0:
                        return '不限';
                    default :
                        return val + '人'
                }
            },
            toThousands: function (val) {
                if(val){
                    return val.toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1,');
                }
            }
        },
        mounted(){
            this.getJobPosition();
            this.getJobHistory();
        }
    }

</script>

<style lang="less" scoped>
    @import "../../less/shared/variables.less";

    .job-position-header {
        background-color: @white;
        color: extract(@gray-group, 5);
        line-height: 50px;
        padding: 0 20px;
        margin-bottom: 20px;
        .el-col{
            height: 50px;
        }
        .el-col + .el-col {
            text-align: right;
            & > div {
                display: inline-block;
                color: extract(@gray-group, 2);
                font-size: @size-lg;
                margin-left: 30px;
                cursor: pointer;
            }
            & > div.disabled {
                cursor: not-allowed;
                color: extract(@gray-group, 10);
            }
        }

        .jl-up-btn {
            .joblist-icon {
                width: 10px;
                height: 14px;
                background-position: -2px -20px;
                margin-bottom: -1px;
            }
            &.disabled {
                .joblist-icon {
                    background-position: -2px -60px;
                }
            }
        }

        .jl-edit-btn {
            text-decoration: none;
            display: inline-block;
            color: #464646;
            font-size: 16px;
            margin-left: 30px;
            cursor: pointer;
            .joblist-icon {
                width: 14px;
                height: 14px;
                background-position: 0 -40px;
                margin-bottom: -1px;
            }
        }

        .jl-down-btn {
            .joblist-icon {
                width: 10px;
                height: 14px;
                background-position: -42px -20px;
                margin-bottom: -1px;
            }
            &.disabled {
                .joblist-icon {
                    background-position: -42px -60px;
                }
            }
        }
    }

    .job-position-title {
        font-size: @size-lg;
        font-weight: 400;
        color: extract(@gray-group, 2);
        margin: 0;
    }


</style>
<style lang="less">
    @import "../../less/shared/variables.less";

    .select-size-sm.el-select-dropdown {
        min-width: 120px !important;
    }

    .job-position-section {
        background-color: @white;
        padding: 10px 20px 50px 37.5px !important;
        margin-bottom: 50px;
        .el-tabs {
            .el-tabs__header {
                padding: 0 20px;
                margin: 0 -20px 15px;
                .el-tabs__item {
                    height: 40px;
                    line-height: 40px;
                    font-size: @size-lg;
                    color: extract(@gray-group, 4);
                    padding: 0 20px;
                    &.is-active {
                        color: @primary-color;
                    }
                }
                .el-tabs__active-bar {
                    left: 20px;
                }
            }
            .el-tabs__content {
                min-height: 520px;
            }
        }
        .el-table {
            border: none;
            color: extract(@gray-group, 3);
        }
        .el-table:before {
            height: 0;
        }
        .el-table:after {
            width: 0;
        }
        .el-table th.is-leaf {
            /*border-bottom: none;*/
        }
        .el-table--border td, .el-table--border th {
            border-right: none;
        }
        .el-table th {
            background-color: initial;
        }
        .el-table__fixed-header-wrapper thead div, .el-table__header-wrapper thead div {
            color: extract(@gray-group, 2);
            background-color: initial;
            text-align: center;
        }
        .el-table td {
            border-bottom: 1px dotted #ddd;
            padding: 8px 0 7px;
            text-align: center;
        }
        .el-table--enable-row-hover tr:hover > td {
            background-color: extract(@gray-group, 13);
        }
    }

    .job-position-tip {
        border: 1px solid @warning-color;
        background: extract(@bgColor, 3);
        padding: 10px 15px 0;
        margin-bottom: 20px;
        & > ul {
            list-style: none;
            margin: 0 0 10px 0;
            padding: 0;
            & > li {
                display: inline-block;
                margin-right: 20px;
            }
        }
        .job-preview-btn {
            position: absolute;
            right: 15px;
            top: 10px;
            color: @primary-color;
            cursor: pointer;
            .joblist-icon {
                background-position: -60px -40px;
                width: 14px;
                height: 14px;
                margin-bottom: -1px;
            }
            &:hover {
                color: @primary-color;
            }
        }
        & > p {
            margin: 0 0 10px 0;
        }
    }

    .job-position-info {
        margin-bottom: 25px;
        color: extract(@gray-group, 5);
        & > .el-row {
            margin-bottom: 15px;
            .el-col {
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
                span {
                    color: extract(@gray-group, 3);
                }
            }
        }
    }

    .job-desc-title {
        margin: 0 0 15px;
        font-size: @size-lg;
        color: extract(@gray-group, 2);
    }

    .job-position-article {
        color: extract(@gray-group, 3);
        & > * {
            margin: 0;
            font-size: inherit;
        }
    }

    .job-position-status, .job-position-recruitment {
        background-color: @white;
        margin-bottom: 20px;
        padding: 20px;
    }

    .job-position-status {
        & > p {
            margin: 0;
            color: extract(@gray-group, 4);
            & > span {
                color: extract(@gray-group, 3);
            }
        }
    }

    .job-position-recruitment {
        min-height: 360px;
        & > p {
            margin: 0 0 20px;
            color: extract(@gray-group, 4);
        }
    }

    .jp-aside-title {
        margin: 0 0 20px;
        font-size: @size-lg;
        color: extract(@gray-group, 2);
    }

    .jp-recruitment-list {
        list-style: none;
        margin: 0;
        background: url("../../img/job/pyramid.jpg") no-repeat left top;
        position: relative;
        height: 138px;
        .jp-recruitment-employed, .jp-recruitment-interview, .jp-recruitment-test, .jp-recruitment-beginscreen {
            position: absolute;
        }
        .jp-recruitment-employed {
            top: 8px;
            left: 80px;
        }
        .jp-recruitment-interview {
            top: 40px;
            left: 90px;
        }
        .jp-recruitment-test {
            top: 74px;
            left: 105px;
        }
        .jp-recruitment-beginscreen {
            top: 110px;
            left: 120px;
        }
    }
</style>
