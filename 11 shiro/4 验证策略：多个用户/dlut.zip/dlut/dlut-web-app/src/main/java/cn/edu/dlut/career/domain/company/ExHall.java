package cn.edu.dlut.career.domain.company;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *  展厅
 * Created by HealerJean on 2017/3/24.
 */
@Entity
@Table(name="rec_exhibite_hall")
public class ExHall {
    // 编号id
    @Id
    @GenericGenerator(name = "idGenerator", strategy = "uuid")
    @GeneratedValue(generator = "idGenerator")
    private String id;

    //名称name
    @Column(length = 20)
    private String name;

    //地址
    @Column(length=40)
    private String address;

    //面积acreage
    @Column(length=10)
    private String acreage;

    //展位图
    @Column(length=50)
    private String exhPhoto;

    //联系人
    @Column(length=10)
    private String contactPerson;

    //联系电话phone
    @Column(length = 15)
    private String phone;

    //可容纳人数
    private int accNumber;

    //展位数量
    private int amount;

    public ExHall() {
    }

    @Override
    public String toString() {
        return "ExHall{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", address='" + address + '\'' +
                ", acreage='" + acreage + '\'' +
                ", exhPhoto='" + exhPhoto + '\'' +
                ", contactPerson='" + contactPerson + '\'' +
                ", phone='" + phone + '\'' +
                ", accNumber=" + accNumber +
                ", amount=" + amount +
                '}';
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAcreage() {
        return acreage;
    }

    public void setAcreage(String acreage) {
        this.acreage = acreage;
    }

    public String getExhPhoto() {
        return exhPhoto;
    }

    public void setExhPhoto(String exhPhoto) {
        this.exhPhoto = exhPhoto;
    }

    public String getContactPerson() {
        return contactPerson;
    }

    public void setContactPerson(String contactPerson) {
        this.contactPerson = contactPerson;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public int getAccNumber() {
        return accNumber;
    }

    public void setAccNumber(int accNumber) {
        this.accNumber = accNumber;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }


}
