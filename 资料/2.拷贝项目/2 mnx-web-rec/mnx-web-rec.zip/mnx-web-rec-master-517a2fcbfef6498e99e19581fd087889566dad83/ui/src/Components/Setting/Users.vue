<template>
    <router-view></router-view>
</template>

<script type="text/babel">
    export default {
        name: 'users',
        data() {
            return {
            }
        }
    }
</script>