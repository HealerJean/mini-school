<template>
    <div class="dashboard-wrap">
        <a class="report-title">
            <i></i>招聘报告
        </a>
        <el-row :gutter="20">
            <el-col :span="6">
                <div class="dashboard-box">
                    <i class="positions-icon"></i>
                    <h2>{{ jobCout }} </h2>
                    <p>发布职位</p>
                </div>
            </el-col>
            <el-col :span="6">
                <div class="dashboard-box">
                    <i class="total-icon"></i>
                    <h2>{{ total }} </h2>
                    <p>简历总数</p>
                </div>
            </el-col>
            <el-col :span="6">
                <div class="dashboard-box">
                    <i class="processedResume-icon"></i>
                    <h2>{{ processedResume }} </h2>
                    <p>已处理简历数</p>
                </div>
            </el-col>
            <el-col :span="6">
                <div class="dashboard-box">
                    <i class="offers-icon"></i>
                    <h2>{{ offers }} </h2>
                    <p>录用数量</p>
                </div>
            </el-col>
        </el-row>
        <div class="chart-wrap">
            <div id="chart"></div>
        </div>
    </div>
</template>

<script type="text/babel">
    import echarts from 'echarts'

    export default {
        name: 'dashboard',
        data() {
            return {
                jobCout: 0,
                total: 0,
                processedResume: 0,
                offers: 0,

                //echart
                chart: null,
                chartDate: [],
                chartResumeCount: []
            };
        },

        methods: {
            setChart (id) {
                this.getIndexData();
                let self=this;
                setTimeout(function(){
                   self.chart = echarts.init(document.getElementById(id))
                   self.chart.setOption({
                       title: {
                           text: '最近7天招聘趋势',
                           x: 'center'
                       },
                       tooltip: {
                           trigger: 'axis',
                           axisPointer: {
                               animation: false
                           }
                       },
                       legend: {
                           data: ['简历投递数量/个'],
                           x: 'left'
                       },
                       xAxis: {
                           type : 'category',
                           boundaryGap : false,
                           axisLine: {onZero: true},
                           data: self.chartDate
                       },
                       yAxis: {max:100},
                       series: [
                           {
                               name: '简历数',
                               type: 'line',
                               smooth:true,
                               itemStyle:{
                                   normal:{
                                       color:'#049cff'
                                   }
                               },
                               data: self.chartResumeCount
                           }
                       ]
                   })
                },300)
            },
            getIndexData: function () {
                //this.$http.get('../static/json/index.json').then(response => {
                this.$http.get('/candidate/354bdb8f-ecd6-4c82-80fe-5f42db62d0a1/stat').then(response => {
                    let newData = response.body;
                    this.jobCout = newData.jobCout;
                    this.total = newData.applicationCount;
                    this.processedResume = newData.dealedCount;
                    this.offers = newData.offerCount;

                    let chartData = newData.sevenDayStat;
                    let _this=this;
                    chartData.forEach(function(item){
                        _this.chartDate.push(_this.formatDate(item[0]));
                        _this.chartResumeCount.push(item[1]);
                    })
                }, response => {
                    /* eslint-disable */
                    console.log('error');
                    /* eslint-disable */
                });
            },
            formatDate(date) {
                let newDate = new Date(date);
                let year = newDate.getFullYear(),
                    month = newDate.getMonth() >= 9 ? newDate.getMonth() + 1 : '0' + (newDate.getMonth() + 1),
                    day = newDate.getDate() >= 10 ? newDate.getDate() : '0' + newDate.getDate();
                return year + '/' + month + '/' + day
            }
        },
        mounted() {
            this.$nextTick(function() {
                this.setChart('chart');
            })


        }
    }

</script>

<style lang="less">
    @import "../less/shared/variables.less";

    .dashboard-wrap {
        line-height: 1;
        .report-title {
            color: extract(@gray-group, 2);
            cursor:pointer;
            & > i {
                display: inline-block;
                width: 12px;
                height: 14px;
                margin-bottom: -2px;
                margin-right: 5px;
                background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAwAAAAOCAYAAAAbvf3sAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyJpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYxIDY0LjE0MDk0OSwgMjAxMC8xMi8wNy0xMDo1NzowMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNS4xIFdpbmRvd3MiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6OURCNEI1QTZGQTdDMTFFNjhFMTRDMUMxQkFDNDlFRjEiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6OURCNEI1QTdGQTdDMTFFNjhFMTRDMUMxQkFDNDlFRjEiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo5REI0QjVBNEZBN0MxMUU2OEUxNEMxQzFCQUM0OUVGMSIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo5REI0QjVBNUZBN0MxMUU2OEUxNEMxQzFCQUM0OUVGMSIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PvIA+8oAAADISURBVHjaYmSZ8/8rAwMDFwN+8BKIPX8nM5xnBGr4D+QIAjkfsKlkncsgAKTeA/EnIA5gYSAMfgHxOSBmA+KtLFhMZAJSXkB8E2jrbSD+BmQbw2xiwmJiDhBvBuLTQEVs6JLYNAhAaU4oRgHY/DAP5DmQe4HO+YjXBqAT1IFUBRCfBWJlID8diFmw2gCUEAJSB9CcAfK8PBBXYWgAWv8OSEkSCmNkG2yAlAkOdTOx2XAESB3BZTLQQHZcwYoXMBKZ+GDgG0CAAQCTVTDJryKrKgAAAABJRU5ErkJggg==");
            }
            &:hover {
                color: @primary-color;
            }
        }
    }

    .dashboard-box {
        margin: 20px 0 0;
        padding: 30px 30px 30px 150px;
        background: @white;
        height: 160px;
        box-sizing: border-box;
        position: relative;
        cursor:pointer;
        & > i {
            position: absolute;
            left: 30px;
            top: 30px;
            width: 100px;
            height: 100px;
            background: url("../img/dashboard/dash-icon2.png") no-repeat;
        }
        .positions-icon {
            background-position: 0 0;
        }
        .total-icon {
            background-position: -110px 0;
        }
        .processedResume-icon {
            background-position: -220px 0;
        }
        .offers-icon {
            background-position: -330px 0;
        }
        & > h2 {
            color: extract(@gray-group, 2);
            font-size: 38px;
            margin: 18px 0 10px;
            font-weight: 400;
        }
        & > p {
            color: extract(@gray-group, 4);
            font-size: @size-lg;
            margin: 0;
        }
    }

    .chart-wrap {
        background-color: @white;
        min-height: 460px;
        margin: 20px 0 40px;
        padding:30px 40px;
    }

    #chart {
        width: 100%;
        height: 460px;
    }
</style>
