package com.minixiao.api.recruiter.controller.candidate;


import org.springframework.web.bind.annotation.RestController;

@RestController
public class HandleHistoryCommand {

}
