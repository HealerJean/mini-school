package cn.edu.dlut.career.recruiter.domain;

import cn.edu.dlut.career.recruiter.domain.Audit;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * Created by 史念念 on 2017/3/23.
 * 招聘职位实体类
 */
@Entity
@Table(name="rec_job")
public class RecruitJob {

  //编号
  @Id
  @GenericGenerator(name = "idGenerator", strategy = "uuid")
  @GeneratedValue(generator = "idGenerator")
  private String id;

  //公司编号(外键)
  @Column(name="rec_id",length = 32,nullable = false)
  private String recId;

  //职位名称
  @Column(name="job_target",length = 100,nullable = false)
  private String jobTarget;

  //职位类型 （0 兼职，1全职，2 实习）
  @Column(name="job_type",length = 1,nullable = false)
  private String jobType;

  //薪资待遇（0 0-3000,1 3000-5000,2 5000-10000，3 10000以上 ）
  @Column(length = 2,nullable = false)
  private String salary;

  //工作城市
  @Column(length = 20,nullable = false)
  private String location;

  //详细地点
  @Column(name="detailed_address",length = 1000,nullable = false)
  private String detailedAddress;

  //学历要求(0 不限，1 专科，2 本科，3 硕士，4 博士)
  @Column(length = 2,nullable = false)
  private String qualification;

  //招聘人数
  @Column(name="recruitment_num",length = 4,nullable = false)
  private int recruitmentNum;

  //职位描述
  @Column(name="job_description",length = 1000,nullable = false)
  private String jobDescription;

  //所需专业(关联字典)
  @Column(length = 6,nullable = false)
  private String major;

  //有效开始时间  不为空这里为了测试暂时设置为true
  @Column(name="start_time",nullable = true)
  private LocalDateTime startTime;

  //有效结束时间 不为空这里为了测试暂时设置为true
  @Column(name="end_time",nullable = true)
  private  LocalDateTime endTime;

  //提交时间
  @Column(name="post_time",nullable = false)
  @CreationTimestamp
  private LocalDateTime postTime;

  //审核相关
  @Embedded
  @AttributeOverrides(
      {
          @AttributeOverride(name = "auditStatus", column = @Column(name = "audit_status", nullable = false)),
          @AttributeOverride(name = "auditTime", column = @Column(name = "audit_time", nullable = true)),
          @AttributeOverride(name = "auditPerson", column = @Column(name = "audit_person", nullable = true)),
          @AttributeOverride(name = "auditFailReason", column = @Column(name = "audit_fail_reason", nullable = true))
      }
  )
  private Audit audit;

  //标签
  @Column(length = 1000,nullable = true)
  private String tags;

  public RecruitJob(){}

  public RecruitJob(String id, String recId, String jobTarget, String jobType, String salary, String location, String detailedAddress, String qualification, int recruitmentNum, String jobDescription, String major, LocalDateTime startTime, LocalDateTime endTime, LocalDateTime postTime, Audit audit, String tags) {
    this.id = id;
    this.recId = recId;
    this.jobTarget = jobTarget;
    this.jobType = jobType;
    this.salary = salary;
    this.location = location;
    this.detailedAddress = detailedAddress;
    this.qualification = qualification;
    this.recruitmentNum = recruitmentNum;
    this.jobDescription = jobDescription;
    this.major = major;
    this.startTime = startTime;
    this.endTime = endTime;
    this.postTime = postTime;
    this.audit = audit;
    this.tags = tags;
  }

  public String getId() {
    return id;
  }

  public String getRecId() {
    return recId;
  }

  public String getJobTarget() {
    return jobTarget;
  }

  public String getJobType() {
    return jobType;
  }

  public String getSalary() {
    return salary;
  }

  public String getLocation() {
    return location;
  }

  public String getDetailedAddress() {
    return detailedAddress;
  }

  public String getQualification() {
    return qualification;
  }

  public int getRecruitmentNum() {
    return recruitmentNum;
  }

  public String getJobDescription() {
    return jobDescription;
  }

  public String getMajor() {
    return major;
  }

  public LocalDateTime getStartTime() {
    return startTime;
  }

  public LocalDateTime getEndTime() {
    return endTime;
  }

  public LocalDateTime getPostTime() {
    return postTime;
  }

  public Audit getAudit() {
    return audit;
  }

  public String getTags() {
    return tags;
  }

  public void setId(String id) {
    this.id = id;
  }

  public void setRecId(String recId) {
    this.recId = recId;
  }

  public void setJobTarget(String jobTarget) {
    this.jobTarget = jobTarget;
  }

  public void setJobType(String jobType) {
    this.jobType = jobType;
  }

  public void setSalary(String salary) {
    this.salary = salary;
  }

  public void setLocation(String location) {
    this.location = location;
  }

  public void setDetailedAddress(String detailedAddress) {
    this.detailedAddress = detailedAddress;
  }

  public void setQualification(String qualification) {
    this.qualification = qualification;
  }

  public void setRecruitmentNum(int recruitmentNum) {
    this.recruitmentNum = recruitmentNum;
  }

  public void setJobDescription(String jobDescription) {
    this.jobDescription = jobDescription;
  }

  public void setMajor(String major) {
    this.major = major;
  }

  public void setStartTime(LocalDateTime startTime) {
    this.startTime = startTime;
  }

  public void setEndTime(LocalDateTime endTime) {
    this.endTime = endTime;
  }

  public void setPostTime(LocalDateTime postTime) {
    this.postTime = postTime;
  }

  public void setAudit(Audit audit) {
    this.audit = audit;
  }

  public void setTags(String tags) {
    this.tags = tags;
  }
}
