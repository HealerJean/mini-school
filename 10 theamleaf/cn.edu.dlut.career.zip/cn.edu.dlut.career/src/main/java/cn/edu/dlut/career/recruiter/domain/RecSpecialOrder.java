package cn.edu.dlut.career.recruiter.domain;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by 史念念 on 2017/3/24.
 *
 *专场招聘会预约 实体类
 */
@Entity
@Table(name="rec_special_order")
public class RecSpecialOrder {

  //主键
  @Id
  @GenericGenerator(name = "idGenerator",strategy = "uuid")
  @GeneratedValue(generator = "idGenerator")
  private String id;

  //企业id
  @Column(name="rec_id",nullable = false)
  private String recId;

  //招聘会名称
  @Column(name="job_fair_name",length = 100,nullable = false)
  private String jobFairName;

  //招聘简章
  @Column(name="fair_catalog",length = 1000,nullable = false)
  private String fairCatalog;

  //计划召开日期
  @Column(name="hold_time",nullable = false)
  private LocalDateTime holdTime;

  //开始时间
  @Column(name="start_time",nullable = false)
  private LocalDateTime startTime;

  //结束时间
  @Column(name="end_time",nullable = false)
  private LocalDateTime endTime;

  //首选联系人
  @Column(name="contacts1",length = 50,nullable = false)
  private String contacts1;

  //首选联系人联系电话
  @Column(name="con_tel1",length = 20,nullable = false)
  private String conTel1;

  //第二联系人
  @Column(name="contacts2",length = 50,nullable = true)
  private String contacts2;

  //第二联系人联系电话
  @Column(name="con_tel2",length = 20,nullable = true)
  private String conTel2;

  //场地要求
  @Column(name="yardRequire",length = 50,nullable = true)
  private String yardRequire;

  //场地数量
  @Column(name = "yard_num",length = 10,nullable = true)
  private String yardNum;

  //场地规模
  @Column(name="yard_size",length = 1,nullable = true)
  private String yardSize;

  //场地用途
  @Column(name="yard_using",length = 100,nullable = true)
  private String yardUsing;

  //场地地址
  @Column(name="yard_location",length = 100,nullable = true)
  private String yardLocation;

  //申请日期
  @Column(name="application_time",nullable = false)
  @CreationTimestamp
  private LocalDateTime applicationTime;

  //备注
  @Column(name="remarks",length = 1000,nullable = true)
  private String remarks;

  //接待人
  @Column(name="receptionist",length = 50,nullable =true )
  private String receptionist;

  //接待人联系方式
  @Column(name="recep_tel",length = 20,nullable = true)
  private String recepTel;

  //审核相关
  @Embedded
  @AttributeOverrides(
      {
          @AttributeOverride(name = "auditStatus", column = @Column(name = "audit_status", nullable = false)),
          @AttributeOverride(name = "auditTime", column = @Column(name = "audit_time", nullable = true)),
          @AttributeOverride(name = "auditPerson", column = @Column(name = "audit_person", nullable = true)),
          @AttributeOverride(name = "auditFailReason", column = @Column(name = "audit_fail_reason", nullable = true))
      }
  )
  private Audit audit;

  //关联 招聘职位
  @OneToMany(cascade = CascadeType.ALL)
  @JoinTable(name="rec_special_job",
      joinColumns=@JoinColumn(name="ord_id" ,referencedColumnName="id"),
      inverseJoinColumns=
          {@JoinColumn(name="job_id" ,referencedColumnName="id"),
            @JoinColumn(name="job_target",referencedColumnName = "job_target")})
  private List<RecruitJob> recruitJobs = new ArrayList<RecruitJob>();


  public RecSpecialOrder(){}

  public RecSpecialOrder(String id, String recId, String jobFairName, String fairCatalog, LocalDateTime holdTime, LocalDateTime startTime, LocalDateTime endTime, String contacts1, String conTel1, String contacts2, String conTel2, String yardRequire, String yardNum, String yardSize, String yardUsing, String yardLocation, LocalDateTime applicationTime, String remarks, String receptionist, String recepTel, Audit audit, List<RecruitJob> recruitJobs) {
    this.id = id;
    this.recId = recId;
    this.jobFairName = jobFairName;
    this.fairCatalog = fairCatalog;
    this.holdTime = holdTime;
    this.startTime = startTime;
    this.endTime = endTime;
    this.contacts1 = contacts1;
    this.conTel1 = conTel1;
    this.contacts2 = contacts2;
    this.conTel2 = conTel2;
    this.yardRequire = yardRequire;
    this.yardNum = yardNum;
    this.yardSize = yardSize;
    this.yardUsing = yardUsing;
    this.yardLocation = yardLocation;
    this.applicationTime = applicationTime;
    this.remarks = remarks;
    this.receptionist = receptionist;
    this.recepTel = recepTel;
    this.audit = audit;
    this.recruitJobs = recruitJobs;
  }

  public String getId() {
    return id;
  }

  public String getRecId() {
    return recId;
  }

  public String getJobFairName() {
    return jobFairName;
  }

  public String getFairCatalog() {
    return fairCatalog;
  }

  public LocalDateTime getHoldTime() {
    return holdTime;
  }

  public LocalDateTime getStartTime() {
    return startTime;
  }

  public LocalDateTime getEndTime() {
    return endTime;
  }

  public String getContacts1() {
    return contacts1;
  }

  public String getConTel1() {
    return conTel1;
  }

  public String getContacts2() {
    return contacts2;
  }

  public String getConTel2() {
    return conTel2;
  }

  public String getYardRequire() {
    return yardRequire;
  }

  public String getYardNum() {
    return yardNum;
  }

  public String getYardSize() {
    return yardSize;
  }

  public String getYardUsing() {
    return yardUsing;
  }

  public String getYardLocation() {
    return yardLocation;
  }

  public LocalDateTime getApplicationTime() {
    return applicationTime;
  }

  public String getRemarks() {
    return remarks;
  }

  public String getReceptionist() {
    return receptionist;
  }

  public String getRecepTel() {
    return recepTel;
  }

  public Audit getAudit() {
    return audit;
  }

  public List<RecruitJob> getRecruitJobs() {
    return recruitJobs;
  }

  public void setId(String id) {
    this.id = id;
  }

  public void setRecId(String recId) {
    this.recId = recId;
  }

  public void setJobFairName(String jobFairName) {
    this.jobFairName = jobFairName;
  }

  public void setFairCatalog(String fairCatalog) {
    this.fairCatalog = fairCatalog;
  }

  public void setHoldTime(LocalDateTime holdTime) {
    this.holdTime = holdTime;
  }

  public void setStartTime(LocalDateTime startTime) {
    this.startTime = startTime;
  }

  public void setEndTime(LocalDateTime endTime) {
    this.endTime = endTime;
  }

  public void setContacts1(String contacts1) {
    this.contacts1 = contacts1;
  }

  public void setConTel1(String conTel1) {
    this.conTel1 = conTel1;
  }

  public void setContacts2(String contacts2) {
    this.contacts2 = contacts2;
  }

  public void setConTel2(String conTel2) {
    this.conTel2 = conTel2;
  }

  public void setYardRequire(String yardRequire) {
    this.yardRequire = yardRequire;
  }

  public void setYardNum(String yardNum) {
    this.yardNum = yardNum;
  }

  public void setYardSize(String yardSize) {
    this.yardSize = yardSize;
  }

  public void setYardUsing(String yardUsing) {
    this.yardUsing = yardUsing;
  }

  public void setYardLocation(String yardLocation) {
    this.yardLocation = yardLocation;
  }

  public void setApplicationTime(LocalDateTime applicationTime) {
    this.applicationTime = applicationTime;
  }

  public void setRemarks(String remarks) {
    this.remarks = remarks;
  }

  public void setReceptionist(String receptionist) {
    this.receptionist = receptionist;
  }

  public void setRecepTel(String recepTel) {
    this.recepTel = recepTel;
  }

  public void setAudit(Audit audit) {
    this.audit = audit;
  }

  public void setRecruitJobs(List<RecruitJob> recruitJobs) {
    this.recruitJobs = recruitJobs;
  }
}
