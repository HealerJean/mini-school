package cn.edu.dlut.career.recruiter.service;

import cn.edu.dlut.career.recruiter.domain.MattersNeedingAttention;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;

import java.util.UUID;

import static org.junit.Assert.*;

/**
 * Created by wei on 2017/3/27.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class MattersNeedingAttentionServiceTest {
  @Resource
  MattersNeedingAttentionService mattersNeedingAttentionService;
  @Test
  public void save() throws Exception {
    MattersNeedingAttention mattersNeedingAttention = new MattersNeedingAttention();
    mattersNeedingAttention.setId(UUID.randomUUID().toString());
    mattersNeedingAttention.setAddress("金台路");
    mattersNeedingAttention.setContacts("lw");
    mattersNeedingAttention.setTel("182333283223");
    mattersNeedingAttention.setRemarks("ahahha");
    mattersNeedingAttention.setRecruitId(UUID.randomUUID().toString());
  }

  @Test
  public void delete() throws Exception {

  }

  @Test
  public void findAll() throws Exception {

  }


}