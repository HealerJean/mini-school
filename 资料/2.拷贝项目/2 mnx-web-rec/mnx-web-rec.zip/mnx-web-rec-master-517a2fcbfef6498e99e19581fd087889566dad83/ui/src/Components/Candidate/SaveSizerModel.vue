<template>
    <div class="save-sizer">
        <el-dialog title="存为筛选器"
            v-model="saveSizerModelVisible"
            size="tiny"
            :close-on-click-modal="false"
            :close-on-press-escape="false"
            @close="closeModal">
            筛选器名称<el-input v-model="sizerName" class="sizer-name"></el-input>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" @click="saveSizer">确 定</el-button>
                <el-button @click="closeModal">取 消</el-button>
            </div>
        </el-dialog>


    </div>
</template>

<script type="text/babel">

    export default {
        name: 'save-sizer',
        data:function(){
            return{
               sizerName:"",
            }
        },
        computed: {
           saveSizerModelVisible() {
                return this.isSaveSizer;
            }
        },
        props:{
            isSaveSizer: {
                type: Boolean,
                default: false

            }
        },

        methods: {
            closeModal() {
                this.$emit('closeSizer');
            },
            saveSizer() {
                if(this.sizerName.trim()===''){
                    this.$message({
                            message:'请输入筛选器名称',
                            duration:2500
                        });
                    return;
                }
                this.$emit('saveSizer', this.sizerName);
                this.$emit('closeSizer');
            }

        }
    }
</script>

<style lang="less">
.save-sizer{
    .sizer-name {
        width: 240px;
    }
    .el-dialog__header {
        text-align: center;
    }
    .el-dialog__body {
            text-align: center;
        }
}

</style>
