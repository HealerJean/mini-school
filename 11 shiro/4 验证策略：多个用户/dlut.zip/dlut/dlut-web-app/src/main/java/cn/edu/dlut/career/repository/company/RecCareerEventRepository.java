package cn.edu.dlut.career.repository.company;

import cn.edu.dlut.career.domain.company.RecCareerEvent;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Created by 史念念 on 2017/3/24.
 *
 * 专场招聘会预约 持久层
 */
@Transactional
public interface RecCareerEventRepository extends CrudRepository<RecCareerEvent,String> {

  /**
   * 查询所有专场招聘会预约信息
   * @return
   */
 List<RecCareerEvent> findAll();

  /**
   * 根据id查找专场招聘会信息
   * @param id
   * @return
   */
 RecCareerEvent findById(String id);

  /**
   * 根据公司Id查找专场招聘会预约信息
   * @param recId
   * @return
   */
 List<RecCareerEvent> findByRecId(String recId);

  /**
   * 修改审核及回执信息
   * @param auditStatus
   * @return
   */
  @Modifying
  @Query("update RecCareerEvent set auditStatus=?2, auditSuggest=?3, areaAddress=?4, " +
      "areaCost=?5, receiver=?6, receiverTel=?7, auditTime=?8, auditor=?9, holdTime=?10," +
      "startTime=?11, endTime=?12 where id=?1")
  int updateAudit(String id,char auditStatus,String auditSuggest,String areaAddress,
                  float areaCost,String receiver,String receiverTel, LocalDateTime auditTime,
                  String auditor,LocalDateTime holdTime,LocalDateTime startTime,
                  LocalDateTime endTime);

}
