# 招聘职位业务领域

## 接口定义

### 创建招聘职位

#### HTTP 请求
**POST** /requisitions

#### 参数

#### 权限
- role=rec*
- role=*

### 删除招聘职位

#### HTTP 请求
**DELETE** /requisitions/{id}

#### 参数

### 修改招聘职位

#### HTTP 请求
**PUT** /requisitions/{id}

#### 参数

## 实体模型
```JSON
{
    "title":"Java 工程师",
    "description":"**招聘需求**",
    "status":"open|on_hold|filled|closed",
    "headcount":0,
    "job_type":"full_time|part_time|internship",
    "career_level":"student",
    "audit_status":new|passed|nopass,
    "condition_stat": {
        "total":123456,
        "new":12345,
        "inprocess":12456,
        "offer":345,
        "declined":3456
    },
    "created_on":"2016-02-19T19:36:42.346Z",
    "updated_on":"2016-02-19T19:36:42.346Z"
}
```
| 属性 | 数据类型 | 长度 | 必填 | 备注说明  |
|:----|:--------:|-----:|:----:|:--------------|
| title | string | ? | true | 职位标题。 |
| description | string | ? | true | 职位描述 |
| status | string | ? | true | 当前职位状态。 - open - on_hold |
| headcount | uint | | true | 招聘人数。 |
| job_type | string | ? | true | 职位类型。只接收：full_time（全职）、part_time（兼职）、internship（实习）|
| job_category | String | ? |true | 职位类别 |
| career_level | string | ? | true | 职位级别，学历要求 |
| department | String | ? | false | 所属部门 |
| job_area | String | ? |true | 工作地区 |
| sarlary | String | ? | true | 月薪范围 |
| apply_begin_date | Date | | true | 网申开始日期 |
| apply_end_date | Date | | true | 网申结束日期，必须大于或等于网申开始日期 |
| apply_url | String | ? | true | 投递链接 |
| audit_status | String | | true | 审核状态。只接受：new（待审核）、passed（审核通过）、nopass（审核不通过） |
| nopass_result | String | ? | false | 审核不通过原因 | 
| condition_stat.total | uint | | | 应聘总人数 |
| condition_stat.new | uint | | | 当前初筛阶段人数 |
| condition_stat.inprocess | uint | | | 当前处理中的人数 |
| condition_stat.offer | uint | | | 当前录用总人数 |
| condition_stat.declined | uint | | | 当前不通过的总人数 |
| created_on | string |  | true | 创建时间。ISO 8601 格式字符串。 |
| updated_on | string |  | true | 更新时间。ISO 8601 格式字符串。 |

## 业务事件流

### 添加职位
- 添加职位后，检查数据格式是否符合要求
- 同时需要检查同一公司内，每个地区的职位名称不能重复
- 异步记录相关操作日志
- 如果该职位需要发布出来，则发送相关添加信息进入职位广告领域

### 修改职位
- 职位修改不能修改职位名称、职位类别、工作地区、职位类型这些业务领域属性
- 检查其他字段是否符合数据格式要求
- 如果该职位处于发布状态，则发送相关更新信息进入职位广告领域

### 删除职位
- 职位一旦发布过，则不允许删除，只允许删除从未发布过的职位

### 职位审核
- 监听职位广告领域中审核事件
- 修改职位的审核状态；如果不通过的话，同时记录不通过原因

### 应聘申请
- 监听候选人业务领域的应聘申请事件
- 一旦出现应聘申请事件，则异步更新本职位的相关统计数据

### 候选人操作
- 监听候选人业务领域的改变候选人流程状态事件
- 一旦出现改变候选人流程状态事件，则异步更新本职位的相关统计数据
