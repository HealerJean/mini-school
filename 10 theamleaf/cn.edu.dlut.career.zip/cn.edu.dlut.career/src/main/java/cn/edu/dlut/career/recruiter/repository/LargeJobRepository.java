package cn.edu.dlut.career.recruiter.repository;

import cn.edu.dlut.career.recruiter.domain.LargeJob;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 大型招聘会 预约职位 数据库操作
 * Created by HealerJean on 2017/3/24.
 */
@Repository
public interface LargeJobRepository extends CrudRepository<LargeJob,String>{
    //查找全部信息
    List<LargeJob> findAll();

    //根据id进行查找
    LargeJob findById(String id);


}
