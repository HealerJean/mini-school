package cn.edu.dlut.career.recruiter.service;

import cn.edu.dlut.career.recruiter.domain.RecSpecialOrder;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Created by 史念念 on 2017/3/24.
 *
 * 专场招聘会预约 服务层接口
 */
public interface RecSpecialOrderService {

  /**
   * 添加 专场招聘会预约信息
   * @param recSpecialOrder
   * @return
   */
  String saveRecSpecialOrder(RecSpecialOrder recSpecialOrder);

  /**
   * 查询所有 专场招聘会预约信息
   * @return
   */
  List<RecSpecialOrder> findAll();

  /**
   * 根据id查找 专场招聘会预约信息
   * @param id
   * @return
   */
  RecSpecialOrder findById(String id);

  /**
   * 根据公司id查找 专场招聘会预约信息
   * @param recId
   * @return
   */
  List<RecSpecialOrder> findByRecId(String recId);

  /**
   * 修改审核状态,审核人,审核时间,未通过原因
   * @param id 主键
   * @param auditStatus 状态
   * @param auditPerson 审核人
   * @param auditTime 审核时间
   * @param auditFailReason  审核失败原因
   * @return
   */
  String updateAudit(String id , String auditStatus,
                     String auditPerson, LocalDateTime auditTime,
                     String auditFailReason);

  /**
   * 修改接待人，接待人联系方式
   * @param receptionist 接待人
   * @param recepTel 接待人联系方式
   * @return
   */
  String updateReceptionistAndRecepTel(String id,String receptionist,String recepTel);

  /**
   * 删除 专场招聘会预约信息
   * @param id
   * @return
   */
  String deleteById(String id);

}
