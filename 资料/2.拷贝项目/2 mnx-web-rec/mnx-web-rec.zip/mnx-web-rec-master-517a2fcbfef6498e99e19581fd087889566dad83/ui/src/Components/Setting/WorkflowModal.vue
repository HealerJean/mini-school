<template>
    <div class="workflow-setting">

        <div class="workflow-setting-title">

            <h2>
                招聘流程设置
            </h2>
        </div>
        <div class="workflow">
            <div class="workflow-item" v-for="(item,index) in recruiterFlows">

                <div v-if="!isEditorWorklow(item.name)">
                    <div class="item-circle" :style="circleColor(item.type)">{{index+1}}</div>
                    <div class="kuang" :style="bgColor(item.type)">
                        <div class="kuang-allow" :style="rbColor(item.type)">
                        </div>
                        <div class="trangle-up" v-if="isShowEditorButton(item.name)" @click="flowOrderUp(item,index)">
                        </div>
                        <div class="trangle-down" v-if="isShowEditorButton(item.name)" @click="flowOrderDown(item,index)">
                        </div>
                        <div class="workflow-body">
                            <span>{{item.name}}</span>
                            <div class="workflow-item-button" v-if="isShowEditorButton(item.name)">
                                <el-button type="text" class="editor" @click="editorWorklow(item)">编辑</el-button>
                                <el-button type="text" class="remove" @click="deleteflow(item)">删除</el-button>
                            </div>
                        </div>

                    </div>
                    <el-button type="text" class="workflow-add" v-if="isShowEditorButton(item.name)" @click="addflow(item,index)"><div class="workflow-add-circle">+</div>添加流程</el-button>
                </div>
                <div v-else>
                    <div class="item-circle-editor">{{index+1}}</div>
                    <div class="editor-body">
                        <div class="editor-allow"></div>
                        <div class="workflow-body">
                            <el-select v-model="typeEditor" placeholder="流程类型" class="workflow-select">
                                <el-option v-for="item in typeItems" :label="item.label" :value="item.value">
                                </el-option>
                            </el-select>
                            <el-input class="workflow-input" v-model="nameEditor" placeholder="请输入流程名称"></el-input>
                            <el-button type="primary" @click="saveflow(item)">保存</el-button>
                            <el-button class="workflow-cancle" @click.stop="editorClose">取消</el-button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="workflow-instruction">
            <h3>
                招聘流程说明
            </h3>
            <ul>
                <li>1. 流程设置需在职位发布前设置好，当有简历投递后，将不可进行修改</li>
                <li>2. 如需修改请联系迷你校客服，客服电话：010-56261180</li>
                <li>3. 通过修改【▲】【▼】可修改招聘流程设置</li>
                <li>4. 目前【流程类型】只能添加筛选类型、笔试类型、面试类型3种流程</li>
                <li>5. 【流程名称】可进行自定义设置</li>

            </ul>
        </div>
    </div>
</template>

<script type="text/babel">


    export default {
        data:function(){
            return{
                workflowEditoring:'',
                typeEditor:'',
                nameEditor:'',
                isEditoring:false,
                typeItems:[{
                    label:'筛选类型',
                    value:'筛选类型'
                },{
                    label:'笔试类型',
                    value:'笔试类型'
                },{
                    label:'面试类型',
                    value:'面试类型'
                }],
                recruiterFlows:[
                // {
                //     "id":"",
                //     "recId":"4028478159a534640159a53870b40000",
                //     "type": "筛选类型",
                //     "name":"初筛",
                //     "flowOrder":0,
                //     "candidateCount":0
                // },{
                //     "id":"17d6d4033ec6c70046e0bb5c32c790ca",
                //     "recId":"4028478159a534640159a53870b40000",
                //     "type": "筛选类型",
                //     "name":"精选",
                //     "flowOrder":2,
                //     "candidateCount":128
                //   },{
                //     "id":"6g74f4033ec6c70046j9535c32c790c3",
                //     "recId":"4028478159a534640159a53870b40000",
                //     "type": "笔试类型",
                //     "name":"笔试",
                //     "flowOrder":3,
                //     "candidateCount":66
                //   },{
                //     "id":"27d6d4033ec6c70046e0bb5c32c790ca",
                //     "recId":"4028478159a534640159a53870b40000",
                //     "type": "面试类型",
                //     "name":"面试",
                //     "flowOrder":4,
                //     "candidateCount":3
                //   },{
                //     "id":"",
                //     "recId":"",
                //     "type": "录用类型",
                //     "name":"录用",
                //     "flowOrder":9999999,
                //     "candidateCount":0
                //   }
                ],
            }
        },
        computed: {
            userId(){
                return this.$store.getters.userId
            },
            userName(){
                return this.$store.getters.userName
            },
            recId(){
                return this.$store.getters.recId
            }
        },
        methods: {
            getRecruiterFlows(){
                this.$http.get('/company/flows').then(
                    response => {
                        console.log(response.body);
                       let flows = response.body;
                        this.recruiterFlows=flows;
                    });
            },
            saveflow(flow){

                if(this.nameEditor==''){
                    this.$message({
                        message:'流程名字不能为空',
                        type: 'warning',
                        duration:3000
                    });
                    return;
                }
                if(this.typeEditor==''){
                    this.$message({
                        message:'流程类型不能为空',
                        type: 'warning',
                        duration:3000
                    });
                    return;
                }
                if(flow.id==''){
                    this.$http.post('company/flow?name='+this.nameEditor+'&type='+this.typeEditor+'&flowOrder='+flow.flowOrder).then(response =>{
                        this.$message({
                            message:response.body,
                            duration:3000
                        });
                        this.getRecruiterFlows();
                    })
                }else{
                    this.$http.put('company/flows/'+flow.id+'?name='+this.nameEditor+'&type='+this.typeEditor).then(response =>{
                        this.$message({
                            message:response.body,
                            duration:3000
                        });
                        this.getRecruiterFlows();
                    })
                }
                this.workflowEditoring = '';
                this.nameEditor = '';
                this.typeEditor = '';
                this.isEditoring = false;
            },
            addflow(flow,index){
                if(this.isEditoring==true){
                    this.$message({
                            message:'请先保存其他修改',
                            duration:3000
                        });
                    return;
                }
                this.isEditoring=true;
                let indexAfter = index +1;
                // console.log(this.recruiterFlows[index].flowOrder);
                // console.log(this.recruiterFlows[indexAfter].flowOrder);

                let flowOrder = Math.floor((this.recruiterFlows[index].flowOrder+this.recruiterFlows[indexAfter].flowOrder)/2);
                console.log(flowOrder);
                console.log(typeof flowOrder);
                let newflow ={
                    "id":"",
                    "recId":this.recId,
                    "type": "筛选类型",
                    "name":"",
                    "flowOrder":flowOrder,
                    "candidateCount":0
                }
                this.recruiterFlows.splice(indexAfter,0,newflow);
            },
            deleteflow(flow){
                this.$http.delete('company/flows/'+flow.id).then(response =>{
                    this.$message({
                        message:response.body,
                        duration:3000
                    });
                    this.getRecruiterFlows();
                })

                this.workflowEditoring = '';
                this.nameEditor = '';
                this.typeEditor = '';
                this.isEditoring = false;
            },
            flowOrderUp(flow,index){
                console.log('向上')
                if(this.isEditoring==true){
                    this.$message({
                            message:'请先保存其他修改',
                            duration:3000
                        });
                    return;
                }
                let indexBefore = index -1;
                if(this.recruiterFlows[indexBefore].flowOrder<=this.recruiterFlows[0].flowOrder){
                    this.$message({
                            message:'此流程不能放到初筛之前',
                            duration:3000
                        });
                    return;
                }
                let flowOrder = Math.floor((this.recruiterFlows[indexBefore-1].flowOrder+this.recruiterFlows[indexBefore].flowOrder)/2);
                console.log(flowOrder);
                this.$http.put('company/flows/'+flow.id+'/order?flowOrder='+flowOrder).then(response =>{
                        this.$message({
                            message:response.body,
                            duration:3000
                        });
                        this.getRecruiterFlows();
                    })

            },
            flowOrderDown(flow,index){
                console.log('向下')
                if(this.isEditoring==true){
                    this.$message({
                            message:response.body,
                            duration:3000
                        });
                    return;
                }
                let indexAfter = index +1;
                let luyongflowOrderIndex = this.recruiterFlows.length-1;
                if(this.recruiterFlows[indexAfter].flowOrder>=this.recruiterFlows[luyongflowOrderIndex].flowOrder){
                    this.$message({
                            message:'此流程不能放到录用之后',
                            duration:3000
                        });
                    return;
                }
                let flowOrder = Math.floor((this.recruiterFlows[indexAfter+1].flowOrder+this.recruiterFlows[indexAfter].flowOrder)/2);
                console.log(flowOrder);
                this.$http.put('company/flows/'+flow.id+'/order?flowOrder='+flowOrder).then(response =>{
                        this.$message({
                            message:response.body,
                            duration:3000
                        });
                        this.getRecruiterFlows();
                    })

            },
            isShowEditorButton(name){

                return !(name ==='初筛' || name === '录用')
            },
            circleColor(value){
                let  colorBg = {
                    '筛选类型':'#77cab0',
                    '笔试类型':'#dc9627',
                    '面试类型':'#dccc27',
                    '录用类型':'#14bde7'}

                let  colorBorder = {
                    '筛选类型':'#3ab18c',
                    '笔试类型':'#c87a00',
                    '面试类型':'#c8b300',
                    '录用类型':'#057c99'}

                return {
                    backgroundColor: colorBg[value],
                    borderColor: colorBorder[value]
                }
            },
            bgColor(value){
              let  colorBg = {
                    '筛选类型':'#77cab0',
                    '笔试类型':'#dc9627',
                    '面试类型':'#dccc27',
                    '录用类型':'#14bde7'}
                return {
                    backgroundColor: colorBg[value]
                }
            },
            rbColor(value){
                let  colorBg = {
                    '筛选类型':'#77cab0',
                    '笔试类型':'#dc9627',
                    '面试类型':'#dccc27',
                    '录用类型':'#14bde7'
                }
                return {
                    borderRightColor: colorBg[value]
                }
            },
            isEditorWorklow(value){

                return value===this.workflowEditoring;

            },
            editorWorklow(value){
                this.workflowEditoring = value.name;
                this.nameEditor = value.name;
                this.typeEditor = value.type;
            },
            editorClose(){
                this.getRecruiterFlows();
                this.workflowEditoring = '';
                this.nameEditor = '';
                this.typeEditor = '';
                this.isEditoring = false;

            }
        },

        mounted(){
                this.getRecruiterFlows();

        }
    }

</script>

<style lang="less">
    .workflow-setting {
        width:1180px;
        background-color: #ffffff;
        position: relative;
        .workflow-setting-title {
            height:80px;
            line-height: 80px;
            padding-left: 90px;
           // font-size: 18px;

        }
        .workflow-instruction {
            width: 486px;
            margin-right: 40px;
            height: 500px;
            position: absolute;
            right: 0;
            top: 80px;
            ul {
                padding: 0;
                margin:0;
                list-style-type: none;
                li {
                font-size: 14px;
                line-height: 40px;
                }
            }

        }
    }
    .workflow {
        border-left: 4px solid #dddddd;
        border-right: 1px solid #dddddd;
        margin-left: 110px;
        width: 500px;
        .workflow-item {
            padding: 20px 0;
        }
        .workflow-add {
            color: #3ab1ff;
            font-size: 16px;
            .workflow-add-circle {

                width:14px;
                height: 14px;
                border: 1px solid #3ab1ff;
                border-radius: 50%;
                display: inline-block;
                margin-right: 4px;
                font-size: 14px;
            }
        }
        .editor-body {
            display: inline-block;
            width: 436px;
            height: 70px;
            background-color: #dddddd;
            margin-left: 18px;
           // line-height: 70px;
            position: relative;
            .workflow-input {
                height: 26px;
                width:120px;
                display: inline-block;
                margin-left:10px;
                margin-right:10px;
                .el-input__inner {
                    height: 26px;
                }
            }
            .workflow-select {
                height: 26px;
                width:120px;
                margin-left: 20px;
                display: inline-block;
                .el-input__inner {
                    height: 26px;
                }
            }
            .el-button {
                height: 26px;
                width: 62px;
                padding:0 0;
                font-size: 14px;
            }
            .workflow-cancle {
                background-color: #ffffff;
            }
            .editor-allow {
                display: inline-block;
                border-right: 14px solid #dddddd;
                border-top: 8px solid transparent;
                border-left: 14px solid transparent;
                border-bottom: 8px solid transparent;
                margin-left: -28px;
                position: relative;
                top: 27px;
            }
        }
        .item-circle-editor {
            display: inline-block;
            border: 4px solid #c2c2c2;
            border-radius: 50%;
            width:24px;
            height:24px;
            text-align: center;
            line-height: 24px;
            margin-left: -18px;
            background-color: #dddddd;
            // position: relative;
            // top: 23px;
        }
        .item-circle {
            display: inline-block;
            border: 4px solid #3ab18c;
            border-radius: 50%;
            width:24px;
            height:24px;
            text-align: center;
            line-height: 24px;
            margin-left: -18px;
        }
        .kuang {
            display: inline-block;
            width: 310px;
            height: 70px;
            background-color: #77cab0;
            margin-left: 18px;
            line-height: 70px;
            position: relative;
            .kuang-allow {
                display: inline-block;
                border-right: 14px solid #77cab0;
                border-top: 8px solid transparent;
                border-left: 14px solid transparent;
                border-bottom: 8px solid transparent;
                margin-left: -28px;
            }
            .trangle-up {
                position:absolute;
                border-right: 6px solid transparent;
                border-top: 8px solid transparent;
                border-left: 6px solid transparent;
                border-bottom: 8px solid #555555;
                left:14px;
                top:4px;
                cursor: pointer;

            }
            .trangle-down {
                position:absolute;
                border-right: 6px solid transparent;
                border-top: 8px solid #555555;
                border-left: 6px solid transparent;
                border-bottom: 8px solid transparent;
                left:14px;
                bottom:4px;
                cursor: pointer;
            }
            .workflow-body {
                width: 260px;
                margin-left: 44px;
                font-size: 20px;
                color: #ffffff;
                display: inline-block;
            }
            .workflow-item-button {
                float: right;
                text-align: right;
                padding-right: 24px;
                .el-button {
                    padding: 0px;
                    font-size: 16px;
                    color: #ffffff;
                }

            }
        }
    }
</style>
