package com.minixiao.web.controller;

import com.minixiao.apiauth.client.HeaderUtil;
import com.minixiao.web.dto.jobrequistion.JobRequistion;
import com.minixiao.web.dto.recruiters.UserDTO;
import com.minixiao.web.utils.YmlConfig;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * @Description .
 * @Author JiangYh
 * @CreateTime 2017/2/13 11:09
 */
@Controller
@RequestMapping(value = "/requisitionLog")
public class JobRequistionLogController {

    @Autowired
    private YmlConfig ymlConfig;
    RestTemplate restTemplate = new RestTemplate();

    /**
     * @return
     */
    @GetMapping(value = "/{jobId}")
    @ResponseBody
    public Page<JobRequistion> findList(Pageable pageable, @PathVariable UUID jobId) {

        Subject subject = SecurityUtils.getSubject();
        if (subject != null) {
            UserDTO user = (UserDTO) subject.getSession().getAttribute(ymlConfig.getSession_current_user());
            if (user != null) {
                UUID recId = user.getRecId();
                String url = ymlConfig.getUrl_api_recruiter()+"requisitionLog/" + jobId + "?sort=createdOn,desc";
                int page = pageable.getPageNumber();
                url += "&page=" + page;
                int size = pageable.getPageSize();
                url += "&size=" + size;
                UUID optUid = user.getId();
                String optName = user.getRealName();
                String recName = user.getRecName();
                HttpHeaders requestHeaders = HeaderUtil.getHeader(optUid, optName, "COMPANY", recId,
                    recName);
                HttpEntity<String> request = new HttpEntity<String>(null, requestHeaders);
                ResponseEntity<Map> rEntity = restTemplate.exchange(url, HttpMethod.GET,
                    request, Map.class);
                Object obj = rEntity.getBody().get("content");
                Object total = rEntity.getBody().get("totalElements");
                if (obj instanceof ArrayList<?>) {
                    List list = (ArrayList) obj;
                    return new PageImpl(list, pageable, Long.valueOf(total.toString()));
                }
            }
        }
        return null;
    }
}
