package cn.edu.dlut.career.repository.company;

import cn.edu.dlut.career.domain.company.RecJobPosition;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Created by 史念念 on 2017/3/23.
 *
 * 招聘职位持久层
 */
@Transactional
public interface RecJobPositionRepository extends CrudRepository<RecJobPosition,String> {

  /**
   * 查询全部招聘职位信息
   * @return
   */
  List<RecJobPosition> findAll();

  /**
   * 根据编号查找公司招聘信息
   * @param id
   * @return
   */
  RecJobPosition findById(String id);

  /**
   * 根据公司编号查找招聘信息
   * @param recId
   * @return
   */
  List<RecJobPosition> findByRecId(String recId);

  /**
   * 修改审核状态,审核人,审核时间,未通过原因
   * @param auditStatus
   * @return
   */
  @Modifying
  @Query("update RecJobPosition  set auditStatus=?2 ,auditor=?3 ," +
      "auditTime=?4,onpassReason=?5 where id = ?1")
  int updateAudit(String id, char auditStatus,
                  String auditor, LocalDateTime auditTime,
                  String nopassReason);


}
