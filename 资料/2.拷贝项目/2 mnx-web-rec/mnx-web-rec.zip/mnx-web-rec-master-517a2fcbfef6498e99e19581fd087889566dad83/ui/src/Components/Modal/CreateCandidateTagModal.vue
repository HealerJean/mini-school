<template>
    <div class="save-tag">
        <el-dialog title="存为筛选器"
            v-model="createTagModelVisible"
            size="tiny"
            :close-on-click-modal="false"
            :close-on-press-escape="false"
            @close="closeModal">
            标签名称<el-input v-model="tagName" class="tag-name"></el-input>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" @click="createTag">确 定</el-button>
                <el-button @click="closeModal">取 消</el-button>
            </div>
        </el-dialog>


    </div>
</template>

<script type="text/babel">

    export default {
        name: 'create-tag',
        data:function(){
            return{
               tagName:"",
            }
        },
        computed: {
           createTagModelVisible() {
                return this.iscreateTag;
            }
        },
        props:{
            iscreateTag: {
                type: Boolean,
                default: false

            }
        },

        methods: {
            closeModal() {
                this.$emit('closeCreatetag');
            },
            createTag() {
                if(this.tagName.trim()===''){
                    this.$message({
                            message:'请输入筛选器名称',
                            duration:2500
                        });
                    return;
                }
                this.$emit('createTag', this.tagName);
                this.$emit('closeCreatetag');
            }

        }
    }
</script>

<style lang="less">
.save-tag{
    .tag-name {
        width: 240px;
    }
    .el-dialog__header {
        text-align: center;
    }
    .el-dialog__body {
            text-align: center;
        }
}

</style>
