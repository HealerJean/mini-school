<template>
    <div class="guide">
        <div class="guide-header">
            <div class="guide-header-text">完善以下信息即可进行职位发布</div>
            <span class="guide-header-hint" v-if="active===1"><i class="icon-red-star"></i>为必填</span>
        </div>
        <div class="guide-body">
            <el-steps :space="400" :active="active" :align-center="true">
                <el-step title="完善公司信息" ></el-step>
                <el-step title="招聘流程设置" ></el-step>
            </el-steps>
            <div class="guide-step1" v-if="active===1">
                <div guide-company-setting>
                    <div class="guide-company-title">
                        <h2>
                            第一步：公司信息设置
                        </h2>
                    </div>
                    <div class="guide-company-form">
                        <el-form :model="recruiterForm" :rules="rules" ref="recruiterForm" label-width="100px">
                            <el-form-item label="公司logo" prop="logo">
                                <div >
                                    <el-upload
                                      class="company-logo-uploader"
                                      action="//jsonplaceholder.typicode.com/posts/"
                                      :show-file-list="false"
                                      :on-success="handleAvatarScucess"
                                      :before-upload="beforeAvatarUpload">
                                      <img v-if="imageUrl" :src="imageUrl" class="avatar">
                                      <i v-else class="el-icon-upload2 company-logo-uploader-icon"></i>
                                    </el-upload>
                                    <div class="company-logo-uploader-text">
                                        (请上传文件小于1M的图片，尺寸160px*160px，支持格式jpg、gif、png)
                                    </div>
                                </div>
                            </el-form-item>
                            <el-row>
                                <el-col :span="12">
                                    <el-form-item label="公司名称" prop="fullName">
                                        <el-input v-model="recruiterForm.fullName" readonly></el-input>
                                        <div>
                                            <span>*如有问题请联系您的销售顾问</span>
                                        </div>
                                    </el-form-item>
                                </el-col>
                                <el-col :span="12">
                                    <el-form-item label="公司简称" prop="shortName">
                                        <el-input v-model="recruiterForm.shortName" auto-complete="off" readonly></el-input>
                                        <div>
                                            <span>*如有问题请联系您的销售顾问</span>
                                        </div>
                                    </el-form-item>
                                </el-col>
                            </el-row>
                            <el-row>
                                <el-col :span="12">
                                    <el-form-item label="公司性质" prop="nature">
                                        <el-select v-model="recruiterForm.nature"  >
                                            <el-option v-for="item in natureItems" :label="item" :value="item">
                                            </el-option>
                                        </el-select>
                                    </el-form-item>
                                </el-col>
                                <el-col :span="12">
                                    <el-form-item label="公司规模" prop="size">
                                        <el-select v-model="recruiterForm.size" >
                                            <el-option v-for="item in SizeItems" :label="item" :value="item">
                                            </el-option>
                                        </el-select>
                                    </el-form-item>
                                </el-col>
                            </el-row>

                            <el-row>
                                <el-col :span="12">
                                    <el-form-item label="行业类别1" prop="primaryIndustry">
                                        <el-input v-model="recruiterForm.primaryIndustry"  @focus="isSelectPrimary=true" readonly></el-input>
                                    </el-form-item>
                                </el-col>
                                <el-col :span="12">
                                    <el-form-item label="所在省市" prop="city">
                                        <el-input v-model="recruiterForm.city" @focus="isSelectCity=true" readonly></el-input>
                                    </el-form-item>
                                </el-col>
                            </el-row>
                            <!-- 选择行业类别2选择框 -->
                            <select-industry-modal :isSelectingIndustry="isSelectPrimary" @modal:select-industry-closing="closeSelectSlave" @modal:emit-selected-industries="selectedSlave" :max="max"></select-industry-modal>
                             <!-- 选择城市弹出框 -->
                            <select-city-modal :isSelectingCity="isSelectCity" @modal:select-city-closing="closeSelectCity" @modal:emit-selected-cities="selectedCity" :max="max"></select-city-modal>
                            <el-row>
                                <el-col :span="12">
                                    <el-form-item label="详细地址" prop="detailAddress">
                                        <el-input auto-complete="off" v-model="recruiterForm.detailAddress"></el-input>
                                    </el-form-item>
                                </el-col>
                                <el-col :span="12">
                                    <el-form-item label="公司官网" prop="website">
                                        <el-input auto-complete="off" v-model="recruiterForm.website"></el-input>
                                    </el-form-item>
                                </el-col>
                            </el-row>
                            <div class="company-tag">
                                <el-row >
                                    <el-col :span="3"><div ><i class="icon-red-star"></i>公司标签</div></el-col>
                                    <el-col :span="21">
                                        <div >
                                            <el-tag v-for="(tag,index) in tags" :closable="true" type="warning" @close="removeTag(index)">{{tag}}
                                            </el-tag>
                                            <el-button type="text" @click="isAddingTags=true">+添加标签</el-button>
                                        </div>
                                    </el-col>
                                </el-row>
                                <add-tag-modal :isAddingTags="isAddingTags"></add-tag-modal>
                            </div>
                            <el-form-item label="一句话介绍" prop="slogan">
                                <el-input type="textarea" :rows="4" placeholder="请输入一句话介绍" v-model="recruiterForm.slogan"></el-input>
                                <div class="description-count-div">
                                    <span class="description-count" >当前输入{{sloganCount}}/50字符</span>
                                </div>
                            </el-form-item>
                            <el-form-item label="公司简介" prop="description">
                                <el-input type="textarea" :rows="4" placeholder="请输入简短介绍" v-model="recruiterForm.description"></el-input>
                                <div class="description-count-div">
                                    <span class="description-count" >当前输入{{descriptionCount}}/10000字符</span>
                                </div>
                            </el-form-item>

                        </el-form>
                    </div>
                </div>
                <div class="next-step">
                    <el-button @click="nextStep('recruiterForm')" type="primary">下一步</el-button>
                </div>
            </div>
            <div class="guide-step2" v-if="active===2">
                <workflow-modal></workflow-modal>
                <el-button @click="submitForm()" type="primary" class="guide-button-complete">完成</el-button>
            </div>
        </div>
    </div>
</template>

<script type="text/babel">

import eventBus from '../../js/shared/eventBus';
import WorkflowModal from '../Setting/WorkflowModal'
import AddTagModal from '../Modal/AddTagModal'
import SelectCityModal from '../Modal/SelectCityModal'
import SelectIndustryModal from '../Modal/SelectIndustryModal'


    export default {
        data() {
            return  {
                isSelectPrimary: false,
                isSelectCity: false,
                isAddingTags: false,
                SizeItems:[ "1-49人", "50-99人", "100-499人", "500-999人", "1000-2000人", "2000-5000人", "5000-10000人" ],
                natureItems:[ "私营/民营企业",
                    "中外合资企业",
                    "外商独资企业",
                    "上市公司",
                    "国有企业",
                    "政府/事业单位",
                    "非营利性组织"
                ],
                recruiterForm: {
                    fullName: '',
                    shortName: '',
                    nature: '',
                    size: '',
                    primaryIndustry: '',
                    city: '',
                    detailAddress: '',
                    website: '',
                    slogan: '',
                    description: '',
                    tags:'',
                },
                rules: {
                    fullName: [
                        { required: true, message: '请输入公司名称', trigger: 'blur' },
                        { min: 1, max: 100, message: '长度在 1 到 100 个字符', trigger: 'blur' }
                    ],
                    shortName: [
                        { required: true, message: '请选择公司简称', trigger: 'blur' },
                        { min: 1, max: 50, message: '长度在 1 到 50 个字符', trigger: 'blur' }
                    ],
                    nature: [
                    { required: true, message: '请选择公司性质', trigger: 'change' },
                    ],
                    size: [
                    { required: true, message: '请选择公司规模', trigger: 'change' },
                    ],
                    primaryIndustry: [
                    { required: true, message: '请输入行业类别', trigger: 'change' },
                    ],
                    city: [
                    { required: true, message: '请选择所在省市', trigger: 'change' }
                    ],
                    detailAddress: [
                    { required: true, message: '请填写详细地址', trigger: 'blur' }
                    ],
                    website: [
                    { required: true, message: '请填写公司官网', trigger: 'blur' }
                    ],
                    slogan: [
                    { required: true, message: '请填写一句话介绍', trigger: 'blur' },
                    { min: 1, max: 50, message: '长度在 1 到 50 个字符', trigger: 'blur' }
                    ],
                    description: [
                    { required: true, message: '请填写简短介绍', trigger: 'blur' },
                    { min: 1, max: 10000, message: '长度在 1 到 10000 个字符', trigger: 'blur' }
                    ]
                },
                active: 1
            };
        },
        computed: {
            sloganCount() {
                if(this.recruiterForm.slogan.length>51){
                    this.recruiterForm.slogan = this.recruiterForm.slogan.substr(0,50);
                }
                return this.recruiterForm.slogan.length;
            },
            descriptionCount() {
                if(this.recruiterForm.description.length>10001) {
                    this.recruiterForm.description = this.recruiterForm.description.substr(0,10000);
                    /* eslint-disable */
                    console.log(this.descriptionModify);
                    /* eslint-disable */
                }
                return this.recruiterForm.description.length;
            },
            tags() {
                return this.recruiterForm.tags.replace(/，/g,',').split(',');
            }
        },
        methods: {
            getCompanyInfo: function(){
                this.$http.get('/company/detail').then(response =>{
                    let a = response.body;
                    this.recruiterForm.fullName = a.fullName;
                    this.recruiterForm.shortName = a.shortName;
                    this.recruiterForm.nature = a.nature;
                    this.recruiterForm.size = a.size;
                    this.recruiterForm.primaryIndustry = a.primaryIndustry;
                    this.recruiterForm.city = a.city;
                    this.recruiterForm.detailAddress = a.detailAddress;
                    this.recruiterForm.website = a.website;
                    this.recruiterForm.slogan = a.slogan;
                    this.recruiterForm.description = a.description;
                })
            },
            removeTag(tagIndex) {
                let tags = this.tags;
                tags.splice(tagIndex,1);
                let modifyTags = tags.join(',');
                this.$http.put('/company/'+this.recId+'/modification/tags?tags='+ modifyTags).then(
                    response => {
                        this.getCompanyInfo();
                    });
            },
            submitForm() {
                window.location.href = 'http://localhost:8080/index.html';
            },
            nextStep(formName) {
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        this.$http.put('company/modification', this.recruiterForm).then(
                        response => {
                            if (this.active++ > 1) this.active = 1;
                        });  
                    } else {
                        console.log('error submit!!');
                        return false;
                    }
                });
            },
            selectedCity: function(value){
                this.recruiterForm.city = value.join(',');
            },
            closeSelectCity: function(){
                this.isSelectCity = false;
            },
            selectedSlave: function(value){
                this.recruiterForm.primaryIndustry = value.join(',');
            },
            closeSelectSlave: function(){
                this.isSelectPrimary = false;
            },
        },
        mounted() {
            eventBus.$on('modal:add-tags-closing',()=> {
                this.isAddingTags=false;

            });
            eventBus.$on('modal:emit-added-tags',(val)=> {
                //提交保存标签
                let modifyTags = val.join(',');
                console.log(modifyTags+'修改标签');
                this.$http.put('/company/'+this.recId+'/modification/tags?tags='+ modifyTags).then(
                    response => {
                        this.getCompanyInfo();
                    });
            });
            console.log("1111");
            this.getCompanyInfo();
            console.log("222");

        },
        components: {
            WorkflowModal,
            AddTagModal,
            SelectCityModal,
            SelectIndustryModal
        }
    }

</script>

<style lang="less">
    .guide {
        background-color: #ffffff;
        width:1180px;
        .icon-red-star {
            width:6px;
            height:6px;
            background: url(../../img/company/star.png) no-repeat;

            display: inline-block;
        }
        .guide-header {
            width:1180px;
            height: 50px;
            line-height: 50px;
            position: relative;
            border-bottom: 1px solid #e2e2e2;
            .guide-header-text {
                margin: 0 auto;
                text-align: center;
                font-size: 22px;
                line-height: 50px;
            }
            .guide-header-hint {
                position: absolute;
                right: 20px;
                top: 0;
                font-size: 16px;
            }
        }
        .guide-body {
            .el-steps {
                text-align: center;
                position: relative;
                margin-top: 30px;
                left:184px;
                .el-step__title {
                    font-size: 16px;
                }
            }
            .guide-step1 {
                .guide-company-title {
                    height:80px;
                    line-height: 80px;
                    padding-left: 90px;

                }
                .guide-company-form {
                    width: 1020px;
                    margin: 0 auto;
                    .company-logo-uploader-text {
                        display: inline-block;
                    }
                    .company-logo-uploader {
                        width:120px;
                        height:120px;
                        background-color: #eeeeee;

                        border: 1px dashed #eeeeee;
                        cursor: pointer;
                        display: inline-block;
                        .company-logo-uploader-icon {
                            width:118px;
                            height:118px;
                            text-align: center;
                            line-height: 118px;
                        }
                    }
                }

            }
            .guide-step2 {
                .guide-button-complete {
                    margin-bottom: 40px;
                    position: relative;
                    left:300px;
                    width:90px;
                    height: 40px;

                }
            }
        }
        .company-description {
            margin-bottom:20px;

            .el-row {
                // margin-left: 40px;
                padding-left: 40px;
                margin-bottom: 0px;
                padding-top: 24px;
                p {
                    line-height: 2em;
                }
                .el-button-editor{
                    float: right;
                }
                .description-count-div{
                    text-align: right;
                    width: 680px;
                    .description-count {
                    font-size: 10px;

                    }
                }
            }
        }

        .slogan-count-div{
            text-align: right;
            width: 680px;
            .slogan-count {
            font-size: 10px;

            }
        }

        .next-step{
            text-align: center;
            button {
                margin: 30px auto;
            }
        } 
    }
    .company-tag {
        margin-bottom:20px;

        .el-row {
            // margin-left: 40px;
            padding-left: 40px;
            margin-bottom: 0px;
        }
    }
</style>
