package cn.edu.dlut.career.recruiter.service;


import cn.edu.dlut.career.recruiter.domain.LargePerson;

import java.util.List;

/**
 * 大招代表人 服务层 接口
 * Created by HealerJean on 2017/3/24.
 */
public interface LargePersonService  {

    //保存，添加
    LargePerson saveLargePerson(LargePerson largePerson) ;

    //根据id查询
    LargePerson findById(String id);

    // 更新
    LargePerson updateLargePerson(LargePerson largePerson);

    //根据id删除 删除成功返回 ok ，否则 null
    String deleteLargePerson(String id);

    //查询所有的数据
    List<LargePerson> findAllLargePerson();


}
