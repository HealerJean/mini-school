package com.minixiao.web.controller.candidate;

import com.minixiao.apiauth.client.HeaderUtil;
import com.minixiao.web.dto.recruiters.UserDTO;
import com.minixiao.web.utils.YmlConfig;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.util.UUID;

/**
 * @Author wangyj.
 * @Date 2017/3/4  12:24.
 */
@RestController
public class ApplicationStatController {

    @Autowired
    private YmlConfig ymlConfig;

    private RestTemplate restTemplate = new RestTemplate();

    /**
     * @Description 与公司相关的数据统计（sass首页）.
     * @Author  wangyj
     * @CreateDate 2017/3/10 11:20
     * @Param
     * @Return
     */
    @GetMapping("/candidate/{recId}/stat")
    @ResponseBody
    public ResponseEntity<String> getApplication(@PathVariable UUID recId) {
        Subject subject = SecurityUtils.getSubject();
        if (subject != null) {
            UserDTO user = (UserDTO) subject.getSession().getAttribute(ymlConfig.getSession_current_user());
            if (user != null) {
                recId = user.getRecId();
                UUID optUid = user.getId();
                String optName = user.getRealName();
                String recName = user.getRecName();
                HttpHeaders requestHeaders = HeaderUtil.getHeader(optUid, optName, "COMPANY", recId,
                    recName);
                HttpEntity requestEntity = new HttpEntity(null, requestHeaders);
                ResponseEntity<String> responseEntity = restTemplate.exchange(
                    ymlConfig.getUrl_api_recruiter() + "candidate/{recId}/stat", HttpMethod.GET, requestEntity,
                    String.class, recId);
                String result = responseEntity.getBody();
                return ResponseEntity
                    .status(HttpStatus.OK)
                    .cacheControl(CacheControl.noCache())
                    .body(result);
            }
        }
        return null;
    }
}
