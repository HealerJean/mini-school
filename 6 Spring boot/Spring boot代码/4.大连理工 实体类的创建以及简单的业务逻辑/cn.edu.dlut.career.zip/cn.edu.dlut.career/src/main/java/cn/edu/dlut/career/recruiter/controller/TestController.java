package cn.edu.dlut.career.recruiter.controller;

import cn.edu.dlut.career.recruiter.domain.LargeOrder;
import cn.edu.dlut.career.recruiter.domain.YardOrder;
import cn.edu.dlut.career.recruiter.repository.LargeOrderRepository;
import cn.edu.dlut.career.recruiter.repository.YardOrderRepository;
import cn.edu.dlut.career.recruiter.service.LargeOrderService;
import cn.edu.dlut.career.recruiter.service.YardOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Created by HealerJean on 2017/3/23.
 */

@RestController
public class TestController {
  @Autowired
    LargeOrderRepository largeOrderRepository;
    //使用接口的注解
    @Autowired
    LargeOrderService largeOrderService;
    @Autowired
    YardOrderRepository yardOrderRepository;
    @Autowired
    YardOrderService yardOrderService;
    @GetMapping("/index")
    public String index() {
        return  "index.html";
    }
   @PostMapping("/addyardorder")
   public YardOrder testAddYardOrer() {
       YardOrder yardOrder = new YardOrder();
       yardOrder.setRecepPerson("张宇晋");

       yardOrder.setRequirements("yardRequirements");
       yardOrder.setQuantity(13);
       yardOrder.setScale("yardsScale") ;
       yardOrder.setUse("sideUse");
       yardOrder.setAddress("yardAddress");
     yardOrder.setUseStartTime(LocalDateTime.now());
    yardOrder.setUseEndTime(LocalDateTime.now());
       yardOrder.setRecepPerson("recepPerson");
       yardOrder.setAuditState("12");
       yardOrder.setAuditTime(LocalDateTime.now());
       yardOrder.setAuditPerson("张宇");

       return yardOrderRepository.save(yardOrder);
   }

    @GetMapping("/findAll")
    public List<YardOrder> findAllYardOrder() {
        return yardOrderService.findAll();
    }
    @DeleteMapping("/delete")
    public void deleteYardOrder() {

    }
    @PostMapping("/addLargeOrder")
    public LargeOrder testAddLargeOrder() {
        LargeOrder largeOrder = new LargeOrder();
        largeOrder.setOrderMethod("registrMethod");
        largeOrder.setOrderPosition("赵春宇");
        largeOrder.setCost(2.2);
        largeOrder.setPayState("success");
        largeOrder.setRemarks("备注");
        largeOrder.setAuditState("success");
       largeOrder.setAuditTime(LocalDateTime.now());
        largeOrder.setAuditPerson("张宇晋");
         return  largeOrderService.saveLargeOrder(largeOrder);
    }


    @PutMapping("/updateLargeOrder")
    public LargeOrder updateLargeOrder() {
        LargeOrder largeOrder = new LargeOrder();
        largeOrder.setId("402881215afa16f1015afa25def60000");
        largeOrder.setOrderMethod("registrMethod");
        largeOrder.setOrderPosition("11111");
        largeOrder.setCost(2.2);
        largeOrder.setPayState("success");
        largeOrder.setRemarks("备注");
        largeOrder.setAuditState("success");
        largeOrder.setAuditPerson("张宇晋");
        return  largeOrderService.updateLargeOrder(largeOrder);
    }
    @DeleteMapping("/deleteLargeOrder")
    public String  deleteLargeOrder() {
        LargeOrder largeOrder = new LargeOrder();

        largeOrderService.deleteLargeOrder(("402881215afa0c63015afa0dfcde0000"));
        return  "ok";
    }
   /* @PutMapping("/updateLargeOrderAudit")
    public int  updateLargeOrderAudit() {
        LargeOrder largeOrder = new LargeOrder();
        largeOrder.setId("402881215b0dcf03015b0dcfaa000000");
        largeOrder.setAuditPerson("刘利");
       largeOrder.setAuditTime(LocalDateTime.now());
        largeOrder.setAuditState("two");
   //    largeOrderService.updateLargeOrderAudit(largeOrder.getId(),largeOrder.getAuditPerson(),new Date(),largeOrder.getAuditState());

        return         largeOrderService.updateLargeOrderAudit(largeOrder.getId(),largeOrder.getAuditPerson(),largeOrder.getAuditTime(),largeOrder.getAuditState());

    }*/
    @PutMapping("/updateYardOrderAudit")
    public int  updateYardOrderAudit() {
        YardOrder yardOrder = new YardOrder();
        yardOrder.setId("402881215afa4fb1015afa5056a90000");
        yardOrder.setAuditPerson("刘利");
        yardOrder.setAuditTime(LocalDateTime.now());
        yardOrder.setAuditState("two");
   //     largeOrderService.updateLargeOrderAudit(yardOrder.getId(),yardOrder.getAuditPerson(),new Date(),yardOrder.getAuditState());

        return          yardOrderService.updateYardOrderAudit(yardOrder.getId(),yardOrder.getAuditPerson(),LocalDateTime.now(),yardOrder.getAuditState());
    }


}