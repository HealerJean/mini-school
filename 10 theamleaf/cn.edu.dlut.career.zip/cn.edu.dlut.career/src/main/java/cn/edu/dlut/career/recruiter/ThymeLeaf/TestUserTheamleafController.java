package cn.edu.dlut.career.recruiter.ThymeLeaf;

import cn.edu.dlut.career.recruiter.domain.LargeOrder;
import cn.edu.dlut.career.recruiter.service.LargeOrderService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;
import java.util.List;

/**
 * Created by HealerJean on 2017/3/28.
 */
@Controller
public class TestUserTheamleafController {
    private Logger logger = LoggerFactory.getLogger(TestUserTheamleafController.class);

    @Autowired
    LargeOrderService largeOrderService;
    @Autowired
    TestPageableRepository testPageableRepository;
    @RequestMapping("/useTheamLeafList")
    public ModelAndView  useTheamLeafList() {
        ModelAndView mv = new ModelAndView("find");
        List<LargeOrder>  largeOrders = largeOrderService.findAllLargeOrder();
        mv.addObject("largeOrders",largeOrders);
        return  mv;
    }

    @RequestMapping("/pageable")
    public String showUsers(Model model) {

    Pageable pageable = new Pageable() {
        @Override
        public int getPageNumber() {
            return 0;
        }

        @Override
        public int getPageSize() {
            return 4;
        }

        @Override
        public int getOffset() {
            return 0;
        }

        @Override
        public Sort getSort() {
            return null;
        }

        @Override
        public Pageable next() {
            return null;
        }

        @Override
        public Pageable previousOrFirst() {
            return null;
        }

        @Override
        public Pageable first() {
            return null;
        }

        @Override
        public boolean hasPrevious() {
            return false;
        }
    };


        model.addAttribute("largeOrders", testPageableRepository.findAll(pageable));

        return "find";
    }


    /**
     * 添加首页面
     * @return
     */
    @RequestMapping(value = "/addindex" ,method = RequestMethod.GET)
    public String addindex(){

        return "add";
    }
    /**
     * 添加功能 验证表单
     */
    /*@RequestMapping(value = "/add" ,method = RequestMethod.POST)
    public ModelAndView add(ModelAndView model, @Valid LargeOrderForm largeOrderForm, BindingResult result){

        LargeOrder largeOrder = new LargeOrder();
        largeOrder.setAuditPerson(largeOrderForm.auditPerson);
        largeOrder.setAuditState(largeOrderForm.auditState);
        LargeOrder largeOrder1 =  testPageableRepository.save(largeOrder);
       logger.info(largeOrder+"");

        if(result.hasErrors()){
            model.addObject("MSG", "出错啦！");
        }else{
            model.addObject("MSG", "提交成功！");
        }
        model.setViewName("add");

     //   List<LargeOrder>  largeOrders = largeOrderService.findAllLargeOrder();
     //    model.addObject("largeOrders",largeOrders);
        return model;
    }*/


    @RequestMapping(value = "/add" ,method = RequestMethod.POST)
    public ModelAndView add(LargeOrder largeOrder){
        LargeOrder largeOrder1 =  testPageableRepository.save(largeOrder);
        logger.info(largeOrder+"");

        ModelAndView  model = new ModelAndView("find");

         List<LargeOrder>  largeOrders = largeOrderService.findAllLargeOrder();
         model.addObject("largeOrders",largeOrders);
        return model;
    }

    @RequestMapping(value = "/update" ,method = RequestMethod.GET)
    public String updateindex(){

        return "update";
    }

    /**
     * 开始更新
     * @param id
     * @param
     * @return
     */
    @RequestMapping(value = "/updateindex" ,method = RequestMethod.GET)
    public ModelAndView updateindex(@RequestParam("id") String id){
        logger.info("更新页面");
        LargeOrder largeOrder =  testPageableRepository.findById(id);
        ModelAndView  model = new ModelAndView("update");
        model.addObject("largeOrder",largeOrder);
        return model;

    }

    /**
     * 删除功能
     * @param id
     * @return
     */
    @RequestMapping(value = "/delete" ,method = RequestMethod.GET)
    public ModelAndView delete(@RequestParam("id") String id){
        logger.info("删除页面");
        testPageableRepository.delete(id);

        ModelAndView mv = new ModelAndView("find");
        List<LargeOrder>  largeOrders = testPageableRepository.findAll();
        mv.addObject("largeOrders",largeOrders);

        return mv;

    }




    @ResponseBody
    @RequestMapping(value = "/ajaxindex" ,method = RequestMethod.GET)
    public List<LargeOrder>  ajaxindex() {
        ModelAndView mv = new ModelAndView("find");
        List<LargeOrder>  largeOrders = testPageableRepository.findAll();
        logger.info(""+largeOrders.size());
        return  largeOrders;
    }
}
