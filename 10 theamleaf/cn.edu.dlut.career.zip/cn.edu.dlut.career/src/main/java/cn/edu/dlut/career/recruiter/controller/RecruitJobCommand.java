package cn.edu.dlut.career.recruiter.controller;

import cn.edu.dlut.career.recruiter.domain.RecruitJob;
import cn.edu.dlut.career.recruiter.service.RecruitJobService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * Created by 史念念 on 2017/3/27.
 *
 * 招聘职位 增删改
 */
@Controller
@RequestMapping("/recruitJob")
@Transactional
public class RecruitJobCommand {
  @Autowired
  private RecruitJobService recruitJobService;

  private Logger logger = LoggerFactory.getLogger(RecruitJobCommand.class);

  /**
   * 添加招聘职位
   * @param recruitJob
   * @return
   */
  @PostMapping
  @ResponseBody
  public String saveRecJob(@RequestBody RecruitJob recruitJob){

    String result = "error";
    try {
      result = recruitJobService.saveRecruitJob(recruitJob);

    } catch (Exception e) {
      e.printStackTrace();
      result = "error";
    }
    logger.info(result);
    return result;
  }

}
