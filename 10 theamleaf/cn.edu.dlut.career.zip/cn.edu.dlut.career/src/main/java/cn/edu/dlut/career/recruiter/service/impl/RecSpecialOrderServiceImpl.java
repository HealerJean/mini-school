package cn.edu.dlut.career.recruiter.service.impl;

import cn.edu.dlut.career.recruiter.domain.RecSpecialOrder;
import cn.edu.dlut.career.recruiter.repository.RecSpecialOrderRepository;
import cn.edu.dlut.career.recruiter.service.RecSpecialOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Created by 史念念 on 2017/3/24.
 *
 * 专场招聘会预约服务层实现类
 */
@Service
public class RecSpecialOrderServiceImpl implements RecSpecialOrderService {
  @Autowired
  private RecSpecialOrderRepository recSpecialOrderRepository;

  /**
   * 添加 专场招聘会预约信息
   * @param recSpecialOrder
   * @return
   */
  @Override
  public String saveRecSpecialOrder(RecSpecialOrder recSpecialOrder) {
    try {
      recSpecialOrderRepository.save(recSpecialOrder);
      return "ok";
    }catch (Exception e){
      e.printStackTrace();
      return "fail";
    }
  }

  /**
   * 查询所有 专场招聘会预约信息
   * @return
   */
  @Override
  public List<RecSpecialOrder> findAll() {
    List<RecSpecialOrder> recSpecialOrders = recSpecialOrderRepository.findAll();

    return recSpecialOrders;
  }

  /**
   * 根据Id查找 专场招聘会预约信息
   * @param id
   * @return
   */
  @Override
  public RecSpecialOrder findById(String id) {
    RecSpecialOrder recSpecialOrder = recSpecialOrderRepository.findById(id);

    return recSpecialOrder;
  }

  /**
   * 根据企业id 查找专场招聘会预约信息
   * @param recId
   * @return
   */
  @Override
  public List<RecSpecialOrder> findByRecId(String recId) {
    List<RecSpecialOrder> recSpecialOrders = recSpecialOrderRepository.findByRecId(recId);

    return recSpecialOrders;
  }

  /**
   * 修改审核信息
   * @param id 主键
   * @param auditStatus 状态
   * @param auditPerson 审核人
   * @param auditTime 审核时间
   * @param auditFailReason  审核失败原因
   * @return
   */
  @Override
  public String updateAudit(String id, String auditStatus, String auditPerson, LocalDateTime auditTime, String auditFailReason) {
    int result = recSpecialOrderRepository.updateAudit(id,auditStatus,auditPerson,auditTime,auditFailReason);

    return result>0?"ok":"fail";
  }

  /**
   * 修改接待人，接待人联系方式
   * @param id
   * @param receptionist 接待人
   * @param recepTel 接待人联系方式
   * @return
   */
  @Override
  public String updateReceptionistAndRecepTel(String id, String receptionist, String recepTel) {
    int result = recSpecialOrderRepository.updateReceptionistAndRecepTel(id,receptionist,recepTel);

    return result>0?"ok":"fail";
  }

  /**
   * 删除 专场招聘会预约信息
   * @param id
   * @return
   */
  @Override
  public String deleteById(String id) {
    try {
      recSpecialOrderRepository.delete(id);
      return "ok";
    }catch (Exception e){
      e.printStackTrace();
      return "fail";
    }
  }
}
