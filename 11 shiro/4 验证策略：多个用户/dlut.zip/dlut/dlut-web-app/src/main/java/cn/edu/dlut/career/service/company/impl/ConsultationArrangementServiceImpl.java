package cn.edu.dlut.career.service.company.impl;


import cn.edu.dlut.career.domain.school.ConsultationArrangement;
import cn.edu.dlut.career.repository.company.ConsultationArrangementRepository;
import cn.edu.dlut.career.service.company.ConsultationArrangementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by liang on 2017/3/30.
 */
@Service
public class ConsultationArrangementServiceImpl implements ConsultationArrangementService {
    @Autowired
    private ConsultationArrangementRepository consultationArrangementRepository;
    @Override
    public List<ConsultationArrangement> findAll() {
        return consultationArrangementRepository.findAll();
    }

    @Override
    public ConsultationArrangement finOne(String id) {
        return consultationArrangementRepository.findOne(id);
    }

    @Override
    public void delete(String id) {
        consultationArrangementRepository.delete(id);
    }

    @Override
    public void save(ConsultationArrangement consultationArrangement) {
        consultationArrangementRepository.save(consultationArrangement);
    }
}
