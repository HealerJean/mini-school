<template>
    <el-dialog title="下线提醒"
               v-model="offlineRemindModalVisible"
               size="tiny"
               :close-on-click-modal="false"
               :close-on-press-escape="false"
               @close="closeModal">
        当前职位已成功下线
        <div slot="footer" class="dialog-footer">
            <el-button type="primary" @click="closeModal">确定</el-button>
        </div>
    </el-dialog>
</template>

<script type="text/babel">

    import eventBus from '../../js/shared/eventBus';

    export default {
        name: 'offline-remind-modal',

        data() {
            return {

            };
        },

        computed: {
            offlineRemindModalVisible() {
                return this.isOfflineRemind;
            }
        },

        props: {
            isOfflineRemind: {
                type: Boolean,
                default: false
            }
        },

        methods: {
            closeModal() {
                eventBus.$emit('modal:offline-remind-closing');
            }
        }
    }

</script>

<style lang="less" scoped>

    @import "../../less/shared/variables";

    .change-time-main{
        display:inline-block;
        text-align: left;
    }
    .change-time-label{
        margin-right:10px;
        font-size:@size-lg;
    }
    .change-time-tip{
        margin-top:18px;
        margin-bottom:0;
        font-size:@size-sm;
        color:@highlight-color;
    }


</style>
