package cn.edu.dlut.career.repository.company;


import cn.edu.dlut.career.domain.school.ConsultationAppointment;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

/**
 * Created by liang on 2017/3/30.
 */
public interface ConsultationAppointmentRepository extends CrudRepository<ConsultationAppointment,String> {
    List<ConsultationAppointment> findAll();
}
