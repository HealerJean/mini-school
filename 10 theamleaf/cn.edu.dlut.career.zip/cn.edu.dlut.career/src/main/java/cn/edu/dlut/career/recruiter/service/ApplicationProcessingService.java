package cn.edu.dlut.career.recruiter.service;

import cn.edu.dlut.career.recruiter.domain.ApplicationProcessing;

import java.util.List;

/**
 * Created by wei on 2017/3/24.
 */
public interface ApplicationProcessingService {
  ApplicationProcessing save(ApplicationProcessing applicationProcessing);

  void delete (String id);

  ApplicationProcessing update(ApplicationProcessing applicationProcessing);

  List<ApplicationProcessing> findAll();

  ApplicationProcessing findOne(String id);
}
