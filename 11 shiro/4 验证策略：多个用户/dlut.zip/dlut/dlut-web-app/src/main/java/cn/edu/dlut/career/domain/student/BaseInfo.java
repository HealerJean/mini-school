package cn.edu.dlut.career.domain.student;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * 学生的基本信息／学籍信息
 */
@Entity
public class BaseInfo {
    @Id
    // 学号
    private String xh;
    // 考生号
    private String ksh;
    // 姓名，少数民族学生姓名中的点需要统一处理为"·"
    @Column(name="xm", length = 40, nullable = false)
    private String xm;
    // 身份证号
    @Column(name="sfzh", length=18, nullable = false)
    private String sfzh;
    // 性别代码
    @Column(name="xbdm", length = 1, nullable = false)
    private String xbdm;
    // 民族代码
    private String mzdm;
    // 政治面貌代码
    private String zzmmdm;
}
