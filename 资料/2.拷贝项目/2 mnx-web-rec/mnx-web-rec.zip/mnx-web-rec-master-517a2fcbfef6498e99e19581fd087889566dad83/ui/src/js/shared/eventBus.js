// eventBus
// 用于不同组件之间的事件派发接收等
import Vue from 'vue';

export default new Vue;
