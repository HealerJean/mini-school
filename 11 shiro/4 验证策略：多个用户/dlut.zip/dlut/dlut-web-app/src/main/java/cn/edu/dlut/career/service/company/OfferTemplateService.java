package cn.edu.dlut.career.service.company;

import cn.edu.dlut.career.domain.company.OfferTemplate;

import java.util.List;

/**
 * Created by wei on 2017/3/28.
 */
public interface OfferTemplateService {
    void save(OfferTemplate offerTemplate);

    void delete(String id);

    List<OfferTemplate> findAll();

    OfferTemplate findOne(String id);

    void update(OfferTemplate offerTemplate);
}
