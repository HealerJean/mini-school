package com.minixiao.web.controller.setting;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.minixiao.apiauth.client.HeaderUtil;
import com.minixiao.web.dto.recruiters.CompanyFlowDTO;
import com.minixiao.web.dto.recruiters.UserDTO;
import com.minixiao.web.utils.YmlConfig;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Created by xiachao on 2017/3/2.
 */
@RestController
public class CompanyFlowController {
    private Logger logger = LoggerFactory.getLogger(CompanyFlowController.class);

    @Autowired
    private YmlConfig ymlConfig;

    private RestTemplate restTemplate = new RestTemplate();

    private ObjectMapper objectMapper = new ObjectMapper();

    /**
     * @Description 根据公司Id获取所有该公司下所有招聘流程.
     * @Author xiachao
     * @CreateTime 2017/3/4 16:00
     * @Param
     * @Return
     */
    @GetMapping("/company/flows")
    public String getAllRecruiterFlow() {
        Subject subject = SecurityUtils.getSubject();
        if (subject != null) {
            UserDTO user = (UserDTO) subject.getSession().getAttribute(
                ymlConfig.getSession_current_user());
            if (user != null) {
                UUID userId2 = user.getId();
                String userName = user.getRealName();
                UUID recId2 = user.getRecId();
                String recName = user.getRecName();
                HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                    recId2, recName);
                HttpEntity requestEntity = new HttpEntity(null, httpHeaders);
                ResponseEntity<String> responseEntity = restTemplate.exchange(
                    ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2 + "/flows",
                    HttpMethod.GET, requestEntity, String.class);
                if (responseEntity.getStatusCodeValue() == 200) {
                    return responseEntity.getBody();
                }
            }
        }
        return null;
    }

    /**
     * @Description 为公司创建默认的招聘流程 即为公司创建初筛 笔试 面试 录用四个流程.
     * @Author xiachao
     * @CreateTime 2017/3/2 15:49
     * @Param
     * @Return
     */
    @PostMapping("company/flows/init")
    public boolean initRecruiterFlow() {
        Subject subject = SecurityUtils.getSubject();
        if (subject != null) {
            UserDTO user = (UserDTO) subject.getSession().getAttribute(
                ymlConfig.getSession_current_user());
            if (user != null) {
                UUID userId2 = user.getId();
                String userName = user.getRealName();
                UUID recId2 = user.getRecId();
                String recName = user.getRecName();
                HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                    recId2, recName);
                HttpEntity requestEntity = new HttpEntity(null, httpHeaders);
                ResponseEntity<String> responseEntity = restTemplate.exchange(
                    ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2 + "/flows/init",
                    HttpMethod.POST, requestEntity, String.class);
                if (responseEntity.getStatusCodeValue() == 200) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * @Description 创建用户自定义公司招聘流程.
     * @Author xiachao
     * @CreateTime 2017/3/2 15:58
     * @Param
     * @Return
     */
    @PostMapping("company/flow")
    public String createRecruiterFlow(String type, String name, String flowOrder) {
        if (type != null && type != "" && name != null
            && name != "" && flowOrder != null && flowOrder != "") {
            Subject subject = SecurityUtils.getSubject();
            if (subject != null) {
                UserDTO user = (UserDTO) subject.getSession().getAttribute(
                    ymlConfig.getSession_current_user());
                if (user != null) {
                    UUID userId2 = user.getId();
                    String userName = user.getRealName();
                    UUID recId2 = user.getRecId();
                    String recName = user.getRecName();
                    HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                        recId2, recName);
                    httpHeaders.setContentType(MediaType.APPLICATION_JSON_UTF8);
                    CompanyFlowDTO companyFlowDTO = new CompanyFlowDTO();
                    companyFlowDTO.setName(name);
                    companyFlowDTO.setFlowOrder(Integer.parseInt(flowOrder));
                    companyFlowDTO.setType(type);
                    HttpEntity<CompanyFlowDTO> requestEntity = new HttpEntity<CompanyFlowDTO>(companyFlowDTO, httpHeaders);
                    ResponseEntity<String> responseEntity = restTemplate.exchange(
                        ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2 + "/flow",
                        HttpMethod.POST, requestEntity, String.class);
                    if (responseEntity.getBody() != null) {
                        return responseEntity.getBody();
                    }
                }
            }
        }
        return "添加失败！请检查是否已添加了相同的招聘流程名称";
    }

    /**
     * @Description 删除自定义招聘流程.
     * @Author xiachao
     * @CreateTime 2017/3/2 16:34
     * @Param
     * @Return
     */
    @DeleteMapping("company/flows/{id}")
    public String deleteRecruiterFlow(@PathVariable UUID id) {
        if (id != null) {
            Subject subject = SecurityUtils.getSubject();
            if (subject != null) {
                UserDTO user = (UserDTO) subject.getSession().getAttribute(
                    ymlConfig.getSession_current_user());
                if (user != null) {
                    UUID userId2 = user.getId();
                    String userName = user.getRealName();
                    UUID recId2 = user.getRecId();
                    String recName = user.getRecName();
                    HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                        recId2, recName);
                    HttpEntity requestEntity = new HttpEntity(null, httpHeaders);
                    httpHeaders.setContentType(MediaType.APPLICATION_JSON_UTF8);
                    ResponseEntity<String> responseEntity = restTemplate.exchange(
                        ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2 + "/flows/" + id,
                        HttpMethod.DELETE, requestEntity, String.class);
                    if (responseEntity.getStatusCodeValue() == 200) {
                        return responseEntity.getBody();
                    }
                }
            }
        }
        return "删除失败";
    }

    /**
     * @Description 修改某一招聘流程的名称或类型.
     * @Author xiachao
     * @CreateTime 2017/3/2 16:38
     * @Param
     * @Return
     */
    @PutMapping("company/flows/{id}")
    public String updateRecruiterFlowName(String name, String type, @PathVariable UUID id) {
        if (name != null && name != "" && type != null) {
            Subject subject = SecurityUtils.getSubject();
            if (subject != null) {
                UserDTO user = (UserDTO) subject.getSession().getAttribute(
                    ymlConfig.getSession_current_user());
                if (user != null) {
                    UUID userId2 = user.getId();
                    String userName = user.getRealName();
                    UUID recId2 = user.getRecId();
                    String recName = user.getRecName();
                    HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                        recId2, recName);
                    HttpEntity requestEntity = new HttpEntity(null, httpHeaders);
                    httpHeaders.setContentType(MediaType.APPLICATION_JSON_UTF8);
                    ResponseEntity<String> responseEntity = restTemplate.exchange(
                        ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2 + "/flows/" + id + "?name=" + name + "&type=" + type,
                        HttpMethod.PUT, requestEntity, String.class);
                    if (responseEntity.getStatusCodeValue() == 200) {
                        return responseEntity.getBody();
                    }
                }
            }
        }
        return "修改失败";
    }

    /**
     * @Description 修改某一招聘流程的次序.
     * @Author xiachao
     * @CreateTime 2017/3/2 16:38
     * @Param
     * @Return
     */
    @PutMapping("company/flows/{id}/order")
    public String updateRecruiterFlowOrder(Integer flowOrder, @PathVariable UUID id) {
        if (flowOrder != null) {
            Subject subject = SecurityUtils.getSubject();
            if (subject != null) {
                UserDTO user = (UserDTO) subject.getSession().getAttribute(
                    ymlConfig.getSession_current_user());
                if (user != null) {
                    UUID userId2 = user.getId();
                    String userName = user.getRealName();
                    UUID recId2 = user.getRecId();
                    String recName = user.getRecName();
                    HttpHeaders httpHeaders = HeaderUtil.getHeader(userId2, userName, "COMPANY",
                        recId2, recName);
                    HttpEntity requestEntity = new HttpEntity(null, httpHeaders);
                    httpHeaders.setContentType(MediaType.APPLICATION_JSON_UTF8);
                    ResponseEntity<String> responseEntity = restTemplate.exchange(
                        ymlConfig.getUrl_api_recruiter() + "recruiters/" + recId2 + "/flows/" + id + "/order?flowOrder=" + flowOrder,
                        HttpMethod.PUT, requestEntity, String.class);
                    if (responseEntity.getStatusCodeValue() == 200) {
                        return responseEntity.getBody();
                    }
                }
            }
        }
        return "操作失败";
    }

}
