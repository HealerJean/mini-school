package cn.edu.dlut.career.recruiter.service;

import cn.edu.dlut.career.recruiter.domain.CompanyInfo;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.UUID;

import static org.junit.Assert.*;

/**
 * Created by wei on 2017/3/23.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class CompanyInfoServiceTest {
  @Resource
  CompanyInfoService companyInfoService;

  @Test
  public void saveCompany(){
    CompanyInfo companyInfo = new CompanyInfo();
    DateTimeFormatter ymd = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    LocalDateTime localDate =LocalDateTime.parse("2015-11-23 11:00:00", ymd);
    companyInfo.setPwd("123456");
    companyInfo.setName("minixiao");
    companyInfo.setAddress("金台路");
    companyInfo.setId(UUID.randomUUID().toString());
    companyInfo.setOrganizationCode("12357643254578");
    companyInfo.setNature("IT");
    companyInfo.setName("迷你校");
    companyInfo.setIndustry("招聘");
    companyInfo.setContactNumber("12345654332");
    companyInfo.setContacts("梁伟");
    companyInfo.setEmail("123@minixiao.com");
    companyInfo.setBusinessLicense("saw.2e3re.sdada");
    companyInfo.setZipCode("123123");
    companyInfo.setWebsite("www.minixiao.com");
    companyInfo.setSynopsis("迷你校一个牛逼的公司！");
    companyInfo.setRemarks("没有备注");
    companyInfo.setSize("大型公司");
    companyInfo.setRegistrationTime(localDate);
    companyInfo.setAuditStatus("0");
    companyInfo.setAuditTime(localDate);
    companyInfo.setReviewer("张三");
    companyInfo.setLabel("IT");
    companyInfoService.saveCompany(companyInfo);

  }

  @Test
  public void testUpdate(){
    CompanyInfo companyInfo = companyInfoService.findOne("402881f95afa4972015afa4983f90000");
    companyInfo.setName("精准投");
    companyInfoService.saveCompany(companyInfo);
  }
  @Test
  public void testDelete(){
    companyInfoService.delete("402881f95afa4972015afa4983f90000");
  }


}