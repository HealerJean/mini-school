<template>
    <h1>关于我们</h1>
</template>

<script type="text/babel">

    export default {
        data:function(){
            return {

            }
        }
    }

</script>

<style lang="less">

</style>
