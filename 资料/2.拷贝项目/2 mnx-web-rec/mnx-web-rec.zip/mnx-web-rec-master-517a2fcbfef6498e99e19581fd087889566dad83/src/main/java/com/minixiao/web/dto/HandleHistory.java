package com.minixiao.web.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.UUID;


public class HandleHistory implements Serializable {

  private static final long SERIVALVERSIONUID = 876280513342148585L;



  //申请表id
  public UUID applicationId;

  //候选人名称
  private String candidateName;

  //公司ID
  private UUID recId;

  //公司名称
  private String recName;

  //职位ID
  private UUID jobId;

  //职位名称
  private String jobName;

  //操作人ID
  private UUID optUid;

  //操作人名称
  private String optUname;

  //操作类型 （）
  private String optType;

  //处理历史描述
  private String description;

  //操作时间
  private LocalDate optDate;

  //候选人的状态
  private String status;

  //备注
  private String remark;


  public UUID getApplicationId() {
    return applicationId;
  }

  public void setApplicationId(UUID applicationId) {
    this.applicationId = applicationId;
  }

  public String getCandidateName() {
    return candidateName;
  }

  public void setCandidateName(String candidateName) {
    this.candidateName = candidateName;
  }

  public UUID getRecId() {
    return recId;
  }

  public void setRecId(UUID recId) {
    this.recId = recId;
  }

  public String getRecName() {
    return recName;
  }

  public void setRecName(String recName) {
    this.recName = recName;
  }

  public UUID getJobId() {
    return jobId;
  }

  public void setJobId(UUID jobId) {
    this.jobId = jobId;
  }

  public String getJobName() {
    return jobName;
  }

  public void setJobName(String jobName) {
    this.jobName = jobName;
  }

  public UUID getOptUid() {
    return optUid;
  }

  public void setOptUid(UUID optUid) {
    this.optUid = optUid;
  }

  public String getOptUname() {
    return optUname;
  }

  public void setOptUname(String optUname) {
    this.optUname = optUname;
  }

  public String getOptType() {
    return optType;
  }

  public void setOptType(String optType) {
    this.optType = optType;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public LocalDate getOptDate() {
    return optDate;
  }

  public void setOptDate(LocalDate optDate) {
    this.optDate = optDate;
  }

  public String getRemark() {
    return remark;
  }

  public void setRemark(String remark) {
    this.remark = remark;
  }

  /**
   * 构造函数.
   */
  public HandleHistory() {
  }

  /**
   * 构造函数.
   *
   * @param applicationId   候选人申请表
   * @param candidateName 候选人名称
   * @param recId         公司Id
   * @param recName       公司名称
   * @param jobId         职位Id
   * @param jobName       职位名称
   * @param optUid        操作人Id
   * @param optUname      操作人名称
   * @param optType       操作类型
   * @param description   描述
   * @param status        状态
   * @param optDate       操作时间
   * @param remark        操作时间
   */
  public HandleHistory( UUID applicationId, String candidateName,
                       UUID recId, String recName, UUID jobId, String jobName,
                       UUID optUid, String optUname, String optType, String description,
                       String status, LocalDate optDate, String remark) {
    this.applicationId = applicationId;
    this.candidateName = candidateName;
    this.recId = recId;
    this.recName = recName;
    this.jobId = jobId;
    this.jobName = jobName;
    this.optUid = optUid;
    this.optUname = optUname;
    this.optType = optType;
    this.description = description;
    this.status = status;
    this.optDate = optDate;
    this.remark = remark;
  }

  public static enum OptType {
    TYPE_A("通过"), TYPE_B("不通过"), TYPE_C("待定"),
    TYPE_D("安排面试"), TYPE_E("修改面试安排"), TYPE_F("取消面试"),
    TYPE_G("安排笔试"), TYPE_H("修改笔试安排"), TYPE_I("取消笔试"),
    TYPE_J("发邮件"), TYPE_K("淘汰"), TYPE_L("打标签"), TYPE_M("阶段跳转");


    private String value;

    /**
     * A
     * 操作类型.
     */
    private OptType(String value) {
      this.value = value;
    }

    @Override
    public String toString() {
      return this.value;
    }
  }
}
