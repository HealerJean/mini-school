package cn.edu.dlut.career.service.company.impl;


import cn.edu.dlut.career.domain.company.RecCareerEvent;
import cn.edu.dlut.career.repository.company.RecCareerEventRepository;
import cn.edu.dlut.career.service.company.RecCareerEventService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Created by 史念念 on 2017/3/24.
 * <p>
 * 专场招聘会预约服务层实现类
 */
@Service
public class RecCareerEventServiceImpl implements RecCareerEventService {
    @Autowired
    private RecCareerEventRepository recCareerEventRepository;

    /**
     * 添加 专场招聘会预约信息
     *
     * @param recCareerEvent
     * @return
     */
    @Override
    public String saveRecCareerEvent(RecCareerEvent recCareerEvent) {
        try {
            recCareerEventRepository.save(recCareerEvent);
            return "ok";
        } catch (Exception e) {
            e.printStackTrace();
            return "fail";
        }
    }

    /**
     * 查询所有 专场招聘会预约信息
     *
     * @return
     */
    @Override
    public List<RecCareerEvent> findAll() {
        List<RecCareerEvent> recCareerEvents = recCareerEventRepository.findAll();

        return recCareerEvents;
    }

    /**
     * 根据Id查找 专场招聘会预约信息
     *
     * @param id
     * @return
     */
    @Override
    public RecCareerEvent findById(String id) {
        RecCareerEvent recCareerEvent = recCareerEventRepository.findById(id);

        return recCareerEvent;
    }

    /**
     * 根据企业id 查找专场招聘会预约信息
     *
     * @param recId
     * @return
     */
    @Override
    public List<RecCareerEvent> findByRecId(String recId) {
        List<RecCareerEvent> recCareerEvents = recCareerEventRepository.findByRecId(recId);

        return recCareerEvents;
    }

    /**
     * 修改审核及回执信息
     *
     * @param id
     * @param auditStatus  审核状态
     * @param auditSuggest 审核意见
     * @param areaAddress  场地地址
     * @param areaCost     场地费用
     * @param receiver     接待人
     * @param receiverTel  接待人联系方式
     * @param auditTime    审核时间
     * @param auditor      审核人
     * @param holdTime     举办时间（年月日）
     * @param startTime    开始时间（几点几分）
     * @param endTime      结束时间
     * @return
     */
    @Override
    public String updateAudit(String id, char auditStatus, String auditSuggest, String areaAddress, float areaCost, String receiver, String receiverTel, LocalDateTime auditTime, String auditor, LocalDateTime holdTime, LocalDateTime startTime, LocalDateTime endTime) {
        try {
            int i = recCareerEventRepository.updateAudit(id, auditStatus, auditSuggest, areaAddress, areaCost, receiver, receiverTel, auditTime, auditor, holdTime, startTime, endTime);
            return i > 0 ? "ok" : "fail";
        } catch (Exception e) {
            e.printStackTrace();
            return "fail";
        }
    }

    /**
     * 删除 专场招聘会预约信息
     *
     * @param id
     * @return
     */
    @Override
    public String deleteById(String id) {
        try {
            recCareerEventRepository.delete(id);
            return "ok";
        } catch (Exception e) {
            e.printStackTrace();
            return "fail";
        }
    }
}
