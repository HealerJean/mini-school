<template>
    <div class="breadcrumb">
        <span>我的位置：</span>
        <el-breadcrumb separator=">">
            <el-breadcrumb-item v-for="item in breadcrumbs" :to="item.router">{{ item.text }}</el-breadcrumb-item>
        </el-breadcrumb>
    </div>

</template>
<script type="text/babel">
    export default{
        name:'bread-crumb',
        data(){
            return{
               
            }
        },
        props: {
            breadcrumbs: {
                type: Array,
                default() {
                    return []
                }
            }
        }
    }

</script>
<style lang="less" scoped>
    @import "../../less/shared/variables.less";

    .breadcrumb{
        color:extract(@gray-group,4);
        font-size:@size-md;
        margin-bottom:20px;
        line-height:1;
        &>span{
            float: left;
        }
    }
    .el-breadcrumb{
        font-size:@size-md;
    }

</style>
