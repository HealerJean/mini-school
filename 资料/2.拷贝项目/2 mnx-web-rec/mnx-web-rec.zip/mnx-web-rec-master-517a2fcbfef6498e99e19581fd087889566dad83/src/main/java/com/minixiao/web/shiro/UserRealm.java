package com.minixiao.web.shiro;

import com.minixiao.apiauth.client.HeaderUtil;
import com.minixiao.web.dto.recruiters.RecruiterInfo;
import com.minixiao.web.dto.recruiters.UserDTO;
import com.minixiao.web.utils.MD5Util;
import com.minixiao.web.utils.YmlConfig;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.*;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.HashSet;
import java.util.Set;

/**
 * 验证用户登录
 *
 * @author Administrator
 */
@Component("userRealm")
public class UserRealm extends AuthorizingRealm {

    @Autowired
    private YmlConfig ymlConfig;

    RestTemplate restTemplate = new RestTemplate();

    static  final String CURRENT_USER = "MNX_CURRENT_USER";

    public UserRealm() {
        setName("MnxUserRealm");
        // 采用MD5加密
        //setCredentialsMatcher(new HashedCredentialsMatcher("md5"));
    }

    //权限资源角色
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principals) {
        String userName = (String) principals.getPrimaryPrincipal();
        if (userName == null || "".equals(userName)) {
            throw new AccountException("获取用户认证时，用户名为空。");
        }
        //根据登录名查找用户信息
        String url = ymlConfig.getUrl_api_recruiter() + "recruiters/users/email?email="+ userName +"";
        HttpHeaders requestHeaders = HeaderUtil.getHeader(null, null, "COMPANY", null,
            null);
        HttpEntity<String> request = new HttpEntity<String>(null, requestHeaders);
        ResponseEntity<UserDTO> rEntity = restTemplate.exchange(url, HttpMethod.GET,
            request, UserDTO.class);
        UserDTO user = rEntity.getBody();
        if (user != null) {
            SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();
            Set<String> set = new HashSet<String>();
            if (user.isAdmin()) {
                set.add("admin");
            }
            info.setRoles(set);//添加管理员角色
            //根据用户查找该公司信息是否填写完整
            url = ymlConfig.getUrl_api_recruiter() + "recruiters/"+ user.getRecId() +"";
            ResponseEntity<RecruiterInfo> entity = restTemplate.exchange(url, HttpMethod.GET,
                request, RecruiterInfo.class);
            RecruiterInfo companyInfo = entity.getBody();
            if (companyInfo != null && isComplete(companyInfo)) {
                Set<String> perSet = new HashSet<String>();
                perSet.add("corpInfoComplete");
                info.setStringPermissions(perSet);//添加公司信息完整权限
            }
            return info;
        } else {
            throw new UnknownAccountException("用户名不存在： [" + userName + "]");
        }
    }

    //公司必填项是否填写完整
    private boolean isComplete(RecruiterInfo companyInfo) {
        if (companyInfo.getFullName() == null) {
            return false;
        }
        if (companyInfo.getShortName() == null) {
            return false;
        }
        if (companyInfo.getPrimaryIndustry() == null) {
            return false;
        }
        if (companyInfo.getSlaveIndustry() == null) {
            return false;
        }
        if (companyInfo.getNature() == null) {
            return false;
        }
        if (companyInfo.getCity() == null) {
            return false;
        }
        if (companyInfo.getDetailAddress() == null) {
            return false;
        }
        if (companyInfo.getSize() == null) {
            return false;
        }
        return true;
    }

    //登录验证
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) throws AuthenticationException {
        UsernamePasswordToken upt = (UsernamePasswordToken) token;
        String userName = upt.getUsername();
        if (userName == null || "".equals(userName)) {
            throw new AccountException("获取用户认证时，用户名为空。");
        }
        //根据登录名查找用户信息
        String url = ymlConfig.getUrl_api_recruiter() + "recruiters/users/email?email="+ userName +"";
        HttpHeaders requestHeaders = HeaderUtil.getHeader(null, null, "COMPANY", null,
            null);
        HttpEntity<String> request = new HttpEntity<String>(null, requestHeaders);
        ResponseEntity<UserDTO> rEntity = restTemplate.exchange(url, HttpMethod.GET,
            request, UserDTO.class);
        UserDTO user = rEntity.getBody();
        if (user != null) {
            if (MD5Util.compare(new String(upt.getPassword()), user.getPwd())) {//为符合系统旧数据，仍然使用之前的自定义随机盐MD5加密
                upt.setPassword(user.getPwd().toCharArray());
                upt.setUsername(user.getEmail());
                SecurityUtils.getSubject().getSession().setAttribute(ymlConfig.getSession_current_user(), user);
            }
            SimpleAuthenticationInfo authenticationInfo = new SimpleAuthenticationInfo(user.getEmail(), user.getPwd(), getName());
            return authenticationInfo;
        } else {
            throw new UnknownAccountException("用户名不存在： [" + userName + "]");
        }
    }
}
